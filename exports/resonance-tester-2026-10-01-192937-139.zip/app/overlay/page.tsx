'use client';
import { useEffect, useRef, useState } from 'react';
import {
  Overlay,
  estimatedProgress,
  type Config,
  type Track,
} from '@/lib/overlay';
import { fontFormatHint } from '@/lib/fonts';
type CustomFontMeta = { id: string; family: string; format: string };
export default function OBS() {
  const [config, setConfig] = useState<Config | null>(null),
    [track, setTrack] = useState<Track | null>(null),
    [notice, setNotice] = useState(''),
    [customFonts, setCustomFonts] = useState<CustomFontMeta[]>([]);
  const lastTrackId = useRef('');
  const slot = useRef(0);
  const fontsKey = useRef('');
  // Custom Fonts: @font-face-Regeln injizieren, sobald sich die Liste ändert.
  useEffect(() => {
    if (customFonts.length === 0) return;
    const style = document.createElement('style');
    style.textContent = customFonts
      .map(
        (f) => `
  @font-face {
    font-family: '${f.family}';
    src: url('/api/fonts/${f.id}/file') format('${fontFormatHint(f.format)}');
    font-display: swap;
  }
`,
      )
      .join('\n');
    document.head.appendChild(style);
    return () => {
      style.remove();
    };
  }, [customFonts]);
  useEffect(() => {
    document.body.classList.add('obs-page', 'allow-motion');
    document.documentElement.style.background = 'transparent';
    const key = location.hash.slice(1);
    if (!key) {
      setNotice(
        'Öffne das Overlay mit dem vollständigen Link aus deinem Studio.',
      );
      return;
    }
    let stopped = false;
    let timeout: ReturnType<typeof setTimeout>;
    let lastGood = 0;
    async function poll() {
      let wait = 5000;
      try {
        const r = await fetch('/api/now', {
          headers: { Authorization: 'Bearer ' + key },
          cache: 'no-store',
        });
        const d = (await r.json()) as {
          error?: string;
          config: Config;
          track: Track | null;
          message?: string;
          retryAfter?: number;
          customFonts?: CustomFontMeta[];
        };
        if (stopped) return;
        if (!r.ok) {
          if (r.status === 401) {
            setNotice(
              'Dieser Overlay-Link ist ungültig. Kopiere den aktuellen Link aus dem Studio.',
            );
            setTrack(null);
            return;
          }
          throw new Error(d.error);
        }
        setConfig(d.config);
        const nextFontsKey = JSON.stringify(d.customFonts || []);
        if (nextFontsKey !== fontsKey.current) {
          fontsKey.current = nextFontsKey;
          setCustomFonts(d.customFonts || []);
        }
        if (d.track) {
          const id = d.track.id || d.track.title + '|' + d.track.artist;
          if (id !== lastTrackId.current) {
            lastTrackId.current = id;
            slot.current += 1;
          }
          setTrack({
            ...d.track,
            slot: slot.current,
            fetchedAt: Date.now(),
          });
        } else if (!d.message) setTrack(null);
        lastGood = Date.now();
        setNotice('');
        wait = Math.max(5000, (d.retryAfter || 0) * 1000);
      } catch {
        if (!stopped && Date.now() - lastGood > 15000) setTrack(null);
        wait = 10000;
      }
      if (!stopped) timeout = setTimeout(poll, wait);
    }
    poll();
    const tick = setInterval(
      () =>
        setTrack((t) =>
          t?.playing
            ? {
                ...t,
                progress: estimatedProgress(t),
                fetchedAt: Date.now(),
              }
            : t,
        ),
      1000,
    );
    return () => {
      stopped = true;
      clearTimeout(timeout);
      clearInterval(tick);
      document.body.classList.remove('obs-page', 'allow-motion');
      document.documentElement.style.background = '';
    };
  }, []);
  return (
    <>
      {notice && <div className="obs-notice">{notice}</div>}
      <div className="obs-canvas">
        {config && <Overlay config={config} track={track} />}
      </div>
    </>
  );
}
