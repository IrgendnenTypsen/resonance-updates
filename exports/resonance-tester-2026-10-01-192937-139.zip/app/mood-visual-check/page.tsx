'use client';
import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { MemorySlot, defaults } from '@/lib/overlay';
import './qa.css';

const MOODS = [
  'happy',
  'sad',
  'dark',
  'angry',
  'calm',
  'energy',
  'romantic',
  'lonely',
  'hopeful',
  'nostalgic',
] as const;

const ACCENTS: Record<string, string> = {
  happy: '#ffda78',
  sad: '#accde9',
  dark: '#a9b6fa',
  angry: '#ff9b83',
  calm: '#a5deca',
  energy: '#d3ee87',
  romantic: '#f5b9cd',
  lonely: '#bad0e8',
  hopeful: '#e6ecad',
  nostalgic: '#f0cf8d',
};

const COVER =
  'data:image/svg+xml,' +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><defs><linearGradient id="a" x2="1" y2="1"><stop stop-color="#e9b67b"/><stop offset=".5" stop-color="#7d5e99"/><stop offset="1" stop-color="#1c4669"/></linearGradient></defs><rect width="200" height="200" fill="url(#a)"/><circle cx="100" cy="100" r="60" fill="none" stroke="#fce6bd" stroke-width="2"/><circle cx="100" cy="100" r="40" fill="none" stroke="#fce6bd" stroke-width="2"/><text x="100" y="174" fill="white" font-size="15" text-anchor="middle">RESONANCE</text></svg>',
  );

const DURATION = 224000;

type ExportInfo = { file: string; createdAt: string; size: number; entries: number };

function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export default function Check() {
  const [state, setState] = useState<'playing' | 'paused' | 'idle'>('playing');
  const [mood, setMood] = useState<string>('energy');
  const [width, setWidth] = useState(760);
  const [intensity, setIntensity] = useState(100);
  const [motion, setMotion] = useState(true);
  const [enabled, setEnabled] = useState(true);
  const [progress, setProgress] = useState(87000);
  const [reduced, setReduced] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [exportInfo, setExportInfo] = useState<ExportInfo | null>(null);
  const [exportState, setExportState] = useState<'loading' | 'ready' | 'missing'>('loading');
  const previewRef = useRef<HTMLDivElement>(null);

  // Tester-ZIP-Export: latest.json aus public/exports/ abfragen
  useEffect(() => {
    let cancelled = false;
    fetch('/exports/latest.json', { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        const info = data as ExportInfo | null;
        if (cancelled) return;
        if (info && typeof info.file === 'string' && info.file.endsWith('.zip')) {
          setExportInfo(info);
          setExportState('ready');
        } else {
          setExportState('missing');
        }
      })
      .catch(() => {
        if (!cancelled) setExportState('missing');
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // OS-Reduced-Motion-Status anzeigen (nur Info, QA-Toggle erzwingt trotzdem)
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReduced(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);

  // Lokale Demo-Progress-Simulation
  useEffect(() => {
    if (state !== 'playing') return;
    const t = setInterval(() => setProgress((p) => (p + 1000) % DURATION), 1000);
    return () => clearInterval(t);
  }, [state]);

  // Preview an Container-Breite anpassen
  useEffect(() => {
    const el = previewRef.current;
    if (!el) return;
    const ob = new ResizeObserver((entries) => {
      const w = entries[0].contentRect.width;
      setZoom(Math.min(1, (w - 24) / width));
    });
    ob.observe(el);
    return () => ob.disconnect();
  }, [width]);

  const track =
    state === 'idle'
      ? null
      : {
          id: 'qa-track',
          title: 'Midnight in Motion (Extended Mix)',
          artist: 'Resonance Radio feat. The Night Owls',
          cover: COVER,
          duration: DURATION,
          progress,
          playing: state === 'playing',
          slot: 7,
          favorite: true,
          inObservedPlaylist: true,
          lyricMoodScores: { [mood]: 100 },
        };

  const baseStyle = {
    '--oa': '#b66cff',
    '--ot': '#f7f5f2',
    '--or': '20px',
    '--op': '18px',
    '--ofs': '25px',
    width,
    fontFamily: 'Arial, sans-serif',
  } as CSSProperties;

  const thumbStyle = {
    '--oa': '#b66cff',
    '--ot': '#f7f5f2',
    '--or': '20px',
    '--op': '18px',
    '--ofs': '25px',
    width: 300,
    fontFamily: 'Arial, sans-serif',
  } as CSSProperties;

  const thumbTrack = {
    id: 'qa-thumb',
    title: 'Midnight in Motion (Extended Mix)',
    artist: 'Resonance Radio feat. The Night Owls',
    cover: COVER,
    duration: DURATION,
    progress: 87000,
    playing: true,
    slot: 7,
    favorite: true,
    inObservedPlaylist: true,
    lyricMoodScores: { happy: 100 },
  };

  return (
    <main className={'qa-page allow-motion' + (motion ? ' qa-motion-on' : '')}>
      <div className="qa-shell">
        <header className="qa-header">
          <div className="qa-header-left">
            <button
              type="button"
              className="qa-back"
              aria-label="Zurück zum Studio"
              onClick={() => {
                window.location.href = '/';
              }}
            >
              ← Studio
            </button>
            <div className="qa-title">
              <span className="qa-kicker">QA LAB</span>
              <h1>Mood Visual System</h1>
            </div>
          </div>
          <span className={'qa-badge' + (reduced ? ' is-reduced' : '')}>
            {reduced ? 'OS reduced-motion: AN' : 'OS reduced-motion: aus'}
          </span>
        </header>

        <section className="qa-export">
          <div className="qa-export-info">
            <span className="qa-kicker">DEVELOPER</span>
            <h2>Export Tester ZIP</h2>
            <p>Create a clean ZIP of the current Resonance build without local user data.</p>
          </div>
          <div className="qa-export-actions">
            {exportState === 'ready' && exportInfo ? (
              <>
                <a
                  className="qa-export-btn"
                  href={'/exports/' + encodeURIComponent(exportInfo.file)}
                  download
                >
                  Export Tester ZIP
                </a>
                <span className="qa-export-meta">
                  {exportInfo.file} · {formatBytes(exportInfo.size)}
                </span>
              </>
            ) : exportState === 'loading' ? (
              <span className="qa-export-btn is-disabled">Prüfe Export …</span>
            ) : (
              <span
                className="qa-export-btn is-disabled"
                title="Führe einmal `npm run export:tester` im Projektordner aus."
              >
                Export Tester ZIP
              </span>
            )}
          </div>
          {exportState === 'missing' && (
            <p className="qa-note warn qa-export-note">
              Noch kein Export vorhanden. Führe einmal <code>npm run export:tester</code> im
              Projektordner aus – danach erscheint hier der Download.
            </p>
          )}
        </section>

        <section className="qa-card">
          <div className="qa-field">
            <span className="qa-label">Mood</span>
            <div className="qa-moods">
              {MOODS.map((m) => (
                <button
                  key={m}
                  className={'qa-mood-btn' + (mood === m ? ' active' : '')}
                  onClick={() => setMood(m)}
                >
                  <i style={{ background: ACCENTS[m] }} />
                  {m}
                </button>
              ))}
            </div>
          </div>

          <div className="qa-grid">
            <div className="qa-field">
              <span className="qa-label">State</span>
              <div className="qa-seg">
                {(['playing', 'paused', 'idle'] as const).map((s) => (
                  <button
                    key={s}
                    className={'qa-seg-btn' + (state === s ? ' active' : '')}
                    onClick={() => setState(s)}
                  >
                    {s.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            <div className="qa-field">
              <span className="qa-label">
                Width <b>{width}px</b>
              </span>
              <input
                type="range"
                className="qa-slider"
                min={280}
                max={900}
                step={20}
                value={width}
                onChange={(e) => setWidth(Number(e.target.value))}
              />
              <small className="qa-ref-note">
                Reference Width: 760px
                {width !== 760 && ` · aktuell ${width}px`}
              </small>
            </div>

            <div className="qa-field">
              <span className="qa-label">
                Intensity <b>{intensity}%</b>
              </span>
              <input
                type="range"
                className="qa-slider"
                min={0}
                max={100}
                step={5}
                value={intensity}
                onChange={(e) => setIntensity(Number(e.target.value))}
              />
            </div>

            <div className="qa-field">
              <span className="qa-label">Motion</span>
              <button
                className={'qa-toggle' + (motion ? ' on' : '')}
                onClick={() => setMotion((v) => !v)}
              >
                {motion ? 'ON' : 'OFF'}
              </button>
            </div>

            <div className="qa-field">
              <span className="qa-label">Mood Switch</span>
              <button
                className={'qa-toggle' + (enabled ? ' on' : '')}
                onClick={() => setEnabled((v) => !v)}
              >
                {enabled ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>

          {reduced && (
            <p className="qa-note warn">
              Dein Betriebssystem hat „reduzierte Bewegung“ aktiv. Der QA-Motion-Toggle erzwingt die
              Mood-Animationen trotzdem für diesen Test. In Produktion (OBS/Preview) bleiben sie
              deaktiviert.
            </p>
          )}
        </section>

        <section className="qa-preview" ref={previewRef}>
          <div className="qa-preview-wrap" style={{ zoom }}>
            <MemorySlot
              mood={mood}
              style={baseStyle}
              config={{
                ...defaults,
                layout: 'memory',
                background: '#ece8df',
                accent: '#b66cff',
                text: '#f7f5f2',
                width,
                fontSize: 25,
                spacing: 18,
                opacity: 100,
                moodSwitch: enabled,
                moodIntensity: intensity,
                animation: motion ? 'slide' : 'none',
              }}
              track={track}
            />
          </div>
        </section>

        <section className="qa-thumbs">
          <h2>Alle Moods</h2>
          <div className="qa-thumb-grid">
            {MOODS.map((m) => (
              <button
                type="button"
                key={m}
                className={'qa-thumb' + (mood === m ? ' active' : '')}
                onClick={() => setMood(m)}
              >
                <div className="qa-thumb-inner" style={{ zoom: 0.55 }}>
                  <MemorySlot
                    mood={m}
                    style={thumbStyle}
                    config={{
                      ...defaults,
                      layout: 'memory',
                      background: '#ece8df',
                      accent: '#b66cff',
                      text: '#f7f5f2',
                      width: 300,
                      fontSize: 25,
                      spacing: 18,
                      opacity: 100,
                      moodSwitch: true,
                      moodIntensity: 100,
                      animation: 'none',
                    }}
                    track={thumbTrack}
                  />
                </div>
                <span>{m}</span>
              </button>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
