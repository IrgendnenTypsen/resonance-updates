'use client';
import {
  useEffect,
  useState,
  useRef,
  type CSSProperties,
  type ReactNode,
} from 'react';
import {
  AudioLines,
  ArrowUpRight,
  SlidersHorizontal,
  Radio,
  Check,
  Music2,
  Monitor,
  Sparkles,
  Copy,
  Save,
  RotateCcw,
  Pause,
  Play,
  ExternalLink,
  Lock,
  Unplug,
  RefreshCw,
  Info,
  MousePointer2,
  ChevronLeft,
  Image as ImageIcon,
  Gauge,
  Gamepad2,
  Tag,
  Box,
  Lightbulb,
  Type,
  Plus,
  Trash2,
} from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import {
  Overlay,
  defaults,
  demo,
  FONT_LIBRARY,
  estimatedProgress,
  type Config,
  type Track,
} from '@/lib/overlay';
import { presets } from '@/lib/presets';
import { detectMood, moodDemos } from '@/lib/mood';
import { fontFormatHint } from '@/lib/fonts';
async function api(path: string, body?: unknown) {
  const r = await fetch(path, {
    method: body ? 'POST' : 'GET',
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const d = (await r.json()) as {
    error?: string;
    config: Config;
    connected: boolean;
    overlayKey: string;
    redirect: string;
    url: string;
    track: Track | null;
    message?: string;
    retryAfter?: number;
    pinned_at?: number | null;
    look?: CustomLook;
  };
  if (!r.ok) throw new Error(d.error || 'Verbindung fehlgeschlagen.');
  return d;
}
type PlaylistItem = {
  id: string;
  name: string;
  image?: string;
  owner?: { id?: string };
  collaborative?: boolean;
};
type CustomFontMeta = {
  id: string;
  name: string;
  format: string;
  family: string;
  size: number;
  createdAt: number;
};
type CustomLook = {
  id: string;
  name: string;
  config: Config;
  created_at: number;
  pinned: number;
  pinned_at: number | null;
};
type ResonanceLookFile = {
  format: 'resonance-look';
  version: 1;
  name: string;
  config: unknown;
};
function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function configSnapshotKey(config: Config): string {
  return JSON.stringify(
    Object.fromEntries(
      Object.keys(config)
        .sort()
        .map((key) => [key, config[key as keyof Config]]),
    ),
  );
}
function Picker({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: [string, string][];
  onChange: (v: string) => void;
}) {
  return (
    <label className="picker">
      <span>{label}</span>
      <Select value={value} onValueChange={(v) => v && onChange(v)}>
        <SelectTrigger aria-label={label}>
          <SelectValue>{options.find((o) => o[0] === value)?.[1]}</SelectValue>
        </SelectTrigger>
        <SelectContent>
          {options.map(([v, l]) => (
            <SelectItem key={v} value={v}>
              {l}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </label>
  );
}
const LED_BEHAVIOR_LABELS: Record<string, string> = {
  solid: 'Solid',
  soft: 'Soft Pulse',
  breathe: 'Breathe',
  double: 'Double Pulse',
  heartbeat: 'Heartbeat',
  flicker: 'Flicker',
  off: 'Off',
};
const EDITOR_NAMES: Record<string, string> = {
  device: 'Gerät',
  cover: 'Albumcover',
  display: 'Display',
  led: 'LED',
  controls: 'Bedienelemente',
  progress: 'Wiedergabe',
  note: 'Notiz',
  title: 'Songtitel',
  artist: 'Interpret',
  'display-meta': 'Statuszeile',
};
const EDITOR_TARGETS: Array<[string, string]> = [
  ['led', '.memory-led'],
  ['title', '.track-title'],
  ['artist', '.track-artist'],
  ['display-meta', '.memory-status'],
  ['progress', '.track-progress'],
  ['controls', '.memory-controls'],
  ['display', '.memory-screen'],
  ['cover', '.memory-cover-slot'],
  ['note', '.memory-note'],
  ['device', '.layout-memory'],
];
export default function Studio() {
  const [config, setConfig] = useState<Config>(defaults),
    [historyPast, setHistoryPast] = useState<Config[]>([]),
    [historyFuture, setHistoryFuture] = useState<Config[]>([]),
    [saved, setSaved] = useState(''),
    [connected, setConnected] = useState(false),
    [ready, setReady] = useState(false),
    [key, setKey] = useState(''),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState(''),
    [error, setError] = useState(''),
    [modal, setModal] = useState<'spotify' | 'obs' | null>(null),
    [track, setTrack] = useState<Track | null>(null),
    [demoMode, setDemoMode] = useState(true),
    [demoPlaying, setDemoPlaying] = useState(true),
    [canvas, setCanvas] = useState('ambient'),
    [canvasWidth, setCanvasWidth] = useState(600),
    [selectedElement, setSelectedElement] = useState<string | null>(null),
    [markerRect, setMarkerRect] = useState<{
      top: number;
      left: number;
      width: number;
      height: number;
    } | null>(null),
    [tick, setTick] = useState(0),
    [origin, setOrigin] = useState(''),
    [spotifyRedirect, setSpotifyRedirect] = useState(''),
    [playlists, setPlaylists] = useState<PlaylistItem[]>([]),
    [currentUserId, setCurrentUserId] = useState(''),
    [demoIndex, setDemoIndex] = useState(0),
    [moodSettingsOpen, setMoodSettingsOpen] = useState(false),
    [moodSetupDismissed, setMoodSetupDismissed] = useState(false),
    [lastfmConfigured, setLastfmConfigured] = useState(false),
    [geniusConfigured, setGeniusConfigured] = useState(false),
    [lastfmKey, setLastfmKey] = useState(''),
    [geniusToken, setGeniusToken] = useState(''),
    [moodBusy, setMoodBusy] = useState(false),
    [lastfmTest, setLastfmTest] = useState<
      '' | 'testing' | 'connected' | 'invalid' | 'unavailable'
    >(''),
    [geniusTest, setGeniusTest] = useState<
      '' | 'testing' | 'connected' | 'invalid' | 'unavailable'
    >('');
  const [customFonts, setCustomFonts] = useState<CustomFontMeta[]>([]);
  const [customLooks, setCustomLooks] = useState<CustomLook[]>([]);
  const [lookName, setLookName] = useState('');
  const lookImportRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [pendingUploadTarget, setPendingUploadTarget] = useState<
    'title' | 'artist' | 'meta' | null
  >(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{
    id: string;
    name: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sliderStart = useRef<Config | null>(null);
  const preview = useRef<HTMLDivElement>(null);
  const inspector = useRef<HTMLElement>(null);
  const liveTrackId = useRef('');
  const liveSlot = useRef(0);
  const configRef = useRef(config);
  const savedRef = useRef(saved);
  const persistRevision = useRef(0);
  const persisting = useRef(false);
  configRef.current = config;
  savedRef.current = saved;
  const dirty = saved !== JSON.stringify(config);
  const savedConfig = (() => {
    try {
      const parsed: unknown = JSON.parse(saved);
      return isRecord(parsed) ? (parsed as Config) : null;
    } catch {
      return null;
    }
  })();
  const activeLiveLookId = savedConfig
    ? customLooks.find(
        (look) =>
          !!look.pinned &&
          configSnapshotKey(look.config) === configSnapshotKey(savedConfig),
      )?.id
    : undefined;
  const liveLooks = customLooks
    .filter((look) => !!look.pinned)
    .sort(
      (a, b) =>
        (a.pinned_at ?? Number.MAX_SAFE_INTEGER) -
          (b.pinned_at ?? Number.MAX_SAFE_INTEGER) || a.id.localeCompare(b.id),
    );
  const chosen = presets.find((p) => p.id === config.layout);
  const demoTrack = {
    ...demo,
    ...moodDemos[demoIndex],
    slot: demoIndex + 1,
    playing: demoPlaying,
    progress: demoPlaying
      ? (demo.progress + tick * 1000) % demo.duration
      : demo.progress,
  };
  const shown = demoMode
    ? demoTrack
    : track
      ? { ...track, progress: estimatedProgress(track) }
      : null;
  const detected = detectMood(shown, shown?.lastfmTags);
  const obsUrl = origin + '/overlay#' + key;
  useEffect(() => {
    setOrigin(location.origin);
    if (new URLSearchParams(location.search).has('connect'))
      setModal('spotify');
    let alive = true;
    api('/api/studio')
      .then((d) => {
        if (!alive) return;
        configRef.current = d.config;
        setConfig(d.config);
        setHistoryPast([]);
        setHistoryFuture([]);
        const initialSaved = JSON.stringify(d.config);
        savedRef.current = initialSaved;
        setSaved(initialSaved);
        setConnected(d.connected);
        setDemoMode(!d.connected);
        setKey(d.overlayKey);
        setSpotifyRedirect(d.redirect);
        setReady(true);
      })
      .catch((e) => {
        if (alive) setError(e.message);
      });
    fetch('/api/mood/settings')
      .then(async (r) => {
        if (!alive || !r.ok) return;
        const d = (await r.json()) as {
          lastfmConfigured?: boolean;
          geniusConfigured?: boolean;
        };
        setLastfmConfigured(!!d.lastfmConfigured);
        setGeniusConfigured(!!d.geniusConfigured);
      })
      .catch(() => {});
    fetch('/api/looks')
      .then((r) => (r.ok ? r.json() : { looks: [] }))
      .then((d) => alive && setCustomLooks(d.looks || []))
      .catch(() => {});
    const status = new URLSearchParams(location.search).get('spotify');
    if (status) {
      setMessage(
        status === 'connected'
          ? 'Spotify ist verbunden. Starte einen Titel in Spotify.'
          : status === 'cancelled'
            ? 'Spotify-Anmeldung abgebrochen.'
            : status === 'expired'
              ? 'Anmeldung abgelaufen. Bitte erneut verbinden.'
              : status === 'token'
                ? 'Spotify hat die Anmeldung abgelehnt. Prüfe im Spotify Developer Dashboard die Redirect-URI: http://127.0.0.1:3000/api/spotify/callback'
                : 'Spotify-Anmeldung fehlgeschlagen. Prüfe die Redirect-URI und versuche es erneut.',
      );
      history.replaceState(null, '', '/');
    }
    return () => {
      alive = false;
    };
  }, []);
  useEffect(() => {
    if (!ready) return;
    let stopped = false;
    let inFlight = false;
    let requestSequence = 0;
    let timer: ReturnType<typeof setInterval> | undefined;

    async function syncLiveConfig(force = false) {
      if (
        stopped ||
        (inFlight && !force) ||
        persisting.current ||
        document.visibilityState !== 'visible'
      )
        return;
      inFlight = true;
      const requestId = ++requestSequence;
      const requestRevision = persistRevision.current;
      try {
        const d = await api('/api/studio');
        if (
          stopped ||
          requestId !== requestSequence ||
          persisting.current ||
          document.visibilityState !== 'visible' ||
          requestRevision !== persistRevision.current
        )
          return;

        const serverConfig = d.config;
        let persistedConfig: Config | null = null;
        try {
          const parsed: unknown = JSON.parse(savedRef.current);
          if (isRecord(parsed)) persistedConfig = parsed as Config;
        } catch {}
        if (
          persistedConfig &&
          configSnapshotKey(serverConfig) === configSnapshotKey(persistedConfig)
        )
          return;

        const localConfig = configRef.current;
        const editorWasClean =
          !!persistedConfig &&
          configSnapshotKey(localConfig) === configSnapshotKey(persistedConfig);
        const nextSaved = JSON.stringify(serverConfig);
        savedRef.current = nextSaved;
        setSaved(nextSaved);

        if (editorWasClean) {
          configRef.current = serverConfig;
          setConfig(serverConfig);
          setHistoryPast([]);
          setHistoryFuture([]);
          sliderStart.current = null;
        } else {
          setMessage(
            'Live-Konfiguration wurde extern geändert. Deine lokalen Änderungen wurden nicht überschrieben.',
          );
        }
      } catch {
        // Hintergrund-Sync bleibt bei temporären Fehlern absichtlich still.
      } finally {
        if (requestId === requestSequence) inFlight = false;
      }
    }

    function stopPolling() {
      if (timer) clearInterval(timer);
      timer = undefined;
    }
    function startPolling() {
      stopPolling();
      if (document.visibilityState !== 'visible') return;
      void syncLiveConfig(true);
      timer = setInterval(() => void syncLiveConfig(), 1000);
    }
    function handleVisibilityChange() {
      startPolling();
    }

    document.addEventListener('visibilitychange', handleVisibilityChange);
    startPolling();
    return () => {
      stopped = true;
      stopPolling();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [ready]);
  // Custom Fonts: Liste laden und @font-face-Regeln injizieren.
  useEffect(() => {
    let alive = true;
    fetch('/api/fonts')
      .then(async (r) => {
        const d = (await r.json()) as { fonts?: CustomFontMeta[] };
        if (!alive || !r.ok) return;
        setCustomFonts(d.fonts || []);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, []);
  useEffect(() => {
    if (customFonts.length === 0) return;
    const style = document.createElement('style');
    style.textContent = customFonts
      .map(
        (f) => `
  @font-face {
    font-family: '${f.family}';
    src: url('/api/fonts/${f.id}/file') format('${fontFormatHint(f.format)}');
    font-display: swap;
  }
`,
      )
      .join('\n');
    document.head.appendChild(style);
    return () => {
      style.remove();
    };
  }, [customFonts]);
  useEffect(() => {
    const timer = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    if (!preview.current) return;
    const ob = new ResizeObserver((entries) =>
      setCanvasWidth(entries[0].contentRect.width),
    );
    ob.observe(preview.current);
    return () => ob.disconnect();
  }, []);
  // Editor-Selection: Escape → Deselect (nur wenn kein Base-UI-Popup offen ist)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        // Offene Base-UI-Popups (Select/Popover/Dropdown/Dialog) schließt
        // Base UI selbst per Escape – hier kein Deselect auslösen.
        const openPopup = document.querySelector(
          '[data-base-ui-portal] [data-open]',
        );
        if (!openPopup) setSelectedElement(null);
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);
  useEffect(() => {
    inspector.current?.scrollTo({ top: 0, behavior: 'smooth' });
  }, [selectedElement]);
  // Editor-Selection: Marker-Position des gewählten Elements verfolgen
  useEffect(() => {
    if (!selectedElement) {
      const frame = requestAnimationFrame(() =>
        setMarkerRect((current) => (current === null ? current : null)),
      );
      return () => cancelAnimationFrame(frame);
    }
    const canvas = preview.current;
    const sel = EDITOR_TARGETS.find(([n]) => n === selectedElement)?.[1];
    if (!canvas || !sel) return;
    const update = () => {
      const el = canvas.querySelector(sel);
      if (!el) {
        setMarkerRect((current) => (current === null ? current : null));
        return;
      }
      const cr = canvas.getBoundingClientRect();
      const er = el.getBoundingClientRect();
      const next = {
        top: er.top - cr.top,
        left: er.left - cr.left,
        width: er.width,
        height: er.height,
      };
      setMarkerRect((current) => {
        if (
          current &&
          Math.abs(current.top - next.top) < 0.25 &&
          Math.abs(current.left - next.left) < 0.25 &&
          Math.abs(current.width - next.width) < 0.25 &&
          Math.abs(current.height - next.height) < 0.25
        )
          return current;
        return next;
      });
    };
    const frame = requestAnimationFrame(update);
    const ro = new ResizeObserver(update);
    ro.observe(canvas);
    const el = canvas.querySelector(sel);
    if (el) ro.observe(el);
    return () => {
      cancelAnimationFrame(frame);
      ro.disconnect();
    };
  }, [
    selectedElement,
    config,
    shown?.id,
    shown?.title,
    shown?.artist,
    shown?.playing,
  ]);
  useEffect(() => {
    if (!connected || demoMode) return;
    let stopped = false;
    let timeout: ReturnType<typeof setTimeout>;
    async function poll() {
      let wait = 5000;
      try {
        const d = await api('/api/now');
        if (stopped) return;
        if (d.track) {
          const id = d.track.id || d.track.title + '|' + d.track.artist;
          if (id !== liveTrackId.current) {
            liveTrackId.current = id;
            liveSlot.current += 1;
          }
          setTrack({
            ...d.track,
            slot: liveSlot.current,
            fetchedAt: Date.now(),
          });
        } else if (!d.message) setTrack(null);
        setError(d.message || '');
        if (!d.connected) {
          setConnected(false);
          setError('Spotify-Verbindung abgelaufen. Bitte erneut verbinden.');
        }
        wait = Math.max(5000, (d.retryAfter || 0) * 1000);
      } catch (e) {
        if (stopped) return;
        setError((e as Error).message);
        wait = 10000;
      }
      if (!stopped) timeout = setTimeout(poll, wait);
    }
    poll();
    return () => {
      stopped = true;
      clearTimeout(timeout);
    };
  }, [connected, demoMode]);
  useEffect(() => {
    if (!connected) return;
    let alive = true;
    fetch('/api/spotify/playlists')
      .then(async (r) => {
        const d = await r.json();
        if (!alive) return;
        if (!r.ok)
          throw new Error(d.error || 'Playlists konnten nicht geladen werden.');
        setCurrentUserId(d.currentUserId || '');
        setPlaylists(d.playlists || []);
      })
      .catch((e) => {
        if (alive) setError((e as Error).message);
      });
    return () => {
      alive = false;
    };
  }, [connected]);
  const commitConfig = (next: Config) =>
    setConfig((current) => {
      if (JSON.stringify(current) === JSON.stringify(next)) return current;
      setHistoryPast((past) => [...past, current].slice(-50));
      setHistoryFuture([]);
      return next;
    });
  const update = <K extends keyof Config>(k: K, v: Config[K]) =>
    setConfig((current) => {
      const next = { ...current, [k]: v };
      if (JSON.stringify(current) !== JSON.stringify(next)) {
        setHistoryPast((past) => [...past, current].slice(-50));
        setHistoryFuture([]);
      }
      return next;
    });
  const beginSlider = () => {
    if (!sliderStart.current) sliderStart.current = config;
  };
  const updateSlider = <K extends keyof Config>(k: K, v: Config[K]) => {
    beginSlider();
    setConfig((current) => ({ ...current, [k]: v }));
  };
  const commitSlider = () => {
    const start = sliderStart.current;
    sliderStart.current = null;
    if (!start || JSON.stringify(start) === JSON.stringify(config)) return;
    setHistoryPast((past) => [...past, start].slice(-50));
    setHistoryFuture([]);
  };
  const undo = () => {
    const previous = historyPast.at(-1);
    if (!previous) return;
    setHistoryPast((past) => past.slice(0, -1));
    setHistoryFuture((future) => [config, ...future].slice(0, 50));
    setConfig(previous);
  };
  const redo = () => {
    const next = historyFuture[0];
    if (!next) return;
    setHistoryFuture((future) => future.slice(1));
    setHistoryPast((past) => [...past, config].slice(-50));
    setConfig(next);
  };
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (
        target?.matches('input,textarea,[contenteditable="true"]') ||
        !event.ctrlKey
      )
        return;
      if (event.key.toLowerCase() === 'z') {
        event.preventDefault();
        event.shiftKey ? redo() : undo();
      } else if (event.key.toLowerCase() === 'y') {
        event.preventDefault();
        redo();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [historyPast, historyFuture, config]);
  const canObserve = (p: PlaylistItem) =>
    p.collaborative === true || p.owner?.id === currentUserId;
  const selectedObserved = playlists.find(
    (p) => p.id === config.observedPlaylistId,
  );
  async function save() {
    setBusy(true);
    setError('');
    persisting.current = true;
    persistRevision.current += 1;
    try {
      await api('/api/studio', { config });
      const nextSaved = JSON.stringify(config);
      savedRef.current = nextSaved;
      setSaved(nextSaved);
      setMessage(
        'Design gespeichert. Dein OBS-Overlay übernimmt die Änderungen.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      persisting.current = false;
      setBusy(false);
    }
  }
  async function saveLook() {
    const name = lookName.trim();
    if (!name) {
      setError('Bitte gib deinem Look einen Namen.');
      return;
    }
    try {
      const r = await api('/api/looks', { name, config });
      const look = r.look;
      if (!look) throw new Error('Look konnte nicht gespeichert werden.');
      setCustomLooks((looks) => [look, ...looks]);
      setLookName('');
      setMessage('Look gespeichert.');
    } catch (e) {
      setError((e as Error).message);
    }
  }
  async function deleteLook(id: string) {
    try {
      const r = await fetch('/api/looks?id=' + encodeURIComponent(id), {
        method: 'DELETE',
        headers: { Origin: location.origin },
      });
      if (!r.ok) throw new Error('Look konnte nicht gelöscht werden.');
      setCustomLooks((looks) => looks.filter((look) => look.id !== id));
    } catch (e) {
      setError((e as Error).message);
    }
  }
  async function pinLook(look: CustomLook) {
    try {
      const r = await api('/api/looks', {
        action: 'pin',
        id: look.id,
        pinned: !look.pinned,
      });
      if (!r) return;
      setCustomLooks((looks) =>
        looks.map((item) =>
          item.id === look.id
            ? {
                ...item,
                pinned: look.pinned ? 0 : 1,
                pinned_at: look.pinned ? null : (r.pinned_at ?? null),
              }
            : item,
        ),
      );
    } catch (e) {
      setError((e as Error).message);
    }
  }
  async function activateLook(look: CustomLook) {
    const previous = config;
    persisting.current = true;
    persistRevision.current += 1;
    configRef.current = look.config;
    setConfig(look.config);
    try {
      await api('/api/studio', { config: look.config });
      const nextSaved = JSON.stringify(look.config);
      savedRef.current = nextSaved;
      setSaved(nextSaved);
      setMessage(`${look.name} ist live aktiv.`);
    } catch (e) {
      configRef.current = previous;
      setConfig(previous);
      setError((e as Error).message);
    } finally {
      persisting.current = false;
    }
  }
  function exportLook(look: CustomLook) {
    const blob = new Blob(
      [
        JSON.stringify(
          {
            format: 'resonance-look',
            version: 1,
            name: look.name,
            config: look.config,
            exportedAt: new Date().toISOString(),
          },
          null,
          2,
        ),
      ],
      { type: 'application/json' },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `resonance-look-${
      look.name
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '') || 'custom-look'
    }.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
  async function importLook(file: File) {
    try {
      const parsed: unknown = JSON.parse(await file.text());
      if (!isRecord(parsed)) throw new Error('Die Look-Datei ist ungültig.');
      if (parsed.format !== 'resonance-look')
        throw new Error('Diese Datei ist keine Resonance-Look-Datei.');
      if (parsed.version !== 1)
        throw new Error(
          'Diese Look-Datei verwendet eine neuere, nicht unterstützte Version.',
        );
      const data: ResonanceLookFile = {
        format: 'resonance-look',
        version: 1,
        name: typeof parsed.name === 'string' ? parsed.name : '',
        config: parsed.config,
      };
      if (!data.name.trim() || !isRecord(data.config))
        throw new Error('Die Look-Datei ist unvollständig.');
      const r = await api('/api/looks', {
        name: data.name,
        config: data.config,
        import: true,
      });
      const look = r.look;
      if (!look) throw new Error('Look konnte nicht importiert werden.');
      setCustomLooks((looks) => [look, ...looks]);
      const fonts = [
        data.config.titleFont,
        data.config.artistFont,
        data.config.metaFont,
      ];
      if (
        fonts.some(
          (font) =>
            typeof font === 'string' &&
            font.startsWith('custom:') &&
            !customFonts.some((item) => `custom:${item.id}` === font),
        )
      )
        setMessage(
          'Look importiert. Dieser Look verwendet eine Custom Font, die auf diesem System nicht vorhanden ist.',
        );
      else setMessage('Look importiert.');
    } catch (e) {
      setError((e as Error).message || 'Look konnte nicht importiert werden.');
    }
  }
  async function connect() {
    setBusy(true);
    setError('');
    try {
      const d = await api('/api/spotify/start', {});
      window.location.assign(d.url);
    } catch (e) {
      setError((e as Error).message);
      setBusy(false);
    }
  }
  async function disconnect() {
    setBusy(true);
    try {
      await api('/api/studio', { action: 'disconnect' });
      setConnected(false);
      setDemoMode(true);
      setTrack(null);
      setMessage('Spotify wurde getrennt.');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function copy(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      setMessage('In die Zwischenablage kopiert.');
    } catch {
      setError('Bitte markiere die Adresse und kopiere sie manuell.');
    }
  }
  async function reloadCustomFonts() {
    const r = await fetch('/api/fonts');
    if (!r.ok) return;
    const d = (await r.json()) as { fonts?: CustomFontMeta[] };
    setCustomFonts(d.fonts || []);
  }
  async function uploadFont(file: File, target: 'title' | 'artist' | 'meta') {
    const fontKey = `${target}Font` as 'titleFont' | 'artistFont' | 'metaFont';
    setUploading(true);
    setError('');
    try {
      const fd = new FormData();
      fd.append('file', file);
      const r = await fetch('/api/fonts', { method: 'POST', body: fd });
      const d = (await r.json()) as {
        error?: string;
        duplicate?: boolean;
        message?: string;
        font?: CustomFontMeta;
      };
      if (!r.ok) throw new Error(d.error || 'Upload fehlgeschlagen.');
      if (d.duplicate) {
        // Font NICHT neu anwenden, wenn er schon angewendet ist; sonst anwenden
        if (d.font)
          update(fontKey, ('custom:' + d.font.id) as Config[typeof fontKey]);
        setMessage(
          (d.message || 'Font already uploaded.') +
            ' Design speichern, um die Auswahl dauerhaft zu übernehmen.',
        );
        return;
      }
      await reloadCustomFonts();
      if (d.font)
        update(fontKey, ('custom:' + d.font.id) as Config[typeof fontKey]);
      setMessage(
        'Font hochgeladen und angewendet. Design speichern, um die Auswahl dauerhaft zu übernehmen.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setUploading(false);
    }
  }
  async function doDeleteFont(id: string) {
    setBusy(true);
    setError('');
    try {
      const r = await fetch('/api/fonts/' + id, { method: 'DELETE' });
      const d = (await r.json()) as { error?: string };
      if (!r.ok) throw new Error(d.error || 'Löschen fehlgeschlagen.');
      await reloadCustomFonts();
      setMessage('Font gelöscht.');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  function requestDeleteFont(id: string, name: string) {
    const used =
      config.titleFont === 'custom:' + id ||
      config.artistFont === 'custom:' + id ||
      config.metaFont === 'custom:' + id;
    if (used) {
      setDeleteConfirm({ id, name });
      return;
    }
    void doDeleteFont(id);
  }
  async function confirmDeleteFont() {
    if (!deleteConfirm) return;
    const { id } = deleteConfirm;
    setDeleteConfirm(null);
    // Fallback: verwendete Felder auf Inter ('sans') zurücksetzen.
    const usedKeys = (['titleFont', 'artistFont', 'metaFont'] as const).filter(
      (k) => config[k] === 'custom:' + id,
    );
    if (usedKeys.length > 0) {
      setConfig((c) => {
        const next = { ...c };
        for (const k of usedKeys) next[k] = 'sans';
        return next;
      });
    }
    await doDeleteFont(id);
  }
  async function openMoodSettings() {
    setMoodSettingsOpen(true);
    setLastfmTest('');
    setGeniusTest('');
    setError('');
    try {
      const r = await fetch('/api/mood/settings');
      if (!r.ok) return;
      const d = (await r.json()) as {
        lastfmConfigured?: boolean;
        geniusConfigured?: boolean;
      };
      setLastfmConfigured(!!d.lastfmConfigured);
      setGeniusConfigured(!!d.geniusConfigured);
    } catch {
      // Status bleibt unverändert
    }
  }
  async function saveMoodCredential(provider: 'lastfm' | 'genius') {
    setMoodBusy(true);
    setError('');
    try {
      const body =
        provider === 'lastfm'
          ? { lastfmApiKey: lastfmKey.trim() }
          : { geniusAccessToken: geniusToken.trim() };
      const r = await fetch('/api/mood/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const d = (await r.json()) as {
        error?: string;
        lastfmConfigured?: boolean;
        geniusConfigured?: boolean;
      };
      if (!r.ok) throw new Error(d.error || 'Speichern fehlgeschlagen.');
      setLastfmConfigured(!!d.lastfmConfigured);
      setGeniusConfigured(!!d.geniusConfigured);
      setMessage(
        provider === 'lastfm'
          ? 'Last.fm-Key gespeichert.'
          : 'Genius-Token gespeichert.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setMoodBusy(false);
    }
  }
  async function removeMoodCredential(provider: 'lastfm' | 'genius') {
    setMoodBusy(true);
    setError('');
    try {
      const body =
        provider === 'lastfm'
          ? { lastfmApiKey: '' }
          : { geniusAccessToken: '' };
      const r = await fetch('/api/mood/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const d = (await r.json()) as {
        error?: string;
        lastfmConfigured?: boolean;
        geniusConfigured?: boolean;
      };
      if (!r.ok) throw new Error(d.error || 'Entfernen fehlgeschlagen.');
      setLastfmConfigured(!!d.lastfmConfigured);
      setGeniusConfigured(!!d.geniusConfigured);
      if (provider === 'lastfm') setLastfmKey('');
      else setGeniusToken('');
      setMessage(
        provider === 'lastfm'
          ? 'Last.fm-Key entfernt.'
          : 'Genius-Token entfernt.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setMoodBusy(false);
    }
  }
  async function testMoodCredential(provider: 'lastfm' | 'genius') {
    const setTest = provider === 'lastfm' ? setLastfmTest : setGeniusTest;
    setTest('testing');
    setError('');
    try {
      const r = await fetch('/api/mood/settings/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider }),
      });
      const d = (await r.json()) as {
        error?: string;
        status?: 'connected' | 'invalid' | 'unavailable';
      };
      if (!r.ok) throw new Error(d.error || 'Test fehlgeschlagen.');
      setTest(d.status || 'unavailable');
    } catch (e) {
      setTest('unavailable');
      setError((e as Error).message);
    }
  }
  function range(
    k:
      | 'radius'
      | 'opacity'
      | 'width'
      | 'spacing'
      | 'fontSize'
      | 'moodIntensity'
      | 'spinSpeed'
      | 'ledBrightness'
      | 'ledGlow'
      | 'ledSize'
      | 'ledOffsetX'
      | 'ledOffsetY'
      | 'displayBrightness'
      | 'textGlow'
      | 'progressEdge'
      | 'progressWidth'
      | 'progressThickness'
      | 'progressOffsetX'
      | 'progressOffsetY'
      | 'progressRadius'
      | 'controlsSize'
      | 'controlsIconSize'
      | 'controlsGap'
      | 'controlsOffsetX'
      | 'controlsOffsetY'
      | 'coverBrightness'
      | 'coverSaturation'
      | 'coverContrast'
      | 'coverSize'
      | 'coverOffsetX'
      | 'coverOffsetY'
      | 'coverRadius'
      | 'noteSize'
      | 'noteOffsetX'
      | 'noteOffsetY'
      | 'noteRotation'
      | 'noteOpacity'
      | 'titleOffsetX'
      | 'titleOffsetY'
      | 'artistOffsetX'
      | 'artistOffsetY'
      | 'metaOffsetX'
      | 'metaOffsetY'
      | 'titleArtistSpacing'
      | 'scanlineStrength'
      | 'grainStrength'
      | 'vignetteStrength'
      | 'titleSize'
      | 'artistSize'
      | 'metaSize'
      | 'titleLetterSpacing'
      | 'artistLetterSpacing'
      | 'metaLetterSpacing',
    label: string,
    min: number,
    max: number,
    unit: string,
  ) {
    return (
      <div className="range-control">
        <div className="range-label">
          <span>{label}</span>
          <code>
            {config[k]} {unit}
          </code>
        </div>
        <Slider
          aria-label={label}
          value={[config[k]]}
          min={min}
          max={max}
          onPointerDown={beginSlider}
          onValueChange={(v) => updateSlider(k, Array.isArray(v) ? v[0] : v)}
          onValueCommitted={commitSlider}
        />
      </div>
    );
  }
  function toggle(
    k:
      | 'glow'
      | 'cover'
      | 'progress'
      | 'artist'
      | 'badge'
      | 'hidePaused'
      | 'moodSwitch'
      | 'spin'
      | 'scanlinesEnabled'
      | 'grainEnabled'
      | 'linkAccentColors',
    label: string,
  ) {
    return (
      <div className="switch-row" key={k}>
        <label htmlFor={k}>{label}</label>
        <Switch
          id={k}
          checked={config[k]}
          onCheckedChange={(v) => update(k, v)}
        />
      </div>
    );
  }
  function renderLedPanel() {
    const ledHidden = !(config.ledVisible && config.ledBehavior !== 'off');
    return (
      <div className="context-transition">
        <div
          className={'led-preview' + (config.moodSwitch ? ' led-muted' : '')}
          data-led-preview="playing"
          data-led-behavior={
            config.ledVisible && config.ledBehavior !== 'off'
              ? config.ledBehavior
              : 'off'
          }
          style={
            {
              '--memory-led-user-color': config.ledColor,
              '--memory-led-user-brightness': config.ledBrightness / 100,
              '--memory-led-user-glow': config.ledGlow / 100,
              '--memory-led-user-speed':
                (8 - (config.ledSpeed / 100) * 5.5).toFixed(2) + 's',
            } as CSSProperties
          }
        >
          <div className="led-preview-stage">
            <i className="memory-led" />
          </div>
          <div className="led-preview-meta">
            <span className="led-preview-title">LED Preview</span>
            <span className="led-preview-behavior">
              {
                LED_BEHAVIOR_LABELS[
                  config.ledVisible && config.ledBehavior !== 'off'
                    ? config.ledBehavior
                    : 'off'
                ]
              }
            </span>
          </div>
        </div>
        <div className={'switch-row' + (config.moodSwitch ? ' led-muted' : '')}>
          <label htmlFor="ledVisible">LED sichtbar</label>
          <Switch
            id="ledVisible"
            checked={config.ledVisible && config.ledBehavior !== 'off'}
            onCheckedChange={(v) => {
              update('ledVisible', v);
              if (v && config.ledBehavior === 'off')
                update('ledBehavior', 'soft');
            }}
          />
        </div>
        <div
          className={
            'led-controls' +
            (config.moodSwitch || ledHidden ? ' led-muted' : '')
          }
        >
          <label className="color-field">
            <span>LED Farbe</span>
            <code>{config.ledColor}</code>
            <input
              aria-label="LED Farbe"
              type="color"
              value={config.ledColor}
              onChange={(e) => update('ledColor', e.target.value)}
            />
          </label>
          <Picker
            label="LED Behavior"
            value={config.ledBehavior}
            options={[
              ['solid', 'Solid'],
              ['soft', 'Soft Pulse'],
              ['breathe', 'Breathe'],
              ['double', 'Double Pulse'],
              ['heartbeat', 'Heartbeat'],
              ['flicker', 'Flicker'],
            ]}
            onChange={(v) => update('ledBehavior', v)}
          />
          {range('ledBrightness', 'Helligkeit', 10, 100, '%')}
          {range('ledGlow', 'Glow', 0, 100, '%')}
          {range('ledSize', 'LED Größe', 80, 120, '%')}
          {range('ledOffsetX', 'LED Horizontal', -8, 8, 'px')}
          {range('ledOffsetY', 'LED Vertikal', -8, 8, 'px')}
          <button
            type="button"
            className="context-reset"
            onClick={() =>
              setConfig((current) => ({
                ...current,
                ledSize: defaults.ledSize,
                ledOffsetX: defaults.ledOffsetX,
                ledOffsetY: defaults.ledOffsetY,
              }))
            }
          >
            LED-Layout zurücksetzen
          </button>
          <div className="range-control">
            <div className="range-label">
              <span>Speed</span>
              <code>
                {config.ledSpeed <= 33
                  ? 'Slow'
                  : config.ledSpeed <= 66
                    ? 'Normal'
                    : 'Fast'}
              </code>
            </div>
            <Slider
              aria-label="LED Speed"
              value={[config.ledSpeed]}
              min={0}
              max={100}
              onValueChange={(v) =>
                update('ledSpeed', Array.isArray(v) ? v[0] : v)
              }
            />
          </div>
        </div>
        {config.moodSwitch && (
          <small className="led-hint">
            Mood Switch controls the LED while active.
          </small>
        )}
      </div>
    );
  }
  function renderDisplayPanel() {
    return (
      <div className="context-transition">
        <div
          className={'led-controls' + (config.moodSwitch ? ' led-muted' : '')}
        >
          <label className="color-field">
            <span>Display Farbe</span>
            <code>{config.displayColor}</code>
            <input
              aria-label="Display Farbe"
              type="color"
              value={config.displayColor}
              onChange={(e) => update('displayColor', e.target.value)}
            />
          </label>
          {range('displayBrightness', 'Helligkeit', 20, 100, '%')}
          {range('textGlow', 'Text Glow', 0, 100, '%')}
          {toggle('scanlinesEnabled', 'Scanlines')}
          <div className={config.scanlinesEnabled ? '' : 'led-muted'}>
            {range('scanlineStrength', 'Scanline Stärke', 0, 100, '%')}
          </div>
          {toggle('grainEnabled', 'Grain')}
          <div className={config.grainEnabled ? '' : 'led-muted'}>
            {range('grainStrength', 'Grain Stärke', 0, 100, '%')}
          </div>
          {range('vignetteStrength', 'Vignette', 0, 100, '%')}
        </div>
        {config.moodSwitch && (
          <small className="led-hint">
            Mood Switch controls the display while active.
          </small>
        )}
      </div>
    );
  }
  function renderTypographyPanel(target: 'title' | 'artist' | 'meta') {
    const fontKey = `${target}Font` as 'titleFont' | 'artistFont' | 'metaFont';
    const weightKey = `${target}Weight` as
      | 'titleWeight'
      | 'artistWeight'
      | 'metaWeight';
    const sizeKey = `${target}Size` as 'titleSize' | 'artistSize' | 'metaSize';
    const lsKey = `${target}LetterSpacing` as
      | 'titleLetterSpacing'
      | 'artistLetterSpacing'
      | 'metaLetterSpacing';
    const caseKey = `${target}Case` as 'titleCase' | 'artistCase' | 'metaCase';
    const currentFont = config[fontKey] as string;
    const currentWeight = config[weightKey] as number;
    const currentFontDef = FONT_LIBRARY.find((f) => f.id === currentFont);
    const fontOptions: [string, string][] = [
      ...FONT_LIBRARY.map(
        (f) => [f.id, f.name + ' · ' + f.category] as [string, string],
      ),
      ...customFonts.map(
        (f) => ['custom:' + f.id, f.name + ' · Custom'] as [string, string],
      ),
    ];
    return (
      <>
        <Picker
          label="Font"
          value={currentFont}
          options={fontOptions}
          onChange={(v) => update(fontKey, v)}
        />
        <button
          type="button"
          className="upload-font-button"
          onClick={() => {
            setPendingUploadTarget(target);
            fileInputRef.current?.click();
          }}
        >
          <Plus size={13} />
          Custom Font hochladen
        </button>
        {uploading && <p className="upload-status">Uploading…</p>}
        {customFonts.length > 0 && (
          <div className="custom-font-list">
            <span className="custom-font-list-label">Eigene Fonts</span>
            {customFonts.map((f) => (
              <div key={f.id} className="custom-font-row">
                <span className="custom-font-name" title={f.name}>
                  {f.name}
                </span>
                <button
                  className="custom-font-delete"
                  aria-label={'Font löschen: ' + f.name}
                  onClick={() => requestDeleteFont(f.id, f.name)}
                >
                  <Trash2 size={13} />
                </button>
              </div>
            ))}
          </div>
        )}
        <Picker
          label="Weight"
          value={String(currentWeight)}
          options={(currentFontDef?.weights || [400]).map((w) => [
            String(w),
            String(w),
          ])}
          onChange={(v) => update(weightKey, Number(v))}
        />
        {range(
          sizeKey,
          'Größe',
          target === 'title' ? 14 : target === 'artist' ? 10 : 8,
          target === 'title' ? 48 : 24,
          'px',
        )}
        {range(lsKey, 'Letter Spacing', -2, 6, 'px')}
        <Picker
          label="Case"
          value={config[caseKey] as string}
          options={[
            ['normal', 'Normal'],
            ['uppercase', 'UPPERCASE'],
          ]}
          onChange={(v) => update(caseKey, v)}
        />
      </>
    );
  }
  function contextHead(icon: ReactNode, title: string, description: string) {
    return (
      <div className="context-panel-head">
        <span className="context-icon" aria-hidden="true">
          {icon}
        </span>
        <div>
          <small>DIREKT BEARBEITEN</small>
          <h3>{title}</h3>
          <p>{description}</p>
        </div>
      </div>
    );
  }
  function renderAccentField(label = 'Akzentfarbe') {
    return (
      <label className="color-field color-field-featured">
        <span>{label}</span>
        <code>{config.accent}</code>
        <input
          aria-label={label}
          type="color"
          value={config.accent}
          onChange={(e) => update('accent', e.target.value)}
        />
      </label>
    );
  }
  function renderColorField(
    k: 'progressColor' | 'controlAccentColor' | 'statusAccentColor',
    label: string,
    muted = false,
  ) {
    return (
      <label
        className={
          'color-field color-field-featured' + (muted ? ' led-muted' : '')
        }
      >
        <span>{label}</span>
        <code>{config[k]}</code>
        <input
          aria-label={label}
          type="color"
          value={config[k]}
          onChange={(e) => update(k, e.target.value)}
        />
      </label>
    );
  }
  return (
    <main className="studio">
      <input
        ref={fileInputRef}
        type="file"
        accept=".woff2,.woff,.ttf,.otf"
        style={{ display: 'none' }}
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = '';
          if (file && pendingUploadTarget) {
            void uploadFont(file, pendingUploadTarget);
          }
          setPendingUploadTarget(null);
        }}
      />
      <header className="topbar">
        <a className="brand" href="/">
          <AudioLines />
          <span>
            resonance<span className="brand-dot">.</span>
          </span>
        </a>
        <span className="edition">OVERLAY STUDIO</span>
        <div className="top-actions">
          <a className="qa-lab-link" href="/mood-visual-check">
            QA Lab
          </a>
          <span className="demo-badge">
            <i className={connected ? 'is-connected' : ''} />
            {connected ? 'Spotify verbunden' : 'Demo-Modus'}
          </span>
          <button className="primary" onClick={() => setModal('obs')}>
            In OBS verwenden <ArrowUpRight size={16} />
          </button>
        </div>
      </header>
      <div className="workspace">
        <section className="creative">
          <div className="page-heading">
            <div>
              <div className="eyebrow">DEIN SOUND. DEIN LOOK.</div>
              <h1>
                Mach Musik sichtbar<span>.</span>
              </h1>
              <p>Von MP3-Nostalgie bis Desktop-Magie. Dein Mix.</p>
            </div>
            <div className="workspace-mark">
              <AudioLines />
            </div>
          </div>
          <div className="canvas-wrap">
            <div className="canvas-top">
              <span>
                <Radio size={14} /> LIVE-VORSCHAU
              </span>
              <span>
                {chosen?.name} / {config.width} px
              </span>
            </div>
            <div
              ref={preview}
              data-selected={selectedElement || undefined}
              className={
                'preview-canvas canvas-' +
                canvas +
                ' allow-motion' +
                (selectedElement ? ' editor-selecting' : '')
              }
              onClick={(e) => {
                const t = e.target as HTMLElement;
                for (const [name, sel] of EDITOR_TARGETS) {
                  if (t.closest(sel)) {
                    setSelectedElement(name);
                    return;
                  }
                }
              }}
            >
              <div className="preview-label">
                {demoMode
                  ? 'Demo-Titel · keine Audiowiedergabe'
                  : 'Deine Musik aus Spotify'}
              </div>
              <div
                style={
                  {
                    zoom: Math.min(1, (canvasWidth - 50) / config.width),
                  } as CSSProperties
                }
              >
                <Overlay config={config} track={shown} />
              </div>
              {selectedElement && markerRect && (
                <div
                  className="editor-selection"
                  data-label={EDITOR_NAMES[selectedElement]}
                  style={{
                    top: markerRect.top,
                    left: markerRect.left,
                    width: markerRect.width,
                    height: markerRect.height,
                  }}
                >
                  <i className="corner tl" />
                  <i className="corner tr" />
                  <i className="corner bl" />
                  <i className="corner br" />
                </div>
              )}
              {!shown && (
                <div className="empty-track">
                  <Music2 />
                  <b>Bereit für deinen nächsten Track.</b>
                  <span>Starte einen Song in Spotify.</span>
                </div>
              )}
              {shown && !shown.playing && config.hidePaused && (
                <div className="empty-track">
                  <Pause />
                  <span>Bei Pause ausgeblendet.</span>
                </div>
              )}
            </div>
            <div className="canvas-bottom">
              <div className="canvas-modes">
                {[
                  ['ambient', 'Stream'],
                  ['checker', 'Transparent'],
                  ['light', 'Hell'],
                ].map(([v, l]) => (
                  <button
                    key={v}
                    aria-pressed={canvas === v}
                    className={canvas === v ? 'active' : ''}
                    onClick={() => setCanvas(v)}
                  >
                    {l}
                  </button>
                ))}
              </div>
              <div className="preview-play">
                <button
                  onClick={() =>
                    demoMode ? setDemoPlaying(!demoPlaying) : setDemoMode(true)
                  }
                  aria-label={
                    demoMode
                      ? demoPlaying
                        ? 'Demo pausieren'
                        : 'Demo abspielen'
                      : 'Demo anzeigen'
                  }
                >
                  {demoMode ? (
                    demoPlaying ? (
                      <Pause size={14} />
                    ) : (
                      <Play size={14} />
                    )
                  ) : (
                    <Play size={14} />
                  )}
                </button>
                <span>{demoMode ? 'Demo' : 'Spotify'}</span>
                {connected && (
                  <button
                    className={!demoMode ? 'live-active' : ''}
                    onClick={() => setDemoMode(!demoMode)}
                  >
                    {demoMode ? 'Live ansehen' : 'Demo ansehen'}
                  </button>
                )}
              </div>
            </div>
          </div>
          <div className="presets-heading">
            <h2>Finde deinen Vibe</h2>
            <span>{presets.length} SIGNATURE STYLES</span>
          </div>
          {liveLooks.length > 0 && (
            <section className="live-looks">
              <div className="live-looks-head">
                <b>LIVE LOOKS</b>
                <span className="live-looks-help">Schnell aktivieren</span>
              </div>
              <div className="live-looks-grid">
                {liveLooks.map((look) => (
                  <button
                    type="button"
                    key={look.id}
                    className={look.id === activeLiveLookId ? 'active' : ''}
                    aria-pressed={look.id === activeLiveLookId}
                    onClick={() => activateLook(look)}
                  >
                    {look.id === activeLiveLookId && (
                      <i aria-hidden="true">●</i>
                    )}
                    {look.name}
                  </button>
                ))}
              </div>
            </section>
          )}
          <div className="preset-grid">
            {presets.map((p) => (
              <button
                key={p.id}
                className={
                  'preset ' + (config.layout === p.id ? 'selected' : '')
                }
                aria-pressed={config.layout === p.id}
                onClick={() => {
                  setSelectedElement(null);
                  setConfig({
                    ...p.config,
                    moodSwitch: config.moodSwitch,
                    moodIntensity: config.moodIntensity,
                  });
                }}
              >
                <div className={'preset-art art-' + p.id}>
                  <div className="mini-chrome">
                    <i />
                    <i />
                    <i />
                  </div>
                  <span className="mini-cover" />
                  <span className="mini-lines">
                    <b />
                    <i />
                    <em />
                  </span>
                  {p.id === 'sticker' && <span className="mini-star">✦</span>}
                </div>
                <div>
                  <span>{p.name}</span>
                  {config.layout === p.id ? (
                    <Check size={15} />
                  ) : (
                    <ArrowUpRight size={15} />
                  )}
                </div>
                <p>{p.note}</p>
              </button>
            ))}
          </div>
          <section className="custom-looks" aria-label="My Looks">
            <div className="presets-heading">
              <h2>My Looks</h2>
              <span>DEINE GESPEICHERTEN DESIGNS</span>
            </div>
            <div className="custom-look-save">
              <input
                value={lookName}
                maxLength={50}
                placeholder="z. B. Midnight Purple"
                onChange={(e) => setLookName(e.target.value)}
              />
              <button type="button" className="secondary" onClick={saveLook}>
                <Plus size={15} /> Aktuellen Look speichern
              </button>
              <input
                ref={lookImportRef}
                type="file"
                accept="application/json,.json"
                hidden
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void importLook(file);
                  e.currentTarget.value = '';
                }}
              />
              <button
                type="button"
                className="secondary"
                onClick={() => lookImportRef.current?.click()}
              >
                Look importieren
              </button>
            </div>
            {customLooks.length > 0 && (
              <div className="custom-look-list">
                {customLooks.map((look) => (
                  <div className="custom-look-row" key={look.id}>
                    <span>{look.name}</span>
                    <button
                      type="button"
                      onClick={() => {
                        setConfig(look.config);
                        setSelectedElement(null);
                      }}
                    >
                      Apply
                    </button>
                    <button type="button" onClick={() => activateLook(look)}>
                      Activate
                    </button>
                    <button type="button" onClick={() => pinLook(look)}>
                      {look.pinned ? '★' : '☆'}
                    </button>
                    <button type="button" onClick={() => exportLook(look)}>
                      Export
                    </button>
                    <button
                      type="button"
                      aria-label={`${look.name} löschen`}
                      onClick={() => deleteLook(look.id)}
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </section>
          <div className="bottom-note">
            <Sparkles size={16} />
            <span>Jeder Look ist ein Anfang. Mach ihn zu deinem.</span>
            <span className="version">RESONANCE / 01</span>
          </div>
          <div className="status-area" aria-live="polite">
            {error && <p className="error-message">{error}</p>}
            {message && <p className="success-message">{message}</p>}
          </div>
        </section>
        <aside className="inspector" ref={inspector}>
          <div className="inspector-heading">
            <SlidersHorizontal size={19} />
            <h2>Dein Design</h2>
            <span className="live-pill">LIVE</span>
          </div>
          <div
            className={'editor-context' + (selectedElement ? ' is-active' : '')}
          >
            <span className="editor-context-pointer" aria-hidden="true">
              <MousePointer2 size={15} />
            </span>
            <span className="editor-context-copy">
              <span className="editor-context-label">
                {selectedElement ? 'AUSGEWÄHLT' : 'DIREKT IM PLAYER'}
              </span>
              <span className="editor-context-value">
                {selectedElement
                  ? EDITOR_NAMES[selectedElement]
                  : 'Element anklicken zum Bearbeiten'}
              </span>
            </span>
            {selectedElement && (
              <button
                className="editor-context-clear"
                onClick={() => setSelectedElement(null)}
                aria-label="Zurück zum gesamten Player"
              >
                <ChevronLeft size={15} />
                Player
              </button>
            )}
          </div>
          {selectedElement === 'led' ? (
            <div className="context-panel">
              {contextHead(
                <Lightbulb size={19} />,
                'LED',
                'Farbe, Leuchten und Puls direkt am Gerät abstimmen.',
              )}
              {renderLedPanel()}
            </div>
          ) : selectedElement === 'display' ? (
            <div className="context-panel">
              {contextHead(
                <Monitor size={19} />,
                'Display',
                'LCD-Farbe, Körnung und Tiefe für den Screen einstellen.',
              )}
              {renderDisplayPanel()}
            </div>
          ) : selectedElement === 'title' ? (
            <div className="context-panel">
              {contextHead(
                <Type size={19} />,
                'Songtitel',
                'Die wichtigste Zeile: klar, charaktervoll und gut lesbar.',
              )}
              <div className="context-transition">
                {renderTypographyPanel('title')}
                <div className="context-section">
                  {range('titleOffsetX', 'Horizontal', -8, 8, 'px')}
                  {range('titleOffsetY', 'Vertikal', -6, 6, 'px')}
                  {range(
                    'titleArtistSpacing',
                    'Abstand zum Interpreten',
                    0,
                    8,
                    'px',
                  )}
                  <button
                    type="button"
                    className="context-reset"
                    onClick={() =>
                      setConfig((current) => ({
                        ...current,
                        titleOffsetX: defaults.titleOffsetX,
                        titleOffsetY: defaults.titleOffsetY,
                      }))
                    }
                  >
                    Titel-Position zurücksetzen
                  </button>
                </div>
              </div>
            </div>
          ) : selectedElement === 'artist' ? (
            <div className="context-panel">
              {contextHead(
                <Music2 size={19} />,
                'Interpret',
                'Die zweite Textzeile passend zum Titel gestalten.',
              )}
              <div className="context-transition">
                {renderTypographyPanel('artist')}
                <div className="context-section">
                  {range('artistOffsetX', 'Horizontal', -8, 8, 'px')}
                  {range('artistOffsetY', 'Vertikal', -6, 6, 'px')}
                  <button
                    type="button"
                    className="context-reset"
                    onClick={() =>
                      setConfig((current) => ({
                        ...current,
                        artistOffsetX: defaults.artistOffsetX,
                        artistOffsetY: defaults.artistOffsetY,
                      }))
                    }
                  >
                    Interpret-Position zurücksetzen
                  </button>
                </div>
              </div>
            </div>
          ) : selectedElement === 'display-meta' ? (
            <div className="context-panel">
              {contextHead(
                <Radio size={19} />,
                'Statuszeile',
                'Now Playing, Pause und Slot-Nummer fein abstimmen.',
              )}
              <div className="context-transition">
                {renderTypographyPanel('meta')}
                <div className="context-section">
                  {range('metaOffsetX', 'Horizontal', -8, 8, 'px')}
                  {range('metaOffsetY', 'Vertikal', -6, 6, 'px')}
                  <button
                    type="button"
                    className="context-reset"
                    onClick={() =>
                      setConfig((current) => ({
                        ...current,
                        metaOffsetX: defaults.metaOffsetX,
                        metaOffsetY: defaults.metaOffsetY,
                      }))
                    }
                  >
                    Status-Position zurücksetzen
                  </button>
                  {renderColorField(
                    'statusAccentColor',
                    'Status-Akzent',
                    config.linkAccentColors,
                  )}
                  {config.linkAccentColors && (
                    <small className="context-note">
                      Wird vom gekoppelten Akzent gesteuert. Deaktiviere
                      „Akzente koppeln“ im Gerät-Panel, um ihn einzeln zu
                      setzen.
                    </small>
                  )}
                </div>
              </div>
            </div>
          ) : selectedElement === 'progress' ? (
            <div className="context-panel">
              {contextHead(
                <Gauge size={19} />,
                'Wiedergabe',
                'Fortschritt, Zeit und Akzent als eine ruhige Einheit.',
              )}
              <div className="context-transition context-section">
                {toggle('progress', 'Fortschritt anzeigen')}
                {renderColorField(
                  'progressColor',
                  'Progress Farbe',
                  config.linkAccentColors,
                )}
                {config.linkAccentColors && (
                  <small className="context-note">
                    Wird vom gekoppelten Akzent gesteuert. Deaktiviere „Akzente
                    koppeln“ im Gerät-Panel, um ihn einzeln zu setzen.
                  </small>
                )}
                {range('progressEdge', 'Lichtkante', 0, 100, '%')}
                <div className="context-divider" />
                {range('progressWidth', 'Breite', 84, 100, '%')}
                {range('progressThickness', 'Stärke', 72, 128, '%')}
                {range('progressOffsetX', 'Horizontal', -6, 6, 'px')}
                {range('progressOffsetY', 'Vertikal', -5, 5, 'px')}
                {range('progressRadius', 'Rundung', 0, 12, 'px')}
                <button
                  type="button"
                  className="context-reset"
                  onClick={() =>
                    setConfig((current) => ({
                      ...current,
                      progressWidth: defaults.progressWidth,
                      progressThickness: defaults.progressThickness,
                      progressOffsetX: defaults.progressOffsetX,
                      progressOffsetY: defaults.progressOffsetY,
                      progressRadius: defaults.progressRadius,
                    }))
                  }
                >
                  Progress-Layout zurücksetzen
                </button>
              </div>
            </div>
          ) : selectedElement === 'controls' ? (
            <div className="context-panel">
              {contextHead(
                <Gamepad2 size={19} />,
                'Bedienelemente',
                'Play, Skip, Shuffle und Herz optisch zusammenführen.',
              )}
              <div className="context-transition context-section">
                {renderColorField(
                  'controlAccentColor',
                  'Tasten-Akzent',
                  config.linkAccentColors,
                )}
                {config.linkAccentColors && (
                  <small className="context-note">
                    Wird vom gekoppelten Akzent gesteuert. Deaktiviere „Akzente
                    koppeln“ im Gerät-Panel, um ihn einzeln zu setzen.
                  </small>
                )}
                {toggle('glow', 'Sanfter Tastenglow')}
                <div className="context-divider" />
                {range('controlsSize', 'Tastengröße', 85, 115, '%')}
                {range('controlsIconSize', 'Icongröße', 80, 120, '%')}
                {range('controlsGap', 'Abstand', 70, 140, '%')}
                {range('controlsOffsetX', 'Horizontal', -8, 8, 'px')}
                {range('controlsOffsetY', 'Vertikal', -6, 6, 'px')}
                <button
                  type="button"
                  className="context-reset"
                  onClick={() =>
                    setConfig((current) => ({
                      ...current,
                      controlsSize: defaults.controlsSize,
                      controlsIconSize: defaults.controlsIconSize,
                      controlsGap: defaults.controlsGap,
                      controlsOffsetX: defaults.controlsOffsetX,
                      controlsOffsetY: defaults.controlsOffsetY,
                    }))
                  }
                >
                  Controls-Layout zurücksetzen
                </button>
                <small className="context-note">
                  Die Bedienelemente sind im Stream visuell. Spotify wird hier
                  nicht ferngesteuert.
                </small>
              </div>
            </div>
          ) : selectedElement === 'cover' ? (
            <div className="context-panel">
              {contextHead(
                <ImageIcon size={19} />,
                'Albumcover',
                'Das Artwork als sichtbaren Speicherstand inszenieren.',
              )}
              <div className="context-transition context-section">
                {toggle('cover', 'Albumcover anzeigen')}
                <div className="context-mini-preview cover-mini-preview">
                  <div className="mini-cover-art" />
                  <span>Artwork folgt automatisch dem aktuellen Song.</span>
                </div>
                {range('coverBrightness', 'Helligkeit', 40, 140, '%')}
                {range('coverSaturation', 'Sättigung', 0, 150, '%')}
                {range('coverContrast', 'Kontrast', 60, 140, '%')}
                <div className="context-divider" />
                <small className="context-note">
                  Layout verändert nur das Artwork im bestehenden Cover-Slot.
                </small>
                {range('coverSize', 'Größe', 84, 116, '%')}
                {range('coverOffsetX', 'Horizontal', -8, 8, 'px')}
                {range('coverOffsetY', 'Vertikal', -8, 8, 'px')}
                {range('coverRadius', 'Eckenrundung', 0, 16, 'px')}
                <label className="context-select">
                  <span>Bildanpassung</span>
                  <select
                    value={config.coverFit}
                    onChange={(e) => update('coverFit', e.target.value)}
                  >
                    <option value="cover">Cover</option>
                    <option value="contain">Contain</option>
                  </select>
                </label>
                <button
                  type="button"
                  className="context-reset"
                  onClick={() =>
                    setConfig((current) => ({
                      ...current,
                      coverSize: defaults.coverSize,
                      coverOffsetX: defaults.coverOffsetX,
                      coverOffsetY: defaults.coverOffsetY,
                      coverRadius: defaults.coverRadius,
                      coverFit: defaults.coverFit,
                    }))
                  }
                >
                  Cover-Layout zurücksetzen
                </button>
              </div>
            </div>
          ) : selectedElement === 'note' ? (
            <div className="context-panel">
              {contextHead(
                <Tag size={19} />,
                'Notiz',
                'Dein kleiner persönlicher Sticker am Player.',
              )}
              <div className="context-transition context-section">
                <label className="memory-label-editor context-label-editor">
                  <span>Text auf der Notiz</span>
                  <input
                    value={config.memoryLabel}
                    maxLength={32}
                    placeholder="GOOD MUSIC BETTER DAYS."
                    onChange={(e) => update('memoryLabel', e.target.value)}
                  />
                  <small>Leer lassen, um die Notiz auszublenden.</small>
                </label>
                <div className="context-divider" />
                <small className="context-note">
                  Positioniert die Notiz im bestehenden sicheren Bereich.
                </small>
                {range('noteSize', 'Größe', 88, 112, '%')}
                {range('noteOffsetX', 'Horizontal', -8, 8, 'px')}
                {range('noteOffsetY', 'Vertikal', -8, 8, 'px')}
                {range('noteRotation', 'Drehung', -6, 6, '°')}
                {range('noteOpacity', 'Deckkraft', 55, 100, '%')}
                <button
                  type="button"
                  className="context-reset"
                  onClick={() =>
                    setConfig((current) => ({
                      ...current,
                      noteSize: defaults.noteSize,
                      noteOffsetX: defaults.noteOffsetX,
                      noteOffsetY: defaults.noteOffsetY,
                      noteRotation: defaults.noteRotation,
                      noteOpacity: defaults.noteOpacity,
                    }))
                  }
                >
                  Notiz-Layout zurücksetzen
                </button>
              </div>
            </div>
          ) : selectedElement === 'device' ? (
            <div className="context-panel">
              {contextHead(
                <Box size={19} />,
                'Gerät',
                'Größe, Material und Grundfarben des gesamten Players.',
              )}
              <div className="context-transition context-section">
                {range('width', 'Breite', 280, 900, 'px')}
                {range('spacing', 'Innenabstand', 8, 42, 'px')}
                {range('radius', 'Rundung', 0, 40, 'px')}
                {range('opacity', 'Deckkraft', 20, 100, '%')}
                {renderAccentField()}
                {toggle('linkAccentColors', 'Akzente koppeln')}
                <small className="context-note">
                  Nutzt den Haupt-Akzent für Tasten, Fortschritt und Status.
                  Aus, um alle drei einzeln zu setzen.
                </small>
                <label className="color-field color-field-featured">
                  <span>Gehäusefarbe</span>
                  <code>{config.background}</code>
                  <input
                    aria-label="Gehäusefarbe"
                    type="color"
                    value={config.background}
                    onChange={(e) => update('background', e.target.value)}
                  />
                </label>
                {toggle('glow', 'Sanfter Außenglow')}
              </div>
            </div>
          ) : (
            <Tabs defaultValue="design">
              <TabsList className="editor-tabs">
                <TabsTrigger value="design">Design</TabsTrigger>
                <TabsTrigger value="elements">Elemente</TabsTrigger>
                <TabsTrigger value="motion">Bewegung</TabsTrigger>
              </TabsList>
              <TabsContent value="design">
                <div className="mood-card">
                  <div className="mood-title">
                    <Sparkles size={17} />
                    <label htmlFor="moodSwitch">MoodSwitch</label>
                    <Switch
                      id="moodSwitch"
                      checked={config.moodSwitch}
                      onCheckedChange={(v) => update('moodSwitch', v)}
                    />
                  </div>
                  <div className="mood-sources">
                    <span>Sources</span>
                    <span className={lastfmConfigured ? 'ok' : ''}>
                      Last.fm {lastfmConfigured ? '✓' : '· Not configured'}
                    </span>
                    <span className={geniusConfigured ? 'ok' : ''}>
                      Genius{' '}
                      {geniusConfigured ? '✓' : 'Optional · Not configured'}
                    </span>
                    <button onClick={openMoodSettings}>Settings</button>
                  </div>
                  <p>Dein Look fühlt mit. Farben folgen dem Song.</p>
                  {config.moodSwitch && (
                    <>
                      {!moodSetupDismissed &&
                        (!lastfmConfigured || !geniusConfigured) && (
                          <div className="mood-setup-hint">
                            <b>Mood Switch Setup</b>
                            <p>
                              Für genauere Mood-Erkennung kann Resonance
                              zusätzliche Musikdaten verwenden.
                            </p>
                            <span>
                              Last.fm{' '}
                              {lastfmConfigured
                                ? '· Configured'
                                : '· Not configured'}{' '}
                              · Genres, Tags und Metadaten
                            </span>
                            <span>
                              Genius{' '}
                              {geniusConfigured ? '· Configured' : '· Optional'}{' '}
                              · Zusätzlicher Lyrics-Fallback
                            </span>
                            <button onClick={openMoodSettings}>Set up</button>
                            <button onClick={() => setMoodSetupDismissed(true)}>
                              Continue with limited detection
                            </button>
                          </div>
                        )}
                      <div
                        className="mood-result"
                        style={{
                          borderColor: detected?.mood.accent || '#54634b',
                        }}
                      >
                        <b>
                          {detected
                            ? detected.mood.label
                            : 'Dein Original-Look'}
                        </b>
                        <span>
                          {detected
                            ? 'Geschätzt aus ' +
                              detected.source +
                              ' · ' +
                              detected.confidence
                            : 'Kein klares Stimmungssignal'}
                        </span>
                      </div>
                      {range('moodIntensity', 'Intensität', 0, 100, '%')}
                      {demoMode && (
                        <button
                          className="secondary"
                          onClick={() =>
                            setDemoIndex((i) => (i + 1) % moodDemos.length)
                          }
                        >
                          <RefreshCw size={13} />
                          Nächsten Demo-Mood testen
                        </button>
                      )}
                      <small>
                        Schätzung aus Metadaten, keine Audioanalyse.
                        Künstler-Genres sind nur ein Anhaltspunkt. Dein
                        Basisdesign bleibt erhalten.
                      </small>
                    </>
                  )}
                </div>
                <div className="control-group">
                  <h3>Farbwelt</h3>
                  <p>Setze deinen eigenen Akzent.</p>
                  <div className="swatches">
                    {[
                      '#b3f47c',
                      '#c1a0ff',
                      '#ffac75',
                      '#71d6ff',
                      '#fb88bd',
                      '#ffffff',
                    ].map((c) => (
                      <button
                        key={c}
                        aria-label={'Akzent ' + c}
                        onClick={() => update('accent', c)}
                        style={{ background: c }}
                        className={c === config.accent ? 'chosen' : ''}
                      >
                        {c === config.accent && <Check size={15} />}
                      </button>
                    ))}
                  </div>
                  {(['accent', 'background', 'text'] as const).map((k, i) => (
                    <label className="color-field" key={k}>
                      <span>{['Akzent', 'Hintergrund', 'Text'][i]}</span>
                      <code>{config[k]}</code>
                      <input
                        aria-label={
                          ['Akzentfarbe', 'Hintergrundfarbe', 'Textfarbe'][i]
                        }
                        type="color"
                        value={config[k]}
                        onChange={(e) => update(k, e.target.value)}
                      />
                    </label>
                  ))}
                </div>
                <div className="control-group">
                  <h3>Form & Oberfläche</h3>
                  {range('radius', 'Rundung', 0, 40, 'px')}
                  {range('opacity', 'Deckkraft', 0, 100, '%')}
                  {toggle('glow', 'Sanfter Glow')}
                </div>
                <div className="control-group">
                  <h3>Typografie</h3>
                  <Picker
                    label="Schrift"
                    value={config.titleFont}
                    options={[
                      ...FONT_LIBRARY.map(
                        (f) =>
                          [f.id, f.name + ' · ' + f.category] as [
                            string,
                            string,
                          ],
                      ),
                      ...customFonts.map(
                        (f) =>
                          ['custom:' + f.id, f.name + ' · Custom'] as [
                            string,
                            string,
                          ],
                      ),
                    ]}
                    onChange={(v) => update('titleFont', v)}
                  />
                  <button
                    type="button"
                    className="upload-font-button"
                    onClick={() => {
                      setPendingUploadTarget('title');
                      fileInputRef.current?.click();
                    }}
                  >
                    <Plus size={13} />
                    Custom Font hochladen
                  </button>
                  {uploading && <p className="upload-status">Uploading…</p>}
                  {range('titleSize', 'Titelgröße', 14, 48, 'px')}
                </div>
              </TabsContent>
              <TabsContent value="elements">
                <div className="control-group">
                  <h3>Was dein Overlay zeigt</h3>
                  {toggle('cover', 'Albumcover')}
                  {toggle('artist', 'Künstler')}
                  {toggle('progress', 'Fortschrittsbalken')}
                  {toggle('badge', 'Wiedergabestatus')}
                  {config.layout === 'memory' && (
                    <>
                      <label className="memory-label-editor">
                        <span>Beschriftung des Speicherstands</span>
                        <input
                          value={config.memoryLabel}
                          maxLength={32}
                          placeholder="GOOD MUSIC BETTER DAYS."
                          onChange={(e) =>
                            update('memoryLabel', e.target.value)
                          }
                        />
                        <small>Zum Beispiel: CHILL, GYM oder LATE NIGHT</small>
                      </label>
                      <div className="editor-entry-list">
                        {[
                          'device',
                          'cover',
                          'display',
                          'title',
                          'artist',
                          'display-meta',
                          'progress',
                          'controls',
                          'led',
                          'note',
                        ].map((element) => (
                          <button
                            key={element}
                            className="editor-entry"
                            onClick={() => setSelectedElement(element)}
                          >
                            <i className="editor-entry-dot" />
                            <span className="editor-entry-name">
                              {EDITOR_NAMES[element]}
                            </span>
                            <span className="editor-entry-hint">
                              Bearbeiten
                            </span>
                          </button>
                        ))}
                      </div>
                      <div className="playlist-picker">
                        <span>Observed Playlist</span>
                        <Select
                          value={config.observedPlaylistId}
                          onValueChange={(v) => {
                            if (!v || v === '__none__') {
                              update('observedPlaylistId', '');
                              update('observedPlaylistName', '');
                            } else {
                              const p = playlists.find((p) => p.id === v);
                              update('observedPlaylistId', v);
                              update('observedPlaylistName', p?.name || '');
                            }
                          }}
                        >
                          <SelectTrigger aria-label="Observed Playlist">
                            <SelectValue>
                              {config.observedPlaylistId
                                ? playlists.find(
                                    (p) => p.id === config.observedPlaylistId,
                                  )?.name || config.observedPlaylistName
                                : 'Keine Playlist'}
                            </SelectValue>
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="__none__">
                              Keine Playlist
                            </SelectItem>
                            {playlists.map((p) => (
                              <SelectItem
                                key={p.id}
                                value={p.id}
                                disabled={!canObserve(p)}
                              >
                                {p.image && (
                                  <img
                                    src={p.image}
                                    alt=""
                                    className="playlist-cover"
                                  />
                                )}
                                {p.name}
                                {!canObserve(p) && (
                                  <Lock
                                    size={12}
                                    className="playlist-access-mark"
                                  />
                                )}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {!connected && (
                          <small>
                            Verbinde Spotify, um eine Playlist auszuwählen.
                          </small>
                        )}
                        {config.observedPlaylistId &&
                          selectedObserved &&
                          !canObserve(selectedObserved) && (
                            <small className="playlist-access-warn">
                              Only owned or collaborative playlists can be
                              observed.
                            </small>
                          )}
                        {track?.playlistAccess === 'denied' && (
                          <small className="playlist-access-warn">
                            No access to this playlist
                          </small>
                        )}
                        {track?.playlistAccess === 'rate_limited' && (
                          <small className="playlist-access-warn">
                            Spotify rate limit – playlist status will refresh
                            automatically.
                          </small>
                        )}
                        {/* NEU: Info-Hinweis */}
                        <div className="playlist-api-hint">
                          <Info size={13} className="playlist-api-hint-icon" />
                          <span>
                            <strong>Spotify-Limit beim Memory Slot</strong>
                            <br />
                            Dieser Player fragt Spotify häufiger ab, damit
                            Playlist-Markierungen möglichst aktuell bleiben.
                            Wenn Spotify sein API-Limit erreicht, kann die
                            Gold-Markierung eine Weile nicht aktualisiert
                            werden. Resonance trennt dabei nicht deine
                            Verbindung. Sobald Spotify den Zugriff wieder
                            erlaubt, läuft alles automatisch weiter.
                          </span>
                        </div>
                      </div>
                    </>
                  )}
                </div>
                <div className="control-group">
                  <h3>Größe & Abstände</h3>
                  {range('width', 'Breite', 280, 900, 'px')}
                  {range('spacing', 'Innenabstand', 8, 48, 'px')}
                  <Picker
                    label="Textausrichtung"
                    value={config.align}
                    options={[
                      ['left', 'Links'],
                      ['center', 'Zentriert'],
                    ]}
                    onChange={(v) => update('align', v)}
                  />
                </div>
              </TabsContent>
              <TabsContent value="motion">
                <div className="control-group">
                  <h3>Beim Songwechsel</h3>
                  <Picker
                    label="Übergang"
                    value={config.animation}
                    options={[
                      ['fade', 'Sanft einblenden'],
                      ['slide', 'Hineingleiten'],
                      ['zoom', 'Pop-in'],
                      ['blur', 'Aus der Unschärfe'],
                      ['flip', '3D-Flip'],
                      ['none', 'Ohne Animation'],
                    ]}
                    onChange={(v) => update('animation', v)}
                  />
                  <p className="motion-help">
                    Wird bei jedem neuen Titel abgespielt.
                  </p>
                  {toggle('hidePaused', 'Bei Pause ausblenden')}
                  {toggle('spin', 'Cover drehen')}
                  {config.spin &&
                    range('spinSpeed', 'Eine Umdrehung', 4, 40, 's')}
                </div>
                <div className="control-group">
                  <h3>Vorschau testen</h3>
                  <button
                    className="secondary"
                    onClick={() => {
                      setDemoMode(true);
                      setDemoIndex((i) => (i + 1) % moodDemos.length);
                    }}
                  >
                    <RefreshCw size={14} />
                    Songwechsel testen
                  </button>
                  <button
                    className="secondary"
                    onClick={() => {
                      setDemoMode(true);
                      setDemoPlaying((p) => !p);
                    }}
                  >
                    {demoPlaying ? <Pause size={14} /> : <Play size={14} />}Demo{' '}
                    {demoPlaying ? 'pausieren' : 'fortsetzen'}
                  </button>
                </div>
              </TabsContent>
            </Tabs>
          )}
          <div className="save-row">
            <button
              type="button"
              className="icon-button"
              onClick={undo}
              disabled={!historyPast.length}
              aria-label="Undo (Ctrl+Z)"
              title="Undo (Ctrl+Z)"
            >
              <RotateCcw size={16} />
            </button>
            <button
              type="button"
              className="icon-button"
              onClick={redo}
              disabled={!historyFuture.length}
              aria-label="Redo (Ctrl+Y)"
              title="Redo (Ctrl+Y)"
            >
              <RotateCcw size={16} style={{ transform: 'scaleX(-1)' }} />
            </button>
            <button
              className="primary"
              disabled={busy || !ready || !dirty}
              onClick={save}
            >
              <Save size={16} />
              {busy ? 'Speichert …' : 'Design speichern'}
            </button>
            <button
              className="icon-button"
              title="Aktuellen Look zurücksetzen"
              aria-label="Aktuellen Look zurücksetzen"
              onClick={() => setConfig({ ...(chosen?.config || defaults) })}
            >
              <RotateCcw size={17} />
            </button>
          </div>
          <p className="save-hint">
            {!ready
              ? 'Studio wird verbunden …'
              : dirty
                ? 'Ungespeicherte Änderungen'
                : 'Gespeichert · bereit für deinen Stream'}
          </p>
          <button
            className="connection-card"
            onClick={() => setModal('spotify')}
          >
            <Music2 size={21} />
            <div>
              <b>{connected ? 'Spotify verbunden' : 'Deine Musik, live.'}</b>
              <p>
                {connected
                  ? 'Verbindung verwalten'
                  : 'Spotify-Account verbinden'}
              </p>
            </div>
            <ArrowUpRight size={18} />
          </button>
          <div className="inspector-footer">
            <Monitor size={15} /> Für OBS & Streamlabs
          </div>
        </aside>
      </div>
      <Dialog
        open={modal !== null}
        onOpenChange={(open) => !open && setModal(null)}
      >
        <DialogContent className="setup-dialog">
          <DialogTitle>
            {modal === 'spotify'
              ? 'Spotify verbinden'
              : 'Bereit für deinen Stream.'}
          </DialogTitle>
          <DialogDescription>
            {modal === 'spotify'
              ? 'Deine Developer-App ist vorbereitet. Es wird nur der aktuelle Titel gelesen.'
              : 'Speichere dein Design und füge das Overlay als Browser-Quelle in OBS hinzu.'}
          </DialogDescription>
          {modal === 'spotify' ? (
            <>
              <div className="setup-step">
                <span>01</span>
                <div>
                  <h3>Redirect-URI eintragen</h3>
                  <p>
                    Öffne deine App im{' '}
                    <a
                      href="https://developer.spotify.com/dashboard"
                      target="_blank"
                      rel="noreferrer"
                    >
                      Spotify Developer Dashboard ↗
                    </a>
                    . Füge unter Settings diese Redirect-URI hinzu und speichere
                    sie.
                  </p>
                  <div className="copy-field">
                    <input
                      aria-label="Spotify Redirect-URI"
                      readOnly
                      value={spotifyRedirect}
                    />
                    <button
                      aria-label="Redirect-URI kopieren"
                      onClick={() => copy(spotifyRedirect)}
                    >
                      <Copy size={16} />
                    </button>
                  </div>
                </div>
              </div>
              <div className="setup-step">
                <span>02</span>
                <div>
                  <h3>Mit Spotify anmelden</h3>
                  <p>
                    Client-ID: <code>6dde544e…790b338</code>. Bestätige danach
                    den Zugriff in Spotify.
                  </p>
                </div>
              </div>
              <button
                className="primary"
                disabled={busy || !ready}
                onClick={connect}
              >
                <Music2 size={17} />
                {connected
                  ? 'Erneut mit Spotify verbinden'
                  : 'Mit Spotify verbinden'}
              </button>
              {connected && (
                <button
                  className="secondary"
                  disabled={busy}
                  onClick={disconnect}
                >
                  <Unplug size={15} />
                  Spotify trennen
                </button>
              )}
            </>
          ) : (
            <>
              <div className="setup-step">
                <span>01</span>
                <div>
                  <h3>Design übernehmen</h3>
                  <p>
                    {dirty
                      ? 'Dein Entwurf enthält Änderungen. Speichere sie vor dem Kopieren.'
                      : 'Dein aktuelles Design ist gespeichert.'}
                  </p>
                  {dirty && (
                    <button
                      className="secondary"
                      disabled={!ready || busy}
                      onClick={save}
                    >
                      <Save size={15} />
                      Jetzt speichern
                    </button>
                  )}
                </div>
              </div>
              <div className="setup-step">
                <span>02</span>
                <div>
                  <h3>Browser-Quelle hinzufügen</h3>
                  <p>
                    OBS → Quellen → + → Browser. Setze die Breite auf{' '}
                    <b>{config.width + 100} px</b>, die Höhe auf <b>600 px</b>.
                    Die Fläche ist transparent.
                  </p>
                  <div className="copy-field">
                    <input
                      aria-label="OBS Overlay-Adresse"
                      readOnly
                      value={key ? obsUrl : 'Studio wird geladen …'}
                    />
                    <button
                      aria-label="Overlay-Adresse kopieren"
                      disabled={!key || dirty}
                      onClick={() => copy(obsUrl)}
                    >
                      <Copy size={16} />
                    </button>
                  </div>
                </div>
              </div>
              {!connected && (
                <button className="primary" onClick={() => setModal('spotify')}>
                  <Music2 size={17} />
                  Zuerst Spotify verbinden
                </button>
              )}
              {key && (
                <a
                  className="secondary"
                  href={obsUrl}
                  target="_blank"
                  rel="noreferrer"
                >
                  <ExternalLink size={15} />
                  Overlay öffnen
                </a>
              )}
              <p className="privacy-note">
                Der Overlay-Link erlaubt das Lesen deines aktuellen Titels.
                Behalte ihn für dich.
              </p>
              <button
                className="text-button"
                disabled={!ready || busy}
                onClick={async () => {
                  setBusy(true);
                  try {
                    const d = await api('/api/studio', { action: 'rotate' });
                    setKey(d.overlayKey);
                    setMessage(
                      'Neuer Overlay-Link erstellt. Aktualisiere ihn auch in OBS.',
                    );
                  } catch (e) {
                    setError((e as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                <RefreshCw size={13} />
                Neuen Overlay-Link erstellen
              </button>
            </>
          )}
          <div aria-live="polite">
            {error && <p className="error-message">{error}</p>}
            {message && <p className="success-message">{message}</p>}
          </div>
        </DialogContent>
      </Dialog>
      <Dialog
        open={moodSettingsOpen}
        onOpenChange={(open) => !open && setMoodSettingsOpen(false)}
      >
        <DialogContent className="setup-dialog">
          <DialogTitle>Mood Switch Settings</DialogTitle>
          <DialogDescription>
            Optionale Datenquellen für genauere Mood-Erkennung. Ohne Keys
            funktioniert Mood Switch weiterhin.
          </DialogDescription>
          <div className="mood-settings-section">
            <h3>Last.fm</h3>
            <p>Genres, Tags und Metadaten für die Mood-Erkennung.</p>
            <div
              className={
                'mood-settings-status' + (lastfmConfigured ? ' connected' : '')
              }
            >
              {lastfmConfigured ? 'Connected' : 'Not configured'}
            </div>
            <input
              className="mood-settings-input"
              type="password"
              value={lastfmKey}
              placeholder="Last.fm API Key"
              autoComplete="off"
              spellCheck={false}
              onChange={(e) => setLastfmKey(e.target.value)}
            />
            <div className="mood-settings-actions">
              <button
                className="secondary"
                disabled={moodBusy}
                onClick={() => saveMoodCredential('lastfm')}
              >
                <Save size={15} />
                Speichern
              </button>
              <button
                className="secondary"
                disabled={moodBusy}
                onClick={() => testMoodCredential('lastfm')}
              >
                Test Connection
              </button>
              {lastfmConfigured && (
                <button
                  className="text-button"
                  disabled={moodBusy}
                  onClick={() => removeMoodCredential('lastfm')}
                >
                  Entfernen
                </button>
              )}
            </div>
            {lastfmTest && (
              <p className={'mood-settings-test ' + lastfmTest}>
                {lastfmTest === 'testing'
                  ? 'Teste Verbindung …'
                  : lastfmTest === 'connected'
                    ? 'Connected'
                    : lastfmTest === 'invalid'
                      ? 'Invalid key'
                      : 'Dienst nicht erreichbar'}
              </p>
            )}
            <a
              href="https://www.last.fm/api/account/create"
              target="_blank"
              rel="noreferrer"
            >
              How to get a key ↗
            </a>
          </div>
          <div className="mood-settings-section">
            <h3>
              Genius <em>Optional</em>
            </h3>
            <p>Zusätzlicher Lyrics-Fallback für die Mood-Erkennung.</p>
            <div
              className={
                'mood-settings-status' + (geniusConfigured ? ' connected' : '')
              }
            >
              {geniusConfigured ? 'Connected' : 'Not configured'}
            </div>
            <input
              className="mood-settings-input"
              type="password"
              value={geniusToken}
              placeholder="Genius Access Token"
              autoComplete="off"
              spellCheck={false}
              onChange={(e) => setGeniusToken(e.target.value)}
            />
            <div className="mood-settings-actions">
              <button
                className="secondary"
                disabled={moodBusy}
                onClick={() => saveMoodCredential('genius')}
              >
                <Save size={15} />
                Speichern
              </button>
              <button
                className="secondary"
                disabled={moodBusy}
                onClick={() => testMoodCredential('genius')}
              >
                Test Connection
              </button>
              {geniusConfigured && (
                <button
                  className="text-button"
                  disabled={moodBusy}
                  onClick={() => removeMoodCredential('genius')}
                >
                  Entfernen
                </button>
              )}
            </div>
            {geniusTest && (
              <p className={'mood-settings-test ' + geniusTest}>
                {geniusTest === 'testing'
                  ? 'Teste Verbindung …'
                  : geniusTest === 'connected'
                    ? 'Connected'
                    : geniusTest === 'invalid'
                      ? 'Invalid token'
                      : 'Dienst nicht erreichbar'}
              </p>
            )}
            <a
              href="https://genius.com/api-clients"
              target="_blank"
              rel="noreferrer"
            >
              How to get a token ↗
            </a>
          </div>
          <div aria-live="polite">
            {error && <p className="error-message">{error}</p>}
            {message && <p className="success-message">{message}</p>}
          </div>
        </DialogContent>
      </Dialog>
      <Dialog
        open={deleteConfirm !== null}
        onOpenChange={(open) => !open && setDeleteConfirm(null)}
      >
        <DialogContent className="setup-dialog">
          <DialogTitle>Font löschen</DialogTitle>
          <DialogDescription>
            Dieser Font wird aktuell verwendet. Beim Löschen fällt der Player
            auf Inter zurück.
          </DialogDescription>
          <p className="delete-font-name">
            „{deleteConfirm?.name}“ wird gelöscht.
          </p>
          <div className="dialog-actions">
            <button
              className="primary"
              disabled={busy}
              onClick={() => void confirmDeleteFont()}
            >
              Delete and fall back to Inter
            </button>
            <button
              className="secondary"
              disabled={busy}
              onClick={() => setDeleteConfirm(null)}
            >
              Cancel
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </main>
  );
}
