import { db, getStudio, isLocalRequest, json, saveStudioConfig } from '@/lib/server';

// Externe Aktivierung gepinnter Live Looks (Checkpoint 16.23).
// Slot 1–5 entspricht der Reihenfolge der gepinnten LIVE LOOKS
// (ORDER BY pinned_at ASC, identisch zur Studio-UI).
// Die Aktivierung nutzt dieselbe Persistenz wie der Activate-Button
// (saveStudioConfig), damit UI und API exakt denselben Config-Zustand
// erzeugen. Das Overlay erhält den neuen Look über den normalen
// Config-Pfad (/api/now liest row.config).
export async function POST(req: Request) {
  // Local-Only Guard (Checkpoint 16.23.1): Live-Look-Trigger sind bewusst auf
  // lokale Requests beschränkt (localhost, 127.0.0.1, ::1). LAN-/Tailscale-
  // Adressen werden abgelehnt; Remote-Trigger können später mit eigener
  // Authentifizierung ergänzt werden. Die Prüfung nutzt den Request-Host aus
  // dem Server Request Context (isLocalRequest in lib/server.ts) und verlässt
  // sich bewusst NICHT auf einen Browser-Origin-Header, damit auch
  // Nicht-Browser-Clients wie Streamer.bot funktionieren.
  if (!isLocalRequest(req))
    return json(
      {
        ok: false,
        error: 'Live Look triggers are currently limited to local requests.',
      },
      403,
    );
  try {
    const row = await getStudio(req);
    if (!row) return json({ error: 'Studio nicht verfügbar.' }, 401);

    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return json({ error: 'Ungültiger Request Body.' }, 400);
    }
    if (!body || typeof body !== 'object' || Array.isArray(body))
      return json({ error: 'Ungültiger Request Body.' }, 400);

    const slot = (body as Record<string, unknown>).slot;
    if (
      typeof slot !== 'number' ||
      !Number.isInteger(slot) ||
      slot < 1 ||
      slot > 5
    )
      return json({ error: 'Ungültiger Slot. Erlaubt sind 1–5.' }, 400);

    const pinned = await db()
      .prepare(
        'SELECT id, name, config FROM custom_looks WHERE owner=? AND pinned=1 ORDER BY pinned_at ASC, id ASC',
      )
      .bind(row.owner)
      .all<{ id: string; name: string; config: string }>();

    const look = pinned.results[slot - 1];
    if (!look) return json({ error: 'Kein Live Look in diesem Slot.' }, 404);

    let lookConfig: unknown;
    try {
      lookConfig = JSON.parse(look.config);
    } catch {
      return json({ error: 'Gespeicherter Look ist beschädigt.' }, 500);
    }

    await saveStudioConfig(row.owner, lookConfig);

    return json({ ok: true, slot, look: { id: look.id, name: look.name } });
  } catch {
    return json({ error: 'Live Look konnte nicht aktiviert werden.' }, 400);
  }
}
