import {
  getStudio,
  json,
  csrf,
  cleanConfig,
  db,
  random,
  redirectFor,
  isLocalRequest,
  isTailscaleRequest,
  saveStudioConfig,
} from '@/lib/server';
export async function GET(req: Request) {
  if (
    !isLocalRequest(req) &&
    !isTailscaleRequest(req) &&
    !req.headers.get('oai-authenticated-user-id') &&
    !req.headers.get('oai-authenticated-user-email')
  )
    return json({ error: 'Bitte anmelden.' }, 401);
  try {
    const row = await getStudio(req, true);
    if (!row) return json({ error: 'Studio nicht verfügbar.' }, 503);
    return json({
      config: cleanConfig(JSON.parse(row.config)),
      connected: !!row.refresh_token,
      overlayKey: row.overlay_key,
      redirect: redirectFor(req),
    });
  } catch {
    return json(
      {
        error:
          'Studio konnte nicht geladen werden. Bitte anmelden und erneut versuchen.',
      },
      503,
    );
  }
}
export async function POST(req: Request) {
  try {
    csrf(req);
    const row = await getStudio(req);
    if (!row) return json({ error: 'Bitte lade die Seite neu.' }, 401);
    const body = (await req.json()) as { action?: string; config?: unknown };
    if (body.action === 'disconnect') {
      await db()
        .prepare(
          'UPDATE studios SET access_token=NULL,refresh_token=NULL,expires=0,cached=NULL,verifier=NULL,oauth_state=NULL WHERE owner=?',
        )
        .bind(row.owner)
        .run();
      return json({ ok: true });
    }
    if (body.action === 'rotate') {
      const key = random();
      await db()
        .prepare('UPDATE studios SET overlay_key=? WHERE owner=?')
        .bind(key, row.owner)
        .run();
      return json({ overlayKey: key });
    }
    // Save-Safety: Nur vollständige Config-Objekte akzeptieren.
    // Ungültige Payloads (z.B. Strings) dürfen die gespeicherte Config
    // NICHT durch Defaults überschreiben.
    if (
      !body.config ||
      typeof body.config !== 'object' ||
      Array.isArray(body.config)
    )
      return json({ error: 'Ungültige Konfiguration.' }, 400);
    const config = await saveStudioConfig(row.owner, body.config);
    return json({ ok: true, config });
  } catch {
    return json(
      { error: 'Speichern fehlgeschlagen. Bitte erneut versuchen.' },
      400,
    );
  }
}
