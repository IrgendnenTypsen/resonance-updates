import {
  db,
  getStudio,
  json,
  now,
  cleanConfig,
  listCustomFonts,
  type Row,
} from '@/lib/server';
export async function GET(req: Request) {
  try {
    const auth = req.headers.get('authorization');
    const key = auth?.startsWith('Bearer ') ? auth.slice(7) : null;
    const row = key
      ? await db()
          .prepare('SELECT * FROM studios WHERE overlay_key=?')
          .bind(key)
          .first<Row>()
      : await getStudio(req);
    if (!row) return json({ error: 'Overlay nicht gefunden.' }, 401);
    const result = await now(row);
    const customFonts = await listCustomFonts(row.owner);
    return json({
      ...result,
      config: cleanConfig(JSON.parse(row.config)),
      connected: !!row.refresh_token,
      customFonts: customFonts.map((f) => ({
        id: f.id,
        family: f.family,
        format: f.format,
      })),
    });
  } catch (e) {
    return json(
      {
        error: e instanceof Error ? e.message : 'Verbindung unterbrochen.',
        track: null,
      },
      503,
    );
  }
}
