import { cleanConfig, csrf, db, identity, json, random } from '@/lib/server';

export async function GET(req: Request) {
  try {
    const owner = identity(req);
    const result = await db().prepare('SELECT id, name, config, created_at, pinned, pinned_at FROM custom_looks WHERE owner=? ORDER BY CASE WHEN pinned=1 THEN 0 ELSE 1 END, pinned_at ASC, created_at DESC, id ASC').bind(owner).all<{id:string;name:string;config:string;created_at:number;pinned:number;pinned_at:number|null}>();
    return json({ looks: result.results.map((look) => ({ ...look, config: cleanConfig(JSON.parse(look.config)) })) });
  } catch { return json({ error: 'Looks konnten nicht geladen werden.' }, 400); }
}

export async function POST(req: Request) {
  try {
    csrf(req);
    const owner = identity(req);
    const body = await req.json() as { name?: unknown; config?: unknown; import?: unknown; action?: unknown; id?: unknown; pinned?: unknown };
    if (body.action === 'pin' && typeof body.id === 'string' && typeof body.pinned === 'boolean') {
      if (body.pinned) { const count = await db().prepare('SELECT COUNT(*) AS count FROM custom_looks WHERE owner=? AND pinned=1').bind(owner).first<{count:number}>(); if ((count?.count || 0) >= 5) return json({ error: 'Maximal 5 Live Looks.' }, 400); }
      const pinnedAt = body.pinned ? Date.now() : null;
      await db().prepare('UPDATE custom_looks SET pinned=?, pinned_at=? WHERE id=? AND owner=?').bind(body.pinned ? 1 : 0, pinnedAt, body.id, owner).run(); return json({ ok: true, pinned_at: pinnedAt });
    }
    const name = typeof body.name === 'string' ? body.name.trim().slice(0, 50) : '';
    if (!name) return json({ error: 'Bitte gib deinem Look einen Namen.' }, 400);
    if (!body.config || typeof body.config !== 'object' || Array.isArray(body.config)) return json({ error: 'Ungültiger Look.' }, 400);
    const config = cleanConfig(body.config);
    let finalName = name;
    if (body.import) {
      const rows = await db().prepare('SELECT name FROM custom_looks WHERE owner=?').bind(owner).all<{name:string}>();
      const names = new Set(rows.results.map((row) => row.name)); let suffix = 2;
      while (names.has(finalName)) finalName = `${name} (${suffix++})`;
    }
    const id = random(); const now = Date.now();
    await db().prepare('INSERT INTO custom_looks (id,owner,name,config,created_at,updated_at) VALUES (?,?,?,?,?,?)').bind(id,owner,name,JSON.stringify(config),now,now).run();
    return json({ look: { id, name: finalName, config, created_at: now, pinned: 0, pinned_at: null } });
  } catch { return json({ error: 'Look konnte nicht gespeichert werden.' }, 400); }
}

export async function DELETE(req: Request) {
  try {
    csrf(req); const owner = identity(req); const id = new URL(req.url).searchParams.get('id');
    if (!id || !/^[a-f0-9]{64}$/.test(id)) return json({ error: 'Ungültiger Look.' }, 400);
    await db().prepare('DELETE FROM custom_looks WHERE id=? AND owner=?').bind(id,owner).run();
    return json({ ok: true });
  } catch { return json({ error: 'Look konnte nicht gelöscht werden.' }, 400); }
}
