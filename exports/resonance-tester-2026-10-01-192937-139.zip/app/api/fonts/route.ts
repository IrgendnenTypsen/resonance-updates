import {
  getStudio,
  json,
  csrf,
  random,
  listCustomFonts,
  insertCustomFont,
  findCustomFontByHash,
  detectFontFormat,
} from '@/lib/server';

const MAX_FONT_SIZE = 5 * 1024 * 1024; // 5 MB

async function sha256(data: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest(
    'SHA-256',
    data.buffer as ArrayBuffer,
  );
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, '0')).join('');
}

export async function GET(req: Request) {
  try {
    const row = await getStudio(req);
    if (!row) return json({ error: 'Bitte lade die Seite neu.' }, 401);
    const fonts = await listCustomFonts(row.owner);
    return json({ fonts });
  } catch {
    return json(
      { error: 'Fonts konnten nicht geladen werden.' },
      503,
    );
  }
}

export async function POST(req: Request) {
  try {
    csrf(req);
    const row = await getStudio(req);
    if (!row) return json({ error: 'Bitte lade die Seite neu.' }, 401);
    const form = await req.formData();
    const file = form.get('file');
    if (!(file instanceof File)) {
      return json({ error: 'Keine Datei ausgewählt.' }, 400);
    }
    if (file.size > MAX_FONT_SIZE) {
      return json({ error: 'Font file is too large.' }, 413);
    }
    const data = new Uint8Array(await file.arrayBuffer());
    const format = detectFontFormat(data);
    if (!format) {
      return json({ error: 'Unsupported font format.' }, 400);
    }
    const hash = await sha256(data);
    const existing = await findCustomFontByHash(row.owner, hash);
    if (existing) {
      return json({
        ok: true,
        duplicate: true,
        font: existing,
        message: 'Font already uploaded.',
      });
    }
    const id = random();
    const family = 'ResonanceCustom_' + id;
    const originalFilename = file.name || 'font.' + format;
    const name =
      originalFilename.replace(/\.[^.]+$/, '').trim().slice(0, 64) ||
      'Custom Font';
    const createdAt = Date.now();
    await insertCustomFont({
      id,
      owner: row.owner,
      name,
      originalFilename,
      format,
      family,
      data: data.buffer as ArrayBuffer,
      size: data.byteLength,
      hash,
      createdAt,
    });
    return json({
      ok: true,
      font: { id, name, format, family, size: data.byteLength, createdAt },
    });
  } catch {
    return json(
      { error: 'Upload fehlgeschlagen. Bitte erneut versuchen.' },
      400,
    );
  }
}