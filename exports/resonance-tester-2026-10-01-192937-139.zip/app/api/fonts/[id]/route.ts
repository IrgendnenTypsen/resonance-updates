import { getStudio, json, csrf, deleteCustomFont } from '@/lib/server';

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    csrf(req);
    const row = await getStudio(req);
    if (!row) return json({ error: 'Bitte lade die Seite neu.' }, 401);
    const { id } = await params;
    if (!/^[0-9a-f]{64}$/.test(id))
      return json({ error: 'Font nicht gefunden.' }, 404);
    await deleteCustomFont(id, row.owner);
    return json({ ok: true });
  } catch {
    return json(
      { error: 'Löschen fehlgeschlagen. Bitte erneut versuchen.' },
      400,
    );
  }
}