import { getCustomFont } from '@/lib/server';

const CONTENT_TYPES: Record<string, string> = {
  woff2: 'font/woff2',
  woff: 'font/woff',
  ttf: 'font/ttf',
  otf: 'font/otf',
};

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  // Sicherheit: Nur gültige zufällige IDs (64 Hex-Zeichen) werden akzeptiert.
  // Die ID ist nicht erratbar (random(), wie overlay_key) – OBS greift ohne
  // weitere Auth zu, fremde Studios können die ID nicht erraten.
  if (!/^[0-9a-f]{64}$/.test(id))
    return new Response('Not found', { status: 404 });
  const row = await getCustomFont(id);
  if (!row) return new Response('Not found', { status: 404 });
  const bytes =
    row.data instanceof Uint8Array
      ? row.data
      : row.data instanceof ArrayBuffer
        ? new Uint8Array(row.data)
        : Array.isArray(row.data)
          ? Uint8Array.from(row.data)
          : null;
  if (!bytes || bytes.byteLength === 0)
    return new Response('Font data unavailable', { status: 500 });
  const contentType = CONTENT_TYPES[row.format] || 'application/octet-stream';
  // Response accepts an ArrayBuffer in both the browser and Workers typings.
  // Copy into a plain ArrayBuffer so D1's Array<number> representation and
  // TypeScript's Uint8Array<ArrayBufferLike> do not leak into the response.
  const body = Uint8Array.from(bytes).buffer;
  return new Response(body, {
    headers: {
      'Content-Type': contentType,
      'Cache-Control': 'public, max-age=31536000, immutable',
    },
  });
}
