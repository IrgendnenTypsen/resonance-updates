import {
  getStudio,
  getMoodCredentials,
  json,
  csrf,
} from '@/lib/server';

export async function POST(req: Request) {
  try {
    csrf(req);
    const row = await getStudio(req);
    if (!row) return json({ error: 'Bitte lade die Seite neu.' }, 401);
    const body = (await req.json()) as { provider?: unknown };
    const provider = body.provider;
    if (provider !== 'lastfm' && provider !== 'genius')
      return json({ error: 'Ungültiger Anbieter.' }, 400);

    const creds = await getMoodCredentials(row.owner);

    if (provider === 'lastfm') {
      if (!creds.lastfmApiKey)
        return json({ provider, status: 'unavailable' });
      try {
        const url =
          'https://ws.audioscrobbler.com/2.0/?method=track.getTopTags&artist=test&track=test&api_key=' +
          encodeURIComponent(creds.lastfmApiKey) +
          '&format=json';
        const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
        if (!r.ok) return json({ provider, status: 'unavailable' });
        const d = (await r.json()) as { error?: unknown };
        if (d.error) return json({ provider, status: 'invalid' });
        return json({ provider, status: 'connected' });
      } catch {
        return json({ provider, status: 'unavailable' });
      }
    }

    // Genius
    if (!creds.geniusAccessToken)
      return json({ provider, status: 'unavailable' });
    try {
      const r = await fetch('https://api.genius.com/search?q=test', {
        headers: { Authorization: 'Bearer ' + creds.geniusAccessToken },
        signal: AbortSignal.timeout(8000),
      });
      if (r.status === 401) return json({ provider, status: 'invalid' });
      if (r.ok) return json({ provider, status: 'connected' });
      return json({ provider, status: 'unavailable' });
    } catch {
      return json({ provider, status: 'unavailable' });
    }
  } catch {
    return json(
      { error: 'Verbindungstest fehlgeschlagen. Bitte erneut versuchen.' },
      400,
    );
  }
}