import {
  getStudio,
  getMoodCredentials,
  setMoodCredentials,
  json,
  csrf,
} from '@/lib/server';

const MAX_KEY_LENGTH = 128;

export async function GET(req: Request) {
  try {
    const row = await getStudio(req);
    if (!row) return json({ error: 'Bitte lade die Seite neu.' }, 401);
    const creds = await getMoodCredentials(row.owner);
    return json({
      lastfmConfigured: !!creds.lastfmApiKey,
      geniusConfigured: !!creds.geniusAccessToken,
    });
  } catch {
    return json(
      { error: 'Mood-Einstellungen konnten nicht geladen werden.' },
      503,
    );
  }
}

export async function POST(req: Request) {
  try {
    csrf(req);
    const row = await getStudio(req);
    if (!row) return json({ error: 'Bitte lade die Seite neu.' }, 401);
    const body = (await req.json()) as {
      lastfmApiKey?: unknown;
      geniusAccessToken?: unknown;
    };
    const creds: { lastfmApiKey?: string; geniusAccessToken?: string } = {};
    if (typeof body.lastfmApiKey === 'string')
      creds.lastfmApiKey = body.lastfmApiKey.trim().slice(0, MAX_KEY_LENGTH);
    if (typeof body.geniusAccessToken === 'string')
      creds.geniusAccessToken = body.geniusAccessToken
        .trim()
        .slice(0, MAX_KEY_LENGTH);
    if (!('lastfmApiKey' in creds) && !('geniusAccessToken' in creds))
      return json({ error: 'Ungültige Anfrage.' }, 400);
    await setMoodCredentials(row.owner, creds);
    const saved = await getMoodCredentials(row.owner);
    return json({
      ok: true,
      lastfmConfigured: !!saved.lastfmApiKey,
      geniusConfigured: !!saved.geniusAccessToken,
    });
  } catch {
    return json(
      { error: 'Speichern fehlgeschlagen. Bitte erneut versuchen.' },
      400,
    );
  }
}