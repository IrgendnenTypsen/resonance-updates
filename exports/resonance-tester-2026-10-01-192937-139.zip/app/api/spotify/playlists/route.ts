import { getStudio, json, freshAccess } from '@/lib/server';

export async function GET(req: Request) {
  try {
    const row = await getStudio(req);
    if (!row) return json({ error: 'Bitte anmelden.' }, 401);
    if (!row.refresh_token)
      return json({ error: 'Spotify ist nicht verbunden.' }, 400);
    const access = await freshAccess(row);
    if (!access) return json({ error: 'Spotify ist nicht verbunden.' }, 400);
    const meR = await fetch('https://api.spotify.com/v1/me', {
      headers: { Authorization: 'Bearer ' + access },
      signal: AbortSignal.timeout(10000),
    });
    if (!meR.ok)
      return json(
        { error: 'Spotify-Profil konnte nicht geladen werden.' },
        502,
      );
    const me = (await meR.json()) as { id?: string };
    const playlists: {
      id: string;
      name: string;
      image?: string;
      owner?: { id?: string };
      collaborative?: boolean;
    }[] = [];
    let url: string | null = 'https://api.spotify.com/v1/me/playlists?limit=50';
    while (url) {
      const r = await fetch(url, {
        headers: { Authorization: 'Bearer ' + access },
        signal: AbortSignal.timeout(10000),
      });
      if (!r.ok)
        return json(
          { error: 'Spotify-Playlists konnten nicht geladen werden.' },
          502,
        );
      const d = (await r.json()) as {
        items?: {
          id?: string;
          name?: string;
          images?: { url?: string }[];
          owner?: { id?: string };
          collaborative?: boolean;
        }[];
        next?: string | null;
      };
      for (const item of d.items || []) {
        if (!item.id) continue;
        playlists.push({
          id: item.id,
          name: item.name || '',
          image: item.images?.[0]?.url,
          owner: item.owner,
          collaborative: item.collaborative === true,
        });
      }
      url = d.next;
    }
    return json({ currentUserId: me.id || '', playlists });
  } catch (e) {
    return json(
      {
        error:
          e instanceof Error
            ? e.message
            : 'Spotify-Playlists konnten nicht geladen werden.',
      },
      503,
    );
  }
}