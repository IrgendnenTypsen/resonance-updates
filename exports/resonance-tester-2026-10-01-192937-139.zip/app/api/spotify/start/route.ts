import {
  getStudio,
  json,
  csrf,
  random,
  db,
  CLIENT_ID,
  redirectFor,
} from '@/lib/server';
export async function POST(req: Request) {
  try {
    csrf(req);
    const row = await getStudio(req, true);
    if (!row) return json({ error: 'Studio nicht verfügbar.' }, 503);
    const verifier = random(),
      state = random();
    const digest = await crypto.subtle.digest(
      'SHA-256',
      new TextEncoder().encode(verifier),
    );
    const challenge = btoa(String.fromCharCode(...new Uint8Array(digest)))
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
    await db()
      .prepare(
        'UPDATE studios SET verifier=?,oauth_state=?,oauth_expires=? WHERE owner=?',
      )
      .bind(verifier, state, Date.now() + 600000, row.owner)
      .run();
    const url = new URL('https://accounts.spotify.com/authorize');
    const redirect = redirectFor(req);
    url.search = new URLSearchParams({
      response_type: 'code',
      client_id: CLIENT_ID,
      redirect_uri: redirect,
      scope:
        'user-read-currently-playing user-library-read playlist-read-private playlist-read-collaborative',
      code_challenge_method: 'S256',
      code_challenge: challenge,
      state,
    }).toString();
    return json({ url: url.toString() });
  } catch {
    return json(
      { error: 'Spotify-Anmeldung konnte nicht gestartet werden.' },
      503,
    );
  }
}
