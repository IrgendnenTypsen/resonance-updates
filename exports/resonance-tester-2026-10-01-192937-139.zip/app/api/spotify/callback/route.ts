import {
  getStudio,
  db,
  CLIENT_ID,
  redirectFor,
  requestOrigin,
} from '@/lib/server';
export async function GET(req: Request) {
  const origin = requestOrigin(req);
  const redirect = redirectFor(req);
  const finish = (status: string) =>
    Response.redirect(origin + '/?spotify=' + status, 303);
  try {
    const url = new URL(req.url);
    const row = await getStudio(req);
    if (
      !row ||
      !row.oauth_state ||
      url.searchParams.get('state') !== row.oauth_state ||
      row.oauth_expires < Date.now() ||
      !row.verifier
    )
      return finish('expired');
    const consumed = await db()
      .prepare(
        'UPDATE studios SET oauth_state=NULL,verifier=NULL,oauth_expires=0 WHERE owner=? AND oauth_state=?',
      )
      .bind(row.owner, row.oauth_state)
      .run();
    if (!consumed.meta.changes) return finish('expired');
    if (url.searchParams.has('error')) return finish('cancelled');
    const code = url.searchParams.get('code');
    if (!code) return finish('failed');
    const res = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: CLIENT_ID,
        grant_type: 'authorization_code',
        code,
        redirect_uri: redirect,
        code_verifier: row.verifier,
      }),
      signal: AbortSignal.timeout(10000),
    });
    if (!res.ok) return finish('token');
    const token = (await res.json()) as {
      access_token: string;
      refresh_token: string;
      expires_in: number;
    };
    if (!token.access_token || !token.refresh_token) return finish('failed');
    await db()
      .prepare(
        'UPDATE studios SET access_token=?,refresh_token=?,expires=?,cached=NULL,polled=0,retry_at=0 WHERE owner=?',
      )
      .bind(
        token.access_token,
        token.refresh_token,
        Date.now() + token.expires_in * 1000,
        row.owner,
      )
      .run();
    return finish('connected');
  } catch {
    return finish('failed');
  }
}
