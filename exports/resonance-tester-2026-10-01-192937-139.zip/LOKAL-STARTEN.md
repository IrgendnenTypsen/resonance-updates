# RESONANCE lokal starten

## Einmalig in Spotify eintragen

Öffne deine App im [Spotify Developer Dashboard](https://developer.spotify.com/dashboard), gehe zu **Settings** und füge diese Redirect-URI exakt hinzu:

```text
http://127.0.0.1:3000/api/spotify/callback
```

Speichere die Änderung im Dashboard.

## App starten

1. Doppelklicke auf `Start-Resonance.cmd`.
2. Lass das schwarze Fenster geöffnet.
3. Öffne `http://127.0.0.1:3000` im Browser.
4. Klicke in RESONANCE auf **Spotify verbinden**.

Beim ersten Start werden fehlende Pakete automatisch installiert. Dafür werden Node.js 22 oder neuer und eine Internetverbindung benötigt.

## In OBS verwenden

Öffne im Studio **OBS einrichten**, kopiere die dort erzeugte Overlay-Adresse und füge sie in OBS als Browser-Quelle ein. RESONANCE und das Startfenster müssen während des Streams geöffnet bleiben.

## Beenden

Klicke in das Startfenster und drücke `Strg+C` oder schließe das Fenster.

## An andere weitergeben

Gib den kompletten Projektordner ohne `node_modules`, `.wrangler` und `.npm-cache` weiter. Die andere Person startet ebenfalls `Start-Resonance.cmd`; Einstellungen und Spotify-Tokens bleiben in ihrer lokalen `.wrangler`-Datenbank auf ihrem eigenen Rechner.

Solange die Spotify-App im Development Mode läuft, muss jede weitere Person im Spotify Dashboard unter **Users Management** freigeschaltet sein. Spotify erlaubt dort derzeit bis zu fünf Nutzer und verlangt für Development-Mode-Apps ein Premium-Konto beim App-Eigentümer.
