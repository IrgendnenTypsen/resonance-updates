[CmdletBinding()]
param(
  [string]$ManifestUrl,
  [switch]$TestOnly,
  [switch]$TestMode
)

$ErrorActionPreference = 'Stop'
$UpdaterVersion = 1
$InstallRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProtectedPaths = @('.wrangler', '.npm-cache', '.env', 'node_modules', 'resonance-update.json', 'update.log')
$TempRoot = Join-Path ([System.IO.Path]::GetTempPath()) 'ResonanceUpdater'
$LogPath = Join-Path $InstallRoot 'update.log'

function Write-UpdateLog {
  param([string]$Message)
  $line = "$(Get-Date -Format o) $Message"
  Add-Content -LiteralPath $LogPath -Value $line -Encoding utf8
  $existing = Get-Content -LiteralPath $LogPath -ErrorAction SilentlyContinue
  if ($existing.Count -gt 300) {
    Set-Content -LiteralPath $LogPath -Value ($existing | Select-Object -Last 300) -Encoding utf8
  }
}

function Stop-WithMessage {
  param([string]$Message)
  Write-Host "`n  $Message" -ForegroundColor Red
  Write-UpdateLog "ERROR: $Message"
  exit 1
}

function Test-SafeRelativePath {
  param([string]$Path)
  if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
  $normalized = $Path.Replace('\', '/')
  return $normalized -notmatch '(^/|^[A-Za-z]:|(^|/)\.\.(/|$)|//)'
}

function Test-ProtectedPath {
  param([string]$Path)
  $normalized = $Path.Replace('\', '/').TrimStart('/')
  foreach ($protected in $ProtectedPaths) {
    if ($normalized -eq $protected -or $normalized.StartsWith("$protected/", [StringComparison]::OrdinalIgnoreCase)) {
      return $true
    }
  }
  return $false
}

function Get-Sha256 {
  param([string]$Path)
  return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Read-JsonFile {
  param([string]$Path, [string]$Label)
  try {
    return Get-Content -LiteralPath $Path -Raw -Encoding utf8 | ConvertFrom-Json
  } catch {
    throw "$Label ist ungültig."
  }
}

function Get-ConfiguredManifestUrl {
  if ($ManifestUrl) { return $ManifestUrl }
  $configPath = Join-Path $InstallRoot 'resonance-update.json'
  if (-not (Test-Path -LiteralPath $configPath)) {
    throw 'Updater-Konfiguration fehlt. Lege resonance-update.json mit einer Manifest-URL an.'
  }
  $config = Read-JsonFile $configPath 'Updater-Konfiguration'
  if ($config.updaterVersion -ne $UpdaterVersion -or [string]::IsNullOrWhiteSpace($config.manifestUrl)) {
    throw 'Keine Update-Quelle konfiguriert. Trage eine öffentliche HTTPS-Manifest-URL in resonance-update.json ein.'
  }
  return [string]$config.manifestUrl
}

function Get-AllowedUri {
  param([string]$Value, [string]$Label)
  try { $uri = [Uri]$Value } catch { throw "$Label ist keine gültige URL." }
  $localHttp = $uri.Scheme -eq 'http' -and @('localhost', '127.0.0.1', '::1') -contains $uri.Host
  if ($uri.Scheme -ne 'https' -and $uri.Scheme -ne 'file' -and -not $localHttp) {
    throw "$Label muss HTTPS verwenden. file:// und localhost sind nur für lokale Tests erlaubt."
  }
  return $uri
}

function Receive-UpdateFile {
  param([Uri]$Uri, [string]$Destination)
  if ($Uri.Scheme -eq 'file') {
    Copy-Item -LiteralPath $Uri.LocalPath -Destination $Destination -Force
  } else {
    Invoke-WebRequest -Uri $Uri.AbsoluteUri -OutFile $Destination -UseBasicParsing
  }
}

function Get-ManagedFiles {
  $path = Join-Path $InstallRoot 'resonance-files.json'
  if (-not (Test-Path -LiteralPath $path)) { return @() }
  $manifest = Read-JsonFile $path 'Lokales Dateimanifest'
  if ($manifest.schemaVersion -ne 1 -or -not $manifest.files) { return @() }
  return @($manifest.files | Where-Object { $_ -is [string] -and (Test-SafeRelativePath $_) -and -not (Test-ProtectedPath $_) })
}

function Test-ResonanceRunning {
  try {
    $processes = Get-CimInstance Win32_Process -Filter "Name='node.exe'"
  } catch {
    throw 'Der laufende Resonance-Prozess konnte nicht sicher geprüft werden. Bitte Resonance schließen und erneut starten.'
  }
  foreach ($process in $processes) {
    if ($process.CommandLine -and $process.CommandLine.IndexOf($InstallRoot, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
      return $true
    }
  }
  return $false
}

function Extract-ValidatedZip {
  param([string]$ZipPath, [string]$StagePath, [string]$ExpectedVersion)
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  try {
    $archive = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
  } catch {
    throw 'Update-ZIP ist beschädigt oder nicht lesbar.'
  }
  try {
    $entries = @($archive.Entries | Where-Object { -not $_.FullName.EndsWith('/') })
    $names = @($entries | ForEach-Object { $_.FullName.Replace('\', '/') })
    foreach ($name in $names) {
      if (-not (Test-SafeRelativePath $name)) { throw "ZIP enthält einen unsicheren Pfad: $name" }
    }
    foreach ($required in @('package.json', 'Start-Resonance.cmd', 'resonance-version.json', 'resonance-files.json')) {
      if ($names -notcontains $required) { throw "ZIP enthält $required nicht." }
    }
    New-Item -ItemType Directory -Path $StagePath -Force | Out-Null
    $stageRoot = [System.IO.Path]::GetFullPath($StagePath).TrimEnd([System.IO.Path]::DirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar
    foreach ($entry in $entries) {
      $relative = $entry.FullName.Replace('\', '/')
      $destination = [System.IO.Path]::GetFullPath((Join-Path $StagePath $relative))
      if (-not $destination.StartsWith($stageRoot, [StringComparison]::OrdinalIgnoreCase)) {
        throw "ZIP-Pfad verlässt das Staging-Verzeichnis: $relative"
      }
      [System.IO.Directory]::CreateDirectory([System.IO.Path]::GetDirectoryName($destination)) | Out-Null
      $input = $entry.Open()
      $output = [System.IO.File]::Open($destination, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write)
      try { $input.CopyTo($output) } finally { $output.Dispose(); $input.Dispose() }
    }
  } finally {
    $archive.Dispose()
  }

  $version = Read-JsonFile (Join-Path $StagePath 'resonance-version.json') 'ZIP-Version'
  if ($version.version -ne $ExpectedVersion) { throw 'ZIP-Version entspricht nicht dem Update-Manifest.' }
  $files = Read-JsonFile (Join-Path $StagePath 'resonance-files.json') 'ZIP-Dateimanifest'
  if ($files.schemaVersion -ne 1 -or -not $files.files) { throw 'ZIP-Dateimanifest ist ungültig.' }
  foreach ($file in @($files.files)) {
    if ($file -isnot [string] -or -not (Test-SafeRelativePath $file) -or -not (Test-Path -LiteralPath (Join-Path $StagePath $file))) {
      throw 'ZIP-Dateimanifest enthält einen ungültigen oder fehlenden Eintrag.'
    }
  }
  return @($files.files)
}

function Restore-Backup {
  param([string]$BackupPath, [string[]]$IncomingPaths, [string[]]$PreviousPaths, [bool]$NodeModulesMoved)
  Write-UpdateLog 'ROLLBACK gestartet.'
  foreach ($relative in $IncomingPaths) {
    if (Test-ProtectedPath $relative) { continue }
    $target = Join-Path $InstallRoot $relative
    if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force -ErrorAction SilentlyContinue }
  }
  foreach ($relative in $PreviousPaths) {
    if (Test-ProtectedPath $relative) { continue }
    $source = Join-Path $BackupPath $relative
    if (-not (Test-Path -LiteralPath $source)) { continue }
    $target = Join-Path $InstallRoot $relative
    New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
    Copy-Item -LiteralPath $source -Destination $target -Force
  }
  if ($NodeModulesMoved) {
    $newModules = Join-Path $InstallRoot 'node_modules'
    $oldModules = Join-Path $BackupPath 'node_modules'
    if (Test-Path -LiteralPath $newModules) { Remove-Item -LiteralPath $newModules -Recurse -Force -ErrorAction SilentlyContinue }
    if (Test-Path -LiteralPath $oldModules) { Move-Item -LiteralPath $oldModules -Destination $newModules -Force }
  }
  Write-UpdateLog 'ROLLBACK abgeschlossen.'
}

try {
  Set-Location -LiteralPath $InstallRoot
  Write-UpdateLog 'Update-Prüfung gestartet.'
  if ((-not $TestMode) -and (Test-ResonanceRunning)) { throw 'Resonance läuft noch. Bitte Resonance schließen und Update erneut starten.' }
  if ($TestMode) { Write-UpdateLog 'TestMode: Laufzeitprüfung explizit übersprungen.' }

  $localVersionFile = Join-Path $InstallRoot 'resonance-version.json'
  if (-not (Test-Path -LiteralPath $localVersionFile)) { throw 'Lokale resonance-version.json fehlt. Diese Installation kann nicht sicher aktualisiert werden.' }
  $localVersion = Read-JsonFile $localVersionFile 'Lokale Versionsdatei'
  if ($localVersion.version -notmatch '^\d{4}\.\d{2}\.\d{2}\.\d{6}\.\d{3}$') { throw 'Lokale Versionsdatei ist ungültig.' }

  $manifestUri = Get-AllowedUri (Get-ConfiguredManifestUrl) 'Manifest-URL'
  $updateWork = Join-Path $TempRoot ([Guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $updateWork -Force | Out-Null
  $manifestFile = Join-Path $updateWork 'resonance-latest.json'
  Receive-UpdateFile $manifestUri $manifestFile
  $manifest = Read-JsonFile $manifestFile 'Update-Manifest'
  if ($manifest.schemaVersion -ne 1 -or $manifest.minimumUpdaterVersion -gt $UpdaterVersion -or $manifest.version -notmatch '^\d{4}\.\d{2}\.\d{2}\.\d{6}\.\d{3}$' -or $manifest.sha256 -notmatch '^[a-fA-F0-9]{64}$' -or $manifest.file -notmatch '^resonance-tester-[A-Za-z0-9.-]+\.zip$' -or [int64]$manifest.size -le 0) {
    throw 'Update-Manifest ist ungültig oder wird von diesem Updater nicht unterstützt.'
  }
  $comparison = [string]::CompareOrdinal([string]$manifest.version, [string]$localVersion.version)
  if ($comparison -eq 0) { Write-Host "`n  Resonance ist bereits aktuell ($($localVersion.version))." -ForegroundColor Green; Write-UpdateLog 'Bereits aktuell.'; exit 0 }
  if ($comparison -lt 0) { Write-Host "`n  Das angebotene Update ist älter. Kein Downgrade durchgeführt." -ForegroundColor Yellow; Write-UpdateLog 'Ältere Remote-Version ignoriert.'; exit 0 }

  Write-Host "`n  Resonance Update verfügbar: $($localVersion.version) → $($manifest.version)" -ForegroundColor Cyan
  $zipUri = Get-AllowedUri ([Uri]::new($manifestUri, [string]$manifest.file).AbsoluteUri) 'Update-Datei-URL'
  $zipPath = Join-Path $updateWork $manifest.file
  Receive-UpdateFile $zipUri $zipPath
  if ((Get-Item -LiteralPath $zipPath).Length -ne [int64]$manifest.size -or (Get-Sha256 $zipPath) -ne $manifest.sha256.ToLowerInvariant()) {
    throw 'Update-Datei ist beschädigt oder entspricht nicht dem Manifest.'
  }
  Write-UpdateLog "Download und SHA-256 für $($manifest.version) bestätigt."

  $stage = Join-Path $updateWork 'stage'
  $incomingFiles = Extract-ValidatedZip $zipPath $stage ([string]$manifest.version)
  $payloadFiles = @($incomingFiles + @('resonance-version.json', 'resonance-files.json', 'TESTER-README.md', 'EXPORT-MANIFEST.json') | Select-Object -Unique)
  if ($TestOnly) { Write-Host "`n  Update-Datei wurde erfolgreich geprüft. TestOnly beendet ohne Installation." -ForegroundColor Green; exit 0 }

  $backup = Join-Path $TempRoot ("backup-" + (Get-Date -Format 'yyyyMMdd-HHmmssfff'))
  New-Item -ItemType Directory -Path $backup -Force | Out-Null
  $previousFiles = Get-ManagedFiles
  $backupFiles = @($previousFiles + $payloadFiles | Select-Object -Unique | Where-Object { -not (Test-ProtectedPath $_) })
  foreach ($relative in $backupFiles) {
    $source = Join-Path $InstallRoot $relative
    if (-not (Test-Path -LiteralPath $source)) { continue }
    $destination = Join-Path $backup $relative
    New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
    Copy-Item -LiteralPath $source -Destination $destination -Force
  }

  $oldLock = Join-Path $InstallRoot 'package-lock.json'
  $newLock = Join-Path $stage 'package-lock.json'
  $dependenciesChanged = -not (Test-Path -LiteralPath $oldLock) -or (Get-Sha256 $oldLock) -ne (Get-Sha256 $newLock)
  $nodeModulesMoved = $false
  try {
    foreach ($relative in $previousFiles) {
      if (($payloadFiles -contains $relative) -or (Test-ProtectedPath $relative)) { continue }
      $target = Join-Path $InstallRoot $relative
      if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force }
    }
    foreach ($relative in $payloadFiles) {
      if (Test-ProtectedPath $relative) { continue }
      $source = Join-Path $stage $relative
      if (-not (Test-Path -LiteralPath $source)) { throw "Update-Datei fehlt im Staging: $relative" }
      $target = Join-Path $InstallRoot $relative
      New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
      Copy-Item -LiteralPath $source -Destination $target -Force
    }
    if ($dependenciesChanged) {
      $existingModules = Join-Path $InstallRoot 'node_modules'
      if (Test-Path -LiteralPath $existingModules) {
        Move-Item -LiteralPath $existingModules -Destination (Join-Path $backup 'node_modules') -Force
        $nodeModulesMoved = $true
      }
      Write-Host '  Abhängigkeiten haben sich geändert. Installiere sie neu ...' -ForegroundColor Yellow
      & npm.cmd ci
      if ($LASTEXITCODE -ne 0) { throw 'npm ci ist fehlgeschlagen.' }
    }
  } catch {
    Restore-Backup $backup $payloadFiles $previousFiles $nodeModulesMoved
    throw 'Update fehlgeschlagen. Vorherige Resonance-Version wurde wiederhergestellt.'
  }

  Write-UpdateLog "SUCCESS: $($localVersion.version) -> $($manifest.version); dependenciesChanged=$dependenciesChanged"
  Write-Host "`n  Update erfolgreich: $($localVersion.version) → $($manifest.version)" -ForegroundColor Green
  Write-Host '  Update abgeschlossen. Starte Resonance jetzt über Start-Resonance.cmd.' -ForegroundColor Green
} catch {
  Stop-WithMessage $_.Exception.Message
}
