import type { CSSProperties } from 'react';
import type { Config } from './overlay';

// Presentation only. Mood selection remains exclusively in detectMood().
const materials: Record<string, { shell: string; lcd: string; accent: string }> = {
  happy:     { shell: '#f3dba0', lcd: '#21231a', accent: '#ffda78' },
  sad:       { shell: '#8797a8', lcd: '#111d29', accent: '#accde9' },
  dark:      { shell: '#303844', lcd: '#080e19', accent: '#a9b6fa' },
  angry:     { shell: '#6e4c47', lcd: '#210e12', accent: '#ff9b83' },
  calm:      { shell: '#bfd0c6', lcd: '#142522', accent: '#a5deca' },
  energy:    { shell: '#b9bdac', lcd: '#192016', accent: '#d3ee87' },
  romantic:  { shell: '#d7b0b8', lcd: '#291923', accent: '#f5b9cd' },
  lonely:    { shell: '#626e80', lcd: '#101925', accent: '#bad0e8' },
  hopeful:   { shell: '#e3dfb9', lcd: '#20261e', accent: '#e6ecad' },
  nostalgic: { shell: '#cbb68e', lcd: '#282016', accent: '#f0cf8d' },
};
function mix(a: string, b: string, amount: number) {
  return '#' + [1, 3, 5].map(i => Math.round(parseInt(a.slice(i, i + 2), 16) * (1 - amount) + parseInt(b.slice(i, i + 2), 16) * amount).toString(16).padStart(2, '0')).join('');
}
function luminance(hex: string) {
  const c = [1, 3, 5].map(i => { const v = parseInt(hex.slice(i, i + 2), 16) / 255; return v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; });
  return c[0] * .2126 + c[1] * .7152 + c[2] * .0722;
}
export function memoryContrast(a: string, b: string) {
  const x = luminance(a), y = luminance(b);
  return (Math.max(x, y) + .05) / (Math.min(x, y) + .05);
}
function readable(preferred: string, background: string) {
  if (memoryContrast(preferred, background) >= 4.5) return preferred;
  return memoryContrast('#ffffff', background) >= memoryContrast('#11151a', background) ? '#ffffff' : '#11151a';
}
export function memoryMoodStyle(
  config: Config,
  mood?: string,
  userLcd?: { color: string; brightness: number },
): CSSProperties {
  const amount = config.moodSwitch && mood && materials[mood] ? Math.max(0, Math.min(1, config.moodIntensity / 100)) : 0;
  const palette = mood ? materials[mood] : undefined;
  const shell = mix(mix('#e6e1d8', config.background, .3), palette?.shell || '#e6e1d8', amount);
  const surfaceAlt = mix(shell, '#11151a', .12);
  // LCD: No-Mood → User-Display-Farbe (mit Brightness), sonst Mood-Palette.
  const baseLcd = !mood && userLcd ? userLcd.color : '#101619';
  const lcd = mix(baseLcd, palette?.lcd || baseLcd, amount);
  const lcdFinal = !mood && userLcd ? mix(lcd, '#05070a', 1 - userLcd.brightness) : lcd;
  const accent = mix(config.accent, palette?.accent || config.accent, amount);
  const primary = readable(config.text, lcdFinal);
  const secondary = readable(mix(primary, lcdFinal, .18), lcdFinal);
  return {
    '--mood-surface': shell,
    '--mood-surface-alt': surfaceAlt,
    '--mood-shell-text': readable('#20242a', surfaceAlt),
    '--mood-text-primary': primary,
    '--mood-text-secondary': secondary,
    '--mood-lcd': lcdFinal,
    '--mood-accent': readable(accent, lcdFinal),
    '--mood-progress': accent,
    '--mood-control': accent,
    '--mood-led': accent,
    '--mood-border': mix(shell, '#0c1016', .7),
    '--mood-strength': amount,
  } as CSSProperties;
}
