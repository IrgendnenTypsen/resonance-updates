import { env } from 'cloudflare:workers';
import { defaults, FONT_LIBRARY } from './overlay';
import type { Config, Track } from './overlay';
import {
  analyzeLyricsMood,
  fetchGeniusLyrics,
  fetchLastfmTagsWithFallback,
  fetchMusicBrainzTags,
  type LastfmTag,
} from './mood';
export const CLIENT_ID = '6dde544eefad415eb01bfb2f4790b338';
export const PRODUCTION_ORIGIN =
  'https://resonance-overlay-studio.irgendnentyp.chatgpt.site';
export function isLocalRequest(req: Request) {
  const hostname = new URL(req.url).hostname;
  return (
    hostname === 'localhost' ||
    hostname === '127.0.0.1' ||
    hostname === '[::1]' ||
    hostname === '::1'
  );
}
export function isTailscaleRequest(req: Request) {
  const hostname = new URL(req.url).hostname;
  // CGNAT range: 100.64.0.0/10 → 100.64.0.0 – 100.127.255.255
  return /^100\.(6[4-9]|[7-9]\d|1[0-2][0-7])\.\d{1,3}\.\d{1,3}$/.test(hostname);
}
export function requestOrigin(req: Request) {
  const url = new URL(req.url);
  if (isLocalRequest(req)) return `http://127.0.0.1:${url.port || '3000'}`;
  if (isTailscaleRequest(req))
    return `http://${url.hostname}:${url.port || '3000'}`;
  return PRODUCTION_ORIGIN;
}
export function redirectFor(req: Request) {
  return requestOrigin(req) + '/api/spotify/callback';
}
export type Row = {
  owner: string;
  overlay_key: string;
  config: string;
  access_token: string | null;
  refresh_token: string | null;
  expires: number;
  verifier: string | null;
  oauth_state: string | null;
  oauth_expires: number;
  cached: string | null;
  polled: number;
  retry_at: number;
  lastfm_api_key: string | null;
  genius_access_token: string | null;
};
export const db = () => env.DB as D1Database;
// --- Observed Playlist Cache (pro Playlist-ID) ---
const observedPlaylistCache = new Map<
  string,
  {
    snapshotId: string | null; // Spotify snapshot_id
    ids: Set<string>;
    items: Array<{ id: string | null; name: string; artists: string }>;
    fetchedAt: number; // Zeitpunkt des letzten vollständigen Items-Loads
    snapshotCheckedAt: number; // Zeitpunkt des letzten Snapshot-Checks
  }
>();
const SNAPSHOT_CHECK_INTERVAL = 30000; // 30 Sekunden
// --- Single-flight für parallele Playlist-Fetches ---
const playlistFetchInFlight = new Map<string, Promise<any>>();

async function singleFlight<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const existing = playlistFetchInFlight.get(key);
  if (existing) {
    console.log('[PLAYLIST SINGLE FLIGHT]', { key, action: 'reuse' });
    return existing as Promise<T>;
  }
  console.log('[PLAYLIST SINGLE FLIGHT]', { key, action: 'start' });
  const promise = fn().finally(() => {
    playlistFetchInFlight.delete(key);
    console.log('[PLAYLIST SINGLE FLIGHT]', { key, action: 'finish' });
  });
  playlistFetchInFlight.set(key, promise);
  return promise;
}
// --- Rate-Limit-Tracking pro Spotify-Endpoint ---
const rateLimitState = new Map<
  string,
  { blockedUntil: number; wasClearedAt?: number }
>();
function isRateLimited(endpoint: string): boolean {
  const state = rateLimitState.get(endpoint);
  if (!state) return false;
  if (Date.now() < state.blockedUntil) return true;
  // Keep recovery pending until a complete successful playlist fetch.
  if (!state.wasClearedAt) state.wasClearedAt = Date.now();
  return false;
}
function wasRecentlyRateLimited(endpoint: string): boolean {
  const state = rateLimitState.get(endpoint);
  return !!state?.wasClearedAt;
}
function setRateLimit(endpoint: string, retryAfterSeconds: number): void {
  const blockedUntil = Date.now() + retryAfterSeconds * 1000;
  rateLimitState.set(endpoint, { blockedUntil });
  console.log('[SPOTIFY RATE LIMIT]', {
    endpoint,
    status: 429,
    retryAfter: retryAfterSeconds,
    blockedUntil: new Date(blockedUntil).toISOString(),
  });
}
// --- Favorite-Cache ---
// Strategie: Pro Track maximal EIN Spotify-Request. Danach gecachten Wert
// verwenden, solange derselbe Track läuft. Erst bei Trackwechsel neu prüfen.
const favoriteCache = new Map<string, { value: boolean; at: number }>();
const FAVORITE_TTL = 900000; // 15 Minuten: Wiederverwendung wenn Track erneut erscheint
let lastCheckedTrackId: string | null = null; // Letzte Track-ID, für die Favorite geprüft wurde
export function identity(req: Request) {
  if (isLocalRequest(req) || isTailscaleRequest(req)) return 'local-owner';
  // Both variants are supplied by the trusted Sites dispatcher. Prefer email
  // consistently because rendering and interactive requests may omit the ID.
  const email = req.headers
    .get('oai-authenticated-user-email')
    ?.trim()
    .toLowerCase();
  if (email) return 'email:' + email;
  const id = req.headers.get('oai-authenticated-user-id');
  if (!id) throw new Error('Bitte melde dich an, um dein Studio zu öffnen.');
  return id;
}
export function csrf(req: Request) {
  if (req.headers.get('origin') !== new URL(req.url).origin)
    throw new Error('Ungültiger Ursprung. Bitte lade die Seite neu.');
}
export function json(data: unknown, status = 200) {
  return Response.json(data, {
    status,
    headers: { 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' },
  });
}
export function random() {
  return Array.from(crypto.getRandomValues(new Uint8Array(32)), (v) =>
    v.toString(16).padStart(2, '0'),
  ).join('');
}
export async function getStudio(req: Request, create = false) {
  const owner = identity(req);
  if (create)
    await db()
      .prepare(
        'INSERT INTO studios (owner,overlay_key,config) VALUES (?,?,?) ON CONFLICT(owner) DO NOTHING',
      )
      .bind(owner, random(), JSON.stringify(defaults))
      .run();
  return db()
    .prepare('SELECT * FROM studios WHERE owner=?')
    .bind(owner)
    .first<Row>();
}
// Gemeinsame Persistenz für Studio-Configs. Wird sowohl vom Studio-Save
// (POST /api/studio) als auch von der Live-Look-Aktivierung (POST
// /api/live-look) verwendet, damit UI und API exakt denselben Config-Zustand
// erzeugen. Das Overlay erhält die Änderung über den normalen Config-Pfad
// (/api/now liest row.config).
export async function saveStudioConfig(
  owner: string,
  config: unknown,
): Promise<Config> {
  const clean = cleanConfig(config);
  await db()
    .prepare('UPDATE studios SET config=? WHERE owner=?')
    .bind(JSON.stringify(clean), owner)
    .run();
  return clean;
}
export async function getMoodCredentials(
  owner: string,
): Promise<{ lastfmApiKey: string; geniusAccessToken: string }> {
  const row = await db()
    .prepare(
      'SELECT lastfm_api_key, genius_access_token FROM studios WHERE owner=?',
    )
    .bind(owner)
    .first<{
      lastfm_api_key: string | null;
      genius_access_token: string | null;
    }>();
  return {
    lastfmApiKey: row?.lastfm_api_key || '',
    geniusAccessToken: row?.genius_access_token || '',
  };
}
export async function setMoodCredentials(
  owner: string,
  creds: { lastfmApiKey?: string; geniusAccessToken?: string },
): Promise<void> {
  // Nur gesetzte Felder aktualisieren; leere Strings = entfernen
  const sets: string[] = [];
  const values: Array<string | null> = [];
  if ('lastfmApiKey' in creds) {
    sets.push('lastfm_api_key=?');
    values.push(creds.lastfmApiKey ?? null);
  }
  if ('geniusAccessToken' in creds) {
    sets.push('genius_access_token=?');
    values.push(creds.geniusAccessToken ?? null);
  }
  if (sets.length === 0) return;
  await db()
    .prepare('UPDATE studios SET ' + sets.join(',') + ' WHERE owner=?')
    .bind(...values, owner)
    .run();
}
// --- Custom Fonts (D1 Storage, Checkpoint 16.10) ---
export type CustomFontRow = {
  id: string;
  owner: string;
  name: string;
  original_filename: string;
  format: string;
  family: string;
  data: ArrayBuffer | Uint8Array | number[];
  size: number;
  hash: string | null;
  created_at: number;
};
export type CustomFontMeta = {
  id: string;
  name: string;
  format: string;
  family: string;
  size: number;
  createdAt: number;
};
export async function listCustomFonts(
  owner: string,
): Promise<CustomFontMeta[]> {
  const rows = await db()
    .prepare(
      'SELECT id,name,format,family,size,created_at FROM custom_fonts WHERE owner=? ORDER BY created_at ASC',
    )
    .bind(owner)
    .all<{
      id: string;
      name: string;
      format: string;
      family: string;
      size: number;
      created_at: number;
    }>();
  return (rows.results || []).map((r) => ({
    id: r.id,
    name: r.name,
    format: r.format,
    family: r.family,
    size: r.size,
    createdAt: r.created_at,
  }));
}
export async function getCustomFont(id: string): Promise<CustomFontRow | null> {
  return db()
    .prepare('SELECT * FROM custom_fonts WHERE id=?')
    .bind(id)
    .first<CustomFontRow>();
}
export async function findCustomFontByHash(
  owner: string,
  hash: string,
): Promise<CustomFontMeta | null> {
  const row = await db()
    .prepare(
      'SELECT id,name,format,family,size,created_at FROM custom_fonts WHERE owner=? AND hash=? LIMIT 1',
    )
    .bind(owner, hash)
    .first<{
      id: string;
      name: string;
      format: string;
      family: string;
      size: number;
      created_at: number;
    }>();
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    format: row.format,
    family: row.family,
    size: row.size,
    createdAt: row.created_at,
  };
}
export async function insertCustomFont(font: {
  id: string;
  owner: string;
  name: string;
  originalFilename: string;
  format: string;
  family: string;
  data: ArrayBuffer;
  size: number;
  hash?: string;
  createdAt: number;
}): Promise<void> {
  await db()
    .prepare(
      'INSERT INTO custom_fonts (id,owner,name,original_filename,format,family,data,size,hash,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
    )
    .bind(
      font.id,
      font.owner,
      font.name,
      font.originalFilename,
      font.format,
      font.family,
      font.data,
      font.size,
      font.hash ?? null,
      font.createdAt,
    )
    .run();
}
export async function deleteCustomFont(
  id: string,
  owner: string,
): Promise<void> {
  await db()
    .prepare('DELETE FROM custom_fonts WHERE id=? AND owner=?')
    .bind(id, owner)
    .run();
}
export function detectFontFormat(
  data: Uint8Array,
): 'woff2' | 'woff' | 'ttf' | 'otf' | null {
  if (data.length < 4) return null;
  const b0 = data[0],
    b1 = data[1],
    b2 = data[2],
    b3 = data[3];
  // WOFF2: "wOF2" (77 4F 46 32)
  if (b0 === 0x77 && b1 === 0x4f && b2 === 0x46 && b3 === 0x32) return 'woff2';
  // WOFF: "wOFF" (77 4F 46 46)
  if (b0 === 0x77 && b1 === 0x4f && b2 === 0x46 && b3 === 0x46) return 'woff';
  // TTF: 00 01 00 00
  if (b0 === 0x00 && b1 === 0x01 && b2 === 0x00 && b3 === 0x00) return 'ttf';
  // OTF: "OTTO" (4F 54 54 4F)
  if (b0 === 0x4f && b1 === 0x54 && b2 === 0x54 && b3 === 0x4f) return 'otf';
  return null;
}
export function cleanConfig(value: unknown): Config {
  const c = { ...defaults };
  if (!value || typeof value !== 'object') return c;
  const v = value as Record<string, unknown>;
  for (const k of [
    'accent',
    'background',
    'text',
    'ledColor',
    'displayColor',
    'progressColor',
    'controlAccentColor',
    'statusAccentColor',
  ] as const)
    if (typeof v[k] === 'string' && /^#[0-9a-f]{6}$/i.test(v[k] as string))
      c[k] = v[k] as string;
  // Migration: Alte Configs ohne progressColor übernehmen den accent,
  // damit die Progress-Bar visuell identisch bleibt.
  if (
    !(
      typeof v.progressColor === 'string' &&
      /^#[0-9a-f]{6}$/i.test(v.progressColor)
    ) &&
    typeof v.accent === 'string' &&
    /^#[0-9a-f]{6}$/i.test(v.accent)
  )
    c.progressColor = v.accent;
  // Migration: Alte Configs ohne controlAccentColor/statusAccentColor übernehmen
  // den accent, damit die Werte bei Link OFF visuell identisch bleiben.
  for (const k of ['controlAccentColor', 'statusAccentColor'] as const) {
    if (
      !(typeof v[k] === 'string' && /^#[0-9a-f]{6}$/i.test(v[k])) &&
      typeof v.accent === 'string' &&
      /^#[0-9a-f]{6}$/i.test(v.accent)
    )
      c[k] = v.accent;
  }
  if (typeof v.memoryLabel === 'string')
    c.memoryLabel = v.memoryLabel.trim().slice(0, 32);
  if (typeof v.observedPlaylistId === 'string')
    c.observedPlaylistId = v.observedPlaylistId.trim().slice(0, 64);
  if (typeof v.observedPlaylistName === 'string')
    c.observedPlaylistName = v.observedPlaylistName.trim().slice(0, 128);
  for (const k of [
    'glow',
    'cover',
    'progress',
    'artist',
    'badge',
    'hidePaused',
    'moodSwitch',
    'spin',
    'ledVisible',
    'scanlinesEnabled',
    'grainEnabled',
    'linkAccentColors',
  ] as const)
    if (typeof v[k] === 'boolean') c[k] = v[k] as boolean;
  const ranges = {
    radius: [0, 40],
    opacity: [0, 100],
    width: [280, 900],
    spacing: [8, 48],
    fontSize: [14, 40],
    moodIntensity: [0, 100],
    spinSpeed: [4, 40],
    ledBrightness: [10, 100],
    ledGlow: [0, 100],
    ledSpeed: [0, 100],
    ledSize: [80, 120],
    ledOffsetX: [-8, 8],
    ledOffsetY: [-8, 8],
    displayBrightness: [20, 100],
    textGlow: [0, 100],
    progressEdge: [0, 100],
    progressWidth: [84, 100],
    progressThickness: [72, 128],
    progressOffsetX: [-6, 6],
    progressOffsetY: [-5, 5],
    progressRadius: [0, 12],
    controlsSize: [85, 115],
    controlsIconSize: [80, 120],
    controlsGap: [70, 140],
    controlsOffsetX: [-8, 8],
    controlsOffsetY: [-6, 6],
    coverBrightness: [40, 140],
    coverSaturation: [0, 150],
    coverContrast: [60, 140],
    coverSize: [84, 116],
    coverOffsetX: [-8, 8],
    coverOffsetY: [-8, 8],
    coverRadius: [0, 16],
    noteSize: [88, 112],
    noteOffsetX: [-8, 8],
    noteOffsetY: [-8, 8],
    noteRotation: [-6, 6],
    noteOpacity: [55, 100],
    titleOffsetX: [-8, 8],
    titleOffsetY: [-6, 6],
    artistOffsetX: [-8, 8],
    artistOffsetY: [-6, 6],
    metaOffsetX: [-8, 8],
    metaOffsetY: [-6, 6],
    titleArtistSpacing: [0, 8],
    scanlineStrength: [0, 100],
    grainStrength: [0, 100],
    vignetteStrength: [0, 100],
  };
  for (const k of Object.keys(ranges) as (keyof typeof ranges)[]) {
    if (typeof v[k] === 'number' && Number.isFinite(v[k]))
      c[k] = Math.max(ranges[k][0], Math.min(ranges[k][1], v[k] as number));
  }
  const enums = {
    layout: [
      'glass',
      'minimal',
      'vinyl',
      'spotlight',
      'winamp',
      'memory',
      'aqua',
      'pixel',
      'sticker',
      'cd',
      'floating',
    ],
    font: ['sans', 'serif', 'mono'],
    animation: ['fade', 'slide', 'zoom', 'blur', 'flip', 'none'],
    align: ['left', 'center'],
    ledBehavior: [
      'solid',
      'soft',
      'breathe',
      'double',
      'heartbeat',
      'flicker',
      'off',
    ],
    coverFit: ['cover', 'contain'],
  };
  for (const k of Object.keys(enums) as (keyof typeof enums)[])
    if (enums[k].includes(v[k] as string)) c[k] = v[k] as string;
  // --- Typography (separate Font-Felder) ---
  // Font-IDs validieren. Alte Configs mit nur `font` werden auf die neuen
  // Felder gemappt, damit z.B. `font: 'mono'` weiterhin als Mono gerendert wird.
  // Custom-Font-IDs (`custom:<64 Hex>`) werden ebenfalls akzeptiert.
  const validFontIds = FONT_LIBRARY.map((f) => f.id);
  const isCustomFontId = (s: string) => /^custom:[0-9a-f]{64}$/.test(s);
  const legacyFont =
    typeof v.font === 'string' && validFontIds.includes(v.font) ? v.font : null;
  for (const k of ['titleFont', 'artistFont', 'metaFont'] as const) {
    if (
      typeof v[k] === 'string' &&
      (validFontIds.includes(v[k] as string) || isCustomFontId(v[k] as string))
    )
      c[k] = v[k] as string;
    else if (legacyFont) c[k] = legacyFont;
  }
  // Weights validieren (nur erlaubte Stufen, sonst Default 400)
  for (const k of ['titleWeight', 'artistWeight', 'metaWeight'] as const) {
    if (typeof v[k] === 'number' && Number.isFinite(v[k]))
      c[k] = [300, 400, 500, 700].includes(v[k] as number)
        ? (v[k] as number)
        : 400;
  }
  // Sizes validieren/clampen
  const sizeRanges = {
    titleSize: [14, 48],
    artistSize: [10, 24],
    metaSize: [8, 24],
  };
  for (const k of Object.keys(sizeRanges) as (keyof typeof sizeRanges)[]) {
    if (typeof v[k] === 'number' && Number.isFinite(v[k]))
      c[k] = Math.max(
        sizeRanges[k][0],
        Math.min(sizeRanges[k][1], v[k] as number),
      );
  }
  // Letter Spacing validieren/clampen
  const lsRanges = {
    titleLetterSpacing: [-2, 6],
    artistLetterSpacing: [-2, 6],
    metaLetterSpacing: [-2, 6],
  };
  for (const k of Object.keys(lsRanges) as (keyof typeof lsRanges)[]) {
    if (typeof v[k] === 'number' && Number.isFinite(v[k]))
      c[k] = Math.max(lsRanges[k][0], Math.min(lsRanges[k][1], v[k] as number));
  }
  // Case validieren
  for (const k of ['titleCase', 'artistCase', 'metaCase'] as const) {
    if (v[k] === 'uppercase' || v[k] === 'normal') c[k] = v[k] as string;
  }
  return c;
}
type PlaybackResult = {
  track: Track | null;
  message?: string;
  retryAfter?: number;
  rateLimitReason?: 'RATE_LIMIT' | 'QUOTA_EXCEEDED';
};
const playbackQuotaFailures = new Map<string, number>();
class SpotifyRateLimitError extends Error {
  constructor(
    readonly retryAfter: number,
    readonly reason: 'RATE_LIMIT' | 'QUOTA_EXCEEDED',
  ) {
    super('Spotify rate limited');
  }
}
function parseRetryAfter(value: string | null, now: number) {
  if (!value) return 30;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.max(1, Math.ceil(seconds));
  const date = Date.parse(value);
  return Number.isFinite(date)
    ? Math.max(1, Math.ceil((date - now) / 1000))
    : 30;
}
async function handleSpotify429(r: Response, owner: string, now: number) {
  const retryAfterHeader = r.headers.get('retry-after');
  let message = '';
  let spotifyReason = '';
  try {
    const body = (await r.json()) as {
      message?: unknown;
      reason?: unknown;
      error?: { message?: unknown; reason?: unknown };
    };
    const rawMessage = body.error?.message ?? body.message;
    const rawReason = body.error?.reason ?? body.reason;
    message = typeof rawMessage === 'string' ? rawMessage : '';
    spotifyReason = typeof rawReason === 'string' ? rawReason : '';
  } catch {
    // Retry-After remains authoritative if Spotify omits a JSON body.
  }
  const quotaExceeded = spotifyReason === 'QUOTA_EXCEEDED';
  const failures = quotaExceeded
    ? (playbackQuotaFailures.get(owner) ?? 0) + 1
    : 0;
  if (quotaExceeded) playbackQuotaFailures.set(owner, failures);
  else playbackQuotaFailures.delete(owner);
  const headerSeconds = parseRetryAfter(retryAfterHeader, now);
  const retryAfter = quotaExceeded
    ? Math.max(headerSeconds, Math.min(3600, 60 * 2 ** (failures - 1)))
    : headerSeconds;
  const blockedUntil = now + retryAfter * 1000;
  const reason = quotaExceeded ? 'QUOTA_EXCEEDED' : 'RATE_LIMIT';
  await db()
    .prepare('UPDATE studios SET retry_at=? WHERE owner=?')
    .bind(blockedUntil, owner)
    .run();
  console.debug('[SPOTIFY PLAYBACK RATE LIMIT]', {
    status: r.status,
    retryAfter: retryAfterHeader ?? '(missing; 30s fallback)',
    message: message || '(no message)',
    reason: spotifyReason || '(none)',
    nextRequestAt: new Date(blockedUntil).toISOString(),
  });
  return { retryAfter, reason } as const;
}
function lastKnownTrack(row: Row, now: number) {
  const memory = playbackCache.get(row.owner);
  if (memory?.track) return { ...memory.track };
  if (!row.cached) return null;
  try {
    const track = JSON.parse(row.cached) as Track | null;
    if (track?.playing)
      track.progress = Math.min(
        track.duration,
        Math.max(0, track.progress + Math.max(0, now - row.polled)),
      );
    return track;
  } catch {
    return null;
  }
}
export async function now(row: Row): Promise<PlaybackResult> {
  if (!row.refresh_token) return { track: null };
  const n = Date.now();
  const config = cleanConfig(JSON.parse(row.config));

  // 1. DB-Level Retry-Check
  if (row.retry_at > n)
    return {
      track: lastKnownTrack(row, n),
      message:
        'Spotify-Limit erreicht. Die Verbindung wird automatisch fortgesetzt.',
      retryAfter: Math.ceil((row.retry_at - n) / 1000),
    };

  // 2. In-Memory Cache prüfen: Ist ein Spotify-Refresh nötig?
  const cached = playbackCache.get(row.owner);
  if (cached) {
    const age = n - cached.fetchedAt;
    let refreshInterval = PLAYBACK_NORMAL_INTERVAL;

    if (!cached.track) {
      // 204 / Idle
      refreshInterval = PLAYBACK_IDLE_INTERVAL;
    } else if (!cached.track.playing) {
      // Pause
      refreshInterval = PLAYBACK_PAUSED_INTERVAL;
    } else {
      // Playing: Progress-Berechnung
      const est = cached.track.progress + (n - cached.fetchedAt);
      const remaining = cached.track.duration - est;
      if (remaining <= PLAYBACK_ENDING_THRESHOLD && remaining > 0) {
        refreshInterval = PLAYBACK_ENDING_INTERVAL;
      }
    }

    if (age < refreshInterval) {
      // Cache noch gültig → Spotify NICHT anfragen
      console.log('[PLAYBACK CACHE]', {
        age,
        refreshInterval,
        reason: !cached.track
          ? 'idle'
          : !cached.track.playing
            ? 'paused'
            : cached.track.duration -
                  (cached.track.progress + (n - cached.fetchedAt)) <=
                PLAYBACK_ENDING_THRESHOLD
              ? 'ending'
              : 'normal',
      });
      const t = cached.track ? { ...cached.track } : null;
      if (t?.playing)
        t.progress = Math.min(
          t.duration,
          Math.max(0, t.progress + Math.max(0, n - cached.fetchedAt)),
        );
      // Favoriten & Playlist frisch prüfen (haben eigenen Cache)
      if (t?.id && row.access_token) {
        t.favorite = await favoriteFor(t.id, row.access_token);
        if (config.observedPlaylistId) {
          await applyObservedState(
            t,
            config.observedPlaylistId,
            row.access_token,
          );
        }
      }
      return { track: t };
    }
    // Cache abgelaufen → weiter zu Spotify-Fetch (Single-flight)
  }

  // 3. Spotify Currently-Playing fetchen (mit Single-flight)
  const result = await fetchCurrentlyPlaying(row, config, n);

  // 4. In DB speichern (nur bei echtem Spotify-Fetch)
  if (!result.retryAfter)
    await db()
      .prepare('UPDATE studios SET cached=?,polled=?,retry_at=0 WHERE owner=?')
      .bind(JSON.stringify(result.track), n, row.owner)
      .run();

  return result;
}

// --- Single-flight für Currently-Playing ---
const currentlyPlayingInFlight = new Map<string, Promise<PlaybackResult>>();

async function fetchCurrentlyPlaying(
  row: Row,
  config: ReturnType<typeof cleanConfig>,
  n: number,
): Promise<PlaybackResult> {
  const key = 'playback:' + row.owner;

  const existing = currentlyPlayingInFlight.get(key);
  if (existing) {
    console.log('[PLAYBACK FETCH]', { action: 'reuse' });
    return existing;
  }

  console.log('[PLAYBACK FETCH]', { action: 'start' });
  const promise = (async () => {
    try {
      const access = await freshAccess(row);
      const r = await fetch(
        'https://api.spotify.com/v1/me/player/currently-playing',
        {
          headers: { Authorization: 'Bearer ' + access },
          signal: AbortSignal.timeout(10000),
        },
      );

      if (r.status === 429) {
        const { retryAfter, reason } = await handleSpotify429(r, row.owner, n);
        return {
          track: lastKnownTrack(row, n),
          message:
            'Spotify-Limit erreicht. Die Verbindung wird automatisch fortgesetzt.',
          retryAfter,
          rateLimitReason: reason,
        };
      }

      if (r.status === 401) {
        await db()
          .prepare('UPDATE studios SET expires=0 WHERE owner=?')
          .bind(row.owner)
          .run();
        throw new Error('Spotify-Verbindung wird erneuert.');
      }
      if (r.status === 403)
        throw new Error(
          'Spotify verweigert den Zugriff. Prüfe, ob dein Konto für deine Developer-App freigeschaltet ist.',
        );
      if (!r.ok && r.status !== 204)
        throw new Error('Spotify ist gerade nicht erreichbar.');
      playbackQuotaFailures.delete(row.owner);

      let track: Track | null = null;
      if (r.status !== 204) {
        const p = (await r.json()) as {
          item?: {
            id?: string;
            type?: string;
            name: string;
            artists?: { name: string; id?: string }[];
            album?: { name?: string; images?: { url: string }[] };
            duration_ms: number;
            external_ids?: { isrc?: string };
          };
          progress_ms: number;
          is_playing: boolean;
        };
        if (p.item && p.item.type === 'track')
          track = {
            id: p.item.id,
            title: p.item.name,
            album: p.item.album?.name || '',
            artistId: p.item.artists?.[0]?.id,
            artist: p.item.artists?.map((a) => a.name).join(', ') || '',
            cover: p.item.album?.images?.[0]?.url || '',
            duration: p.item.duration_ms,
            progress: p.progress_ms || 0,
            playing: p.is_playing,
            isrc: p.item.external_ids?.isrc, // NEU
          };
      }

      // In-Memory Cache aktualisieren
      playbackCache.set(row.owner, { track, fetchedAt: Date.now() });

      // Favorite & Playlist (haben eigenen Cache/Single-flight)
      if (track?.id && row.access_token) {
        track.favorite = await favoriteFor(track.id, row.access_token);
        track.inObservedPlaylist = false;
        if (config.observedPlaylistId) {
          await applyObservedState(
            track,
            config.observedPlaylistId,
            row.access_token,
          );
        }
      }
      if (track && config.moodSwitch && track.artistId && row.access_token)
        track.genres = await genresFor(track.artistId, row.access_token);
      // Mood-Credentials aus der DB laden (Last.fm/Genius, optional).
      // Nur setzen, wenn vorhanden – sonst greift der env-Fallback in mood.ts.
      const moodCreds = await getMoodCredentials(row.owner);
      if (moodCreds.lastfmApiKey)
        (globalThis as any).LASTFM_API_KEY = moodCreds.lastfmApiKey;
      if (moodCreds.geniusAccessToken)
        (globalThis as any).GENIUS_ACCESS_TOKEN = moodCreds.geniusAccessToken;
      // Last.fm Tags für Mood-Enrichment (nur wenn moodSwitch aktiv)
      if (track && config.moodSwitch && track.artist && track.title) {
        track.lastfmTags = await fetchLastfmTagsWithFallback(
          track.artist,
          track.title,
          track.album,
        );

        // MusicBrainz + ListenBrainz Fallback (nur wenn Last.fm keine Tags liefert)
        let lbTags: LastfmTag[] | undefined;
        if (
          track.isrc &&
          (!track.lastfmTags || track.lastfmTags.length === 0)
        ) {
          lbTags = await fetchMusicBrainzTags(track.isrc);
          if (lbTags.length > 0) {
            // An bestehende Tags anhängen
            track.lastfmTags = [...(track.lastfmTags || []), ...lbTags];
          }
        }
      }

      // GENIUS LYRICS (experimentell, nur Logging)
      if (track && track.artist && track.title) {
        console.log('[GENIUS FLOW]', {
          step: 'server-before-call',
          title: track.title,
          artist: track.artist,
          spotifyId: track.id ?? null,
        });
        const geniusResult = await fetchGeniusLyrics(
          track.artist,
          track.title,
          track.id,
        );
        console.log('[GENIUS FLOW]', {
          step: 'server-after-call',
          resultIsNull: geniusResult === null,
        });
        if (geniusResult) {
          console.log('[GENIUS RESULT]', {
            track: track.title,
            artist: track.artist,
            found: true,
            geniusTitle:
              geniusResult.matchConfidence === 'high'
                ? track.title
                : '(matched)',
            matchConfidence: geniusResult.matchConfidence,
            characters: geniusResult.lyrics.length,
            lines: geniusResult.lyrics.split('\n').length,
            cacheHit: geniusResult.cacheHit,
          });

          // GENIUS LYRICS → LYRICS MOOD (nur Scores im Track, keine Lyrics)
          if (geniusResult.lyrics.length > 50) {
            const lyricsMood = analyzeLyricsMood(geniusResult.lyrics);
            track.lyricMoodScores = lyricsMood.scores;
            console.log('[LYRICS MOOD DEBUG]', {
              track: track.title,
              artist: track.artist,
              characters: geniusResult.lyrics.length,
              lines: geniusResult.lyrics.split('\n').length,
              uniqueLines: new Set(
                geniusResult.lyrics
                  .split('\n')
                  .map((l) =>
                    l
                      .toLowerCase()
                      .normalize('NFKD')
                      .replace(/[\u0300-\u036f]/g, '')
                      .replace(/[^\w\s]/g, '')
                      .trim(),
                  )
                  .filter(Boolean),
              ).size,
              positiveSignals: lyricsMood.positiveSignals,
              negativeSignals: lyricsMood.negativeSignals,
              calmSignals: lyricsMood.calmSignals,
              intenseSignals: lyricsMood.intenseSignals,
              lyricsScores: lyricsMood.scores,
              confidence: lyricsMood.confidence,
            });
          }
        } else {
          console.log('[GENIUS RESULT]', {
            track: track.title,
            artist: track.artist,
            found: false,
            geniusTitle: null,
            matchConfidence: null,
            characters: 0,
            lines: 0,
            cacheHit: false,
          });
        }
      }

      console.log('[PLAYBACK RESULT]', {
        status: r.status,
        trackId: track?.id ?? null,
        playing: track?.playing ?? false,
      });

      return { track };
    } catch (error) {
      // Bei Fehler: Letzten bekannten State verwenden
      const cached = lastKnownTrack(row, Date.now());
      if (error instanceof SpotifyRateLimitError)
        return {
          track: cached,
          message:
            'Spotify-Limit erreicht. Die Verbindung wird automatisch fortgesetzt.',
          retryAfter: error.retryAfter,
          rateLimitReason: error.reason,
        };
      if (cached) {
        return {
          track: cached,
          message:
            'Spotify ist gerade nicht erreichbar. Die letzte Anzeige bleibt sichtbar.',
        };
      }
      return {
        track: null,
        message:
          'Spotify ist gerade nicht erreichbar. Die Verbindung wird automatisch erneut versucht.',
      };
    }
  })();

  currentlyPlayingInFlight.set(
    key,
    promise.finally(() => {
      currentlyPlayingInFlight.delete(key);
      console.log('[PLAYBACK FETCH]', { action: 'finish' });
    }),
  );

  return promise;
}
// --- Single-flight für Favorite ---
const favoriteInFlight = new Map<string, Promise<boolean>>();

// --- Adaptive Currently-Playing Cache ---
const PLAYBACK_NORMAL_INTERVAL = 5000; // 5s: normal playing
const PLAYBACK_ENDING_INTERVAL = 2500; // 2.5s: <=12s bis Trackende
const PLAYBACK_PAUSED_INTERVAL = 20000; // 20s: paused
const PLAYBACK_IDLE_INTERVAL = 20000; // 20s: 204 / kein Track
const PLAYBACK_ENDING_THRESHOLD = 12000; // 12s: Schwellenwert

const playbackCache = new Map<
  string,
  {
    track: Track | null;
    fetchedAt: number;
  }
>();

async function favoriteFor(id: string, access: string): Promise<boolean> {
  const cacheKey = 'fav:' + id;

  // 0. Single-flight: Wenn bereits ein Request für diese Track-ID läuft,
  //    teile dasselbe Promise.
  const inFlight = favoriteInFlight.get(cacheKey);
  if (inFlight) {
    console.log('[FAVORITE SINGLE FLIGHT]', { trackId: id, action: 'reuse' });
    return inFlight;
  }

  // 1. Derselbe Track wie beim letzten Check → Cache sofort zurück
  if (id === lastCheckedTrackId) {
    const cached = favoriteCache.get(cacheKey);
    if (cached) return cached.value;
  }

  // 2. Rate-Limit
  if (isRateLimited('favorite')) {
    const cached = favoriteCache.get(cacheKey);
    if (cached) {
      console.log('[FAVORITE CACHE FALLBACK]', {
        trackId: id,
        cachedFavorite: cached.value,
        reason: '429',
      });
      return cached.value;
    }
    return false;
  }

  // 3. TTL-Cache (für Track-Wiederverwendung)
  const cached = favoriteCache.get(cacheKey);
  if (cached && Date.now() - cached.at < FAVORITE_TTL) {
    lastCheckedTrackId = id;
    return cached.value;
  }

  // 4. Spotify-API-Call
  lastCheckedTrackId = id;
  console.log('[FAVORITE SINGLE FLIGHT]', { trackId: id, action: 'start' });

  const promise = (async () => {
    try {
      const libR = await fetch(
        'https://api.spotify.com/v1/me/library/contains?uris=' +
          encodeURIComponent('spotify:track:' + id),
        {
          headers: { Authorization: 'Bearer ' + access },
          signal: AbortSignal.timeout(4000),
          cache: 'no-store',
        },
      );
      if (libR.status === 429) {
        const retryAfter = Math.max(
          30,
          Number(libR.headers.get('retry-after')) || 30,
        );
        setRateLimit('favorite', retryAfter);
        const fallback = favoriteCache.get(cacheKey);
        if (fallback) {
          console.log('[FAVORITE CACHE FALLBACK]', {
            trackId: id,
            cachedFavorite: fallback.value,
            reason: '429',
          });
          return fallback.value;
        }
        return false;
      }
      if (libR.ok) {
        const libData = (await libR.json()) as boolean[];
        const result = Array.isArray(libData) && libData[0] === true;
        favoriteCache.set(cacheKey, { value: result, at: Date.now() });
        return result;
      }
      console.error(
        `favoriteFor: /me/library/contains fehlgeschlagen (Status ${libR.status}) für Track ${id}: ${await libR.text()}`,
      );
    } catch (e) {
      console.error(
        `favoriteFor: Fehler bei /me/library/contains für Track ${id}:`,
        e,
      );
    }
    const fallback = favoriteCache.get(cacheKey);
    return fallback ? fallback.value : false;
  })();

  favoriteInFlight.set(
    cacheKey,
    promise.finally(() => {
      favoriteInFlight.delete(cacheKey);
      console.log('[FAVORITE SINGLE FLIGHT]', {
        trackId: id,
        action: 'finish',
      });
    }),
  );

  return promise;
}
export async function freshAccess(row: Row): Promise<string | null> {
  let access = row.access_token;
  if (row.expires < Date.now() + 30000) {
    const r = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: CLIENT_ID,
        grant_type: 'refresh_token',
        refresh_token: row.refresh_token,
      }),
      signal: AbortSignal.timeout(10000),
    });
    if (r.status === 429) {
      const limited = await handleSpotify429(r, row.owner, Date.now());
      throw new SpotifyRateLimitError(limited.retryAfter, limited.reason);
    }
    if (!r.ok) {
      if (r.status === 400 || r.status === 401) {
        await db()
          .prepare(
            'UPDATE studios SET access_token=NULL,refresh_token=NULL,cached=NULL WHERE owner=?',
          )
          .bind(row.owner)
          .run();
        throw new Error(
          'Spotify-Verbindung abgelaufen. Bitte erneut verbinden.',
        );
      }
      throw new Error(
        'Spotify ist gerade nicht erreichbar. Bitte später erneut versuchen.',
      );
    }
    const tokens = (await r.json()) as {
      access_token: string;
      refresh_token?: string;
      expires_in: number;
    };
    access = tokens.access_token;
    await db()
      .prepare(
        'UPDATE studios SET access_token=?,refresh_token=?,expires=? WHERE owner=?',
      )
      .bind(
        access,
        tokens.refresh_token || row.refresh_token,
        Date.now() + tokens.expires_in * 1000,
        row.owner,
      )
      .run();
  }
  return access;
}
type ObservedPlaylistDebugItem = {
  id: string | null;
  name: string;
  artists: string;
};
type ObservedPlaylistResult = {
  ids: Set<string>;
  status: number;
  items: ObservedPlaylistDebugItem[];
};
async function fetchPlaylistSnapshot(
  playlistId: string,
  access: string,
): Promise<string | null> {
  const key = 'snapshot:' + playlistId;
  return singleFlight(key, async () => {
    try {
      const r = await fetch(
        `https://api.spotify.com/v1/playlists/${encodeURIComponent(playlistId)}?fields=snapshot_id`,
        {
          headers: { Authorization: 'Bearer ' + access },
          signal: AbortSignal.timeout(10000),
          cache: 'no-store',
        },
      );
      if (r.status === 429) {
        const seconds = Number(r.headers.get('retry-after'));
        const retryAfter =
          Number.isFinite(seconds) && seconds > 0 ? seconds : 30;
        setRateLimit('playlist:' + playlistId, retryAfter);
        return null;
      }
      if (!r.ok) return null;
      const d = (await r.json()) as { snapshot_id?: string };
      return d.snapshot_id ?? null;
    } catch {
      return null;
    }
  });
}

async function loadPlaylistFull(
  playlistId: string,
  access: string,
): Promise<{
  ids: Set<string>;
  items: ObservedPlaylistDebugItem[];
  status: number;
  snapshotId: string | null;
} | null> {
  const key = 'items:' + playlistId;
  return singleFlight(key, async () => {
    const ids = new Set<string>();
    const items: ObservedPlaylistDebugItem[] = [];
    let status = 0;
    let snapshotId: string | null = null;

    try {
      // Zuerst snapshot_id holen
      snapshotId = await fetchPlaylistSnapshot(playlistId, access);
      if (snapshotId === null) {
        // Rate-Limit oder Fehler
        const rateLimitKey = 'playlist:' + playlistId;
        const cached = observedPlaylistCache.get(playlistId);
        if (cached && cached.ids.size > 0) {
          return {
            ids: cached.ids,
            items: cached.items,
            status: 429,
            snapshotId: cached.snapshotId,
          };
        }
        return null;
      }

      // Dann Items laden
      let url: string | null =
        'https://api.spotify.com/v1/playlists/' +
        encodeURIComponent(playlistId) +
        '/items?limit=100&fields=items(item(id,type,name,artists(name))),next';

      let page = 0;
      while (url) {
        const r = await fetch(url, {
          headers: { Authorization: 'Bearer ' + access },
          signal: AbortSignal.timeout(10000),
          cache: 'no-store',
        });
        page++;
        if (page === 1) status = r.status;

        if (r.status === 429) {
          const seconds = Number(r.headers.get('retry-after'));
          const retryAfter =
            Number.isFinite(seconds) && seconds > 0 ? seconds : 30;
          setRateLimit('playlist:' + playlistId, retryAfter);
          const cached = observedPlaylistCache.get(playlistId);
          if (cached && cached.ids.size > 0) {
            return {
              ids: cached.ids,
              items: cached.items,
              status: 429,
              snapshotId: cached.snapshotId,
            };
          }
          return null;
        }
        if (!r.ok) {
          if (r.status === 403) {
            return { ids: new Set(), items: [], status: 403, snapshotId: null };
          }
          return null;
        }

        const d = (await r.json()) as {
          items?: Array<{
            item?: {
              id?: string | null;
              type?: string | null;
              name?: string | null;
              artists?: { name?: string }[] | null;
            } | null;
          } | null>;
          next?: string | null;
        };
        for (const playlistItem of d.items || []) {
          const media = playlistItem?.item;
          if (media && media.type === 'track' && media.id) {
            ids.add(media.id);
          }
          items.push({
            id: media?.id ?? null,
            name: media?.name ?? '',
            artists: media?.artists?.map((a) => a.name ?? '').join(', ') ?? '',
          });
        }
        url = d.next;
      }

      console.log('[PLAYLIST ITEMS REFRESH]', {
        playlistId,
        trackCount: ids.size,
      });

      return { ids, items, status, snapshotId };
    } catch (e) {
      console.error('loadPlaylistFull: Fehler bei Playlist-Fetch:', e);
      return null;
    }
  });
}

async function observedPlaylistTrackIds(
  playlistId: string,
  access: string,
): Promise<ObservedPlaylistResult | null> {
  const rateLimitKey = 'playlist:' + playlistId;

  // 1. Rate-Limit-Check
  if (isRateLimited(rateLimitKey)) {
    const cached = observedPlaylistCache.get(playlistId);
    if (cached && cached.ids.size > 0) {
      return { ids: cached.ids, status: 429, items: cached.items };
    }
    return { ids: new Set(), status: 429, items: [] };
  }

  const cached = observedPlaylistCache.get(playlistId);

  // 2. Kein Cache vorhanden →首次 Snapshot + Items laden
  if (!cached) {
    const result = await loadPlaylistFull(playlistId, access);
    if (result) {
      observedPlaylistCache.set(playlistId, {
        snapshotId: result.snapshotId,
        ids: result.ids,
        items: result.items,
        fetchedAt: Date.now(),
        snapshotCheckedAt: Date.now(),
      });
      rateLimitState.delete(rateLimitKey);
    }
    return result
      ? { ids: result.ids, status: result.status, items: result.items }
      : null;
  }

  // 3. Cache vorhanden → Snapshot-Check nötig?
  const timeSinceSnapshotCheck = Date.now() - cached.snapshotCheckedAt;
  const wasRecentlyRL = wasRecentlyRateLimited(rateLimitKey);

  if (timeSinceSnapshotCheck >= SNAPSHOT_CHECK_INTERVAL || wasRecentlyRL) {
    // Snapshot-Check durchführen
    const newSnapshotId = await fetchPlaylistSnapshot(playlistId, access);

    if (newSnapshotId === null) {
      // Fehler bei Snapshot-Fetch → Rate-Limit oder Netzwerk
      // Bestehenden Cache weiter verwenden
      return { ids: cached.ids, status: 429, items: cached.items };
    }

    console.log('[PLAYLIST SNAPSHOT CHECK]', {
      playlistId,
      previousSnapshot: cached.snapshotId,
      currentSnapshot: newSnapshotId,
      changed: cached.snapshotId !== newSnapshotId,
    });

    if (newSnapshotId === cached.snapshotId) {
      // Snapshot unverändert → Cache aktualisieren, Items beibehalten
      cached.snapshotCheckedAt = Date.now();
      // Recovery abgeschlossen: Rate-Limit-Flag bereinigen, damit
      // nachfolgende Aufrufe wieder das normale 30s-Intervall nutzen.
      rateLimitState.delete(rateLimitKey);
      return { ids: cached.ids, status: 200, items: cached.items };
    }

    // Snapshot geändert → Items neu laden
    const freshResult = await loadPlaylistFull(playlistId, access);
    if (freshResult) {
      observedPlaylistCache.set(playlistId, {
        snapshotId: freshResult.snapshotId ?? newSnapshotId,
        ids: freshResult.ids,
        items: freshResult.items,
        fetchedAt: Date.now(),
        snapshotCheckedAt: Date.now(),
      });
      rateLimitState.delete(rateLimitKey);
      return {
        ids: freshResult.ids,
        status: freshResult.status,
        items: freshResult.items,
      };
    }
    // Fehler bei Items-Load → alten Cache behalten
    cached.snapshotCheckedAt = Date.now();
    return {
      ids: cached.ids,
      status: cached.ids.size > 0 ? 200 : 0,
      items: cached.items,
    };
  }

  // 4. Kein Snapshot-Check nötig → Cache direkt zurückgeben
  return { ids: cached.ids, status: 200, items: cached.items };
}
async function applyObservedState(
  track: Track,
  playlistId: string,
  access: string,
): Promise<void> {
  if (!track.id) return;
  const result = await observedPlaylistTrackIds(playlistId, access);
  if (!result) return; // A failed recovery cannot overwrite the last known state.
  if (result.status === 429) {
    const cached = observedPlaylistCache.get(playlistId);
    if (cached) track.inObservedPlaylist = cached.ids.has(track.id);
    track.playlistAccess = 'rate_limited';
    return;
  }
  if (result.status === 403) {
    track.inObservedPlaylist = false;
    track.playlistAccess = 'denied';
    return;
  }
  track.inObservedPlaylist = result.ids.has(track.id);
  delete track.playlistAccess;
}
async function genresFor(id: string, access: string): Promise<string[]> {
  try {
    const cached = await db()
      .prepare('SELECT genres,expires FROM artist_genres WHERE id=?')
      .bind(id)
      .first<{ genres: string; expires: number }>();
    if (cached && cached.expires > Date.now()) return JSON.parse(cached.genres);
    const r = await fetch(
      'https://api.spotify.com/v1/artists/' + encodeURIComponent(id),
      {
        headers: { Authorization: 'Bearer ' + access },
        signal: AbortSignal.timeout(4000),
      },
    );
    let genres: string[] = [];
    if (r.ok) {
      const d = (await r.json()) as { genres?: unknown };
      if (Array.isArray(d.genres))
        genres = d.genres.filter((g): g is string => typeof g === 'string');
    }
    const ttl = r.ok
      ? 7 * 86400000
      : r.status === 429
        ? Math.max(60, Number(r.headers.get('retry-after')) || 60) * 1000
        : 3600000;
    await db()
      .prepare(
        'INSERT INTO artist_genres (id,genres,expires) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET genres=excluded.genres,expires=excluded.expires',
      )
      .bind(id, JSON.stringify(genres), Date.now() + ttl)
      .run();
    return genres;
  } catch {
    return [];
  }
}
