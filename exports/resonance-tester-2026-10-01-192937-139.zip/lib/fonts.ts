import { FONT_LIBRARY, type FontDefinition } from './overlay';

// ============================================================================
// Lokale Font-Bereitstellung (Vorbereitung – Checkpoint 16.3.1)
// ----------------------------------------------------------------------------
// Ziel: Built-in Fonts sollen später von Resonance selbst ausgeliefert werden
// (WOFF2 aus /public/fonts/), statt auf das Google-Fonts-CDN zu vertrauen.
//
// AKTUELLER STAND (16.3.1):
// - Der Google-Fonts-@import in app/globals.css bleibt die Primärquelle.
// - Diese Datei ist die Infrastruktur: Sie referenziert für jeden Built-in
//   Font die lokale WOFF2-Datei und kann die @font-face-Regeln generieren.
// - NOCH KEINE Font-Dateien vorhanden – die Regeln in app/fonts.css sind
//   deshalb auskommentiert.
//
// SPÄTER BENÖTIGTE DATEIEN (public/fonts/):
//   /fonts/space-grotesk.woff2      – Space Grotesk  (Google Fonts, OFL)
//   /fonts/jost.woff2               – Jost           (Google Fonts, OFL)
//   /fonts/barlow-condensed.woff2   – Barlow Condensed (Google Fonts, OFL)
//   /fonts/ibm-plex-mono.woff2      – IBM Plex Mono  (Google Fonts, OFL)
//   /fonts/vt323.woff2              – VT323          (Google Fonts, OFL)
//   /fonts/playfair-display.woff2   – Playfair Display (Google Fonts, OFL)
//   /fonts/lora.woff2               – Lora           (Google Fonts, OFL)
//   /fonts/archivo-black.woff2      – Archivo Black  (Google Fonts, OFL)
//   /fonts/press-start-2p.woff2     – Press Start 2P (Google Fonts, OFL)
//   /fonts/caveat.woff2             – Caveat         (Google Fonts, OFL)
//
// Quelle: Google Fonts (https://fonts.google.com), Lizenz: SIL Open Font
// License (OFL). Die WOFF2-Dateien werden NICHT manuell heruntergeladen,
// sondern in einem späteren Schritt aus den Google-Fonts-Repositories
// übernommen. Hinweis: Google Fonts liefert statische WOFF2-Dateien pro
// Gewicht (z.B. jost-latin-400.woff2). Falls pro Gewicht getrennte Dateien
// verwendet werden, muss der Pfad in FONT_LIBRARY (localPath) entsprechend
// angepasst werden.
//
// Der Eintrag 'sans' (Inter/Arial) braucht KEINE lokale Datei: Seine
// font-family ist ein reiner System-Stack (Arial, Helvetica, sans-serif).
// ============================================================================

export type LocalFont = {
  id: string; // FONT_LIBRARY id
  family: string; // @font-face font-family (erster Name der family-Kette)
  weights: number[]; // Verfügbare Gewichte
  file: string; // Lokaler WOFF2-Pfad (/fonts/{name}.woff2)
  license: string; // Lizenz (Google Fonts: OFL)
  source: string; // Herkunft
};

// ----------------------------------------------------------------------------
// CSS format()-Hints für @font-face (Checkpoint 16.10.2)
// ----------------------------------------------------------------------------
// detectFontFormat() liefert 'otf'/'ttf'/'woff'/'woff2'. In CSS sind aber nur
// die format()-Hints 'opentype', 'truetype', 'woff' und 'woff2' gültig.
// Ein ungültiger Hint (z.B. format('otf')) lässt den Browser die komplette
// @font-face-Regel verwerfen → stiller Fallback auf Arial.
export const FONT_FORMAT_HINTS: Record<string, string> = {
  woff2: 'woff2',
  woff: 'woff',
  ttf: 'truetype',
  otf: 'opentype',
};
export function fontFormatHint(format: string): string {
  return FONT_FORMAT_HINTS[format] || format;
}

function hasLocalPath(
  f: FontDefinition,
): f is FontDefinition & { localPath: string } {
  return typeof f.localPath === 'string' && f.localPath.length > 0;
}

/** Erster Familienname aus der CSS-family-Kette, z.B. "'Jost', sans-serif" → "Jost". */
export function familyName(family: string): string {
  const m = family.match(/'([^']+)'/);
  return m ? m[1] : family;
}

/** Alle Built-in Fonts mit lokaler WOFF2-Datei. */
export function localFonts(): LocalFont[] {
  return FONT_LIBRARY.filter(hasLocalPath).map((f) => ({
    id: f.id,
    family: familyName(f.family),
    weights: f.weights,
    file: f.localPath,
    license: 'OFL',
    source: 'Google Fonts',
  }));
}

/**
 * Generiert die @font-face-Regeln für alle lokalen Fonts.
 * Wird aktuell nicht im Build verwendet (app/fonts.css enthält die Regeln
 * auskommentiert). Sobald die WOFF2-Dateien in /public/fonts/ liegen,
 * kann diese Ausgabe die Google-Fonts-@import-Zeile in app/globals.css
 * ersetzen.
 */
export function fontFaceCss(): string {
  return localFonts()
    .map((f) =>
      [
        `@font-face {`,
        `  font-family: '${f.family}';`,
        `  src: url('${f.file}') format('woff2');`,
        `  font-weight: ${f.weights[0]} ${f.weights[f.weights.length - 1]};`,
        `  font-display: swap;`,
        `}`,
      ].join('\n'),
    )
    .join('\n\n');
}