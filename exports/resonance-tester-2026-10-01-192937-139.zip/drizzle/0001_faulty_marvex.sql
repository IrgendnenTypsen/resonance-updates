CREATE TABLE `artist_genres` (
	`id` text PRIMARY KEY NOT NULL,
	`genres` text NOT NULL,
	`expires` integer NOT NULL
);
