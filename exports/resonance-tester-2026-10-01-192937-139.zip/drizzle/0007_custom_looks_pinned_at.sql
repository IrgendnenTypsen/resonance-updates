ALTER TABLE custom_looks ADD COLUMN pinned_at INTEGER;

-- Für historische Pins gibt es keinen echten Pin-Zeitpunkt. Die bestehende
-- Reihenfolge (created_at DESC, bei Gleichstand id ASC) wird daher als
-- deterministische Pin-Reihenfolge übernommen. Die Werte liegen vor allen
-- zukünftigen Date.now()-Zeitpunkten, damit neue Pins stets ans Ende kommen.
UPDATE custom_looks
SET pinned_at =
  (SELECT MIN(created_at) FROM custom_looks WHERE pinned = 1)
  - (SELECT COUNT(*) FROM custom_looks WHERE pinned = 1)
  + (
    SELECT COUNT(*)
    FROM custom_looks AS earlier
    WHERE earlier.pinned = 1
      AND (
        earlier.created_at > custom_looks.created_at
        OR (
          earlier.created_at = custom_looks.created_at
          AND earlier.id <= custom_looks.id
        )
      )
  )
WHERE pinned = 1;

CREATE INDEX custom_looks_owner_pinned_at
  ON custom_looks(owner, pinned, pinned_at ASC);
