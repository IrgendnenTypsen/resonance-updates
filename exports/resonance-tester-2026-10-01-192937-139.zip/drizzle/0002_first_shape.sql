ALTER TABLE `studios` ADD `lastfm_api_key` text;--> statement-breakpoint
ALTER TABLE `studios` ADD `genius_access_token` text;