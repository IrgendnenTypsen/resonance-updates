CREATE TABLE `studios` (
	`owner` text PRIMARY KEY NOT NULL,
	`overlay_key` text NOT NULL,
	`config` text NOT NULL,
	`access_token` text,
	`refresh_token` text,
	`expires` integer DEFAULT 0 NOT NULL,
	`verifier` text,
	`oauth_state` text,
	`oauth_expires` integer DEFAULT 0 NOT NULL,
	`cached` text,
	`polled` integer DEFAULT 0 NOT NULL,
	`retry_at` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `studios_overlay_key_unique` ON `studios` (`overlay_key`);