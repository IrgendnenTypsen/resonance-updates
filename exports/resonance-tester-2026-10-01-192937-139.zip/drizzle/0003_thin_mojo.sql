CREATE TABLE `custom_fonts` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`name` text NOT NULL,
	`original_filename` text NOT NULL,
	`format` text NOT NULL,
	`family` text NOT NULL,
	`data` blob NOT NULL,
	`size` integer NOT NULL,
	`created_at` integer NOT NULL
);
