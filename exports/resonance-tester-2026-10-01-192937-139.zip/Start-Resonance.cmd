@echo off
title RESONANCE Local Studio
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Resonance.ps1"
if errorlevel 1 pause
