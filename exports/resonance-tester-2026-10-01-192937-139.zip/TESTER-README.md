# RESONANCE – Tester Build

RESONANCE ist ein OBS-orientiertes Spotify-Musik-Overlay-Studio.

## Starten

1. Node.js 22+ installieren
2. `Start-Resonance.cmd` doppelklicken
3. Das geöffnete Startfenster während der Nutzung offen lassen
4. Browser: http://127.0.0.1:3000

Beim ersten Start installiert RESONANCE die fehlenden Pakete selbst und
richtet die lokale Datenbank ein. Dafür wird eine Internetverbindung benötigt.

## QA Lab

- Studio: http://127.0.0.1:3000
- QA Lab: http://127.0.0.1:3000/mood-visual-check

## Hinweise

- Dieses ZIP enthält KEINE persönlichen Daten, Tokens oder lokale Konfiguration.
- Spotify-Verbindung muss selbst eingerichtet werden (siehe LOKAL-STARTEN.md).
- Die lokale Datenbank wird beim ersten Start automatisch erstellt.

## Updates

- `Update-Resonance.cmd` prüft auf ein manuell gestartetes Update.
- Vor dem ersten Update muss in `resonance-update.json` eine öffentliche
  HTTPS-URL zu `resonance-latest.json` eingetragen werden.
- Deine lokale Datenbank, Spotify-Verbindung, Looks und Fonts bleiben bei
  einem Update erhalten.

## Mood Switch

Mood Switch funktioniert grundsätzlich ohne persönliche Developer-Credentials
(Spotify-Genres + MusicBrainz/ListenBrainz Fallbacks).

Für genauere Erkennung kannst du in den Mood Switch Settings eigene Zugänge
eintragen:
- Last.fm API Key (optional, verbessert Genres/Tags)
- Genius Access Token (optional, Lyrics-Fallback)

Die Keys werden nur lokal in deiner eigenen Datenbank gespeichert.
