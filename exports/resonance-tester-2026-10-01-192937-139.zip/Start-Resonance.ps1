$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $projectRoot

$env:WRANGLER_SEND_METRICS = 'false'
$env:WRANGLER_WRITE_LOGS = 'false'
$env:WRANGLER_LOG_PATH = Join-Path $projectRoot '.wrangler\logs'
$env:MINIFLARE_REGISTRY_PATH = Join-Path $projectRoot '.wrangler\registry'
$env:XDG_CONFIG_HOME = Join-Path $projectRoot '.wrangler\config'
$env:npm_config_cache = Join-Path $projectRoot '.npm-cache'
$env:RESONANCE_LOCAL = '1'

Write-Host ''
Write-Host '  RESONANCE startet lokal ...' -ForegroundColor Cyan
Write-Host ''

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host 'Node.js fehlt. Installiere Node.js 22 oder neuer.' -ForegroundColor Red
  Read-Host 'Enter zum Schliessen'
  exit 1
}

if (-not (Test-Path -LiteralPath 'node_modules')) {
  Write-Host 'Installiere die App beim ersten Start ...' -ForegroundColor Yellow
  & npm.cmd install
  if ($LASTEXITCODE -ne 0) { throw 'Installation fehlgeschlagen.' }
}

Write-Host 'Bereite die lokale Datenbank vor ...' -ForegroundColor DarkGray

# ---------------------------------------------------------------------------
# Lokale Migration-Registry
#
# Die Drizzle-Migrationen (drizzle/*.sql) sind NICHT idempotent:
#   - CREATE TABLE schlägt fehl, wenn die Tabelle existiert
#   - ALTER TABLE ADD COLUMN schlägt fehl, wenn die Spalte existiert
#
# Die Tabelle `_migrations` verfolgt, welche Migrationen bereits angewendet
# wurden. Bestehende Datenbanken (0000+0001, ohne Registry) werden erkannt
# und nur um die fehlende Migration 0002 ergänzt – ohne Datenverlust.
# ---------------------------------------------------------------------------

$d1Args = @(
  'd1', 'execute', 'site-creator-d1',
  '--local',
  '--config', 'local-wrangler.json',
  '--persist-to', '.wrangler/state'
)

function Invoke-D1 {
  param([string]$Command)
  $out = & npx.cmd wrangler @d1Args --command $Command --json 2>&1 | Out-String
  if ($LASTEXITCODE -ne 0) { throw "D1-Befehl fehlgeschlagen: $Command" }
  return $out
}

function Invoke-Migration {
  param([string]$Name, [string]$File)
  $applied = Invoke-D1 "SELECT name FROM _migrations WHERE name='$Name';"
  if ($applied -match $Name) {
    Write-Host "  Migration $Name bereits angewendet." -ForegroundColor DarkGray
    return
  }
  Write-Host "  Wende Migration $Name an ..." -ForegroundColor Yellow
  & npx.cmd wrangler @d1Args --file $File
  if ($LASTEXITCODE -ne 0) { throw "Migration $Name fehlgeschlagen." }
  Invoke-D1 "INSERT INTO _migrations (name, applied_at) VALUES ('$Name', strftime('%s','now'));"
  Write-Host "  Migration $Name registriert." -ForegroundColor DarkGray
}

# Zustand vor der Registry-Erstellung prüfen
$migTable = Invoke-D1 "SELECT name FROM sqlite_master WHERE type='table' AND name='_migrations';"
$hasRegistry = $migTable -match '_migrations'
$schema = Invoke-D1 "SELECT name FROM sqlite_master WHERE type='table' AND name='studios';"
$hasStudios = $schema -match 'studios'

# Registry-Tabelle robust anlegen (idempotent)
Invoke-D1 "CREATE TABLE IF NOT EXISTS _migrations (name TEXT PRIMARY KEY, applied_at INTEGER NOT NULL);"

if (-not $hasRegistry -and $hasStudios) {
  # Bestehende DB mit 0000+0001, aber ohne Registry:
  # 0000/0001 als angewendet markieren, danach fehlt nur noch 0002.
  Write-Host '  Bestehende Datenbank gefunden – markiere 0000/0001 als angewendet.' -ForegroundColor DarkGray
  Invoke-D1 "INSERT INTO _migrations (name, applied_at) VALUES ('0000_curvy_firebrand', strftime('%s','now'));"
  Invoke-D1 "INSERT INTO _migrations (name, applied_at) VALUES ('0001_faulty_marvex', strftime('%s','now'));"
}

# Fehlende Migrationen in Reihenfolge anwenden (0000 → … → 0007)
Invoke-Migration -Name '0000_curvy_firebrand' -File 'drizzle/0000_curvy_firebrand.sql'
Invoke-Migration -Name '0001_faulty_marvex' -File 'drizzle/0001_faulty_marvex.sql'
Invoke-Migration -Name '0002_first_shape' -File 'drizzle/0002_first_shape.sql'
Invoke-Migration -Name '0003_thin_mojo' -File 'drizzle/0003_thin_mojo.sql'
Invoke-Migration -Name '0004_loud_stick' -File 'drizzle/0004_loud_stick.sql'
Invoke-Migration -Name '0005_custom_looks' -File 'drizzle/0005_custom_looks.sql'
Invoke-Migration -Name '0006_custom_looks_pinned' -File 'drizzle/0006_custom_looks_pinned.sql'
Invoke-Migration -Name '0007_custom_looks_pinned_at' -File 'drizzle/0007_custom_looks_pinned_at.sql'

Write-Host ''
Write-Host '  Fertig: http://127.0.0.1:3000' -ForegroundColor Green
Write-Host '  Dieses Fenster offen lassen. Mit Strg+C beenden.' -ForegroundColor DarkGray
Write-Host ''

& npm.cmd run dev -- --hostname 127.0.0.1 --port 3000
