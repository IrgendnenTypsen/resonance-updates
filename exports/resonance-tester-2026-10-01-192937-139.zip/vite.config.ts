import { sites } from '@openai/sites-vite-plugin';
import tailwindcss from '@tailwindcss/postcss';
import vinext from 'vinext';
import { defineConfig } from 'vite';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';

const SITE_CREATOR_PLACEHOLDER_DATABASE_ID =
  '00000000-0000-4000-8000-000000000000';

// hosting.json ist eine lokale OpenAI-Sites-Datei und fehlt in Tester-ZIPs.
// Fallback auf local-wrangler.json, damit der Build ohne sie startbar ist.
function loadHostingConfig() {
  try {
    if (existsSync('./.openai/hosting.json')) {
      return JSON.parse(readFileSync('./.openai/hosting.json', 'utf8'));
    }
  } catch {}
  // Fallback: local-wrangler.json
  try {
    if (existsSync('./local-wrangler.json')) {
      const w = JSON.parse(readFileSync('./local-wrangler.json', 'utf8'));
      const d1 = w.d1_databases?.[0]?.binding || null;
      return { d1, r2: null };
    }
  } catch {}
  return { d1: null, r2: null };
}

const hostingConfig = loadHostingConfig();
const { d1, r2 } = hostingConfig;

// Das @openai/sites-vite-plugin kopiert hosting.json in closeBundle
// bedingungslos nach dist/.openai/. Damit der Build auch ohne die Datei
// startbar ist, wird sie hier aus dem Fallback erzeugt (nicht-sekret).
if (!existsSync('./.openai/hosting.json')) {
  try {
    mkdirSync('./.openai', { recursive: true });
    writeFileSync(
      './.openai/hosting.json',
      JSON.stringify({ d1, r2: null }, null, 2) + '\n',
    );
  } catch {}
}

// macOS Seatbelt blocks FSEvents, so Codex previews need polling for HMR.
const isCodexSeatbeltSandbox = process.env.CODEX_SANDBOX === 'seatbelt';
const isStableLocalPreview = process.env.RESONANCE_LOCAL === '1';

const localBindingConfig = {
  main: 'vinext/server/fetch-handler',
  compatibility_flags: ['nodejs_compat'],
  d1_databases: d1
    ? [
        {
          binding: d1,
          database_name: 'site-creator-d1',
          database_id: SITE_CREATOR_PLACEHOLDER_DATABASE_ID,
        },
      ]
    : [],
  r2_buckets: r2
    ? [
        {
          binding: r2,
          bucket_name: 'site-creator-r2',
        },
      ]
    : [],
};

export default defineConfig(async () => {
  // Keep Wrangler and Miniflare state project-local. These are non-secret tool
  // settings; application environment belongs in ignored `.env*` files.
  process.env.WRANGLER_WRITE_LOGS ??= 'false';
  process.env.WRANGLER_LOG_PATH ??= '.wrangler/logs';
  process.env.MINIFLARE_REGISTRY_PATH ??= '.wrangler/registry';

  // Wrangler snapshots its log path while the Cloudflare plugin is imported.
  const { cloudflare } = await import('@cloudflare/vite-plugin');

  return {
    resolve: { dedupe: ['react', 'react-dom'] },
    optimizeDeps: {
      include: [
        'react',
        'react-dom/client',
        '@base-ui/react/select',
        '@base-ui/react/dialog',
        '@base-ui/react/slider',
        '@base-ui/react/switch',
        '@base-ui/react/tabs',
        '@base-ui/react/button',
      ],
    },
    css: { postcss: { plugins: [tailwindcss()] } },
    server: {
      ...(isCodexSeatbeltSandbox
        ? { watch: { useFsEvents: false, usePolling: true } }
        : {}),
      ...(isStableLocalPreview ? { hmr: false } : {}),
    },
    plugins: [
      vinext(),
      sites(),
      cloudflare({
        viteEnvironment: { name: 'rsc', childEnvironments: ['ssr'] },
        config: localBindingConfig,
      }),
    ],
  };
});
