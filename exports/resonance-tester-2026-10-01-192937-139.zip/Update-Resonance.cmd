@echo off
title RESONANCE Updater
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update-Resonance.ps1"
if errorlevel 1 pause
