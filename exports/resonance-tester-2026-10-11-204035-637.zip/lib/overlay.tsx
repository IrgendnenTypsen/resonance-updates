import { memoryMoodStyle } from './memory-mood';
import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { moodConfig, detectMood, type LastfmTag } from './mood';
import { isMoodEffectivelyEnabled } from './mood-capabilities';
import { usePocketQuest } from './pocket-quest';
import {
  LOL_DEMO,
  LOL_TIER_COLORS,
  LOL_TIER_NAMES,
  championSplashUrl,
  isApexTier,
  useLolRanked,
  type LolQueue,
  type LolRanked,
} from './lol-ranked';
import {
  getCoverAccent,
  peekCoverAccent,
  titleAccentColor,
} from './cover-accent';
import {
  Music2,
  Heart,
  Shuffle,
  SkipBack,
  SkipForward,
  Play,
  Pause,
  Volume2,
  Square,
} from 'lucide-react';
export type Config = {
  layout: string;
  glassMaterial: 'legacy' | 'afterglow';
  accent: string;
  autoAccentFromCover: boolean;
  titleAccent: boolean;
  // Player-Anpassung (2026-10-11): Cover-Filter für alle Player, plus
  // layout-spezifische Elemente (zuerst Nullsoft '99).
  coverFilter: string;
  bodyStyle: string;
  visualizerVisible: boolean;
  visualizerColor: string;
  visualizerPosition: string;
  controlsVisible: boolean;
  volumeVisible: boolean;
  // Pocket Quest Spielmechanik
  gameLevel: boolean;
  gameRarity: boolean;
  gameCombo: boolean;
  gameQuest: boolean;
  gameAchievements: boolean;
  gameParty: boolean;
  gelAnimation: boolean;
  stickyStack: number;
  stickyTilt: boolean;
  stickySlap: boolean;
  lolQueue: string;
  lolSplash: boolean;
  lolSplashMotion: boolean;
  lolSplashDim: number;
  lolChamp: string;
  lolChampName: string;
  lolMain: boolean;
  lolRank: boolean;
  lolTicker: boolean;
  albumVisible: boolean;
  background: string;
  text: string;
  radius: number;
  opacity: number;
  glow: boolean;
  cover: boolean;
  progress: boolean;
  artist: boolean;
  badge: boolean;
  hidePaused: boolean;
  font: string;
  titleFont: string;
  artistFont: string;
  metaFont: string;
  titleWeight: number;
  artistWeight: number;
  metaWeight: number;
  titleSize: number;
  artistSize: number;
  metaSize: number;
  titleLetterSpacing: number;
  artistLetterSpacing: number;
  metaLetterSpacing: number;
  titleCase: string;
  artistCase: string;
  metaCase: string;
  width: number;
  spacing: number;
  fontSize: number;
  animation: string;
  align: string;
  moodSwitch: boolean;
  moodIntensity: number;
  glassOpacity: number;
  glassTintColor: string;
  glassTintStrength: number;
  glassFrost: number;
  glassHighlight: number;
  spin: boolean;
  spinSpeed: number;
  memoryLabel: string;
  ledVisible: boolean;
  ledColor: string;
  ledBehavior: string;
  ledBrightness: number;
  ledGlow: number;
  ledSpeed: number;
  ledSize: number;
  ledOffsetX: number;
  ledOffsetY: number;
  displayColor: string;
  displayBrightness: number;
  textGlow: number;
  progressColor: string;
  controlAccentColor: string;
  statusAccentColor: string;
  linkAccentColors: boolean;
  progressEdge: number;
  progressWidth: number;
  progressThickness: number;
  progressOffsetX: number;
  progressOffsetY: number;
  progressRadius: number;
  controlsSize: number;
  controlsIconSize: number;
  controlsGap: number;
  controlsOffsetX: number;
  controlsOffsetY: number;
  coverBrightness: number;
  coverSaturation: number;
  coverContrast: number;
  coverSize: number;
  coverOffsetX: number;
  coverOffsetY: number;
  coverRadius: number;
  coverFit: string;
  noteSize: number;
  noteOffsetX: number;
  noteOffsetY: number;
  noteRotation: number;
  noteOpacity: number;
  titleOffsetX: number;
  titleOffsetY: number;
  artistOffsetX: number;
  artistOffsetY: number;
  metaOffsetX: number;
  metaOffsetY: number;
  titleArtistSpacing: number;
  scanlinesEnabled: boolean;
  scanlineStrength: number;
  grainEnabled: boolean;
  grainStrength: number;
  vignetteStrength: number;
  observedPlaylistId: string;
  observedPlaylistName: string;
};
export const defaults: Config = {
  layout: 'glass',
  glassMaterial: 'legacy',
  accent: '#b3f47c',
  autoAccentFromCover: false,
  titleAccent: false,
  coverFilter: 'none',
  bodyStyle: 'default',
  visualizerVisible: true,
  visualizerColor: '',
  visualizerPosition: 'right',
  controlsVisible: true,
  volumeVisible: true,
  gameLevel: true,
  gameRarity: true,
  gameCombo: true,
  gameQuest: true,
  gameAchievements: true,
  gameParty: true,
  gelAnimation: true,
  stickyStack: 2,
  stickyTilt: true,
  stickySlap: true,
  lolQueue: 'solo',
  lolSplash: true,
  lolSplashMotion: true,
  lolSplashDim: 20,
  lolChamp: '',
  lolChampName: '',
  lolMain: true,
  lolRank: true,
  lolTicker: true,
  albumVisible: true,
  background: '#161b20',
  text: '#ffffff',
  radius: 24,
  opacity: 86,
  glow: true,
  cover: true,
  progress: true,
  artist: true,
  badge: true,
  hidePaused: false,
  font: 'sans',
  titleFont: 'sans',
  artistFont: 'sans',
  metaFont: 'sans',
  titleWeight: 700,
  artistWeight: 400,
  metaWeight: 700,
  titleSize: 23,
  artistSize: 14,
  metaSize: 9,
  titleLetterSpacing: -0.65,
  artistLetterSpacing: 0,
  metaLetterSpacing: 1.5,
  titleCase: 'normal',
  artistCase: 'normal',
  metaCase: 'uppercase',
  width: 480,
  spacing: 22,
  fontSize: 23,
  animation: 'fade',
  align: 'left',
  moodSwitch: false,
  moodIntensity: 70,
  glassOpacity: 52,
  glassTintColor: '#dce8f2',
  glassTintStrength: 14,
  glassFrost: 24,
  glassHighlight: 58,
  spin: false,
  spinSpeed: 14,
  memoryLabel: 'GOOD MUSIC BETTER DAYS.',
  ledVisible: true,
  ledColor: '#ff7a6a',
  ledBehavior: 'soft',
  ledBrightness: 70,
  ledGlow: 50,
  ledSpeed: 50,
  ledSize: 100,
  ledOffsetX: 0,
  ledOffsetY: 0,
  displayColor: '#101619',
  displayBrightness: 100,
  textGlow: 0,
  progressColor: '#b3f47c',
  controlAccentColor: '#b3f47c',
  statusAccentColor: '#b3f47c',
  linkAccentColors: true,
  progressEdge: 0,
  progressWidth: 100,
  progressThickness: 100,
  progressOffsetX: 0,
  progressOffsetY: 0,
  progressRadius: 5,
  controlsSize: 100,
  controlsIconSize: 100,
  controlsGap: 100,
  controlsOffsetX: 0,
  controlsOffsetY: 0,
  coverBrightness: 100,
  coverSaturation: 100,
  coverContrast: 100,
  // Die Layout-Defaults entsprechen den bisherigen festen CSS-Werten.
  coverSize: 100,
  coverOffsetX: 0,
  coverOffsetY: 0,
  coverRadius: 5,
  coverFit: 'cover',
  noteSize: 100,
  noteOffsetX: 0,
  noteOffsetY: 0,
  noteRotation: 0,
  noteOpacity: 100,
  titleOffsetX: 0,
  titleOffsetY: 0,
  artistOffsetX: 0,
  artistOffsetY: 0,
  metaOffsetX: 0,
  metaOffsetY: 0,
  titleArtistSpacing: 3,
  scanlinesEnabled: true,
  scanlineStrength: 10,
  grainEnabled: false,
  grainStrength: 10,
  vignetteStrength: 22,
  observedPlaylistId: '',
  observedPlaylistName: '',
};
export function isAfterglow(
  config: Pick<Config, 'layout' | 'glassMaterial'>,
): boolean {
  return config.layout === 'glass' && config.glassMaterial === 'afterglow';
}
export type FontDefinition = {
  id: string;
  name: string; // Anzeigename
  category: string; // Kategorie-Label
  family: string; // CSS font-family
  weights: number[]; // Verfügbare Gewichte
  preview?: string; // Optionaler Vorschau-Text im Picker
  localPath?: string; // Lokale WOFF2-Datei (Vorbereitung, /fonts/{name}.woff2)
};
export const FONT_LIBRARY: FontDefinition[] = [
  // CLEAN / MODERN
  {
    id: 'sans',
    name: 'Inter',
    category: 'Clean',
    family: 'Arial, Helvetica, sans-serif',
    weights: [300, 400, 500, 700],
  },
  {
    id: 'grotesk',
    name: 'Space Grotesk',
    category: 'Clean',
    family: "'Space Grotesk', sans-serif",
    weights: [300, 400, 500, 700],
    localPath: '/fonts/space-grotesk.woff2',
  },
  {
    id: 'aqua',
    name: 'Lucida Grande',
    category: 'Clean',
    family:
      "'Lucida Grande', 'Lucida Sans Unicode', 'Lucida Sans', Geneva, Verdana, sans-serif",
    weights: [400, 700],
  },
  {
    id: 'fantasy',
    name: 'Cinzel',
    category: 'Display',
    family: "'Cinzel', Georgia, serif",
    weights: [600, 700],
  },
  // GEOMETRIC
  {
    id: 'geometric',
    name: 'Jost',
    category: 'Geometric',
    family: "'Jost', 'Century Gothic', sans-serif",
    weights: [300, 400, 700],
    localPath: '/fonts/jost.woff2',
  },
  // CONDENSED
  {
    id: 'condensed',
    name: 'Barlow Condensed',
    category: 'Condensed',
    family: "'Barlow Condensed', 'Arial Narrow', sans-serif",
    weights: [300, 400, 500, 700],
    localPath: '/fonts/barlow-condensed.woff2',
  },
  // MONO / TECH
  {
    id: 'mono',
    name: 'IBM Plex Mono',
    category: 'Mono',
    family: "'IBM Plex Mono', 'Consolas', monospace",
    weights: [300, 400, 500, 700],
    localPath: '/fonts/ibm-plex-mono.woff2',
  },
  {
    id: 'mono-retro',
    name: 'VT323',
    category: 'Mono',
    family: "'VT323', 'Courier New', monospace",
    weights: [400],
    localPath: '/fonts/vt323.woff2',
  },
  // SERIF
  {
    id: 'serif',
    name: 'Playfair Display',
    category: 'Serif',
    family: "'Playfair Display', Georgia, serif",
    weights: [400, 500, 700],
    localPath: '/fonts/playfair-display.woff2',
  },
  {
    id: 'editorial',
    name: 'Lora',
    category: 'Serif',
    family: "'Lora', Georgia, serif",
    weights: [400, 500, 700],
    localPath: '/fonts/lora.woff2',
  },
  // DISPLAY
  {
    id: 'display',
    name: 'Archivo Black',
    category: 'Display',
    family: "'Archivo Black', Impact, sans-serif",
    weights: [400],
    localPath: '/fonts/archivo-black.woff2',
  },
  // RETRO
  {
    id: 'retro',
    name: 'Press Start 2P',
    category: 'Retro',
    family: "'Press Start 2P', monospace",
    weights: [400],
    localPath: '/fonts/press-start-2p.woff2',
  },
  // HANDWRITTEN
  {
    id: 'handwritten',
    name: 'Caveat',
    category: 'Handwritten',
    family: "'Caveat', cursive",
    weights: [400, 500, 700],
    localPath: '/fonts/caveat.woff2',
  },
];
export function resolveFontFamily(fontId: string): string {
  if (fontId.startsWith('custom:')) {
    const id = fontId.slice(7);
    return `'ResonanceCustom_${id}', Arial, sans-serif`;
  }
  const font = FONT_LIBRARY.find((f) => f.id === fontId);
  return font?.family || 'Arial, sans-serif';
}
// Cover-Filter im Insta-Stil (CSS-Filterketten). 'none' = keine Änderung.
export const COVER_FILTERS: Record<string, { label: string; css: string }> = {
  none: { label: 'Original', css: 'saturate(1)' },
  vintage: {
    label: 'Vintage',
    css: 'sepia(0.35) contrast(1.05) saturate(1.2) hue-rotate(-8deg)',
  },
  warm: { label: 'Warm', css: 'sepia(0.2) saturate(1.3) hue-rotate(-10deg)' },
  cool: {
    label: 'Kühl',
    css: 'saturate(1.1) hue-rotate(12deg) brightness(1.03)',
  },
  fade: {
    label: 'Verblasst',
    css: 'contrast(0.85) brightness(1.08) saturate(0.8)',
  },
  vivid: { label: 'Kräftig', css: 'saturate(1.6) contrast(1.1)' },
  mono: { label: 'Schwarzweiß', css: 'grayscale(1) contrast(1.1)' },
  noir: { label: 'Noir', css: 'grayscale(1) contrast(1.45) brightness(0.9)' },
};
export function coverFilterCss(c: Config) {
  return (
    'brightness(' +
    c.coverBrightness / 100 +
    ') saturate(' +
    c.coverSaturation / 100 +
    ') contrast(' +
    c.coverContrast / 100 +
    ') ' +
    (COVER_FILTERS[c.coverFilter] || COVER_FILTERS.none).css
  );
}
export type Track = {
  title: string;
  artist: string;
  cover: string;
  duration: number;
  progress: number;
  playing: boolean;
  demo?: boolean;
  album?: string;
  genres?: string[];
  artistId?: string;
  id?: string;
  slot?: number;
  favorite?: boolean;
  inObservedPlaylist?: boolean;
  playlistAccess?: 'denied' | 'rate_limited';
  lastfmTags?: LastfmTag[];
  isrc?: string; // NEU
  lyricMoodScores?: Record<string, number>;
  fetchedAt?: number;
};
export function estimatedProgress(track: Track, now = Date.now()) {
  const elapsed = track.playing
    ? Math.max(0, now - (track.fetchedAt ?? now))
    : 0;
  return Math.min(track.duration, Math.max(0, track.progress + elapsed));
}
export const demo: Track = {
  title: 'Midnight in Motion',
  artist: 'Resonance Radio',
  cover: '',
  duration: 224000,
  progress: 87000,
  playing: true,
  demo: true,
};
// --- Track Transition (Checkpoint 16.26 / 16.26.1 / 16.26.2) ---
// Subtile, feste Standardtransition beim Wechsel zu einem wirklich neuen
// Spotify-Track. Phasen: stable → exit → swap → enter → stable.
// Die Transition animiert ausschließlich dedizierte Wrapper
// (track-transition-cover/-meta/-title/-artist) im Memory-Layout. Die
// bestehenden Memory-Elemente behalten dadurch ihre Basisanimationen
// (memory-slot-load, memory-text-enter, memory-text-slide) und deren
// fill-mode-Endzustände unverändert. Kein animation-name-Wechsel auf den
// Original-Elementen → kein Double-Blink, keine Layout-Regression.
// Keine neuen Settings, keine Mood-/Layout-Änderungen.
type TransitionPhase = 'stable' | 'exit' | 'enter';
const EXIT_MS = 180;
const ENTER_MS = 300;
function trackId(t: Track | null): string | null {
  if (!t) return null;
  return t.id || t.title + '|' + t.artist;
}
// --- Dynamic Accent from Cover (V1.1) ---
// Liefert den aus dem ANGEZEIGTEN Cover abgeleiteten Akzent oder null.
// null → manueller config.accent. Bei Cover-Wechsel sofort null (kein
// Nachleuchten des alten Tracks), bis die neue Analyse fertig ist.
// Latest wins: Ergebnisse gelten nur für die URL, für die sie berechnet
// wurden; veraltete Promises werden ignoriert.
function useCoverAccent(
  enabled: boolean,
  cover: string | undefined,
): string | null {
  const [result, setResult] = useState<{
    url: string;
    accent: string | null;
  } | null>(null);
  useEffect(() => {
    if (!enabled || !cover) return;
    if (peekCoverAccent(cover) !== undefined) return;
    let current = true;
    getCoverAccent(cover).then((accent) => {
      if (current) setResult({ url: cover, accent });
    });
    return () => {
      current = false;
    };
  }, [enabled, cover]);
  if (!enabled || !cover) return null;
  const known = peekCoverAccent(cover);
  if (known !== undefined) return known;
  return result && result.url === cover ? result.accent : null;
}
// --- Sticky Notes (Player-Redesign 4/4, 2026-10-11): Post-it-Stapel ---
// Papierfarben je Palette (bodyStyle). Jeder Songwechsel nimmt die nächste
// Farbe; die Zettel darunter zeigen die Farben der vorherigen Songs.
export const STICKY_PALETTES: Record<string, string[]> = {
  default: ['#fff27a', '#ff9ec4', '#8cf0c6', '#9fd6ff', '#ffc27a'],
  pastel: ['#fff4c2', '#ffdbe6', '#d9f5e8', '#dceaff', '#ece0ff'],
  kraft: ['#fbfaf6', '#d9bc93', '#f1ece2', '#c9a77c', '#ffffff'],
};
const STICKY_TILTS = [-3, 2.5, -1.5, 3.5, -2.5];
function hashString(v: string) {
  let h = 0;
  for (let i = 0; i < v.length; i++) h = (h * 31 + v.charCodeAt(i)) | 0;
  return Math.abs(h);
}
/** Zählt Songwechsel (Start-Offset aus der Track-ID, damit nicht jeder
 *  Stream mit derselben Farbe beginnt). Leere ID = keine Änderung. */
function useStickyCounter(id: string) {
  const [n, setN] = useState(() => hashString(id) % 5);
  const prev = useRef(id);
  useEffect(() => {
    if (!id) return;
    if (prev.current && prev.current !== id) setN((v) => v + 1);
    prev.current = id;
  }, [id]);
  return n;
}
export function Overlay({
  config: configIn,
  track: t,
}: {
  config: Config;
  track: Track | null;
}) {
  const [displayed, setDisplayed] = useState<Track | null>(t);
  const displayedRef = useRef<Track | null>(t);
  const [phase, setPhase] = useState<TransitionPhase>('stable');
  const pendingRef = useRef<Track | null>(null);
  const exitTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const enterTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Ref parallel zum displayed-State halten, damit der Transition-Effect
  // ohne State-Dependency auf den aktuellen Track zugreifen kann.
  useEffect(() => {
    displayedRef.current = displayed;
  }, [displayed]);

  useEffect(() => {
    const incomingId = trackId(t);
    const displayedId = trackId(displayedRef.current);

    if (incomingId === displayedId) {
      // Gleicher Track: Daten (Play/Pause, Progress, Favorite) übernehmen,
      // ohne eine Track-Transition auszulösen. Ein noch laufender Exit auf
      // einen anderen Track wird abgebrochen (Latest wins).
      if (exitTimer.current) {
        clearTimeout(exitTimer.current);
        exitTimer.current = null;
        pendingRef.current = null;
        setPhase('stable');
      }
      if (t !== displayedRef.current) setDisplayed(t);
      return;
    }

    // Ein neuer Track bricht eine laufende Entry-Animation ab (Latest wins).
    if (enterTimer.current) {
      clearTimeout(enterTimer.current);
      enterTimer.current = null;
    }

    if (incomingId === null) {
      // Track → Idle: sanft ausblenden, danach leerer Zustand.
      if (displayedId === null) return;
      setPhase('exit');
      if (exitTimer.current) clearTimeout(exitTimer.current);
      exitTimer.current = setTimeout(() => {
        setDisplayed(null);
        setPhase('stable');
        exitTimer.current = null;
      }, EXIT_MS);
      return;
    }

    if (displayedId === null) {
      // Idle → Track bzw. Initial Load: direkt setzen, nur dezenter Entry.
      setDisplayed(t);
      setPhase('enter');
      enterTimer.current = setTimeout(() => {
        setPhase('stable');
        enterTimer.current = null;
      }, ENTER_MS);
      return;
    }

    // Track → Track: Exit, Swap auf den zuletzt empfangenen Track, Entry.
    pendingRef.current = t;
    setPhase('exit');
    if (exitTimer.current) clearTimeout(exitTimer.current);
    exitTimer.current = setTimeout(() => {
      const next = pendingRef.current;
      pendingRef.current = null;
      if (next) {
        setDisplayed(next);
        setPhase('enter');
        enterTimer.current = setTimeout(() => {
          setPhase('stable');
          enterTimer.current = null;
        }, ENTER_MS);
      } else {
        setPhase('stable');
      }
      exitTimer.current = null;
    }, EXIT_MS);
  }, [t]);

  useEffect(() => {
    return () => {
      if (exitTimer.current) clearTimeout(exitTimer.current);
      if (enterTimer.current) clearTimeout(enterTimer.current);
    };
  }, []);

  // Dynamic Accent: Cover des eingehenden Tracks vorab analysieren (Cache),
  // angewendet wird aber ausschließlich das Cover von `displayed`.
  useEffect(() => {
    if (configIn.autoAccentFromCover && t?.cover) void getCoverAccent(t.cover);
  }, [configIn.autoAccentFromCover, t?.cover]);
  const coverAccent = useCoverAccent(
    !!configIn.autoAccentFromCover,
    displayed?.cover,
  );
  const pq = usePocketQuest(
    displayed,
    configIn.layout === 'pixel' && !!displayed,
  );
  const lolLive = useLolRanked(
    configIn.layout === 'lol' && !!displayed,
    configIn.lolQueue === 'flex' ? 'flex' : ('solo' as LolQueue),
    15000,
  );
  const stickyN = useStickyCounter(
    configIn.layout === 'sticker' && displayed ? trackId(displayed) || '' : '',
  );
  // Effektiver BASIS-Akzent; Mood (moodConfig/memoryMoodStyle) läuft danach
  // unverändert auf dieser Basis.
  const base: Config = coverAccent
    ? { ...configIn, accent: coverAccent }
    : configIn;
  const moodEnabled = isMoodEffectivelyEnabled(base);
  const c = moodConfig(base, displayed, displayed?.lastfmTags);
  if (!displayed && c.layout !== 'memory') return null;
  if (displayed && c.hidePaused && !displayed.playing) return null;
  const mood = moodEnabled
    ? detectMood(displayed, displayed?.lastfmTags)
    : null;
  const opacityHex = Math.round(c.opacity * 2.55)
    .toString(16)
    .padStart(2, '0');
  // Ranked LoL: echte Client-Daten; ohne Client im Demo-Modus Demo-Werte.
  const lolData: LolRanked | null =
    c.layout !== 'lol'
      ? null
      : lolLive.data.status === 'ok' || lolLive.data.status === 'unranked'
        ? lolLive.data
        : displayed?.demo
          ? LOL_DEMO
          : null;
  const lolChampAlias =
    c.lolChamp || (lolData?.main && lolData.main.alias) || '';
  const lolChampLabel = c.lolChamp
    ? c.lolChampName || c.lolChamp
    : lolData?.main?.name || '';
  const lolSplashUrl =
    c.layout === 'lol' && c.lolSplash ? championSplashUrl(lolChampAlias) : null;
  const lolTier = lolData?.status === 'ok' ? lolData.tier || '' : '';
  const lolColors = LOL_TIER_COLORS[lolTier] || ['#8a8f99', '#c8ccd4', '#3a3f48'];
  const style = {
    '--cover-filter': coverFilterCss(c),
    ...(c.layout === 'lol'
      ? {
          '--lol-dim': c.lolSplashDim / 100,
          '--lol-tier': lolColors[0],
          '--lol-tier-hi': lolColors[1],
          '--lol-tier-lo': lolColors[2],
        }
      : {}),
    '--cover-preset-filter': (COVER_FILTERS[c.coverFilter] || COVER_FILTERS.none)
      .css,
    '--ns-vis': /^#[0-9a-f]{6}$/i.test(c.visualizerColor)
      ? c.visualizerColor
      : 'var(--oa)',
    '--spin-speed': c.spinSpeed + 's',
    ...(c.layout === 'sticker'
      ? (() => {
          const pal = STICKY_PALETTES[c.bodyStyle] || STICKY_PALETTES.default;
          const at = (k: number) => pal[(stickyN - k + pal.length * 1000) % pal.length];
          return {
            '--sn-c': at(0),
            '--sn-c1': at(1),
            '--sn-c2': at(2),
            '--sn-rot': c.stickyTilt
              ? STICKY_TILTS[stickyN % STICKY_TILTS.length] + 'deg'
              : '0deg',
          };
        })()
      : {}),
    ...(moodEnabled
      ? { '--mood-speed': (mood?.mood.speed || 0.8) + 's' }
      : {}),
    '--oa': c.accent,
    '--ot': c.text,
    '--or': c.radius + 'px',
    '--op': c.spacing + 'px',
    '--ofs': c.fontSize + 'px',
    '--mbg': c.background + opacityHex,
    '--glass-base': c.background,
    '--glass-material': c.glassOpacity + '%',
    '--glass-material-alpha': c.glassOpacity / 100,
    '--glass-tint': c.glassTintColor,
    '--glass-tint-strength': c.glassTintStrength + '%',
    '--glass-frost': c.glassFrost + '%',
    '--glass-frost-alpha': c.glassFrost / 100,
    '--glass-highlight': c.glassHighlight + '%',
    '--glass-highlight-alpha': c.glassHighlight / 100,
    background: c.background + opacityHex,
    width: c.width,
    fontFamily: resolveFontFamily(c.titleFont),
    textAlign: c.align,
  } as CSSProperties;
  if (c.layout === 'memory')
    return (
      <MemorySlot
        config={base}
        track={displayed}
        style={style}
        mood={mood?.mood.id}
        phase={phase}
      />
    );
  // Für TypeScript: Nach dem Memory-Return ist displayed garantiert gesetzt.
  if (!displayed) return null;
  const node = (
    <div
      key={c.animation + c.layout + c.glassMaterial}
      style={style}
      className={
        'overlay layout-' +
        c.layout +
        (c.layout === 'glass' ? ' material-' + c.glassMaterial : '') +
        (c.layout === 'winamp' ||
        c.layout === 'pixel' ||
        c.layout === 'aqua' ||
        c.layout === 'sticker' ||
        c.layout === 'lol'
          ? ' body-' + c.bodyStyle
          : '') +
        (c.layout === 'sticker'
          ? (c.stickySlap ? (stickyN % 2 ? ' sn-slap-b' : ' sn-slap-a') : '') +
            (c.stickyTilt ? ' sn-tilt' : '')
          : '') +
        (c.layout === 'aqua'
          ? (c.gelAnimation ? ' aq-gel' : '') +
            (c.cover ? '' : ' aq-nocover') +
            (displayed.playing ? '' : ' aq-paused')
          : '') +
        ' anim-' +
        c.animation +
        (c.glow ? ' has-glow' : '') +
        (phase === 'exit' ? ' track-exit' : '') +
        (phase === 'enter' ? ' track-enter' : '')
      }
    >
      {c.layout === 'winamp' && (
        // Nullsoft '99 (Player-Redesign 1/4): Desktop-Player um 2000 –
        // Fensterleiste, Menüzeile, LCD in Akzentfarbe, Visualizer.
        <>
          <div className="ns-titlebar" aria-hidden="true">
            <span className="ns-app-icon">
              <Music2 size={8} strokeWidth={3} />
            </span>
            <span className="ns-app-name">Resonance Media Player</span>
            <span className="ns-winbtns">
              <i />
              <i />
              <i className="ns-close" />
            </span>
          </div>
          <div className="ns-menu" aria-hidden="true">
            <span>Datei</span>
            <span>Wiedergabe</span>
            <span>Ansicht</span>
            <span>Hilfe</span>
          </div>
        </>
      )}
      {c.layout === 'aqua' && (
        // Aqua Days (Player-Redesign 3/4): Mac-OS-X-Fenster, 8er-Raster.
        <div className="aqua-bar" aria-hidden="true">
          <span className="traffic-lights">
            <i />
            <i />
            <i />
          </span>
          <span className="aqua-title">Now Playing</span>
        </div>
      )}
      {c.layout === 'pixel' && (
        // Pocket Quest (Player-Redesign 2/4): JRPG-Dialog mit Spielmechanik.
        <>
          <div className="pq-tab" aria-hidden="true">
            ♪ QUEST LOG
          </div>
          {c.gameLevel && pq.levelUp && (
            <div className="pq-levelup" aria-hidden="true">
              LEVEL UP! LV {String(pq.level).padStart(2, '0')}
            </div>
          )}
          {c.gameAchievements && pq.toast && (
            <div className="pq-toast" aria-hidden="true">
              <span>★</span>
              <span>
                <b>ERFOLG</b>
                <br />
                {pq.toast}
              </span>
            </div>
          )}
          <span className="pq-arrow" aria-hidden="true">
            ▼
          </span>
        </>
      )}
      {c.layout === 'lol' && (
        // Ranked LoL (Ranked Gaming Players 1/3): Splash-Art des Mains,
        // Hextech-Rahmen mit Eck-Ornamenten.
        <>
          {lolSplashUrl && (
            <div
              className={'lol-splash' + (c.lolSplashMotion ? ' is-moving' : '')}
              style={{ backgroundImage: 'url(' + lolSplashUrl + ')' }}
              aria-hidden="true"
            />
          )}
          <div className="lol-shade" aria-hidden="true" />
          <svg className="lol-corner is-tl" viewBox="0 0 22 22" aria-hidden="true">
            <path d="M1 13V1h12M5 9V5h4" />
          </svg>
          <svg className="lol-corner is-br" viewBox="0 0 22 22" aria-hidden="true">
            <path d="M1 13V1h12M5 9V5h4" />
          </svg>
        </>
      )}
      {c.layout === 'vinyl' && (
        <div className="vinyl-label">
          SIDE A <span>33⅓ RPM · STEREO</span>
        </div>
      )}
      <div className="overlay-main">
        {c.cover && (
          <div
            className={'album-art' + (c.spin ? ' rotating-cover' : '')}
            style={{
              animationPlayState: displayed.playing ? 'running' : 'paused',
            }}
          >
            {c.layout === 'pixel' && c.gameRarity && (
              <span
                className={
                  'pq-rarity ' +
                  (displayed.favorite
                    ? 'is-legendary'
                    : displayed.inObservedPlaylist
                      ? 'is-epic'
                      : 'is-common')
                }
                aria-hidden="true"
              >
                {displayed.favorite
                  ? 'LEGENDÄR'
                  : displayed.inObservedPlaylist
                    ? 'EPISCH'
                    : 'GEWÖHNLICH'}
              </span>
            )}
            {displayed.cover ? (
              <img
                src={displayed.cover}
                alt={'Albumcover: ' + displayed.title}
              />
            ) : (
              <div className="demo-art">
                <Music2 size={38} />
                <span>R / 01</span>
              </div>
            )}
          </div>
        )}
        <div className="track-info">
          {c.layout === 'winamp' && (
            <div className="ns-lcd-top" aria-hidden="true">
              <span className="ns-time">{time(displayed.progress)}</span>
              <span className="ns-state">{displayed.playing ? '▶' : '❚❚'}</span>
              {c.visualizerVisible && c.visualizerPosition !== 'bottom' && (
              <span className="ns-bars">
                {Array.from({ length: 10 }, (_, i) => (
                  <i
                    key={i}
                    style={{
                      animationDelay: -((i * 0.37) % 1.1).toFixed(2) + 's',
                      animationPlayState: displayed.playing
                        ? 'running'
                        : 'paused',
                    }}
                  />
                ))}
              </span>
              )}
            </div>
          )}
          {c.badge && (
            <div
              className="now-playing"
              style={{
                fontFamily: resolveFontFamily(c.metaFont),
                fontWeight: c.metaWeight,
                fontSize: c.metaSize + 'px',
                letterSpacing: c.metaLetterSpacing + 'px',
                textTransform:
                  c.metaCase === 'uppercase' ? 'uppercase' : undefined,
              }}
            >
              <span
                className={'equalizer ' + (!displayed.playing ? 'paused' : '')}
              >
                <i />
                <i />
                <i />
                <i />
              </span>
              {c.layout === 'winamp'
                ? displayed.playing
                  ? '128 KBPS · 44 KHZ · STEREO'
                  : 'PAUSIERT'
                : c.layout === 'pixel'
                  ? displayed.playing
                    ? 'NOW PLAYING'
                    : 'PAUSIERT'
                : c.layout === 'sticker'
                  ? displayed.playing
                    ? 'läuft gerade'
                    : 'pausiert'
                : c.layout === 'lol'
                  ? displayed.playing
                    ? '♪ JETZT LÄUFT'
                    : 'PAUSIERT'
                : displayed.demo
                  ? 'RESONANCE RADIO'
                  : displayed.playing
                    ? 'PLAYING ON SPOTIFY'
                    : 'PAUSIERT'}
              {c.layout === 'sticker' && (
                <svg
                  className="sn-arrow"
                  width="44"
                  height="18"
                  viewBox="0 0 44 18"
                  aria-hidden="true"
                >
                  <path
                    d="M3 4c10 1 22 4 33 10m0 0l-8 1m8-1l-2-8"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              )}
              {c.layout === 'pixel' && c.gameCombo && pq.combo >= 2 && (
                <span className="pq-combo">COMBO ×{pq.combo}</span>
              )}
            </div>
          )}
          <div
            className="track-title"
            title={displayed.title}
            style={{
              fontFamily: resolveFontFamily(c.titleFont),
              fontWeight: c.titleWeight,
              fontSize: c.titleSize + 'px',
              letterSpacing: c.titleLetterSpacing + 'px',
              textTransform:
                c.titleCase === 'uppercase' ? 'uppercase' : undefined,
              color: c.titleAccent
                ? titleAccentColor(c.accent, c.text)
                : undefined,
            }}
          >
            {c.layout === 'winamp' && displayed.title.length > 24 ? (
              <span className="ns-marquee">
                <span>{displayed.title}</span>
                <span aria-hidden="true">{displayed.title}</span>
              </span>
            ) : (
              displayed.title
            )}
          </div>
          {c.layout === 'winamp' &&
            c.visualizerVisible &&
            c.visualizerPosition === 'bottom' && (
              <span className="ns-bars ns-bars-wide" aria-hidden="true">
                {Array.from({ length: 32 }, (_, i) => (
                  <i
                    key={i}
                    style={{
                      animationDelay: -((i * 0.37) % 1.1).toFixed(2) + 's',
                      animationPlayState: displayed.playing
                        ? 'running'
                        : 'paused',
                    }}
                  />
                ))}
              </span>
            )}
          {c.artist && (
            <div
              className="track-artist"
              style={{
                fontFamily: resolveFontFamily(c.artistFont),
                fontWeight: c.artistWeight,
                fontSize: c.artistSize + 'px',
                letterSpacing: c.artistLetterSpacing + 'px',
                textTransform:
                  c.artistCase === 'uppercase' ? 'uppercase' : undefined,
              }}
            >
              {displayed.artist}
              {c.layout === 'aqua' && c.albumVisible && displayed.album && (
                <span className="aq-album"> — {displayed.album}</span>
              )}
            </div>
          )}
        </div>
      </div>
      {c.progress && (
        <div className="track-progress" key={trackId(displayed)}>
          {c.layout === 'pixel' && c.gameLevel && (
            <span className="pq-level">
              LV {String(pq.level).padStart(2, '0')}
            </span>
          )}
          <div className="progress-rail">
            <div
              style={{
                width:
                  Math.min(
                    100,
                    (displayed.progress / Math.max(1, displayed.duration)) *
                      100,
                  ) + '%',
              }}
            />
          </div>
          <div className="track-times">
            <span>{time(displayed.progress)}</span>
            <span>
              {c.layout === 'aqua'
                ? '-' +
                  time(Math.max(0, displayed.duration - displayed.progress))
                : time(displayed.duration)}
            </span>
          </div>
        </div>
      )}
      {c.layout === 'lol' &&
        ((c.lolMain && lolChampLabel) || (c.lolRank && lolData)) && (
          <div className="lol-foot">
            {c.lolMain && lolChampLabel && (
              <span className="lol-main">
                {!c.lolChamp && lolData?.main?.level ? (
                  <i className="lol-mastery">
                    <b>{lolData.main.level}</b>
                  </i>
                ) : null}
                MAIN · {lolChampLabel.toUpperCase()}
              </span>
            )}
            {c.lolRank && lolData && (
              <span className="lol-rank">
                {c.lolTicker && lolLive.event && (
                  <span
                    key={'pop' + lolLive.event.id}
                    className={
                      'lol-pop ' + (lolLive.event.delta > 0 ? 'is-up' : 'is-down')
                    }
                  >
                    {lolLive.event.delta > 0 ? '+' : '−'}
                    {Math.abs(lolLive.event.delta)} LP
                  </span>
                )}
                {lolData.status === 'ok' ? (
                  <>
                    <i
                      key={'gem' + (lolLive.event?.id || 0)}
                      className={
                        'lol-gem' +
                        (c.lolTicker && lolLive.event?.promoted ? ' is-flare' : '')
                      }
                    />
                    <b className="lol-tier">
                      {(LOL_TIER_NAMES[lolTier] || lolTier).toUpperCase()}
                      {isApexTier(lolTier) ? '' : ' ' + (lolData.division || '')}
                    </b>
                    <span className="lol-lp">{lolData.lp} LP</span>
                    <span className="lol-lpbar">
                      <i
                        style={{
                          width:
                            Math.min(
                              100,
                              isApexTier(lolTier)
                                ? (lolData.lp || 0) / 10
                                : lolData.lp || 0,
                            ) + '%',
                        }}
                      />
                    </span>
                  </>
                ) : (
                  <b className="lol-tier">OHNE RANG</b>
                )}
              </span>
            )}
          </div>
        )}
      {c.layout === 'winamp' && (c.controlsVisible || c.volumeVisible) && (
        <div className="player-chrome ns-controls" aria-hidden="true">
          {c.controlsVisible && (
          <div>
            <span>
              <SkipBack size={11} fill="currentColor" />
            </span>
            <span className={displayed.playing ? 'is-on' : ''}>
              <Play size={11} fill="currentColor" />
            </span>
            <span className={!displayed.playing ? 'is-on' : ''}>
              <Pause size={11} fill="currentColor" />
            </span>
            <span>
              <Square size={9} fill="currentColor" />
            </span>
            <span>
              <SkipForward size={11} fill="currentColor" />
            </span>
          </div>
          )}
          {c.volumeVisible && (
            <span className="ns-volume">
              <Volume2 size={13} />
              <i />
            </span>
          )}
        </div>
      )}
      {c.layout === 'aqua' && (c.controlsVisible || c.volumeVisible) && (
        <div className="player-chrome aq-controls" aria-hidden="true">
          {c.controlsVisible && (
            <div>
              <span className="aq-btn">
                <SkipBack size={11} fill="currentColor" />
              </span>
              <span className="aq-btn aq-play">
                {displayed.playing ? (
                  <Play size={12} fill="currentColor" />
                ) : (
                  <Pause size={12} fill="currentColor" />
                )}
              </span>
              <span className="aq-btn">
                <SkipForward size={11} fill="currentColor" />
              </span>
            </div>
          )}
          {c.volumeVisible && (
            <span className="aq-volume">
              <Volume2 size={12} />
              <i />
            </span>
          )}
        </div>
      )}
      {c.layout === 'pixel' && (c.gameQuest || c.gameParty) && (
        <div className="pq-footer" aria-hidden="true">
          {c.gameQuest && (
            <span className="pq-quest">
              <small>QUEST · {pq.quest.label}</small>
              <span>
                {Array.from({ length: pq.quest.goal }, (_, i) => (
                  <i key={i} className={i < pq.questProgress ? 'on' : ''} />
                ))}
                <b>
                  {pq.questProgress}/{pq.quest.goal}
                </b>
              </span>
            </span>
          )}
          {c.gameParty && (
            <span className="pq-party">
              <small>PARTY</small>
              <span>
                {[0, 1, 2].map((i) =>
                  pq.party[i] ? (
                    <img key={i} src={pq.party[i]} alt="" />
                  ) : (
                    <i key={i} />
                  ),
                )}
              </span>
            </span>
          )}
        </div>
      )}
    </div>
  );
  if (c.layout !== 'sticker') return node;
  // Post-it-Stapel: Zettel der vorherigen Songs liegen hinter dem Overlay.
  return (
    <div
      className={'sn-wrap' + (c.stickyTilt ? ' sn-tilt' : '')}
      style={
        {
          width: c.width,
          '--sn-c1': (style as Record<string, string>)['--sn-c1'],
          '--sn-c2': (style as Record<string, string>)['--sn-c2'],
        } as CSSProperties
      }
    >
      {c.stickyStack >= 2 && <span className="sn-sheet sn-sheet-2" data-body-part aria-hidden="true" />}
      {c.stickyStack >= 1 && <span className="sn-sheet sn-sheet-1" data-body-part aria-hidden="true" />}
      {node}
    </div>
  );
}
export function MemorySlot({
  config: c,
  track,
  style,
  mood,
  phase,
}: {
  config: Config;
  track: Track | null;
  style: CSSProperties;
  mood?: string;
  phase?: TransitionPhase;
}) {
  const idle = !track;
  const playing = !!track?.playing;
  const transitionPhase = phase || 'stable';
  const slot = String(track?.slot || 1).padStart(2, '0');
  const fav = !!track?.favorite;
  const inObserved = !!track?.inObservedPlaylist;
  const label = (c.memoryLabel || '').trim();
  const prevFav = useRef<boolean | undefined>(undefined);
  const favStamp = useRef(0);
  if (fav && prevFav.current === false) favStamp.current += 1;
  prevFav.current = fav;
  const stamping = favStamp.current > 0;
  const prevStream = useRef<boolean | undefined>(undefined);
  const streamStamp = useRef(0);
  if (inObserved && prevStream.current === false) streamStamp.current += 1;
  prevStream.current = inObserved;
  const streamStamping = streamStamp.current > 0;
  const ledUserStyle = {
    '--memory-led-user-color': c.ledColor,
    '--memory-led-user-brightness': c.ledBrightness / 100,
    '--memory-led-user-glow': c.ledGlow / 100,
    '--memory-led-user-speed': (8 - (c.ledSpeed / 100) * 5.5).toFixed(2) + 's',
    '--memory-led-size': c.ledSize / 100,
    '--memory-led-offset-x': c.ledOffsetX + 'px',
    '--memory-led-offset-y': c.ledOffsetY + 'px',
  } as CSSProperties;
  const lcdUserStyle = {
    '--memory-lcd-color': c.displayColor,
    '--memory-lcd-brightness': c.displayBrightness / 100,
    '--memory-text-glow': c.textGlow / 100,
    '--memory-scanline-strength': c.scanlinesEnabled
      ? c.scanlineStrength / 100
      : 0,
    '--memory-grain-strength': c.grainEnabled ? c.grainStrength / 100 : 0,
    '--memory-vignette-strength': c.vignetteStrength / 100,
  } as CSSProperties;
  const progressUserStyle = {
    '--memory-progress-edge': c.progressEdge / 100,
    '--memory-progress-width': c.progressWidth + '%',
    '--memory-progress-thickness-scale': c.progressThickness / 100,
    '--memory-progress-offset-x': c.progressOffsetX + 'px',
    '--memory-progress-offset-y': c.progressOffsetY + 'px',
    '--memory-progress-radius': c.progressRadius + 'px',
  } as CSSProperties;
  // Effektive Accent-Farben: Bei gekoppelten Akzenten (linkAccentColors) steuert
  // der Master-Accent Controls, Status und Progress gemeinsam. Individuelle
  // Werte bleiben in der Config erhalten und greifen, sobald Link OFF ist.
  const effectiveControlAccent = c.linkAccentColors
    ? c.accent
    : c.controlAccentColor;
  const effectiveStatusAccent = c.linkAccentColors
    ? c.accent
    : c.statusAccentColor;
  const effectiveProgressColor = c.linkAccentColors
    ? c.accent
    : c.progressColor;
  // Bei aktivem Mood gewinnen die Mood-Accents (--mood-control/--mood-accent):
  // Die User-Accent-Variablen werden dann bewusst nicht gesetzt, damit die
  // CSS-Fallback-Kette auf die Mood-Tokens fällt.
  const moodActive = !!(
    isMoodEffectivelyEnabled(c) && c.moodIntensity > 0 && mood
  );
  const accentUserStyle = moodActive
    ? {}
    : ({
        '--memory-control-accent': effectiveControlAccent,
        '--memory-status-accent': effectiveStatusAccent,
        '--memory-progress-color': effectiveProgressColor,
      } as CSSProperties);
  const coverUserStyle = {
    '--memory-cover-brightness': c.coverBrightness / 100,
    '--memory-cover-saturation': c.coverSaturation / 100,
    '--memory-cover-contrast': c.coverContrast / 100,
    '--memory-cover-size': c.coverSize / 100,
    '--memory-cover-offset-x': c.coverOffsetX + 'px',
    '--memory-cover-offset-y': c.coverOffsetY + 'px',
    '--memory-cover-radius': c.coverRadius + 'px',
    '--memory-cover-fit': c.coverFit,
  } as CSSProperties;
  const noteUserStyle = {
    '--memory-note-size': c.noteSize / 100,
    '--memory-note-offset-x': c.noteOffsetX + 'px',
    '--memory-note-offset-y': c.noteOffsetY + 'px',
    '--memory-note-rotation': c.noteRotation + 'deg',
    '--memory-note-opacity': c.noteOpacity / 100,
  } as CSSProperties;
  const textLayoutStyle = {
    '--memory-title-offset-x': c.titleOffsetX + 'px',
    '--memory-title-offset-y': c.titleOffsetY + 'px',
    '--memory-artist-offset-x': c.artistOffsetX + 'px',
    '--memory-artist-offset-y': c.artistOffsetY + 'px',
    '--memory-meta-offset-x': c.metaOffsetX + 'px',
    '--memory-meta-offset-y': c.metaOffsetY + 'px',
    '--memory-title-artist-spacing': c.titleArtistSpacing + 'px',
  } as CSSProperties;
  const controlsLayoutStyle = {
    '--memory-controls-size': c.controlsSize / 100,
    '--memory-controls-icon-size': c.controlsIconSize / 100,
    '--memory-controls-gap': c.controlsGap / 100,
    '--memory-controls-offset-x': c.controlsOffsetX + 'px',
    '--memory-controls-offset-y': c.controlsOffsetY + 'px',
  } as CSSProperties;
  return (
    <div
      key={c.animation + c.layout}
      data-mood={moodActive ? mood : undefined}
      data-led-behavior={c.ledVisible ? c.ledBehavior : 'off'}
      style={{
        ...style,
        ...memoryMoodStyle(c, mood, {
          color: c.displayColor,
          brightness: c.displayBrightness / 100,
        }),
        ...ledUserStyle,
        ...lcdUserStyle,
        ...progressUserStyle,
        ...accentUserStyle,
        ...coverUserStyle,
        ...noteUserStyle,
        ...textLayoutStyle,
        ...controlsLayoutStyle,
      }}
      className={
        'overlay layout-memory anim-' +
        c.animation +
        (c.glow ? ' has-glow' : '') +
        (!playing ? ' is-paused' : '') +
        (idle ? ' is-idle' : '') +
        (!c.cover ? ' no-cover' : '') +
        (!label ? ' no-label' : '') +
        (transitionPhase === 'exit' ? ' track-exit' : '') +
        (transitionPhase === 'enter' ? ' track-enter' : '')
      }
    >
      <div className="memory-spine" aria-hidden="true">
        <i />
        <i />
        <i />
      </div>
      <i className="memory-screw screw-a" aria-hidden="true" />
      <i className="memory-screw screw-b" aria-hidden="true" />
      <i className="memory-screw screw-c" aria-hidden="true" />
      <i className="memory-screw screw-d" aria-hidden="true" />
      <div className="memory-device-mark" aria-hidden="true">
        <b>A</b>
        <span>▲ R12I5</span>
      </div>
      {c.cover && (
        <div className="memory-cover-slot">
          <div className="track-transition-cover">
            <div className="memory-cover-frame">
              {track?.cover ? (
                <img src={track.cover} alt={'Albumcover: ' + track.title} />
              ) : (
                <div className="memory-empty-cover">?</div>
              )}
            </div>
          </div>
          <b>
            MEMORY SLOT
            {track?.inObservedPlaylist && !idle && (
              <i
                className={
                  'memory-fav-mark' + (streamStamping ? ' fav-stamp' : '')
                }
                aria-hidden="true"
              />
            )}
          </b>
        </div>
      )}
      <div className="memory-screen">
        <div className="memory-copy">
          <div className="track-transition-meta">
            {c.badge && (
              <div
                className="memory-status"
                style={{
                  fontFamily: resolveFontFamily(c.metaFont),
                  fontWeight: c.metaWeight,
                  fontSize: c.metaSize + 'px',
                  letterSpacing: c.metaLetterSpacing + 'px',
                  textTransform:
                    c.metaCase === 'uppercase' ? 'uppercase' : undefined,
                }}
              >
                <span>
                  {idle ? 'Slot empty' : playing ? 'Now Playing' : 'Paused'}
                </span>
                <b key={track?.slot}>SLOT {slot}</b>
              </div>
            )}
          </div>
          <div className="track-transition-title">
            <div
              className="track-title"
              title={track?.title}
              style={{
                fontFamily: resolveFontFamily(c.titleFont),
                fontWeight: c.titleWeight,
                fontSize: c.titleSize + 'px',
                letterSpacing: c.titleLetterSpacing + 'px',
                textTransform:
                  c.titleCase === 'uppercase' ? 'uppercase' : undefined,
              }}
            >
              {track?.title || 'No song playing yet …'}
            </div>
          </div>
          {c.artist && (
            <div className="track-transition-artist">
              <div
                className="track-artist"
                style={{
                  fontFamily: resolveFontFamily(c.artistFont),
                  fontWeight: c.artistWeight,
                  fontSize: c.artistSize + 'px',
                  letterSpacing: c.artistLetterSpacing + 'px',
                  textTransform:
                    c.artistCase === 'uppercase' ? 'uppercase' : undefined,
                }}
              >
                {track?.artist || 'Every great stream needs a soundtrack.'}
              </div>
            </div>
          )}
          {c.progress && (
            <div className="track-progress" key={trackId(track)}>
              <div className="progress-rail">
                <div
                  style={{
                    width:
                      Math.min(
                        100,
                        ((track?.progress || 0) /
                          Math.max(1, track?.duration || 1)) *
                          100,
                      ) + '%',
                  }}
                />
                <i
                  style={{
                    left:
                      Math.min(
                        100,
                        ((track?.progress || 0) /
                          Math.max(1, track?.duration || 1)) *
                          100,
                      ) + '%',
                  }}
                />
              </div>
              <div className="track-times">
                <span>{time(track?.progress || 0)}</span>
                <span>{time(track?.duration || 0)}</span>
              </div>
            </div>
          )}
        </div>
        <div className="memory-controls" aria-hidden="true">
          <span>
            <Shuffle />
          </span>
          <span>
            <SkipBack />
          </span>
          <span className="memory-play">
            {playing ? (
              <Pause fill="currentColor" />
            ) : (
              <Play fill="currentColor" />
            )}
          </span>
          <span>
            <SkipForward />
          </span>
          <span className={'memory-heart' + (fav ? ' active' : '')}>
            <Heart
              className={stamping && fav ? 'heart-stamp' : undefined}
              fill="currentColor"
            />
          </span>
        </div>
      </div>
      {label && (
        <div className="memory-note" aria-hidden="true">
          <i className="memory-led" />
          <div className="memory-note-paper">
            <span>
              {label}
              <b>☺</b>
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
function time(ms: number) {
  return (
    Math.floor(ms / 60000) +
    ':' +
    String(Math.floor(ms / 1000) % 60).padStart(2, '0')
  );
}
