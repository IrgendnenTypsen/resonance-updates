// --- League of Legends Ranked: Abfrage + LP-Ticker-Ereignisse ---
// Fragt den lokalen Endpunkt /__resonance/lol/ranked (Vite-Plugin, liest den
// laufenden League-Client) ab und erkennt LP-Änderungen zwischen zwei
// Abfragen (Grundlage für den LP-Ticker und den Aufstiegs-Effekt).
import { useEffect, useRef, useState } from 'react';

export type LolQueue = 'solo' | 'flex';
export type LolRanked = {
  status: 'ok' | 'unranked' | 'no-client' | 'loading';
  queue?: LolQueue;
  summoner?: string;
  tier?: string;
  division?: string;
  lp?: number;
  wins?: number;
  losses?: number;
  provisional?: boolean;
  streak?: number;
  /** Champ mit der höchsten Meisterschaft (alias = Data-Dragon-Bildname). */
  main?: { id: number; name: string; alias: string; level: number; points: number } | null;
  fetchedAt?: number;
};

/** Splash-Art (Riot Data Dragon, öffentlich). Leerer Alias → null. */
export function championSplashUrl(alias?: string, variant: 'centered' | 'loading' = 'centered') {
  if (!alias || !/^[A-Za-z0-9]+$/.test(alias)) return null;
  return `https://ddragon.leagueoflegends.com/cdn/img/champion/${variant}/${alias}_0.jpg`;
}
export type LolLpEvent = { id: number; delta: number; promoted: boolean };

export const LOL_TIERS = [
  'IRON',
  'BRONZE',
  'SILVER',
  'GOLD',
  'PLATINUM',
  'EMERALD',
  'DIAMOND',
  'MASTER',
  'GRANDMASTER',
  'CHALLENGER',
] as const;
export const LOL_TIER_NAMES: Record<string, string> = {
  IRON: 'Eisen',
  BRONZE: 'Bronze',
  SILVER: 'Silber',
  GOLD: 'Gold',
  PLATINUM: 'Platin',
  EMERALD: 'Smaragd',
  DIAMOND: 'Diamant',
  MASTER: 'Meister',
  GRANDMASTER: 'Großmeister',
  CHALLENGER: 'Herausforderer',
};
/** Eigene Rangfarben (Edelstein): [Grundton, Glanz, Schatten]. */
export const LOL_TIER_COLORS: Record<string, [string, string, string]> = {
  IRON: ['#8a7f7a', '#c9bfb9', '#4a403c'],
  BRONZE: ['#b0703f', '#e2a777', '#5c3218'],
  SILVER: ['#9fb0bf', '#e3ecf3', '#56636f'],
  GOLD: ['#e0b84f', '#fff0b0', '#7a5a14'],
  PLATINUM: ['#3fb6a8', '#a8f0e6', '#14574f'],
  EMERALD: ['#2fbf74', '#9ef5c3', '#0f5c34'],
  DIAMOND: ['#6f8cff', '#c8d4ff', '#2a3a8f'],
  MASTER: ['#b25cd6', '#e8b8fa', '#55216e'],
  GRANDMASTER: ['#e0434b', '#ffb0b4', '#6e1418'],
  CHALLENGER: ['#f2d27a', '#fff6d6', '#2f7fb0'],
};
/** Demo-Daten für Studio-Vorschau/Demo-Modus ohne laufenden Client. */
export const LOL_DEMO: LolRanked = {
  status: 'ok',
  queue: 'solo',
  summoner: 'Demo#EUW',
  tier: 'EMERALD',
  division: 'II',
  lp: 64,
  wins: 38,
  losses: 31,
  streak: 2,
  main: { id: 103, name: 'Ahri', alias: 'Ahri', level: 7, points: 0 },
};
const DIVISIONS = ['IV', 'III', 'II', 'I'];

export function isApexTier(tier = '') {
  return LOL_TIERS.indexOf(tier as (typeof LOL_TIERS)[number]) >= 7;
}

/** Fortlaufende LP-Skala über alle Stufen (für Delta + Auf-/Abstieg). */
export function absoluteLp(r: LolRanked): number | null {
  if (r.status !== 'ok' || !r.tier) return null;
  const t = LOL_TIERS.indexOf(r.tier as (typeof LOL_TIERS)[number]);
  if (t < 0) return null;
  if (t >= 7) return 7 * 400 + (r.lp || 0);
  return t * 400 + Math.max(0, DIVISIONS.indexOf(r.division || 'IV')) * 100 + (r.lp || 0);
}

/** Stufe+Division als vergleichbare Zahl (ohne LP). */
function rankStep(r: LolRanked) {
  const t = LOL_TIERS.indexOf(r.tier as (typeof LOL_TIERS)[number]);
  return t >= 7 ? t * 4 : t * 4 + Math.max(0, DIVISIONS.indexOf(r.division || 'IV'));
}

/** Vergleicht zwei Abfragen; null = keine Änderung. */
export function lpEventBetween(
  prev: LolRanked | null,
  next: LolRanked,
): { delta: number; promoted: boolean } | null {
  if (!prev || prev.queue !== next.queue) return null;
  const a = absoluteLp(prev);
  const b = absoluteLp(next);
  if (a === null || b === null) return null;
  const games =
    (next.wins || 0) + (next.losses || 0) - (prev.wins || 0) - (prev.losses || 0);
  if (a === b && games === 0) return null;
  // Apex-Stufen: LP direkt vergleichen (kein Divisionssprung).
  const delta = isApexTier(prev.tier) && isApexTier(next.tier)
    ? (next.lp || 0) - (prev.lp || 0)
    : b - a;
  return { delta, promoted: rankStep(next) > rankStep(prev) };
}

/** Pollt den Rang (Standard alle 15 s) und meldet LP-Ereignisse. */
export function useLolRanked(enabled: boolean, queue: LolQueue = 'solo', intervalMs = 15000) {
  const [data, setData] = useState<LolRanked>({ status: 'loading' });
  const [event, setEvent] = useState<LolLpEvent | null>(null);
  const prev = useRef<LolRanked | null>(null);
  const counter = useRef(0);
  useEffect(() => {
    if (!enabled) return;
    let stopped = false;
    let clear: ReturnType<typeof setTimeout> | null = null;
    const load = async () => {
      try {
        const r = (await fetch('/__resonance/lol/ranked?queue=' + queue, {
          cache: 'no-store',
        }).then((x) => x.json())) as LolRanked;
        if (stopped) return;
        const ev = r.status === 'ok' ? lpEventBetween(prev.current, r) : null;
        if (r.status === 'ok') prev.current = r;
        setData(r);
        if (ev && ev.delta !== 0) {
          counter.current += 1;
          setEvent({ id: counter.current, ...ev });
          if (clear) clearTimeout(clear);
          clear = setTimeout(() => setEvent(null), 4000);
        }
      } catch {
        if (!stopped) setData({ status: 'no-client' });
      }
    };
    void load();
    const timer = setInterval(load, intervalMs);
    return () => {
      stopped = true;
      clearInterval(timer);
      if (clear) clearTimeout(clear);
    };
  }, [enabled, queue, intervalMs]);
  return { data, event };
}
