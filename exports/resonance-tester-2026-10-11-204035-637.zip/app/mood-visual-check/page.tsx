'use client';
import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { MemorySlot, defaults } from '@/lib/overlay';
import './qa.css';

// QA Lab (Studio-2.0-Look, 2026-10-11). Funktion unverändert: Mood-Vorschau
// des Memory-Players, alle Moods im Raster. Tester-ZIP nur im Entwicklermodus
// (Vite-Dev-Plugin /__resonance/dev/*), in Tester-Builds unsichtbar.

const MOODS = [
  'happy',
  'sad',
  'dark',
  'angry',
  'calm',
  'energy',
  'romantic',
  'lonely',
  'hopeful',
  'nostalgic',
] as const;

const MOOD_LABELS: Record<string, string> = {
  happy: 'Happy',
  sad: 'Sad',
  dark: 'Dark',
  angry: 'Angry',
  calm: 'Calm',
  energy: 'Energy',
  romantic: 'Romantic',
  lonely: 'Lonely',
  hopeful: 'Hopeful',
  nostalgic: 'Nostalgic',
};

const ACCENTS: Record<string, string> = {
  happy: '#ffda78',
  sad: '#accde9',
  dark: '#a9b6fa',
  angry: '#ff9b83',
  calm: '#a5deca',
  energy: '#d3ee87',
  romantic: '#f5b9cd',
  lonely: '#bad0e8',
  hopeful: '#e6ecad',
  nostalgic: '#f0cf8d',
};

const COVER =
  'data:image/svg+xml,' +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><defs><linearGradient id="a" x2="1" y2="1"><stop stop-color="#e9b67b"/><stop offset=".5" stop-color="#7d5e99"/><stop offset="1" stop-color="#1c4669"/></linearGradient></defs><rect width="200" height="200" fill="url(#a)"/><circle cx="100" cy="100" r="60" fill="none" stroke="#fce6bd" stroke-width="2"/><circle cx="100" cy="100" r="40" fill="none" stroke="#fce6bd" stroke-width="2"/><text x="100" y="174" fill="white" font-size="15" text-anchor="middle">RESONANCE</text></svg>',
  );

const DURATION = 224000;

type DevStatus = {
  latest: { file: string; createdAt: string; size: number } | null;
  newestSourceChange: string | null;
  stale: boolean;
};

function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export default function Check() {
  const [state, setState] = useState<'playing' | 'paused' | 'idle'>('playing');
  const [mood, setMood] = useState<string>('energy');
  const [width, setWidth] = useState(760);
  const [intensity, setIntensity] = useState(100);
  const [motion, setMotion] = useState(true);
  const [enabled, setEnabled] = useState(true);
  const [progress, setProgress] = useState(87000);
  const [reduced, setReduced] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [dev, setDev] = useState<DevStatus | null>(null);
  const [devBusy, setDevBusy] = useState(false);
  const [devMessage, setDevMessage] = useState('');
  const previewRef = useRef<HTMLDivElement>(null);

  async function loadDev() {
    try {
      const r = await fetch('/__resonance/dev/status', { cache: 'no-store' });
      if (!r.ok) return setDev(null);
      const d = (await r.json()) as DevStatus & { devMode?: boolean };
      setDev(d.devMode ? d : null);
    } catch {
      setDev(null);
    }
  }
  useEffect(() => {
    void loadDev();
  }, []);
  async function buildZip() {
    setDevBusy(true);
    setDevMessage('');
    try {
      const r = await fetch('/__resonance/dev/export-tester', { method: 'POST' });
      const d = (await r.json()) as { error?: string; latest?: { file: string } };
      if (!r.ok || !d.latest) throw new Error(d.error || 'Export fehlgeschlagen.');
      const a = document.createElement('a');
      a.href = '/exports/' + encodeURIComponent(d.latest.file);
      a.download = d.latest.file;
      a.click();
      setDevMessage('Gebaut: ' + d.latest.file);
      await loadDev();
    } catch (e) {
      setDevMessage((e as Error).message);
    } finally {
      setDevBusy(false);
    }
  }

  // OS-Reduced-Motion-Status anzeigen (nur Info, QA-Toggle erzwingt trotzdem)
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReduced(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);

  // Lokale Demo-Progress-Simulation
  useEffect(() => {
    if (state !== 'playing') return;
    const t = setInterval(() => setProgress((p) => (p + 1000) % DURATION), 1000);
    return () => clearInterval(t);
  }, [state]);

  // Preview an Container-Breite anpassen
  useEffect(() => {
    const el = previewRef.current;
    if (!el) return;
    const ob = new ResizeObserver((entries) => {
      const w = entries[0].contentRect.width;
      setZoom(Math.min(1, (w - 48) / width));
    });
    ob.observe(el);
    return () => ob.disconnect();
  }, [width]);

  const track =
    state === 'idle'
      ? null
      : {
          id: 'qa-track',
          title: 'Midnight in Motion (Extended Mix)',
          artist: 'Resonance Radio feat. The Night Owls',
          cover: COVER,
          duration: DURATION,
          progress,
          playing: state === 'playing',
          slot: 7,
          favorite: true,
          inObservedPlaylist: true,
          lyricMoodScores: { [mood]: 100 },
        };

  const baseStyle = {
    '--oa': '#b66cff',
    '--ot': '#f7f5f2',
    '--or': '20px',
    '--op': '18px',
    '--ofs': '25px',
    width,
    fontFamily: 'Arial, sans-serif',
  } as CSSProperties;

  const thumbStyle = { ...baseStyle, width: 300 } as CSSProperties;

  const thumbTrack = {
    id: 'qa-thumb',
    title: 'Midnight in Motion (Extended Mix)',
    artist: 'Resonance Radio feat. The Night Owls',
    cover: COVER,
    duration: DURATION,
    progress: 87000,
    playing: true,
    slot: 7,
    favorite: true,
    inObservedPlaylist: true,
    lyricMoodScores: { happy: 100 },
  };

  const memoryConfig = (w: number, on: boolean, i: number, anim: string) => ({
    ...defaults,
    layout: 'memory',
    background: '#ece8df',
    accent: '#b66cff',
    text: '#f7f5f2',
    width: w,
    fontSize: 25,
    spacing: 18,
    opacity: 100,
    moodSwitch: on,
    moodIntensity: i,
    animation: anim,
  });

  return (
    <main
      className={'qa-page allow-motion' + (motion ? ' qa-motion-on' : '')}
      style={{ '--qa-mood': ACCENTS[mood] } as CSSProperties}
    >
      <header className="qa-top">
        <a className="qa-back" href="/">
          ← Studio
        </a>
        <div className="qa-title">
          <span>QA Lab</span>
          <b>Mood Visual System</b>
        </div>
        <span className={'qa-pill' + (reduced ? ' is-warn' : '')}>
          {reduced ? 'System: Bewegung reduziert' : 'System: Bewegung an'}
        </span>
      </header>

      <div className="qa-layout">
        <section className="qa-stage" ref={previewRef} aria-label="Vorschau">
          <span className="qa-stage-label">
            <i /> {MOOD_LABELS[mood]} · {state === 'playing' ? 'spielt' : state === 'paused' ? 'pausiert' : 'leer'}
          </span>
          <div className="qa-stage-inner" style={{ zoom }}>
            <MemorySlot
              mood={mood}
              style={baseStyle}
              config={memoryConfig(width, enabled, intensity, motion ? 'slide' : 'none')}
              track={track}
            />
          </div>
        </section>

        <aside className="qa-panel" aria-label="Einstellungen">
          <div className="qa-section">
            <h4>Mood</h4>
            <div className="qa-moods">
              {MOODS.map((m) => (
                <button
                  key={m}
                  type="button"
                  className={'qa-chip' + (mood === m ? ' active' : '')}
                  aria-pressed={mood === m}
                  onClick={() => setMood(m)}
                >
                  <i style={{ background: ACCENTS[m] }} />
                  {MOOD_LABELS[m]}
                </button>
              ))}
            </div>
          </div>

          <div className="qa-section">
            <h4>Wiedergabe</h4>
            <div className="qa-seg" role="group" aria-label="Status">
              {(
                [
                  ['playing', 'Spielt'],
                  ['paused', 'Pausiert'],
                  ['idle', 'Leer'],
                ] as const
              ).map(([s, l]) => (
                <button
                  key={s}
                  type="button"
                  className={state === s ? 'active' : ''}
                  aria-pressed={state === s}
                  onClick={() => setState(s)}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>

          <div className="qa-section">
            <h4>Darstellung</h4>
            <label className="qa-range">
              <span>
                Breite <code>{width} px</code>
              </span>
              <input
                type="range"
                min={280}
                max={900}
                step={20}
                value={width}
                onChange={(e) => setWidth(Number(e.target.value))}
              />
              <small>Referenz 760 px</small>
            </label>
            <label className="qa-range">
              <span>
                Intensität <code>{intensity} %</code>
              </span>
              <input
                type="range"
                min={0}
                max={100}
                step={5}
                value={intensity}
                onChange={(e) => setIntensity(Number(e.target.value))}
              />
            </label>
            <div className="qa-switch">
              <span>Bewegung</span>
              <button
                type="button"
                role="switch"
                aria-checked={motion}
                aria-label="Bewegung"
                className={motion ? 'on' : ''}
                onClick={() => setMotion((v) => !v)}
              >
                <i />
              </button>
            </div>
            <div className="qa-switch">
              <span>Mood Switch</span>
              <button
                type="button"
                role="switch"
                aria-checked={enabled}
                aria-label="Mood Switch"
                className={enabled ? 'on' : ''}
                onClick={() => setEnabled((v) => !v)}
              >
                <i />
              </button>
            </div>
            {reduced && (
              <p className="qa-note">
                Dein System hat „Bewegung reduzieren“ aktiv. Der Schalter
                erzwingt die Mood-Animationen hier trotzdem – in OBS und im
                Studio bleiben sie aus.
              </p>
            )}
          </div>

          {dev && (
            <div className="qa-section qa-dev">
              <h4>
                Tester-ZIP <span className="qa-dev-tag">nur Entwickler</span>
              </h4>
              <p className="qa-dev-meta">
                <span className={'qa-pill' + (dev.stale ? ' is-warn' : ' is-ok')}>
                  {dev.stale ? 'Veraltet' : 'Aktuell'}
                </span>
                {dev.latest
                  ? `${new Date(dev.latest.createdAt).toLocaleString('de-DE')} · ${formatBytes(dev.latest.size)}`
                  : 'Noch kein Build'}
              </p>
              <button
                type="button"
                className="qa-primary"
                disabled={devBusy}
                onClick={buildZip}
              >
                {devBusy ? 'Baue ZIP …' : 'Neu bauen & herunterladen'}
              </button>
              {devMessage && <small className="qa-dev-msg">{devMessage}</small>}
            </div>
          )}
        </aside>
      </div>

      <section className="qa-grid-section" aria-label="Alle Moods">
        <div className="qa-grid-head">
          <h2>Alle Moods</h2>
          <span>Klick übernimmt den Mood oben</span>
        </div>
        <div className="qa-thumb-grid">
          {MOODS.map((m) => (
            <button
              type="button"
              key={m}
              className={'qa-thumb' + (mood === m ? ' active' : '')}
              style={{ '--qa-thumb': ACCENTS[m] } as CSSProperties}
              onClick={() => setMood(m)}
            >
              <div className="qa-thumb-stage">
                <div style={{ zoom: 0.55 }}>
                  <MemorySlot
                    mood={m}
                    style={thumbStyle}
                    config={memoryConfig(300, true, 100, 'none')}
                    track={thumbTrack}
                  />
                </div>
              </div>
              <span>
                <i />
                {MOOD_LABELS[m]}
              </span>
            </button>
          ))}
        </div>
      </section>
    </main>
  );
}
