'use client';
// F22 – Desktop-Widget für Tester (Mockup abgesegnet 2026-10-13, „passt“).
// Studio-Knopf „Widget ▾“ (Desktop-App starten / im Browser) und Setup-Karte
// „Desktop-Widget“ (Status, 3 Schritte, SmartScreen-Hinweis, Autostart).
// Spricht nur mit dem lokalen Vite-Plugin /__resonance/widget/*.
import { useCallback, useEffect, useRef, useState } from 'react';
import { AppWindow, ChevronDown, Copy, MonitorUp } from 'lucide-react';
import { useT } from '@/lib/i18n';
import './desktop-widget.css';

export type WidgetStatus = {
  supported: boolean;
  available: boolean;
  running: boolean;
  autostart: boolean;
  launchedBefore: boolean;
};

const HEADERS = { 'Content-Type': 'application/json', 'x-resonance-widget': '1' };
// Beim ersten Start in dieser Sitzung den SmartScreen-Hinweis stehen lassen.
let firstLaunchAt = 0;

async function fetchStatus(): Promise<WidgetStatus | null> {
  try {
    const r = await fetch('/__resonance/widget/status', { cache: 'no-store' });
    return r.ok ? ((await r.json()) as WidgetStatus) : null;
  } catch {
    return null;
  }
}

export function useWidgetStatus(active: boolean) {
  const [status, setStatus] = useState<WidgetStatus | null>(null);
  const [fast, setFast] = useState(0);
  const refresh = useCallback(async () => {
    const s = await fetchStatus();
    setStatus(s);
    return s;
  }, []);
  useEffect(() => {
    if (!active) return;
    let stop = false;
    const tick = async () => {
      const s = await fetchStatus();
      if (!stop) setStatus(s);
    };
    void tick();
    const timer = setInterval(tick, fast > Date.now() ? 1500 : 5000);
    return () => {
      stop = true;
      clearInterval(timer);
    };
  }, [active, fast]);
  const launch = useCallback(async () => {
    try {
      const r = await fetch('/__resonance/widget/launch', { method: 'POST', headers: HEADERS, body: '{}' });
      const d = (await r.json()) as WidgetStatus & { ok?: boolean; first?: boolean };
      if (d.first) firstLaunchAt = Date.now();
      setStatus(d);
      setFast(Date.now() + 20000);
      return !!d.ok;
    } catch {
      return false;
    }
  }, []);
  const setAutostart = useCallback(async (on: boolean) => {
    setStatus((s) => (s ? { ...s, autostart: on } : s));
    try {
      const r = await fetch('/__resonance/widget/autostart', { method: 'POST', headers: HEADERS, body: JSON.stringify({ on }) });
      if (r.ok) setStatus((await r.json()) as WidgetStatus);
    } catch {
      void refresh();
    }
  }, [refresh]);
  return { status, launch, setAutostart, refresh };
}

/** Studio-Leiste: „Widget ▾“ mit Desktop-App und Browser-Fenster. */
export function WidgetMenu({ onBrowser }: { onBrowser: () => void }) {
  const { t } = useT();
  const [open, setOpen] = useState(false);
  const { status, launch } = useWidgetStatus(true);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const down = (e: PointerEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const key = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('pointerdown', down);
    document.addEventListener('keydown', key);
    return () => {
      document.removeEventListener('pointerdown', down);
      document.removeEventListener('keydown', key);
    };
  }, [open]);
  const app = !!status?.supported && !!status.available;
  const running = !!status?.running;
  return (
    <div className="dw-menu-wrap" ref={ref}>
      <button
        type="button"
        className="secondary v2-widget-btn dw-trigger"
        title={t('st.widgetTitle')}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
      >
        <i className={'dw-dot' + (running ? ' is-live' : '')} aria-hidden="true" />
        {t('st.widget')} <ChevronDown size={14} />
      </button>
      {open && (
        <div className="dw-menu" role="menu">
          {app && (
            <button
              type="button"
              role="menuitem"
              className="dw-opt"
              onClick={() => {
                setOpen(false);
                void launch();
              }}
            >
              <span className="dw-opt-icon is-app">
                <MonitorUp size={16} />
              </span>
              <span>
                <b>{running ? t('dw.menuRunning') : t('dw.menuStart')}</b>
                <small>{running ? t('dw.menuRunningNote') : t('dw.menuStartNote')}</small>
              </span>
            </button>
          )}
          <button
            type="button"
            role="menuitem"
            className="dw-opt"
            onClick={() => {
              setOpen(false);
              onBrowser();
            }}
          >
            <span className="dw-opt-icon">
              <Copy size={15} />
            </span>
            <span>
              <b>{t('dw.menuBrowser')}</b>
              <small>{t('dw.menuBrowserNote')}</small>
            </span>
          </button>
          {!app && status?.supported && <p className="dw-menu-note">{t('dw.missingShort')}</p>}
        </div>
      )}
    </div>
  );
}

/** Setup → Grundlagen: Karte „Desktop-Widget“. */
export function DesktopWidgetCard({ active, onBrowser }: { active: boolean; onBrowser: () => void }) {
  const { t } = useT();
  const { status, launch, setAutostart } = useWidgetStatus(active);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState('');
  const app = !!status?.supported && !!status.available;
  const running = !!status?.running;
  const first = app && (!status?.launchedBefore || Date.now() - firstLaunchAt < 120000);
  const state = !status ? 'checking' : !status.supported ? 'unsupported' : !status.available ? 'missing' : running ? 'running' : first ? 'first' : 'idle';
  const pill: Record<string, string> = {
    checking: t('dw.stChecking'),
    unsupported: t('dw.stUnsupported'),
    missing: t('dw.stMissing'),
    running: t('dw.stRunning'),
    first: t('dw.stFirst'),
    idle: t('dw.stIdle'),
  };
  const start = async () => {
    setBusy(true);
    setNote('');
    const ok = await launch();
    setBusy(false);
    if (!ok) setNote(t('dw.startFailed'));
  };
  return (
    <article className={'v2-setup-card dw-card' + (running ? ' is-done' : '')}>
      <header>
        <span className="v2-setup-icon">
          <AppWindow size={17} />
        </span>
        <div>
          <b>{t('dw.title')}</b>
          <small>{t('dw.sub')}</small>
        </div>
        <span className={'v2-status-pill dw-pill' + (state === 'running' ? ' ok' : state === 'missing' ? ' warn' : ' is-' + state)}>{pill[state]}</span>
      </header>
      <p className="dw-lead">{t('dw.lead')}</p>
      {app && (
        <ol className="dw-steps">
          <li>
            <b>1</b>
            <span>{t('dw.step1')}</span>
          </li>
          <li>
            <b>2</b>
            <span>{t('dw.step2')}</span>
          </li>
          <li>
            <b>3</b>
            <span>{t('dw.step3')}</span>
          </li>
        </ol>
      )}
      {app && first && (
        <div className="dw-smart">
          <b>{t('dw.smartTitle')}</b>
          <div className="dw-smart-box">
            <b>{t('dw.smartHead')}</b>
            <span>{t('dw.smartBody')}</span>
            <span>
              <u>{t('dw.smartMore')}</u> → <em>{t('dw.smartRun')}</em>
            </span>
          </div>
          <small>{t('dw.smartWhy')}</small>
        </div>
      )}
      {state === 'missing' && <p className="v2-setup-why">{t('dw.missing')}</p>}
      {state === 'unsupported' && <p className="v2-setup-why">{t('dw.unsupported')}</p>}
      {app && (
        <label className="dw-toggle">
          <span>{t('dw.autostart')}</span>
          <input type="checkbox" checked={!!status?.autostart} onChange={(e) => void setAutostart(e.target.checked)} />
          <i aria-hidden="true" />
        </label>
      )}
      <div className="dw-actions">
        {app && (
          <button type="button" className="primary" disabled={busy} onClick={() => void start()}>
            {running ? t('dw.show') : t('dw.start')}
          </button>
        )}
        <button type="button" className="secondary" onClick={onBrowser}>
          {t('dw.browser')}
        </button>
      </div>
      {note && <p className="v2-setup-why dw-note">{note}</p>}
    </article>
  );
}
