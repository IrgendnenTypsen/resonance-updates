import { identity, json } from '@/lib/server';
import { seenAgo } from '@/lib/obs-seen';

// F04: Welche OBS-Quellen fragen gerade ab? (Live-Quelle + feste Looks)
export async function GET(req: Request) {
  try {
    return json(seenAgo(identity(req)));
  } catch {
    return json({ live: null, looks: {} });
  }
}
