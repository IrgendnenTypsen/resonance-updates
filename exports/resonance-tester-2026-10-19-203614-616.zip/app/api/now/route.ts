import {
  db,
  getStudio,
  json,
  now,
  cleanConfig,
  listCustomFonts,
  type Row,
} from '@/lib/server';
import { getStreamLang } from '@/lib/stream-settings';
import { lookPrefix, noteSeen } from '@/lib/obs-seen';
export async function GET(req: Request) {
  try {
    const auth = req.headers.get('authorization');
    const key = auth?.startsWith('Bearer ') ? auth.slice(7) : null;
    const row = key
      ? await db()
          .prepare('SELECT * FROM studios WHERE overlay_key=?')
          .bind(key)
          .first<Row>()
      : await getStudio(req);
    if (!row) return json({ error: 'Overlay nicht gefunden.' }, 401);
    // F04 Szenen-Profile: ?look=<name>-<id-Anfang> zeigt einen festen Look.
    // Unbekannt/gelöscht → Live-Look (wie ohne Parameter).
    const prefix = lookPrefix(new URL(req.url).searchParams.get('look'));
    let config = cleanConfig(JSON.parse(row.config));
    let look: { id: string; name: string } | null = null;
    let lookMissing = false;
    if (prefix) {
      const hit = await db()
        .prepare("SELECT id, name, config FROM custom_looks WHERE owner=? AND substr(id,1,10)=? LIMIT 1")
        .bind(row.owner, prefix)
        .first<{ id: string; name: string; config: string }>();
      if (hit) {
        try {
          config = cleanConfig(JSON.parse(hit.config));
          look = { id: hit.id, name: hit.name };
        } catch {
          lookMissing = true;
        }
      } else lookMissing = true;
    }
    if (key) noteSeen(row.owner, look?.id ?? null);
    const result = await now(row);
    const customFonts = await listCustomFonts(row.owner);
    return json({
      ...result,
      config,
      look,
      lookMissing,
      lang: await getStreamLang(db(), row.owner),
      connected: !!row.refresh_token,
      customFonts: customFonts.map((f) => ({
        id: f.id,
        family: f.family,
        format: f.format,
      })),
    });
  } catch (e) {
    return json(
      {
        error: e instanceof Error ? e.message : 'Verbindung unterbrochen.',
        track: null,
      },
      503,
    );
  }
}
