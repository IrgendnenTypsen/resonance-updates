'use client';
// F04 – Szenen-Profile (Mockup abgesegnet 2026-10-16, „sieht gut aus“).
// Ein OBS-Link pro gespeichertem Look: /overlay?look=<name>-<id-Anfang>#<key>.
// Der alte Link ohne ?look= zeigt weiter den Live-Look.
import { useEffect, useRef, useState } from 'react';
import { Check, Copy, ExternalLink, MonitorPlay } from 'lucide-react';
import { useT } from '@/lib/i18n';
import type { Config } from '@/lib/overlay';
import './scene-profiles.css';

export type SceneLook = { id: string; name: string; config: Config };
export type ObsSeen = { live: number | null; looks: Record<string, number> };

const IN_OBS_SECONDS = 30;

export function lookSlug(look: { id: string; name: string }) {
  const name = look.name
    .toLowerCase()
    .replace(/ä/g, 'ae')
    .replace(/ö/g, 'oe')
    .replace(/ü/g, 'ue')
    .replace(/ß/g, 'ss')
    .normalize('NFKD')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 24)
    .replace(/-+$/, '');
  return (name ? name + '-' : '') + look.id.slice(0, 10);
}

export function lookUrl(base: string, key: string, look: { id: string; name: string } | null) {
  return base + (look ? '?look=' + lookSlug(look) : '') + '#' + key;
}

const lookWidth = (c: Config) => (c.layout === 'memory' ? 520 : c.width);

export function isInObs(seen: ObsSeen | null, id: string | null) {
  if (!seen) return false;
  const a = id ? seen.looks[id] : seen.live;
  return typeof a === 'number' && a <= IN_OBS_SECONDS;
}

/** Fragt alle 8 s ab, welche OBS-Quellen gerade laufen. */
export function useObsSeen(active: boolean) {
  const [seen, setSeen] = useState<ObsSeen | null>(null);
  useEffect(() => {
    if (!active) return;
    let stop = false;
    const load = async () => {
      try {
        const r = await fetch('/api/looks/obs', { cache: 'no-store' });
        const d = (await r.json()) as ObsSeen;
        if (!stop) setSeen(d);
      } catch {
        // nur Komfort
      }
    };
    void load();
    const timer = setInterval(load, 8000);
    return () => {
      stop = true;
      clearInterval(timer);
    };
  }, [active]);
  return seen;
}

function CopyRow({ url, disabled }: { url: string; disabled?: boolean }) {
  const { t } = useT();
  const [copied, setCopied] = useState(false);
  return (
    <div className="sp-url">
      <code title={url}>{url.replace(/#.*$/, '#••••••')}</code>
      <button
        type="button"
        className="sp-copy"
        disabled={disabled}
        onClick={async () => {
          try {
            await navigator.clipboard.writeText(url);
            setCopied(true);
            setTimeout(() => setCopied(false), 1400);
          } catch {
            // Browser erlaubt es nicht
          }
        }}
      >
        {copied ? <Check size={14} /> : <Copy size={14} />}
        {copied ? t('sp.copied') : t('sp.copy')}
      </button>
      <a href={url} target="_blank" rel="noreferrer" className="sp-open" title={t('sp.open')} aria-label={t('sp.open')}>
        <ExternalLink size={14} />
      </a>
    </div>
  );
}

/** Looks-Seite: Knopf „OBS-Quelle“ an jeder Look-Karte. */
export function ObsSourceButton({ look, base, overlayKey }: { look: SceneLook; base: string; overlayKey: string }) {
  const { t } = useT();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const down = (e: PointerEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const key = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('pointerdown', down);
    document.addEventListener('keydown', key);
    return () => {
      document.removeEventListener('pointerdown', down);
      document.removeEventListener('keydown', key);
    };
  }, [open]);
  return (
    <div className="sp-wrap" ref={ref} data-tour="obs-source">
      <button
        type="button"
        className={'v2-ghost sp-btn' + (open ? ' is-on' : '')}
        aria-expanded={open}
        title={t('sp.btnTitle')}
        onClick={() => setOpen((o) => !o)}
      >
        <MonitorPlay size={14} /> {t('sp.btn')}
      </button>
      {open && (
        <div className="sp-pop" role="dialog" aria-label={t('sp.popTitle', { name: look.name })}>
          <div className="sp-pop-head">
            <span>
              <b>{t('sp.popTitle', { name: look.name })}</b>
              <small>{t('sp.popSub')}</small>
            </span>
            <button type="button" onClick={() => setOpen(false)} aria-label={t('sp.close')}>
              ×
            </button>
          </div>
          {overlayKey ? <CopyRow url={lookUrl(base, overlayKey, look)} /> : <small>{t('sp.noKey')}</small>}
          <ul className="sp-steps">
            <li>{t('sp.step1', { w: lookWidth(look.config) })}</li>
            <li>{t('sp.step2')}</li>
            <li>{t('sp.step3')}</li>
          </ul>
        </div>
      )}
    </div>
  );
}

/** „Ab in OBS“: Quelle wählen – Live oder ein fester Look. */
export function ObsSourceChooser({
  looks,
  base,
  overlayKey,
  liveWidth,
  liveLocked,
  seen,
}: {
  looks: SceneLook[];
  base: string;
  overlayKey: string;
  liveWidth: number;
  liveLocked: boolean;
  seen: ObsSeen | null;
}) {
  const { t } = useT();
  const [sel, setSel] = useState<string>('live');
  const look = looks.find((l) => l.id === sel) ?? null;
  const width = look ? lookWidth(look.config) : liveWidth;
  const url = overlayKey ? lookUrl(base, overlayKey, look) : '';
  const opts: { id: string; name: string; note: string; inObs: boolean }[] = [
    { id: 'live', name: t('sp.live'), note: t('sp.liveNote'), inObs: isInObs(seen, null) },
    ...looks.map((l) => ({ id: l.id, name: l.name, note: t('sp.fixed', { w: lookWidth(l.config) }), inObs: isInObs(seen, l.id) })),
  ];
  return (
    <div className="sp-chooser">
      <span className="sp-q">{t('sp.which')}</span>
      <div className="sp-opts" role="radiogroup" aria-label={t('sp.which')}>
        {opts.map((o) => (
          <button
            key={o.id}
            type="button"
            role="radio"
            aria-checked={sel === o.id}
            className={'sp-opt' + (sel === o.id ? ' is-on' : '')}
            onClick={() => setSel(o.id)}
          >
            <i aria-hidden="true" />
            <span>
              <b>{o.name}</b>
              <small>{o.note}</small>
            </span>
            {o.inObs && <em>{t('sp.inObs')}</em>}
          </button>
        ))}
      </div>
      {url ? <CopyRow url={url} disabled={!look && liveLocked} /> : <small>{t('sp.noKey')}</small>}
      <small className="sp-hint">
        {look ? t('sp.hintFixed', { w: width + 100 }) : liveLocked ? t('sp.hintLocked') : t('sp.hintLive', { w: width + 100 })}
      </small>
    </div>
  );
}
