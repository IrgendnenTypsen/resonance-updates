'use client';
// F23 – Setup-Karte „Musikquelle“ (Mockup abgesegnet 2026-10-13, „passt“).
// Spotify, Windows-Medienwiedergabe (YouTube Music, Amazon Music, Browser …)
// oder automatisch. Zeigt live, was Windows gerade meldet.
import { useEffect, useState } from 'react';
import { ListMusic } from 'lucide-react';
import { serverMsg, useT } from '@/lib/i18n';
import './source-card.css';

type Mode = 'auto' | 'spotify' | 'other';
type Session = { app: string; title: string; artist: string; status: string; cover: string };

function label(app: string, browser: string) {
  if (/spotify/i.test(app)) return 'Spotify';
  if (/amazon/i.test(app)) return 'Amazon Music';
  if (/youtube\s*music|youtubemusic/i.test(app)) return 'YouTube Music';
  if (/chrome/i.test(app)) return browser + ' · Chrome';
  if (/edge/i.test(app)) return browser + ' · Edge';
  if (/firefox/i.test(app)) return browser + ' · Firefox';
  return app.split(/[!\\]/).pop()?.replace(/\.exe$/i, '') || app;
}

export default function SourceCard({ active }: { active: boolean }) {
  const i18n = useT();
  const { t } = i18n;
  const [mode, setMode] = useState<Mode>('auto');
  const [sessions, setSessions] = useState<Session[] | null>(null);
  const [available, setAvailable] = useState(true);
  const [note, setNote] = useState('');

  useEffect(() => {
    fetch('/api/source', { cache: 'no-store' })
      .then((r) => (r.ok ? (r.json() as Promise<{ mode?: Mode }>) : null))
      .then((d) => d?.mode && setMode(d.mode))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!active) return;
    let stop = false;
    const load = async () => {
      try {
        const r = await fetch('/__resonance/media/sessions', { cache: 'no-store' });
        const d = (await r.json()) as { available?: boolean; sessions?: Session[] };
        if (stop) return;
        setAvailable(!!d.available);
        setSessions(d.sessions ?? []);
      } catch {
        if (!stop) setAvailable(false);
      }
    };
    void load();
    const timer = setInterval(load, 3000);
    return () => {
      stop = true;
      clearInterval(timer);
    };
  }, [active]);

  const choose = async (m: Mode) => {
    const before = mode;
    setMode(m);
    setNote('');
    try {
      const r = await fetch('/api/source', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: m }),
      });
      const d = (await r.json()) as { error?: string };
      if (!r.ok) throw new Error(d.error);
    } catch (e) {
      setMode(before);
      setNote(serverMsg(e instanceof Error ? e.message : ''));
    }
  };

  const modes: [Mode, string, string][] = [
    ['auto', t('source.auto'), t('source.autoNote')],
    ['spotify', t('source.spotify'), t('source.spotifyNote')],
    ['other', t('source.other'), t('source.otherNote')],
  ];

  return (
    <article className="v2-setup-card src-card is-done" data-tour="source">
      <header>
        <span className="v2-setup-icon">
          <ListMusic size={17} />
        </span>
        <div>
          <b>{t('source.title')}</b>
          <small>{t('source.sub')}</small>
        </div>
      </header>
      <div className="src-modes" role="radiogroup" aria-label={t('source.title')}>
        {modes.map(([v, l, n]) => (
          <button key={v} type="button" role="radio" aria-checked={mode === v} className={'src-mode' + (mode === v ? ' is-on' : '')} onClick={() => void choose(v)}>
            <i aria-hidden="true" />
            <span>
              <b>{l}</b>
              <small>{n}</small>
            </span>
          </button>
        ))}
      </div>
      <div className="src-found">
        <span className="src-label">{t('source.found')}</span>
        {!available ? (
          <span className="src-empty">{t('source.unavailable')}</span>
        ) : !sessions ? (
          <span className="src-empty">{t('source.checking')}</span>
        ) : !sessions.length ? (
          <span className="src-empty">{t('source.nothing')}</span>
        ) : (
          sessions.map((s, k) => (
            <div key={s.app + k} className="src-item">
              {s.cover ? <img src={s.cover} alt="" /> : <i />}
              <span className="src-text">
                <b>{s.title}</b>
                <small>{s.artist.replace(/\s+-\s+Topic$/i, '')}</small>
              </span>
              <span className="src-meta">
                <em className={/spotify/i.test(s.app) ? 'is-spotify' : ''}>{label(s.app, t('source.browser'))}</em>
                <small className={s.status === 'Playing' ? 'is-live' : ''}>● {s.status === 'Playing' ? t('source.playing') : t('source.paused')}</small>
              </span>
            </div>
          ))
        )}
      </div>
      <p className="v2-setup-why">{t('source.why')}</p>
      {note && <p className="v2-setup-why src-note">{note}</p>}
    </article>
  );
}
