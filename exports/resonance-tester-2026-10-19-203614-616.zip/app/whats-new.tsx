'use client';
// F24 – Update-Tour „Was ist neu“ (Mockup abgesegnet 2026-10-19, „passt so“).
// Nach einem Update: Karte mit allen Neuigkeiten seit der zuletzt gesehenen
// Version (übersprungene Updates inklusive), dann Schritt-für-Schritt-Tour
// mit Spotlight durch die Seiten. Jederzeit überspringbar, „Was ist neu?“
// oben startet sie wieder.
import { useEffect, useRef, useState } from 'react';
import { useT, type Key } from '@/lib/i18n';
import { RELEASES, readSeen, releasesSince, writeSeen, type Release, type TourPage } from '@/lib/whats-new';
import './whats-new.css';

type Rect = { x: number; y: number; w: number; h: number };
type Phase = 'idle' | 'welcome' | 'step' | 'done';

export default function WhatsNew({
  build,
  manual,
  setView,
}: {
  build: string | null;
  manual: number;
  setView: (v: TourPage) => void;
}) {
  const { t } = useT();
  const tk = (k: string) => t(k as Key);
  const [phase, setPhase] = useState<Phase>('idle');
  const [rels, setRels] = useState<Release[]>([]);
  const [idx, setIdx] = useState(0);
  const [rect, setRect] = useState<Rect | null>(null);
  const buildRef = useRef(build);
  buildRef.current = build;
  const steps = rels.flatMap((r) => r.steps.map((s) => ({ ...s, v: r.version })));
  const step = steps[idx];

  // Automatisch nach dem Laden (Version kommt asynchron → kurz warten).
  useEffect(() => {
    const timer = setTimeout(() => {
      const list = releasesSince(readSeen(), buildRef.current);
      if (list.length) {
        setRels(list);
        setPhase('welcome');
      }
    }, 1800);
    return () => clearTimeout(timer);
  }, []);

  // „Was ist neu?“ oben: alle Neuigkeiten zeigen.
  useEffect(() => {
    if (!manual) return;
    setRels(releasesSince(null, buildRef.current));
    setIdx(0);
    setPhase('welcome');
  }, [manual]);

  const markSeen = () => writeSeen(buildRef.current || RELEASES[0].version);
  const close = () => {
    markSeen();
    setPhase('idle');
    setRect(null);
  };
  const finish = () => {
    markSeen();
    setRect(null);
    setPhase('done');
  };
  const go = (n: number) => {
    if (n < 0) return;
    if (n >= steps.length) return finish();
    setIdx(n);
    setRect(null);
    setPhase('step');
  };

  // Schritt: Seite wechseln, Ziel suchen, Spotlight mitführen.
  useEffect(() => {
    if (phase !== 'step' || !step) return;
    setView(step.page);
    let stop = false;
    let tries = 0;
    const find = () => document.querySelector<HTMLElement>(`[data-tour="${step.target}"]`);
    const measure = () => {
      const el = find();
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return r.width || r.height ? { x: r.left, y: r.top, w: r.width, h: r.height } : null;
    };
    const first = setInterval(() => {
      if (stop) return;
      tries += 1;
      const el = find();
      if (el) {
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        clearInterval(first);
      } else if (tries > 12) clearInterval(first);
    }, 120);
    const follow = setInterval(() => {
      if (!stop) setRect(measure());
    }, 200);
    return () => {
      stop = true;
      clearInterval(first);
      clearInterval(follow);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, idx, rels]);

  useEffect(() => {
    if (phase === 'idle') return;
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
      if (phase === 'step' && e.key === 'ArrowRight') go(idx + 1);
      if (phase === 'step' && e.key === 'ArrowLeft') go(idx - 1);
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, idx]);

  if (phase === 'idle') return null;

  if (phase === 'welcome' || phase === 'done') {
    const done = phase === 'done';
    const news = rels.flatMap((r) => r.news.map((n) => ({ ...n, v: r.version })));
    const kicker = done
      ? t('wn.doneKicker')
      : rels.length > 1
        ? t('wn.kickerMany', { n: rels.length })
        : t('wn.kickerOne', { v: rels[0]?.version ?? '' });
    return (
      <div className="wn-layer" role="dialog" aria-modal="true" aria-label={t('wn.title')}>
        <div className="wn-dim" onClick={close} />
        <div className="wn-card">
          <span className="wn-kicker">{kicker}</span>
          <b className="wn-title">{done ? t('wn.doneTitle') : t('wn.title')}</b>
          <p>{done ? t('wn.doneBody') : rels.length > 1 ? t('wn.bodyMany') : t('wn.bodyOne')}</p>
          {!done && (
            <div className="wn-news">
              {news.map((n, k) => (
                <div key={k} className="wn-item">
                  <span className="wn-icon" aria-hidden="true">
                    {n.icon}
                  </span>
                  <span className="wn-text">
                    <b>{tk(n.title)}</b>
                    <small>{tk(n.sub)}</small>
                  </span>
                  {rels.length > 1 && <span className="wn-ver">{n.v}</span>}
                </div>
              ))}
            </div>
          )}
          <div className="wn-actions">
            <button type="button" className="secondary" onClick={done ? () => go(0) : close}>
              {done ? t('wn.again') : t('wn.later')}
            </button>
            <button type="button" className="primary" onClick={done ? close : () => go(0)} disabled={!done && !steps.length}>
              {done ? t('wn.letsGo') : t('wn.start')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Schritt mit Spotlight
  const pad = 6;
  const vw = typeof window !== 'undefined' ? window.innerWidth : 1280;
  const vh = typeof window !== 'undefined' ? window.innerHeight : 800;
  const popW = Math.min(340, vw - 24);
  let px = (vw - popW) / 2;
  let py = vh / 2 - 90;
  if (rect) {
    px = Math.min(Math.max(12, rect.x + rect.w / 2 - popW / 2), vw - popW - 12);
    const below = rect.y + rect.h + pad + 12;
    py = below + 190 < vh ? below : Math.max(12, rect.y - pad - 12 - 190);
  }
  return (
    <div className="wn-layer" role="dialog" aria-modal="true" aria-label={tk(step.title)}>
      <div className="wn-block" />
      {rect ? (
        <div
          className="wn-spot"
          style={{ left: rect.x - pad, top: rect.y - pad, width: rect.w + pad * 2, height: rect.h + pad * 2 }}
        />
      ) : (
        <div className="wn-dim" />
      )}
      <div className="wn-pop" style={{ left: px, top: py, width: popW }}>
        <span className="wn-pop-head">
          <span className="wn-kicker">{t('wn.stepKicker', { v: step.v, n: idx + 1, of: steps.length })}</span>
          <button type="button" onClick={finish}>
            {t('wn.end')}
          </button>
        </span>
        <b>{tk(step.title)}</b>
        <span className="wn-body">{tk(step.body)}</span>
        <span className="wn-pop-foot">
          <span className="wn-dots">
            {steps.map((_, k) => (
              <i key={k} className={k === idx ? 'is-on' : ''} />
            ))}
          </span>
          <span className="wn-btns">
            <button type="button" className="secondary" onClick={() => go(idx - 1)} disabled={idx === 0}>
              {t('wn.back')}
            </button>
            <button type="button" className="primary" onClick={() => go(idx + 1)}>
              {idx === steps.length - 1 ? t('wn.finish') : t('wn.next')}
            </button>
          </span>
        </span>
      </div>
    </div>
  );
}
