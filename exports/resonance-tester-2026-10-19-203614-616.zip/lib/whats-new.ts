// F24 – „Was ist neu“: Neuigkeiten + Tour-Schritte je Release.
// Neues Release = neuer Eintrag OBEN anhängen (version = Datum JJJJ.MM.TT).
// Gezeigt wird alles, was neuer ist als die zuletzt gesehene Version – also
// auch übersprungene Updates. Texte stehen in lib/i18n.ts (wn.*).
export type TourPage = 'studio' | 'looks' | 'likes' | 'history' | 'setup';
export type TourStep = { page: TourPage; target: string; title: string; body: string };
export type Release = {
  version: string;
  news: { icon: string; title: string; sub: string }[];
  steps: TourStep[];
};

export const RELEASES: Release[] = [
  {
    version: '2026.10.19',
    news: [
      { icon: '⧉', title: 'wn.r1019.scenes', sub: 'wn.r1019.scenesSub' },
      { icon: '+', title: 'wn.r1019.plfix', sub: 'wn.r1019.plfixSub' },
      { icon: '✦', title: 'wn.r1019.tour', sub: 'wn.r1019.tourSub' },
    ],
    steps: [
      { page: 'looks', target: 'obs-source', title: 'wn.r1019.scenes', body: 'wn.r1019.scenesStep' },
      { page: 'studio', target: 'whats-new', title: 'wn.r1019.tour', body: 'wn.r1019.tourStep' },
    ],
  },
  {
    version: '2026.10.13',
    news: [
      { icon: '▣', title: 'wn.r1013.widget', sub: 'wn.r1013.widgetSub' },
      { icon: '♥', title: 'wn.r1013.likes', sub: 'wn.r1013.likesSub' },
      { icon: '♪', title: 'wn.r1013.sources', sub: 'wn.r1013.sourcesSub' },
    ],
    steps: [
      { page: 'studio', target: 'widget', title: 'wn.r1013.widget', body: 'wn.r1013.widgetStep' },
      { page: 'likes', target: 'nav-likes', title: 'wn.r1013.likes', body: 'wn.r1013.likesStep' },
      { page: 'setup', target: 'source', title: 'wn.r1013.sources', body: 'wn.r1013.sourcesStep' },
    ],
  },
];

/** Vor der Tour gab es keinen Merker → alles ab F22 (2026.10.13) zeigen. */
export const BASELINE = '2026.10.12';
export const SEEN_KEY = 'resonance.whatsnew.seen';

/** Releases neuer als `seen`, älteste zuerst (Tour-Reihenfolge). */
export function releasesSince(seen: string | null, build: string | null) {
  const from = seen || BASELINE;
  return RELEASES.filter((r) => r.version > from && (!build || r.version <= build)).reverse();
}

export function readSeen(): string | null {
  try {
    return localStorage.getItem(SEEN_KEY);
  } catch {
    return null;
  }
}

export function writeSeen(v: string) {
  try {
    localStorage.setItem(SEEN_KEY, v);
  } catch {
    // nur Komfort
  }
}
