// F04 Szenen-Profile: merkt sich (nur im Speicher), welche OBS-Quellen gerade
// abfragen – „in OBS“-Hinweis im Studio. Keine Keys, keine Persistenz.
type Seen = { live: number; looks: Map<string, number> };
const byOwner = new Map<string, Seen>();

export function noteSeen(owner: string, lookId: string | null) {
  let s = byOwner.get(owner);
  if (!s) {
    s = { live: 0, looks: new Map() };
    byOwner.set(owner, s);
  }
  if (lookId) s.looks.set(lookId, Date.now());
  else s.live = Date.now();
}

/** Sekunden seit der letzten Abfrage je Quelle (nur die letzten 10 Minuten). */
export function seenAgo(owner: string) {
  const s = byOwner.get(owner);
  const now = Date.now();
  const ago = (t: number) => (t && now - t < 600_000 ? Math.round((now - t) / 1000) : null);
  const looks: Record<string, number> = {};
  for (const [id, t] of s?.looks ?? []) {
    const a = ago(t);
    if (a !== null) looks[id] = a;
  }
  return { live: ago(s?.live ?? 0), looks };
}

/** ?look=<name>-<10 hex> → die 10 hex am Ende (Name ist nur zur Lesbarkeit). */
export function lookPrefix(param: string | null) {
  const m = param ? /([a-f0-9]{10})$/.exec(param.trim().toLowerCase()) : null;
  return m ? m[1] : null;
}
