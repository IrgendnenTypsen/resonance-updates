import { memoryMoodStyle } from './memory-mood';
import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { moodConfig, detectMood, type LastfmTag } from './mood';
import {
  Music2,
  Star,
  Heart,
  Shuffle,
  SkipBack,
  SkipForward,
  Play,
  Pause,
  Volume2,
} from 'lucide-react';
export type Config = {
  layout: string;
  accent: string;
  background: string;
  text: string;
  radius: number;
  opacity: number;
  glow: boolean;
  cover: boolean;
  progress: boolean;
  artist: boolean;
  badge: boolean;
  hidePaused: boolean;
  font: string;
  titleFont: string;
  artistFont: string;
  metaFont: string;
  titleWeight: number;
  artistWeight: number;
  metaWeight: number;
  titleSize: number;
  artistSize: number;
  metaSize: number;
  titleLetterSpacing: number;
  artistLetterSpacing: number;
  metaLetterSpacing: number;
  titleCase: string;
  artistCase: string;
  metaCase: string;
  width: number;
  spacing: number;
  fontSize: number;
  animation: string;
  align: string;
  moodSwitch: boolean;
  moodIntensity: number;
  spin: boolean;
  spinSpeed: number;
  memoryLabel: string;
  ledVisible: boolean;
  ledColor: string;
  ledBehavior: string;
  ledBrightness: number;
  ledGlow: number;
  ledSpeed: number;
  ledSize: number;
  ledOffsetX: number;
  ledOffsetY: number;
  displayColor: string;
  displayBrightness: number;
  textGlow: number;
  progressColor: string;
  controlAccentColor: string;
  statusAccentColor: string;
  linkAccentColors: boolean;
  progressEdge: number;
  progressWidth: number;
  progressThickness: number;
  progressOffsetX: number;
  progressOffsetY: number;
  progressRadius: number;
  controlsSize: number;
  controlsIconSize: number;
  controlsGap: number;
  controlsOffsetX: number;
  controlsOffsetY: number;
  coverBrightness: number;
  coverSaturation: number;
  coverContrast: number;
  coverSize: number;
  coverOffsetX: number;
  coverOffsetY: number;
  coverRadius: number;
  coverFit: string;
  noteSize: number;
  noteOffsetX: number;
  noteOffsetY: number;
  noteRotation: number;
  noteOpacity: number;
  titleOffsetX: number;
  titleOffsetY: number;
  artistOffsetX: number;
  artistOffsetY: number;
  metaOffsetX: number;
  metaOffsetY: number;
  titleArtistSpacing: number;
  scanlinesEnabled: boolean;
  scanlineStrength: number;
  grainEnabled: boolean;
  grainStrength: number;
  vignetteStrength: number;
  observedPlaylistId: string;
  observedPlaylistName: string;
};
export const defaults: Config = {
  layout: 'glass',
  accent: '#b3f47c',
  background: '#161b20',
  text: '#ffffff',
  radius: 24,
  opacity: 86,
  glow: true,
  cover: true,
  progress: true,
  artist: true,
  badge: true,
  hidePaused: false,
  font: 'sans',
  titleFont: 'sans',
  artistFont: 'sans',
  metaFont: 'sans',
  titleWeight: 700,
  artistWeight: 400,
  metaWeight: 700,
  titleSize: 23,
  artistSize: 14,
  metaSize: 9,
  titleLetterSpacing: -0.65,
  artistLetterSpacing: 0,
  metaLetterSpacing: 1.5,
  titleCase: 'normal',
  artistCase: 'normal',
  metaCase: 'uppercase',
  width: 480,
  spacing: 22,
  fontSize: 23,
  animation: 'fade',
  align: 'left',
  moodSwitch: false,
  moodIntensity: 70,
  spin: false,
  spinSpeed: 14,
  memoryLabel: 'GOOD MUSIC BETTER DAYS.',
  ledVisible: true,
  ledColor: '#ff7a6a',
  ledBehavior: 'soft',
  ledBrightness: 70,
  ledGlow: 50,
  ledSpeed: 50,
  ledSize: 100,
  ledOffsetX: 0,
  ledOffsetY: 0,
  displayColor: '#101619',
  displayBrightness: 100,
  textGlow: 0,
  progressColor: '#b3f47c',
  controlAccentColor: '#b3f47c',
  statusAccentColor: '#b3f47c',
  linkAccentColors: true,
  progressEdge: 0,
  progressWidth: 100,
  progressThickness: 100,
  progressOffsetX: 0,
  progressOffsetY: 0,
  progressRadius: 5,
  controlsSize: 100,
  controlsIconSize: 100,
  controlsGap: 100,
  controlsOffsetX: 0,
  controlsOffsetY: 0,
  coverBrightness: 100,
  coverSaturation: 100,
  coverContrast: 100,
  // Die Layout-Defaults entsprechen den bisherigen festen CSS-Werten.
  coverSize: 100,
  coverOffsetX: 0,
  coverOffsetY: 0,
  coverRadius: 5,
  coverFit: 'cover',
  noteSize: 100,
  noteOffsetX: 0,
  noteOffsetY: 0,
  noteRotation: 0,
  noteOpacity: 100,
  titleOffsetX: 0,
  titleOffsetY: 0,
  artistOffsetX: 0,
  artistOffsetY: 0,
  metaOffsetX: 0,
  metaOffsetY: 0,
  titleArtistSpacing: 3,
  scanlinesEnabled: true,
  scanlineStrength: 10,
  grainEnabled: false,
  grainStrength: 10,
  vignetteStrength: 22,
  observedPlaylistId: '',
  observedPlaylistName: '',
};
export type FontDefinition = {
  id: string;
  name: string; // Anzeigename
  category: string; // Kategorie-Label
  family: string; // CSS font-family
  weights: number[]; // Verfügbare Gewichte
  preview?: string; // Optionaler Vorschau-Text im Picker
  localPath?: string; // Lokale WOFF2-Datei (Vorbereitung, /fonts/{name}.woff2)
};
export const FONT_LIBRARY: FontDefinition[] = [
  // CLEAN / MODERN
  {
    id: 'sans',
    name: 'Inter',
    category: 'Clean',
    family: 'Arial, Helvetica, sans-serif',
    weights: [300, 400, 500, 700],
  },
  {
    id: 'grotesk',
    name: 'Space Grotesk',
    category: 'Clean',
    family: "'Space Grotesk', sans-serif",
    weights: [300, 400, 500, 700],
    localPath: '/fonts/space-grotesk.woff2',
  },
  // GEOMETRIC
  {
    id: 'geometric',
    name: 'Jost',
    category: 'Geometric',
    family: "'Jost', 'Century Gothic', sans-serif",
    weights: [300, 400, 700],
    localPath: '/fonts/jost.woff2',
  },
  // CONDENSED
  {
    id: 'condensed',
    name: 'Barlow Condensed',
    category: 'Condensed',
    family: "'Barlow Condensed', 'Arial Narrow', sans-serif",
    weights: [300, 400, 500, 700],
    localPath: '/fonts/barlow-condensed.woff2',
  },
  // MONO / TECH
  {
    id: 'mono',
    name: 'IBM Plex Mono',
    category: 'Mono',
    family: "'IBM Plex Mono', 'Consolas', monospace",
    weights: [300, 400, 500, 700],
    localPath: '/fonts/ibm-plex-mono.woff2',
  },
  {
    id: 'mono-retro',
    name: 'VT323',
    category: 'Mono',
    family: "'VT323', 'Courier New', monospace",
    weights: [400],
    localPath: '/fonts/vt323.woff2',
  },
  // SERIF
  {
    id: 'serif',
    name: 'Playfair Display',
    category: 'Serif',
    family: "'Playfair Display', Georgia, serif",
    weights: [400, 500, 700],
    localPath: '/fonts/playfair-display.woff2',
  },
  {
    id: 'editorial',
    name: 'Lora',
    category: 'Serif',
    family: "'Lora', Georgia, serif",
    weights: [400, 500, 700],
    localPath: '/fonts/lora.woff2',
  },
  // DISPLAY
  {
    id: 'display',
    name: 'Archivo Black',
    category: 'Display',
    family: "'Archivo Black', Impact, sans-serif",
    weights: [400],
    localPath: '/fonts/archivo-black.woff2',
  },
  // RETRO
  {
    id: 'retro',
    name: 'Press Start 2P',
    category: 'Retro',
    family: "'Press Start 2P', monospace",
    weights: [400],
    localPath: '/fonts/press-start-2p.woff2',
  },
  // HANDWRITTEN
  {
    id: 'handwritten',
    name: 'Caveat',
    category: 'Handwritten',
    family: "'Caveat', cursive",
    weights: [400, 500, 700],
    localPath: '/fonts/caveat.woff2',
  },
];
export function resolveFontFamily(fontId: string): string {
  if (fontId.startsWith('custom:')) {
    const id = fontId.slice(7);
    return `'ResonanceCustom_${id}', Arial, sans-serif`;
  }
  const font = FONT_LIBRARY.find((f) => f.id === fontId);
  return font?.family || 'Arial, sans-serif';
}
export type Track = {
  title: string;
  artist: string;
  cover: string;
  duration: number;
  progress: number;
  playing: boolean;
  demo?: boolean;
  album?: string;
  genres?: string[];
  artistId?: string;
  id?: string;
  slot?: number;
  favorite?: boolean;
  inObservedPlaylist?: boolean;
  playlistAccess?: 'denied' | 'rate_limited';
  lastfmTags?: LastfmTag[];
  isrc?: string; // NEU
  lyricMoodScores?: Record<string, number>;
  fetchedAt?: number;
};
export function estimatedProgress(track: Track, now = Date.now()) {
  const elapsed = track.playing
    ? Math.max(0, now - (track.fetchedAt ?? now))
    : 0;
  return Math.min(track.duration, Math.max(0, track.progress + elapsed));
}
export const demo: Track = {
  title: 'Midnight in Motion',
  artist: 'Resonance Radio',
  cover: '',
  duration: 224000,
  progress: 87000,
  playing: true,
  demo: true,
};
// --- Track Transition (Checkpoint 16.26 / 16.26.1 / 16.26.2) ---
// Subtile, feste Standardtransition beim Wechsel zu einem wirklich neuen
// Spotify-Track. Phasen: stable → exit → swap → enter → stable.
// Die Transition animiert ausschließlich dedizierte Wrapper
// (track-transition-cover/-meta/-title/-artist) im Memory-Layout. Die
// bestehenden Memory-Elemente behalten dadurch ihre Basisanimationen
// (memory-slot-load, memory-text-enter, memory-text-slide) und deren
// fill-mode-Endzustände unverändert. Kein animation-name-Wechsel auf den
// Original-Elementen → kein Double-Blink, keine Layout-Regression.
// Keine neuen Settings, keine Mood-/Layout-Änderungen.
type TransitionPhase = 'stable' | 'exit' | 'enter';
const EXIT_MS = 180;
const ENTER_MS = 300;
function trackId(t: Track | null): string | null {
  if (!t) return null;
  return t.id || t.title + '|' + t.artist;
}
export function Overlay({
  config: base,
  track: t,
}: {
  config: Config;
  track: Track | null;
}) {
  const [displayed, setDisplayed] = useState<Track | null>(t);
  const displayedRef = useRef<Track | null>(t);
  const [phase, setPhase] = useState<TransitionPhase>('stable');
  const pendingRef = useRef<Track | null>(null);
  const exitTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const enterTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Ref parallel zum displayed-State halten, damit der Transition-Effect
  // ohne State-Dependency auf den aktuellen Track zugreifen kann.
  useEffect(() => {
    displayedRef.current = displayed;
  }, [displayed]);

  useEffect(() => {
    const incomingId = trackId(t);
    const displayedId = trackId(displayedRef.current);

    if (incomingId === displayedId) {
      // Gleicher Track: Daten (Play/Pause, Progress, Favorite) übernehmen,
      // ohne eine Track-Transition auszulösen. Ein noch laufender Exit auf
      // einen anderen Track wird abgebrochen (Latest wins).
      if (exitTimer.current) {
        clearTimeout(exitTimer.current);
        exitTimer.current = null;
        pendingRef.current = null;
        setPhase('stable');
      }
      if (t !== displayedRef.current) setDisplayed(t);
      return;
    }

    // Ein neuer Track bricht eine laufende Entry-Animation ab (Latest wins).
    if (enterTimer.current) {
      clearTimeout(enterTimer.current);
      enterTimer.current = null;
    }

    if (incomingId === null) {
      // Track → Idle: sanft ausblenden, danach leerer Zustand.
      if (displayedId === null) return;
      setPhase('exit');
      if (exitTimer.current) clearTimeout(exitTimer.current);
      exitTimer.current = setTimeout(() => {
        setDisplayed(null);
        setPhase('stable');
        exitTimer.current = null;
      }, EXIT_MS);
      return;
    }

    if (displayedId === null) {
      // Idle → Track bzw. Initial Load: direkt setzen, nur dezenter Entry.
      setDisplayed(t);
      setPhase('enter');
      enterTimer.current = setTimeout(() => {
        setPhase('stable');
        enterTimer.current = null;
      }, ENTER_MS);
      return;
    }

    // Track → Track: Exit, Swap auf den zuletzt empfangenen Track, Entry.
    pendingRef.current = t;
    setPhase('exit');
    if (exitTimer.current) clearTimeout(exitTimer.current);
    exitTimer.current = setTimeout(() => {
      const next = pendingRef.current;
      pendingRef.current = null;
      if (next) {
        setDisplayed(next);
        setPhase('enter');
        enterTimer.current = setTimeout(() => {
          setPhase('stable');
          enterTimer.current = null;
        }, ENTER_MS);
      } else {
        setPhase('stable');
      }
      exitTimer.current = null;
    }, EXIT_MS);
  }, [t]);

  useEffect(() => {
    return () => {
      if (exitTimer.current) clearTimeout(exitTimer.current);
      if (enterTimer.current) clearTimeout(enterTimer.current);
    };
  }, []);

  const c = moodConfig(base, displayed, displayed?.lastfmTags);
  if (!displayed && c.layout !== 'memory') return null;
  if (displayed && c.hidePaused && !displayed.playing) return null;
  const mood = base.moodSwitch
    ? detectMood(displayed, displayed?.lastfmTags)
    : null;
  const opacityHex = Math.round(c.opacity * 2.55)
    .toString(16)
    .padStart(2, '0');
  const style = {
    '--spin-speed': c.spinSpeed + 's',
    '--mood-speed': (mood?.mood.speed || 0.8) + 's',
    '--oa': c.accent,
    '--ot': c.text,
    '--or': c.radius + 'px',
    '--op': c.spacing + 'px',
    '--ofs': c.fontSize + 'px',
    '--mbg': c.background + opacityHex,
    background: c.background + opacityHex,
    width: c.width,
    fontFamily: resolveFontFamily(c.titleFont),
    textAlign: c.align,
  } as CSSProperties;
  if (c.layout === 'memory')
    return (
      <MemorySlot
        config={base}
        track={displayed}
        style={style}
        mood={mood?.mood.id}
        phase={phase}
      />
    );
  // Für TypeScript: Nach dem Memory-Return ist displayed garantiert gesetzt.
  if (!displayed) return null;
  return (
    <div
      key={c.animation + c.layout}
      style={style}
      className={
        'overlay layout-' +
        c.layout +
        ' anim-' +
        c.animation +
        (c.glow ? ' has-glow' : '') +
        (phase === 'exit' ? ' track-exit' : '') +
        (phase === 'enter' ? ' track-enter' : '')
      }
    >
      {c.layout === 'winamp' && (
        <div className="retro-bar">
          <span>R</span>
          <b>RESONANCE MP3 PLAYER</b>
          <span>− ▪ ×</span>
        </div>
      )}
      {c.layout === 'aqua' && (
        <div className="aqua-bar">
          <span className="traffic-lights">
            <i />
            <i />
            <i />
          </span>
          <span>Now Playing</span>
          <Music2 size={12} />
        </div>
      )}
      {c.layout === 'pixel' && (
        <div className="pixel-bar">
          <span>♪ NOW PLAYING</span>
          <span>LVL. 01</span>
        </div>
      )}
      {c.layout === 'sticker' && (
        <div className="sticker-label">
          on repeat <Star size={17} fill="currentColor" />
        </div>
      )}
      {c.layout === 'vinyl' && (
        <div className="vinyl-label">
          SIDE A <span>33⅓ RPM · STEREO</span>
        </div>
      )}
      <div className="overlay-main">
        {c.cover && (
          <div
            className={'album-art' + (c.spin ? ' rotating-cover' : '')}
            style={{
              animationPlayState: displayed.playing ? 'running' : 'paused',
            }}
          >
            {displayed.cover ? (
              <img
                src={displayed.cover}
                alt={'Albumcover: ' + displayed.title}
              />
            ) : (
              <div className="demo-art">
                <Music2 size={38} />
                <span>R / 01</span>
              </div>
            )}
          </div>
        )}
        <div className="track-info">
          {c.badge && (
            <div
              className="now-playing"
              style={{
                fontFamily: resolveFontFamily(c.metaFont),
                fontWeight: c.metaWeight,
                fontSize: c.metaSize + 'px',
                letterSpacing: c.metaLetterSpacing + 'px',
                textTransform:
                  c.metaCase === 'uppercase' ? 'uppercase' : undefined,
              }}
            >
              <span
                className={'equalizer ' + (!displayed.playing ? 'paused' : '')}
              >
                <i />
                <i />
                <i />
                <i />
              </span>
              {displayed.demo
                ? 'RESONANCE RADIO'
                : displayed.playing
                  ? 'PLAYING ON SPOTIFY'
                  : 'PAUSIERT'}
            </div>
          )}
          <div
            className="track-title"
            title={displayed.title}
            style={{
              fontFamily: resolveFontFamily(c.titleFont),
              fontWeight: c.titleWeight,
              fontSize: c.titleSize + 'px',
              letterSpacing: c.titleLetterSpacing + 'px',
              textTransform:
                c.titleCase === 'uppercase' ? 'uppercase' : undefined,
            }}
          >
            {displayed.title}
          </div>
          {c.artist && (
            <div
              className="track-artist"
              style={{
                fontFamily: resolveFontFamily(c.artistFont),
                fontWeight: c.artistWeight,
                fontSize: c.artistSize + 'px',
                letterSpacing: c.artistLetterSpacing + 'px',
                textTransform:
                  c.artistCase === 'uppercase' ? 'uppercase' : undefined,
              }}
            >
              {displayed.artist}
            </div>
          )}
        </div>
      </div>
      {c.progress && (
        <div className="track-progress" key={trackId(displayed)}>
          <div className="progress-rail">
            <div
              style={{
                width:
                  Math.min(
                    100,
                    (displayed.progress / Math.max(1, displayed.duration)) *
                      100,
                  ) + '%',
              }}
            />
          </div>
          <div className="track-times">
            <span>{time(displayed.progress)}</span>
            <span>{time(displayed.duration)}</span>
          </div>
        </div>
      )}
      {(c.layout === 'winamp' || c.layout === 'aqua') && (
        <div className="player-chrome" aria-hidden="true">
          <div>
            <SkipBack size={12} />
            <Play size={13} fill="currentColor" />
            <SkipForward size={12} />
          </div>
          <span>{c.layout === 'winamp' ? '44 KHZ · STEREO' : '♪'} </span>
          <Volume2 size={14} />
        </div>
      )}
      {c.layout === 'pixel' && (
        <div className="pixel-footer">
          <span>★ ★ ★</span>
          <span>
            {displayed.playing ? 'PRESS PLAY & STAY AWHILE' : 'PAUSED'}
          </span>
        </div>
      )}
    </div>
  );
}
export function MemorySlot({
  config: c,
  track,
  style,
  mood,
  phase,
}: {
  config: Config;
  track: Track | null;
  style: CSSProperties;
  mood?: string;
  phase?: TransitionPhase;
}) {
  const idle = !track;
  const playing = !!track?.playing;
  const transitionPhase = phase || 'stable';
  const slot = String(track?.slot || 1).padStart(2, '0');
  const fav = !!track?.favorite;
  const inObserved = !!track?.inObservedPlaylist;
  const label = (c.memoryLabel || '').trim();
  const prevFav = useRef<boolean | undefined>(undefined);
  const favStamp = useRef(0);
  if (fav && prevFav.current === false) favStamp.current += 1;
  prevFav.current = fav;
  const stamping = favStamp.current > 0;
  const prevStream = useRef<boolean | undefined>(undefined);
  const streamStamp = useRef(0);
  if (inObserved && prevStream.current === false) streamStamp.current += 1;
  prevStream.current = inObserved;
  const streamStamping = streamStamp.current > 0;
  const ledUserStyle = {
    '--memory-led-user-color': c.ledColor,
    '--memory-led-user-brightness': c.ledBrightness / 100,
    '--memory-led-user-glow': c.ledGlow / 100,
    '--memory-led-user-speed': (8 - (c.ledSpeed / 100) * 5.5).toFixed(2) + 's',
    '--memory-led-size': c.ledSize / 100,
    '--memory-led-offset-x': c.ledOffsetX + 'px',
    '--memory-led-offset-y': c.ledOffsetY + 'px',
  } as CSSProperties;
  const lcdUserStyle = {
    '--memory-lcd-color': c.displayColor,
    '--memory-lcd-brightness': c.displayBrightness / 100,
    '--memory-text-glow': c.textGlow / 100,
    '--memory-scanline-strength': c.scanlinesEnabled
      ? c.scanlineStrength / 100
      : 0,
    '--memory-grain-strength': c.grainEnabled ? c.grainStrength / 100 : 0,
    '--memory-vignette-strength': c.vignetteStrength / 100,
  } as CSSProperties;
  const progressUserStyle = {
    '--memory-progress-edge': c.progressEdge / 100,
    '--memory-progress-width': c.progressWidth + '%',
    '--memory-progress-thickness-scale': c.progressThickness / 100,
    '--memory-progress-offset-x': c.progressOffsetX + 'px',
    '--memory-progress-offset-y': c.progressOffsetY + 'px',
    '--memory-progress-radius': c.progressRadius + 'px',
  } as CSSProperties;
  // Effektive Accent-Farben: Bei gekoppelten Akzenten (linkAccentColors) steuert
  // der Master-Accent Controls, Status und Progress gemeinsam. Individuelle
  // Werte bleiben in der Config erhalten und greifen, sobald Link OFF ist.
  const effectiveControlAccent = c.linkAccentColors
    ? c.accent
    : c.controlAccentColor;
  const effectiveStatusAccent = c.linkAccentColors
    ? c.accent
    : c.statusAccentColor;
  const effectiveProgressColor = c.linkAccentColors
    ? c.accent
    : c.progressColor;
  // Bei aktivem Mood gewinnen die Mood-Accents (--mood-control/--mood-accent):
  // Die User-Accent-Variablen werden dann bewusst nicht gesetzt, damit die
  // CSS-Fallback-Kette auf die Mood-Tokens fällt.
  const moodActive = !!(c.moodSwitch && c.moodIntensity > 0 && mood);
  const accentUserStyle = moodActive
    ? {}
    : ({
        '--memory-control-accent': effectiveControlAccent,
        '--memory-status-accent': effectiveStatusAccent,
        '--memory-progress-color': effectiveProgressColor,
      } as CSSProperties);
  const coverUserStyle = {
    '--memory-cover-brightness': c.coverBrightness / 100,
    '--memory-cover-saturation': c.coverSaturation / 100,
    '--memory-cover-contrast': c.coverContrast / 100,
    '--memory-cover-size': c.coverSize / 100,
    '--memory-cover-offset-x': c.coverOffsetX + 'px',
    '--memory-cover-offset-y': c.coverOffsetY + 'px',
    '--memory-cover-radius': c.coverRadius + 'px',
    '--memory-cover-fit': c.coverFit,
  } as CSSProperties;
  const noteUserStyle = {
    '--memory-note-size': c.noteSize / 100,
    '--memory-note-offset-x': c.noteOffsetX + 'px',
    '--memory-note-offset-y': c.noteOffsetY + 'px',
    '--memory-note-rotation': c.noteRotation + 'deg',
    '--memory-note-opacity': c.noteOpacity / 100,
  } as CSSProperties;
  const textLayoutStyle = {
    '--memory-title-offset-x': c.titleOffsetX + 'px',
    '--memory-title-offset-y': c.titleOffsetY + 'px',
    '--memory-artist-offset-x': c.artistOffsetX + 'px',
    '--memory-artist-offset-y': c.artistOffsetY + 'px',
    '--memory-meta-offset-x': c.metaOffsetX + 'px',
    '--memory-meta-offset-y': c.metaOffsetY + 'px',
    '--memory-title-artist-spacing': c.titleArtistSpacing + 'px',
  } as CSSProperties;
  const controlsLayoutStyle = {
    '--memory-controls-size': c.controlsSize / 100,
    '--memory-controls-icon-size': c.controlsIconSize / 100,
    '--memory-controls-gap': c.controlsGap / 100,
    '--memory-controls-offset-x': c.controlsOffsetX + 'px',
    '--memory-controls-offset-y': c.controlsOffsetY + 'px',
  } as CSSProperties;
  return (
    <div
      key={c.animation + c.layout}
      data-mood={c.moodSwitch && c.moodIntensity > 0 ? mood : undefined}
      data-led-behavior={c.ledVisible ? c.ledBehavior : 'off'}
      style={{
        ...style,
        ...memoryMoodStyle(c, mood, {
          color: c.displayColor,
          brightness: c.displayBrightness / 100,
        }),
        ...ledUserStyle,
        ...lcdUserStyle,
        ...progressUserStyle,
        ...accentUserStyle,
        ...coverUserStyle,
        ...noteUserStyle,
        ...textLayoutStyle,
        ...controlsLayoutStyle,
      }}
      className={
        'overlay layout-memory anim-' +
        c.animation +
        (c.glow ? ' has-glow' : '') +
        (!playing ? ' is-paused' : '') +
        (idle ? ' is-idle' : '') +
        (!c.cover ? ' no-cover' : '') +
        (!label ? ' no-label' : '') +
        (transitionPhase === 'exit' ? ' track-exit' : '') +
        (transitionPhase === 'enter' ? ' track-enter' : '')
      }
    >
      <div className="memory-spine" aria-hidden="true">
        <i />
        <i />
        <i />
      </div>
      <i className="memory-screw screw-a" aria-hidden="true" />
      <i className="memory-screw screw-b" aria-hidden="true" />
      <i className="memory-screw screw-c" aria-hidden="true" />
      <i className="memory-screw screw-d" aria-hidden="true" />
      <div className="memory-device-mark" aria-hidden="true">
        <b>A</b>
        <span>▲ R12I5</span>
      </div>
      {c.cover && (
        <div className="memory-cover-slot">
          <div className="track-transition-cover">
            <div className="memory-cover-frame">
              {track?.cover ? (
                <img src={track.cover} alt={'Albumcover: ' + track.title} />
              ) : (
                <div className="memory-empty-cover">?</div>
              )}
            </div>
          </div>
          <b>
            MEMORY SLOT
            {track?.inObservedPlaylist && !idle && (
              <i
                className={
                  'memory-fav-mark' + (streamStamping ? ' fav-stamp' : '')
                }
                aria-hidden="true"
              />
            )}
          </b>
        </div>
      )}
      <div className="memory-screen">
        <div className="memory-copy">
          <div className="track-transition-meta">
            {c.badge && (
              <div
                className="memory-status"
                style={{
                  fontFamily: resolveFontFamily(c.metaFont),
                  fontWeight: c.metaWeight,
                  fontSize: c.metaSize + 'px',
                  letterSpacing: c.metaLetterSpacing + 'px',
                  textTransform:
                    c.metaCase === 'uppercase' ? 'uppercase' : undefined,
                }}
              >
                <span>
                  {idle ? 'Slot empty' : playing ? 'Now Playing' : 'Paused'}
                </span>
                <b key={track?.slot}>SLOT {slot}</b>
              </div>
            )}
          </div>
          <div className="track-transition-title">
            <div
              className="track-title"
              title={track?.title}
              style={{
                fontFamily: resolveFontFamily(c.titleFont),
                fontWeight: c.titleWeight,
                fontSize: c.titleSize + 'px',
                letterSpacing: c.titleLetterSpacing + 'px',
                textTransform:
                  c.titleCase === 'uppercase' ? 'uppercase' : undefined,
              }}
            >
              {track?.title || 'No song playing yet …'}
            </div>
          </div>
          {c.artist && (
            <div className="track-transition-artist">
              <div
                className="track-artist"
                style={{
                  fontFamily: resolveFontFamily(c.artistFont),
                  fontWeight: c.artistWeight,
                  fontSize: c.artistSize + 'px',
                  letterSpacing: c.artistLetterSpacing + 'px',
                  textTransform:
                    c.artistCase === 'uppercase' ? 'uppercase' : undefined,
                }}
              >
                {track?.artist || 'Every great stream needs a soundtrack.'}
              </div>
            </div>
          )}
          {c.progress && (
            <div className="track-progress" key={trackId(track)}>
              <div className="progress-rail">
                <div
                  style={{
                    width:
                      Math.min(
                        100,
                        ((track?.progress || 0) /
                          Math.max(1, track?.duration || 1)) *
                          100,
                      ) + '%',
                  }}
                />
                <i
                  style={{
                    left:
                      Math.min(
                        100,
                        ((track?.progress || 0) /
                          Math.max(1, track?.duration || 1)) *
                          100,
                      ) + '%',
                  }}
                />
              </div>
              <div className="track-times">
                <span>{time(track?.progress || 0)}</span>
                <span>{time(track?.duration || 0)}</span>
              </div>
            </div>
          )}
        </div>
        <div className="memory-controls" aria-hidden="true">
          <span>
            <Shuffle />
          </span>
          <span>
            <SkipBack />
          </span>
          <span className="memory-play">
            {playing ? (
              <Pause fill="currentColor" />
            ) : (
              <Play fill="currentColor" />
            )}
          </span>
          <span>
            <SkipForward />
          </span>
          <span className={'memory-heart' + (fav ? ' active' : '')}>
            <Heart
              className={stamping && fav ? 'heart-stamp' : undefined}
              fill="currentColor"
            />
          </span>
        </div>
      </div>
      {label && (
        <div className="memory-note" aria-hidden="true">
          <i className="memory-led" />
          <div className="memory-note-paper">
            <span>
              {label}
              <b>☺</b>
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
function time(ms: number) {
  return (
    Math.floor(ms / 60000) +
    ':' +
    String(Math.floor(ms / 1000) % 60).padStart(2, '0')
  );
}
