'use client';
// --- Album Wall (F15): gemeinsame Darstellung für OBS-Quelle und Studio-Vorschau ---
// Bühne 1920×1080 in CSS-Pixeln; die Vorschau skaliert sie per transform.
// Mockup abgesegnet 2026-10-12 („passt“): laufende Cover-Reihen, Glas-Karte
// mit Platte, dezenter Visualizer (Animation, kein Audio), optional Aura.
import { useEffect, useMemo, useState, type CSSProperties } from 'react';
import { getCoverAccent, peekCoverAccent } from './cover-accent';
import type { Track } from './overlay';
import type { WallSettings } from './album-wall-settings';
import { useStreamT } from './i18n';
import './album-wall.css';

export type WallTile = { id: string; cover: string; title: string; artist: string; status: string };

const FALLBACK_ACCENT = '#b3f47c';
const RADIUS = { square: 8, soft: 26, round: 48 } as const;
const TILE = { stage: 228, bar: 162, corner: 140 } as const;
const GAP = { stage: 26, bar: 22, corner: 0 } as const;
const SPEED = { off: 0, slow: 34, fast: 80 } as const; // px pro Sekunde
const BAR_SEEDS = [0.9, 0.55, 0.75, 0.62, 1.05, 0.48, 0.82, 0.7, 0.58, 0.95, 0.66, 0.5, 0.88, 0.72];

function fmt(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function useAccent(cover: string | undefined, fixed: string) {
  const [auto, setAuto] = useState<string | null>(() => (cover ? peekCoverAccent(cover) ?? null : null));
  useEffect(() => {
    if (fixed || !cover) return;
    let alive = true;
    const known = peekCoverAccent(cover);
    if (known !== undefined) setAuto(known);
    else void getCoverAccent(cover).then((c) => alive && setAuto(c));
    return () => {
      alive = false;
    };
  }, [cover, fixed]);
  return fixed || auto || FALLBACK_ACCENT;
}

function Row({
  tiles,
  size,
  gap,
  speed,
  reverse,
  paused,
  preview,
}: {
  tiles: WallTile[];
  size: number;
  gap: number;
  speed: number;
  reverse: boolean;
  paused: boolean;
  preview: boolean;
}) {
  // Wenige Cover: in OBS ruhig stehen lassen, ab 8 Covern endlos laufen (Liste
  // doppelt). In der Studio-Vorschau läuft die Wand immer, damit man die
  // eingestellte Geschwindigkeit sieht – dafür wird bei Bedarf wiederholt.
  if (preview && tiles.length > 0 && tiles.length < 8) {
    const out: WallTile[] = [];
    for (let i = 0; out.length < 8; i++) out.push({ ...tiles[i % tiles.length], id: tiles[i % tiles.length].id + '~' + i });
    tiles = out;
  }
  const moving = speed > 0 && tiles.length >= 8;
  const list = moving ? [...tiles, ...tiles] : tiles;
  const dur = moving ? ((tiles.length * (size + gap)) / speed).toFixed(1) + 's' : '0s';
  return (
    <div className={'aw-row' + (moving ? ' is-moving' : '')}>
      <div
        className={'aw-run' + (reverse ? ' is-rev' : '')}
        style={{ gap, animationDuration: dur, animationPlayState: paused ? 'paused' : 'running' } as CSSProperties}
      >
        {list.map((t, i) => (
          <span key={t.id + ':' + i} className="aw-tile" style={{ width: size, height: size }}>
            {t.cover ? <img src={t.cover} alt="" draggable={false} /> : <i />}
          </span>
        ))}
      </div>
    </div>
  );
}

export function AlbumWall({
  settings: s,
  track,
  plays,
  songNumber,
  preview = false,
  lang,
}: {
  /** Stream-Sprache: 'de' | 'en' | 'auto'. */
  lang?: string;
  settings: WallSettings;
  track: Track | null;
  /** Bereits gespielte Songs des laufenden Streams, neueste zuerst. */
  plays: WallTile[];
  songNumber: number;
  /** Studio-Vorschau: Bewegung immer zeigen (keine Pause, keine 8-Cover-Schwelle). */
  preview?: boolean;
}) {
  const st = useStreamT(lang);
  const accent = useAccent(track?.cover, s.accent);
  const paused = !preview && !!track && !track.playing;
  const tiles = useMemo(
    () => plays.filter((p) => !(s.hideSkipped && p.status === 'skipped')),
    [plays, s.hideSkipped],
  );
  const rotate = (k: number) => (tiles.length ? tiles.map((_, i) => tiles[(i + k * 3) % tiles.length]) : tiles);
  const size = TILE[s.layout];
  const speed = SPEED[s.speed];
  const trackKey = track ? track.id || track.title + '|' + track.artist : '';
  const pct = track && track.duration > 0 ? Math.min(100, (track.progress / track.duration) * 100) : 0;
  const vizH = s.vizStrong ? 48 : 30;

  // Aura-Farben: aktuelles und vorheriges Cover.
  const prevAccent = useAccent(s.bg === 'aura' ? tiles[0]?.cover : undefined, '');
  const auraColors = [accent, prevAccent, '#7a5cff'];

  if (!track && !tiles.length) return <div className="aw-root" />;

  return (
    <div
      className={['aw-root', 'aw-' + s.layout, paused ? 'is-paused' : '', 'aw-bg-' + s.bg].join(' ')}
      style={{ '--aw-accent': accent, '--aw-r': RADIUS[s.radius] + 'px' } as CSSProperties}
    >
      {s.bg === 'aura' && (
        <div className="aw-aura" aria-hidden="true">
          <span className="aw-blob aw-b1" style={{ background: auraColors[0] }} />
          <span className="aw-blob aw-b2" style={{ background: auraColors[2] }} />
          <span className="aw-blob aw-b3" style={{ background: auraColors[1] }} />
        </div>
      )}

      {s.layout === 'stage' && tiles.length > 0 && (
        <div className="aw-rows">
          {Array.from({ length: s.rows }, (_, k) => (
            <Row key={k} tiles={rotate(k)} size={size} gap={GAP.stage} speed={speed} reverse={k % 2 === 1} paused={paused} preview={preview} />
          ))}
        </div>
      )}

      {s.layout === 'bar' && tiles.length > 0 && (
        <div className={'aw-bar-row' + (s.vinyl ? ' has-vinyl' : '')}>
          <Row tiles={tiles} size={size} gap={GAP.bar} speed={speed} reverse={false} paused={paused} preview={preview} />
        </div>
      )}

      {s.layout === 'corner' && tiles.length > 0 && (
        <div className="aw-fan" aria-hidden="true">
          {tiles.slice(0, 5).map((t, k) => (
            <span
              key={t.id}
              className="aw-tile"
              style={{ width: size, height: size, right: k * 118, transform: `rotate(${(k % 2 ? 1 : -1) * 3}deg)`, opacity: 1 - k * 0.15 }}
            >
              {t.cover ? <img src={t.cover} alt="" draggable={false} /> : <i />}
            </span>
          ))}
        </div>
      )}

      {track && (
        <div className="aw-card">
          <span className="aw-art">
            {s.vinyl && <span className="aw-vinyl" aria-hidden="true" />}
            <span key={trackKey} className="aw-cover aw-in">
              {track.cover ? <img src={track.cover} alt="" draggable={false} /> : <i />}
            </span>
          </span>
          <span key={trackKey + ':t'} className={'aw-text aw-in' + (s.vinyl ? ' has-vinyl' : '')}>
            <span className="aw-status">
              <i className="aw-dot" />
              {paused ? st('stream.paused') : songNumber > 0 ? st('stream.wall.playingSong', { n: songNumber }) : st('stream.playing')}
            </span>
            <b className="aw-title">{track.title}</b>
            {s.artist && track.artist && <span className="aw-artist">{track.artist}</span>}
            <span className="aw-foot">
              <span className="aw-progress" title={`${fmt(track.progress)} / ${fmt(track.duration)}`}>
                <i style={{ width: pct + '%' }} />
              </span>
              {s.viz !== 'off' && (
                <span className={'aw-viz is-' + s.viz} style={{ height: vizH, opacity: s.vizStrong ? 1 : 0.7 } as CSSProperties} aria-hidden="true">
                  {BAR_SEEDS.map((d, k) => (
                    <i
                      key={k}
                      style={
                        {
                          '--aw-h': vizH + 'px',
                          animationDuration: (d * (s.vizStrong ? 0.8 : 1.1)).toFixed(2) + 's',
                          animationDelay: (-(k * 0.13)).toFixed(2) + 's',
                        } as CSSProperties
                      }
                    />
                  ))}
                </span>
              )}
            </span>
          </span>
        </div>
      )}
    </div>
  );
}
