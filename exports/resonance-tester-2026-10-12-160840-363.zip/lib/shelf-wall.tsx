'use client';
// --- StreamShelf V2/V3 (F21): Live-Regal (OBS) und Archiv (Studio) ---
// Bühne 1920×1080 CSS-Pixel; Vorschau/Archiv skalieren per transform.
// Mockup abgesegnet 2026-10-12 („nice“). Daten: gemeinsamer Song-Verlauf (F03).
import { useEffect, useMemo, useState, type CSSProperties } from 'react';
import { getCoverAccent, peekCoverAccent } from './cover-accent';
import type { Track } from './overlay';
import type { ShelfWallSettings } from './shelf-wall-settings';
import { hasKey, useStreamT, type Key } from './i18n';
import './shelf-wall.css';

export type ShelfItem = {
  id: string;
  trackId: string | null;
  title: string;
  artist: string;
  cover: string;
  startedAt: number;
  status: string;
  fave: boolean;
};

const FALLBACK = ['#e8455f', '#b3f47c', '#c8b8ff', '#ffb3c7', '#4fd18b', '#ff9f43', '#7ad7f0', '#ffd166'];
const ROW_H = { 2: 340, 3: 230, 4: 172 } as const;
// Status-Texte: stream.status.<status> (Sprache über `lang`).
type ST = (k: Key, v?: Record<string, string | number>) => string;
const statusText = (st: ST, status: string) => {
  const k = 'stream.status.' + status;
  return hasKey(k) ? st(k) : status;
};

const hash = (s: string) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
};
const pad = (n: number) => String(n).padStart(2, '0');
const clock = (t: number) => {
  const d = new Date(t);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
};
const lum = (hex: string) => {
  const m = /^#([0-9a-f]{6})$/i.exec(hex);
  if (!m) return 0;
  const n = parseInt(m[1], 16);
  return (0.2126 * ((n >> 16) & 255) + 0.7152 * ((n >> 8) & 255) + 0.0722 * (n & 255)) / 255;
};
export function spotifyLink(item: { trackId: string | null; title: string; artist: string }) {
  return item.trackId
    ? 'https://open.spotify.com/track/' + item.trackId
    : 'https://open.spotify.com/search/' + encodeURIComponent(item.title + ' ' + item.artist);
}

function useCoverColor(cover: string, seed: string) {
  const fallback = FALLBACK[hash(seed) % FALLBACK.length];
  const [c, setC] = useState(() => (cover && peekCoverAccent(cover)) || fallback);
  useEffect(() => {
    if (!cover) return;
    let alive = true;
    void getCoverAccent(cover).then((x) => alive && x && setC(x));
    return () => {
      alive = false;
    };
  }, [cover]);
  return c;
}

type Token =
  | { kind: 'cd'; item: ItemView; w: number; x: number }
  | { kind: 'divider'; label: string; w: number; key: string; x: number };
type ItemView = ShelfItem & { idx: number; face: boolean; h: number };

function Cd({
  it,
  spineW,
  isNew,
  out,
  showPop,
  artistOnSpine,
  onEnter,
  onLeave,
  newAnim,
  popAlign,
  st,
}: {
  st: ST;
  it: ItemView;
  spineW: number;
  isNew: boolean;
  out: boolean;
  showPop: boolean;
  artistOnSpine: boolean;
  onEnter?: () => void;
  onLeave?: () => void;
  newAnim: boolean;
  /** Infokarte am Rand ausrichten, damit sie nicht aus dem Regal ragt. */
  popAlign: 'start' | 'center' | 'end';
}) {
  const color = useCoverColor(it.cover, it.title + it.artist);
  const ink = lum(color) > 0.6 ? '#1d1a16' : '#ffffffeb';
  return (
    <span
      className={'ssw-cd' + (out ? ' is-out' : '') + (isNew && newAnim ? ' is-drop' : '')}
      style={{ zIndex: out ? 40 : 1 }}
      onMouseEnter={onEnter}
      onMouseLeave={onLeave}
    >
      {it.face ? (
        <span className="ssw-face" style={{ width: Math.round(it.h * 0.9), height: it.h }}>
          {it.cover ? <img src={it.cover} alt="" draggable={false} /> : <i />}
          <i className="ssw-face-gloss" />
        </span>
      ) : (
        <span
          className="ssw-spine"
          style={{ width: spineW, height: it.h, '--ssw-c': color, color: ink } as CSSProperties}
        >
          {it.cover && (
            <span className="ssw-strip" style={{ height: spineW }}>
              <img src={it.cover} alt="" draggable={false} />
            </span>
          )}
          <span className="ssw-spine-text">{artistOnSpine && it.artist ? it.artist + ' – ' + it.title : it.title}</span>
        </span>
      )}
      {isNew && <span className="ssw-new">NEU</span>}
      {showPop && (
        <span className={'ssw-pop is-' + popAlign} onMouseEnter={onEnter}>
          <span className="ssw-pop-cover">{it.cover ? <img src={it.cover} alt="" /> : <i />}</span>
          <span className="ssw-pop-text">
            <b>{it.title}</b>
            <span>{it.artist}</span>
            <small>
              {clock(it.startedAt)} · {it.fave ? st('stream.favourite') + ' · ' : ''}
              {statusText(st, it.status)}
            </small>
            <a href={spotifyLink(it)} target="_blank" rel="noreferrer">
              {st('stream.openSpotify')}
            </a>
          </span>
        </span>
      )}
    </span>
  );
}

export function ShelfWall({
  settings: s,
  plays,
  track,
  songNumber,
  mode,
  title,
  startedAt,
  endedAt,
  lang,
}: {
  /** Sprache: 'de' | 'en' | 'auto' (Stream-Sprache) – Archiv im Studio: Studio-Sprache. */
  lang?: string;
  settings: ShelfWallSettings;
  /** Songs des Streams, älteste zuerst (ohne den laufenden Song). */
  plays: ShelfItem[];
  track: Track | null;
  songNumber: number;
  /** live = OBS (Spotlight, NEU), preview = Studio-Vorschau, archive = nach dem Stream (Hover). */
  mode: 'live' | 'preview' | 'archive';
  title: string;
  startedAt: number | null;
  endedAt: number | null;
}) {
  const st = useStreamT(lang);
  const [hover, setHover] = useState<string | null>(null);
  const [spot, setSpot] = useState<string | null>(null);
  const nowColor = useCoverColor(track?.cover || '', track ? track.title + track.artist : 'none');
  const showNow = mode !== 'archive' && s.now === 'side' && !!track;
  const regalW = showNow ? 1250 : 1740;
  const rowH = ROW_H[s.rows];
  const caseH = rowH - 44;
  const spineW = s.wide ? 44 : 32;
  const items: ItemView[] = useMemo(
    () =>
      plays
        .filter((p) => !(s.hideSkipped && p.status === 'skipped'))
        .map((p, idx) => ({ ...p, idx, face: s.faves && p.fave, h: caseH - (hash(p.id) % 3) * 10 })),
    [plays, s.hideSkipped, s.faves, caseH],
  );
  const lastId = items.length ? items[items.length - 1].id : '';

  // Regal packen: Rücken/Cover nebeneinander, Trennkarte bei jeder neuen Stunde.
  const rows = useMemo(() => {
    const inner = regalW - 80;
    const out: Token[][] = [[]];
    let used = 0;
    let lastHour = -1;
    const push = (t: Token) => {
      if (used + t.w > inner && out[out.length - 1].length) {
        out.push([]);
        used = 0;
      }
      t.x = used;
      out[out.length - 1].push(t);
      used += t.w;
    };
    for (const it of items) {
      const hour = new Date(it.startedAt).getHours();
      if (s.dividers && lastHour !== -1 && hour !== lastHour)
        push({ kind: 'divider', label: st('stream.hour', { h: hour }), w: 36, key: 'd' + it.id, x: 0 });
      lastHour = hour;
      push({ kind: 'cd', item: it, w: (it.face ? Math.round(it.h * 0.9) : spineW) + 5, x: 0 });
    }
    const visible = out.filter((r) => r.length).slice(-s.rows);
    while (visible.length < s.rows) visible.push([]);
    return visible;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items, regalW, s.rows, s.dividers, spineW, lang]);

  // Spotlight (nur live/Vorschau): ab und zu rutscht eine CD heraus.
  useEffect(() => {
    if (mode === 'archive' || !s.spotlight || items.length < 2) {
      setSpot(null);
      return;
    }
    const pool = rows.flat().filter((t) => t.kind === 'cd').map((t) => (t as { item: ItemView }).item.id);
    const t = setInterval(() => {
      setSpot((cur) => (cur ? null : pool[Math.floor(Math.random() * pool.length)] || null));
    }, 3600);
    return () => clearInterval(t);
  }, [mode, s.spotlight, rows, items.length]);

  const active = hover || spot;
  const end = endedAt ?? Date.now();
  const mins = startedAt ? Math.max(0, Math.round((end - startedAt) / 60000)) : 0;

  return (
    <div
      className={'ssw-root ssw-mat-' + s.material + ' ssw-back-' + s.back + (mode === 'archive' ? ' is-archive' : '')}
      style={{ '--ssw-glow': nowColor, '--ssw-row': rowH + 'px' } as CSSProperties}
    >
      <div className="ssw-regal" style={{ width: regalW }}>
        <span className="ssw-crown" />
        <span className="ssw-post is-left" />
        <span className="ssw-post is-right" />
        <div className="ssw-head">
          <span className="ssw-neon">{title}</span>
          <span className="ssw-chips">
            <span>
              <b>{items.length}</b> {items.length === 1 ? 'CD' : 'CDs'}
            </span>
            {startedAt && (
              <span>
                {Math.floor(mins / 60)} h {pad(mins % 60)} min
              </span>
            )}
          </span>
        </div>
        {rows.map((row, r) => (
          <div key={r} className="ssw-row" style={{ height: rowH }}>
            <span className="ssw-shade" />
            {s.led && <span className="ssw-led-glow" />}
            <div className="ssw-items">
              {row.map((t) =>
                t.kind === 'divider' ? (
                  <span key={t.key} className="ssw-divider" style={{ height: Math.round(caseH * 0.7) }}>
                    <span>{t.label}</span>
                  </span>
                ) : (
                  <Cd
                    key={t.item.id}
                    it={t.item}
                    spineW={spineW}
                    isNew={mode !== 'archive' && t.item.id === lastId}
                    newAnim={mode === 'live'}
                    out={active === t.item.id}
                    showPop={active === t.item.id}
                    artistOnSpine={s.artist}
                    onEnter={() => setHover(t.item.id)}
                    onLeave={() => setHover((h) => (h === t.item.id ? null : h))}
                    popAlign={t.x < 240 ? 'start' : t.x > regalW - 80 - 300 ? 'end' : 'center'}
                    st={st}
                  />
                ),
              )}
            </div>
            <span className="ssw-board-top" />
            <span className="ssw-board" />
            {s.led && <span className="ssw-led" />}
          </div>
        ))}
        {!items.length && (
          <span className="ssw-empty">
            {mode === 'archive' ? st('stream.shelf.emptyArchive') : st('stream.shelf.emptyLive')}
          </span>
        )}
      </div>

      {showNow && track && (
        <div className="ssw-now" key={track.id || track.title}>
          <span className="ssw-now-glow" />
          <div className={'ssw-now-case' + (track.playing ? '' : ' is-paused')}>
            <span className="ssw-now-disc">
              {track.cover && <img src={track.cover} alt="" draggable={false} />}
            </span>
            <span className="ssw-now-lid">
              {track.cover ? <img src={track.cover} alt="" draggable={false} /> : <i />}
              <i className="ssw-now-hinge" />
              <i className="ssw-now-gloss" />
              <i className="ssw-now-glint" />
            </span>
          </div>
          <span className="ssw-now-board">
            <i style={{ width: (track.duration > 0 ? Math.min(100, (track.progress / track.duration) * 100) : 0) + '%' }} />
          </span>
          <div className="ssw-now-text">
            <span className="ssw-now-status">
              <i />
              {track.playing ? (songNumber > 0 ? st('stream.shelf.songNext', { n: songNumber }) : st('stream.shelf.next')) : st('stream.paused')}
            </span>
            <b>{track.title}</b>
            <span>{track.artist}</span>
          </div>
        </div>
      )}
    </div>
  );
}
