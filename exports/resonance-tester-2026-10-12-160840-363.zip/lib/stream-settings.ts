// F20: Stream-Sprache (Texte in den OBS-Quellen) je Besitzer.
// Eigene Tabelle (Migration 0012), damit Stile/Looks sie nie überschreiben.
// auto = Sprache der OBS-Browserquelle (OBS nutzt seine Oberflächensprache).

export const STREAM_LANGS = ['auto', 'de', 'en'] as const;
export type StreamLang = (typeof STREAM_LANGS)[number];

export function cleanStreamLang(v: unknown): StreamLang {
  return (STREAM_LANGS as readonly string[]).includes(v as string) ? (v as StreamLang) : 'auto';
}

/** Gespeicherte Stream-Sprache; ohne Tabelle (vor dem Neustart) → 'auto'. */
export async function getStreamLang(db: D1Database, owner: string): Promise<StreamLang> {
  try {
    const row = await db.prepare('SELECT lang FROM stream_settings WHERE owner=?').bind(owner).first<{ lang: string }>();
    return cleanStreamLang(row?.lang);
  } catch {
    return 'auto';
  }
}

export async function saveStreamLang(db: D1Database, owner: string, lang: unknown): Promise<StreamLang> {
  const value = cleanStreamLang(lang);
  await db
    .prepare(
      `INSERT INTO stream_settings (owner, lang, updated_at) VALUES (?,?,?)
       ON CONFLICT(owner) DO UPDATE SET lang=excluded.lang, updated_at=excluded.updated_at`,
    )
    .bind(owner, value, Date.now())
    .run();
  return value;
}
