// --- Look-Codes: Looks als kurzen Text teilen (Discord, Chat, Notiz) ---
// Format: "RSN1-" + base64url(deflate-raw(JSON { v:1, n:name, c:diff }))
// diff = nur Felder, die vom Standard abweichen (hält Codes kurz).
// Der Server prüft importierte Configs ohnehin mit cleanConfig().
import { defaults, type Config } from './overlay';

const PREFIX = 'RSN1-';
const MAX_CODE = 24000;
const MAX_JSON = 200000;

function toBase64Url(bytes: Uint8Array) {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function fromBase64Url(text: string) {
  const b64 = text.replace(/-/g, '+').replace(/_/g, '/');
  const bin = atob(b64 + '='.repeat((4 - (b64.length % 4)) % 4));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function pipe(bytes: Uint8Array, stream: CompressionStream | DecompressionStream) {
  const res = new Response(new Blob([bytes as BlobPart]).stream().pipeThrough(stream));
  return new Uint8Array(await res.arrayBuffer());
}

/** Eigene Schriften sind nicht übertragbar → beim Teilen weglassen. */
export function portableDiff(config: Config) {
  const diff: Record<string, unknown> = {};
  const base = defaults as unknown as Record<string, unknown>;
  for (const [k, v] of Object.entries(config)) {
    if (JSON.stringify(v) === JSON.stringify(base[k])) continue;
    if (typeof v === 'string' && v.startsWith('custom:')) continue;
    diff[k] = v;
  }
  return diff;
}

export async function encodeLookCode(name: string, config: Config) {
  const json = JSON.stringify({ v: 1, n: name.slice(0, 60), c: portableDiff(config) });
  const packed = await pipe(new TextEncoder().encode(json), new CompressionStream('deflate-raw'));
  return PREFIX + toBase64Url(packed);
}

export type DecodedLook = { name: string; config: Config };

/** Fehler mit Code, damit das Studio die Meldung übersetzen kann (F20). */
export class LookCodeError extends Error {
  constructor(
    public code: 'notCode' | 'tooLong' | 'damaged' | 'newer',
    message: string,
  ) {
    super(message);
  }
}

export async function decodeLookCode(code: string): Promise<DecodedLook> {
  const clean = code.trim().replace(/\s+/g, '');
  const m = /^RSN1-([A-Za-z0-9_-]+)$/.exec(clean);
  if (!m) throw new LookCodeError('notCode', 'Das ist kein Resonance-Look-Code (beginnt mit „RSN1-“).');
  if (m[1].length > MAX_CODE) throw new LookCodeError('tooLong', 'Der Code ist zu lang.');
  let text: string;
  try {
    const raw = await pipe(fromBase64Url(m[1]), new DecompressionStream('deflate-raw'));
    if (raw.length > MAX_JSON) throw new Error('zu groß');
    text = new TextDecoder().decode(raw);
  } catch {
    throw new LookCodeError('damaged', 'Der Code ist beschädigt oder unvollständig kopiert.');
  }
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    throw new LookCodeError('damaged', 'Der Code ist beschädigt.');
  }
  const d = data as { v?: unknown; n?: unknown; c?: unknown };
  if (!d || d.v !== 1 || typeof d.c !== 'object' || d.c === null || Array.isArray(d.c))
    throw new LookCodeError('newer', 'Dieser Code stammt aus einer neueren Resonance-Version.');
  const name = typeof d.n === 'string' && d.n.trim() ? d.n.trim().slice(0, 60) : 'Geteilter Look';
  // Nur bekannte Felder übernehmen; Feinprüfung macht der Server beim Speichern.
  const base = defaults as unknown as Record<string, unknown>;
  const config: Record<string, unknown> = { ...base };
  for (const [k, v] of Object.entries(d.c as Record<string, unknown>))
    if (k in base && typeof v === typeof base[k]) config[k] = v;
  return { name, config: config as unknown as Config };
}
