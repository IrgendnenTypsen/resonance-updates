-- F20 Mehrsprachigkeit: Sprache der Texte im Stream (OBS) je Besitzer. Rein additiv.
CREATE TABLE stream_settings (
  owner TEXT PRIMARY KEY,
  lang TEXT NOT NULL DEFAULT 'auto',
  updated_at INTEGER NOT NULL
);
