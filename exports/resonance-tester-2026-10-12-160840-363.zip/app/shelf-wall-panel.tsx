'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Switch } from '@/components/ui/switch';
import { ShelfWall, type ShelfItem } from '@/lib/shelf-wall';
import { SHELF_WALL_DEFAULTS, type ShelfWallSettings } from '@/lib/shelf-wall-settings';
import { GALLERY_TRACKS } from '@/lib/gallery-demo';
import { estimatedProgress, type Track } from '@/lib/overlay';
import { type Key, serverMsg, useStreamT, useT } from '@/lib/i18n';

// F21 StreamShelf V2 – Live-Regal: Einstellungen + Vorschau im Tab „Verlauf“.

type ShelfResponse = {
  error?: string;
  settings: ShelfWallSettings;
  session: { startedAt: number; endedAt: number | null; trackCount: number; live: boolean } | null;
  track: Track | null;
  plays: ShelfItem[];
  lang?: string;
};

// Beispiel, solange der Stream noch leer ist (erfundene Demo-Songs).
const DEMO_START = Date.now() - 95 * 60000;
const DEMO_ITEMS: ShelfItem[] = Array.from({ length: 22 }, (_, i) => {
  const t = GALLERY_TRACKS[i % GALLERY_TRACKS.length];
  return {
    id: 'demo-' + i,
    trackId: null,
    title: t.title,
    artist: t.artist,
    cover: t.cover,
    startedAt: DEMO_START + i * 4 * 60000,
    status: i % 7 === 3 ? 'skipped' : 'completed',
    fave: i % 6 === 2,
  };
});

type Opt = [string | number | boolean, Key];
const GROUPS: { key: keyof ShelfWallSettings; label: Key; opts: Opt[] }[] = [
  { key: 'material', label: 'shelf.g.material', opts: [['wood', 'shelf.o.wood'], ['glass', 'shelf.o.glass'], ['metal', 'shelf.o.metal']] },
  { key: 'back', label: 'shelf.g.back', opts: [['none', 'shelf.o.none'], ['dark', 'shelf.o.dark'], ['wood', 'shelf.o.wood']] },
  { key: 'rows', label: 'shelf.g.rows', opts: [[2, '2' as Key], [3, '3' as Key], [4, '4' as Key]] },
  { key: 'wide', label: 'shelf.g.spines', opts: [[false, 'shelf.o.narrow'], [true, 'shelf.o.wide']] },
  { key: 'now', label: 'shelf.g.now', opts: [['side', 'shelf.o.side'], ['off', 'shelf.o.off']] },
];
const TOGGLES: { key: 'spotlight' | 'led' | 'faves' | 'dividers' | 'artist' | 'hideSkipped'; label: Key }[] = [
  { key: 'spotlight', label: 'shelf.t.spotlight' },
  { key: 'led', label: 'shelf.t.led' },
  { key: 'faves', label: 'shelf.t.faves' },
  { key: 'dividers', label: 'shelf.t.dividers' },
  { key: 'artist', label: 'shelf.t.artist' },
  { key: 'hideSkipped', label: 'shelf.t.hideSkipped' },
];
const label = (t: (k: Key) => string, k: Key) => (/^\d+$/.test(k) ? k : t(k));

export default function ShelfWallPanel({ shelfUrl, onCopy }: { shelfUrl: string; onCopy: (text: string) => void }) {
  const { t } = useT();
  const [settings, setSettings] = useState<ShelfWallSettings>(SHELF_WALL_DEFAULTS);
  const [data, setData] = useState<ShelfResponse | null>(null);
  const st = useStreamT(data?.lang);
  const [track, setTrack] = useState<Track | null>(null);
  const [note, setNote] = useState('');
  const [copied, setCopied] = useState(false);
  const [scale, setScale] = useState(0.4);
  const stageRef = useRef<HTMLDivElement>(null);
  const lastSave = useRef(0);
  const dirty = useRef(false);

  const load = useCallback(async () => {
    const started = Date.now();
    try {
      const r = await fetch('/api/shelf', { cache: 'no-store' });
      const d = (await r.json()) as ShelfResponse;
      if (!r.ok) throw new Error(d.error);
      if (!dirty.current && started > lastSave.current) setSettings(d.settings);
      setData(d);
      setTrack(d.track ? { ...d.track, fetchedAt: Date.now() } : null);
    } catch {
      setData((x) => x ?? { settings: SHELF_WALL_DEFAULTS, session: null, track: null, plays: [] });
    }
  }, []);

  useEffect(() => {
    void load();
    const t = setInterval(() => document.visibilityState === 'visible' && void load(), 6000);
    const tick = setInterval(
      () => setTrack((x) => (x?.playing ? { ...x, progress: estimatedProgress(x), fetchedAt: Date.now() } : x)),
      1000,
    );
    return () => {
      clearInterval(t);
      clearInterval(tick);
    };
  }, [load]);

  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setScale(el.clientWidth / 1920));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const save = async (next: ShelfWallSettings) => {
    setSettings(next);
    dirty.current = true;
    lastSave.current = Date.now();
    setNote('');
    try {
      const r = await fetch('/api/shelf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: next }),
      });
      const d = (await r.json()) as { error?: string; settings?: ShelfWallSettings };
      if (!r.ok) throw new Error(d.error || t('source.saveFailed'));
      if (d.settings) setSettings(d.settings);
    } catch (e) {
      setNote(e instanceof Error ? e.message : t('source.saveFailed'));
    } finally {
      dirty.current = false;
    }
  };
  const set = <K extends keyof ShelfWallSettings>(key: K, value: ShelfWallSettings[K]) => void save({ ...settings, [key]: value });

  const isDemo = !!data && !data.plays.length;
  const shownTrack = track ?? (isDemo ? { ...GALLERY_TRACKS[2], playing: true } : null);

  return (
    <section className="awp" aria-label={t('shelf.title')}>
      <div className="awp-head">
        <div>
          <h2>{t('shelf.title')}</h2>
          <p>{t('shelf.intro')}</p>
        </div>
        <div className="awp-link">
          <button
            type="button"
            className="hv-btn is-strong"
            disabled={!shelfUrl}
            onClick={() => {
              onCopy(shelfUrl);
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            }}
          >
            {copied ? t('source.copied') : t('source.copyLink')}
          </button>
          {shelfUrl && (
            <a className="hv-btn" href={shelfUrl} target="_blank" rel="noreferrer">
              {t('source.open')}
            </a>
          )}
        </div>
      </div>
      <div className="awp-body">
        <div className="awp-preview">
          <div ref={stageRef} className="awp-stage">
            <div className="awp-scaler is-interactive" style={{ transform: `scale(${scale})` }}>
              <ShelfWall
                settings={settings}
                plays={isDemo ? DEMO_ITEMS : data?.plays ?? []}
                track={shownTrack}
                songNumber={isDemo ? 23 : data?.session?.trackCount ?? 0}
                mode="preview"
                title={st('stream.shelf.title')}
                lang={data?.lang}
                startedAt={isDemo ? DEMO_START : data?.session?.startedAt ?? null}
                endedAt={null}
              />
            </div>
          </div>
          <p className="awp-hint">
            {isDemo ? t('shelf.hint.demo') : t('shelf.hint.live')}
          </p>
        </div>
        <div className="awp-settings">
          {GROUPS.map((g) => (
            <div key={g.key} className="awp-group">
              <span>{t(g.label)}</span>
              <div className="hv-seg awp-seg" role="radiogroup" aria-label={t(g.label)}>
                {g.opts.map(([v, l]) => (
                  <button
                    key={String(v)}
                    type="button"
                    role="radio"
                    aria-checked={settings[g.key] === v}
                    className={settings[g.key] === v ? 'is-on' : ''}
                    onClick={() => set(g.key, v as never)}
                  >
                    {label(t, l)}
                  </button>
                ))}
              </div>
            </div>
          ))}
          {TOGGLES.map((tg) => (
            <label key={tg.key} className="awp-toggle">
              {t(tg.label)}
              <Switch checked={settings[tg.key]} onCheckedChange={(on) => set(tg.key, on)} />
            </label>
          ))}
          {note && <p className="hv-note" role="status">{serverMsg(note)}</p>}
        </div>
      </div>
    </section>
  );
}
