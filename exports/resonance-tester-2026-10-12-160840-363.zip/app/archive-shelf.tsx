'use client';
import { useEffect, useRef, useState } from 'react';
import { ShelfWall, type ShelfItem } from '@/lib/shelf-wall';
import { SHELF_WALL_DEFAULTS, type ShelfWallSettings } from '@/lib/shelf-wall-settings';
import { useT } from '@/lib/i18n';

// F21 StreamShelf V3 – Archiv: das Regal eines Streams nach dem Stream,
// mit Hover-Karten (Cover, Titel, Interpret, Uhrzeit, Spotify-Link).
type ShelfResponse = {
  error?: string;
  settings: ShelfWallSettings;
  session: { startedAt: number; endedAt: number | null; trackCount: number; live: boolean } | null;
  plays: ShelfItem[];
};

export default function ArchiveShelf({ sessionId, title }: { sessionId: string; title: string }) {
  const { t, locale } = useT();
  const [data, setData] = useState<ShelfResponse | null>(null);
  const [error, setError] = useState('');
  const [scale, setScale] = useState(0.4);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let alive = true;
    setData(null);
    setError('');
    fetch('/api/shelf?session=' + encodeURIComponent(sessionId), { cache: 'no-store' })
      .then((r) => r.json().then((d) => ({ ok: r.ok, d: d as ShelfResponse })))
      .then(({ ok, d }) => {
        if (!alive) return;
        if (!ok) throw new Error(d.error);
        setData(d);
      })
      .catch(() => alive && setError('error'));
    return () => {
      alive = false;
    };
  }, [sessionId]);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setScale(el.clientWidth / 1920));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  return (
    <div className="hv-archive">
      <div ref={ref} className="awp-stage hv-archive-stage">
        <div className="awp-scaler is-interactive" style={{ transform: `scale(${scale})` }}>
          {data && (
            <ShelfWall
              settings={{ ...SHELF_WALL_DEFAULTS, ...data.settings, now: 'off', spotlight: false }}
              plays={data.plays}
              track={null}
              songNumber={data.session?.trackCount ?? 0}
              mode="archive"
              lang={locale}
              title={title}
              startedAt={data.session?.startedAt ?? null}
              endedAt={data.session?.live ? null : data.session?.endedAt ?? null}
            />
          )}
        </div>
      </div>
      <p className="awp-hint">
        {error ? t('shelf.archive.error') : data ? t('shelf.archive.hint') : t('shelf.archive.loading')}
      </p>
    </div>
  );
}
