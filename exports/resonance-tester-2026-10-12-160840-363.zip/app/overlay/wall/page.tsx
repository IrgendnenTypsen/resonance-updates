'use client';
import { useEffect, useRef, useState } from 'react';
import { AlbumWall, type WallTile } from '@/lib/album-wall';
import type { WallSettings } from '@/lib/album-wall-settings';
import { estimatedProgress, type Track } from '@/lib/overlay';
import { hasKey, useStreamT } from '@/lib/i18n';

// F15 Album Wall – eigene OBS-Browserquelle (1920 × 1080, transparent).
// Link: /overlay/wall#<overlay-key> (wie das normale Overlay).
type WallResponse = {
  error?: string;
  settings: WallSettings;
  track: Track | null;
  retryAfter?: number;
  plays: WallTile[];
  songNumber: number;
  lang?: string;
};

export default function AlbumWallSource() {
  const [settings, setSettings] = useState<WallSettings | null>(null);
  const [track, setTrack] = useState<Track | null>(null);
  const [plays, setPlays] = useState<WallTile[]>([]);
  const [songNumber, setSongNumber] = useState(0);
  const [notice, setNotice] = useState('');
  const [lang, setLang] = useState<string | undefined>(undefined);
  const st = useStreamT(lang);
  const playsKey = useRef('');

  useEffect(() => {
    document.body.classList.add('obs-page', 'allow-motion');
    document.documentElement.style.background = 'transparent';
    return () => {
      document.body.classList.remove('obs-page', 'allow-motion');
      document.documentElement.style.background = '';
    };
  }, []);

  useEffect(() => {
    const key = location.hash.slice(1);
    if (!key) {
      setNotice('stream.notice.openWall');
      return;
    }
    let stopped = false;
    let timeout: ReturnType<typeof setTimeout> | undefined;
    let lastGood = 0;
    async function poll() {
      let wait = 5000;
      try {
        const r = await fetch('/api/wall', { headers: { Authorization: 'Bearer ' + key }, cache: 'no-store' });
        const d = (await r.json()) as WallResponse;
        if (stopped) return;
        if (r.status === 401) {
          setNotice('stream.notice.invalidWall');
          setTrack(null);
          return;
        }
        if (!r.ok) throw new Error(d.error);
        setSettings(d.settings);
        setLang(d.lang);
        setTrack(d.track ? { ...d.track, fetchedAt: Date.now() } : null);
        const k = d.plays.map((p) => p.id).join(',');
        if (k !== playsKey.current) {
          playsKey.current = k;
          setPlays(d.plays);
        }
        setSongNumber(d.songNumber);
        setNotice('');
        lastGood = Date.now();
        wait = Math.max(5000, (d.retryAfter || 0) * 1000);
      } catch {
        if (!stopped && Date.now() - lastGood > 15000) setTrack(null);
        wait = 10000;
      }
      if (!stopped) timeout = setTimeout(poll, wait);
    }
    void poll();
    const tick = setInterval(
      () =>
        setTrack((t) => (t?.playing ? { ...t, progress: estimatedProgress(t), fetchedAt: Date.now() } : t)),
      1000,
    );
    return () => {
      stopped = true;
      if (timeout) clearTimeout(timeout);
      clearInterval(tick);
    };
  }, []);

  return (
    <>
      {notice && <div className="obs-notice">{hasKey(notice) ? st(notice) : notice}</div>}
      {settings && <AlbumWall settings={settings} track={track} plays={plays} songNumber={songNumber} lang={lang} />}
    </>
  );
}
