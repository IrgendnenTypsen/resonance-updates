'use client';
import { useEffect, useRef, useState } from 'react';
import { ShelfWall, type ShelfItem } from '@/lib/shelf-wall';
import type { ShelfWallSettings } from '@/lib/shelf-wall-settings';
import { estimatedProgress, type Track } from '@/lib/overlay';
import { hasKey, useStreamT } from '@/lib/i18n';

// F21 StreamShelf V2 – Live-Regal als eigene OBS-Browserquelle
// (1920 × 1080, transparent). Link: /overlay/shelf#<overlay-key>.
type ShelfResponse = {
  error?: string;
  settings: ShelfWallSettings;
  session: { startedAt: number; endedAt: number | null; trackCount: number; live: boolean } | null;
  track: Track | null;
  plays: ShelfItem[];
  lang?: string;
};

export default function ShelfSource() {
  const [data, setData] = useState<ShelfResponse | null>(null);
  const [track, setTrack] = useState<Track | null>(null);
  const [notice, setNotice] = useState('');
  const st = useStreamT(data?.lang);
  const playsKey = useRef('');
  const [plays, setPlays] = useState<ShelfItem[]>([]);

  useEffect(() => {
    document.body.classList.add('obs-page', 'allow-motion');
    document.documentElement.style.background = 'transparent';
    return () => {
      document.body.classList.remove('obs-page', 'allow-motion');
      document.documentElement.style.background = '';
    };
  }, []);

  useEffect(() => {
    const key = location.hash.slice(1);
    if (!key) {
      setNotice('stream.notice.openShelf');
      return;
    }
    let stopped = false;
    let timeout: ReturnType<typeof setTimeout> | undefined;
    let lastGood = 0;
    async function poll() {
      let wait = 5000;
      try {
        const r = await fetch('/api/shelf', { headers: { Authorization: 'Bearer ' + key }, cache: 'no-store' });
        const d = (await r.json()) as ShelfResponse;
        if (stopped) return;
        if (r.status === 401) {
          setNotice('stream.notice.invalidShelf');
          return;
        }
        if (!r.ok) throw new Error(d.error);
        setData(d);
        setTrack(d.track ? { ...d.track, fetchedAt: Date.now() } : null);
        const k = d.plays.map((p) => p.id + (p.fave ? '*' : '')).join(',');
        if (k !== playsKey.current) {
          playsKey.current = k;
          setPlays(d.plays);
        }
        setNotice('');
        lastGood = Date.now();
      } catch {
        if (!stopped && Date.now() - lastGood > 15000) setTrack(null);
        wait = 10000;
      }
      if (!stopped) timeout = setTimeout(poll, wait);
    }
    void poll();
    const tick = setInterval(
      () => setTrack((t) => (t?.playing ? { ...t, progress: estimatedProgress(t), fetchedAt: Date.now() } : t)),
      1000,
    );
    return () => {
      stopped = true;
      if (timeout) clearTimeout(timeout);
      clearInterval(tick);
    };
  }, []);

  return (
    <>
      {notice && <div className="obs-notice">{hasKey(notice) ? st(notice) : notice}</div>}
      {data && (
        <ShelfWall
          settings={data.settings}
          plays={plays}
          track={track}
          songNumber={data.session?.trackCount ?? 0}
          mode="live"
          title={st('stream.shelf.title')}
          lang={data.lang}
          startedAt={data.session?.startedAt ?? null}
          endedAt={null}
        />
      )}
    </>
  );
}
