'use client';
import { useEffect } from 'react';
import { Overlay } from '@/lib/overlay';
import { useOverlayFeed } from './use-overlay-feed';
import { hasKey, useStreamT } from '@/lib/i18n';

export default function OBS() {
  const { config, track, notice, lang } = useOverlayFeed();
  const st = useStreamT(lang);

  useEffect(() => {
    document.body.classList.add('obs-page', 'allow-motion');
    document.documentElement.style.background = 'transparent';
    return () => {
      document.body.classList.remove('obs-page', 'allow-motion');
      document.documentElement.style.background = '';
    };
  }, []);
  return (
    <>
      {notice && <div className="obs-notice">{hasKey(notice) ? st(notice) : notice}</div>}
      <div className="obs-canvas">
        {config && <Overlay config={config} track={track} lang={lang} />}
      </div>
    </>
  );
}
