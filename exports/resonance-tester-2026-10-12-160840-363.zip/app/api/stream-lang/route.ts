import { csrf, db, getStudio, json } from '@/lib/server';
import { getStreamLang, saveStreamLang } from '@/lib/stream-settings';

// F20: Stream-Sprache (Texte in den OBS-Quellen).
// GET  /api/stream-lang → { lang }   (Studio)
// POST /api/stream-lang { lang }    (Studio, csrf)
export async function GET(req: Request) {
  try {
    const row = await getStudio(req);
    if (!row) return json({ error: 'Studio nicht gefunden.' }, 401);
    return json({ lang: await getStreamLang(db(), row.owner) });
  } catch {
    return json({ lang: 'auto' });
  }
}

export async function POST(req: Request) {
  try {
    csrf(req);
    const row = await getStudio(req);
    if (!row) return json({ error: 'Studio nicht gefunden.' }, 401);
    const body = (await req.json()) as { lang?: unknown };
    return json({ ok: true, lang: await saveStreamLang(db(), row.owner, body.lang) });
  } catch (e) {
    const msg = e instanceof Error ? e.message : '';
    if (/no such table/i.test(msg)) return json({ error: 'Bitte Resonance einmal neu starten (Datenbank-Update).' }, 409);
    return json({ error: 'Einstellungen konnten nicht gespeichert werden.' }, 400);
  }
}
