'use client';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Switch } from '@/components/ui/switch';
import AlbumWallPanel from './album-wall-panel';
import ArchiveShelf from './archive-shelf';
import ShelfWallPanel from './shelf-wall-panel';
import type { HistoryPlayView, HistorySessionView } from '@/lib/track-history';
import { serverMsg, useT } from '@/lib/i18n';

// F03 Track History – Studio-Tab „Verlauf“ (Mockup abgesegnet 2026-10-12).
// F20: erster übersetzter Studio-Bereich (useT, Deutsch/Englisch).

type Overview = {
  sessions: HistorySessionView[];
  current: { session: HistorySessionView; plays: HistoryPlayView[] } | null;
  recording: boolean;
  pending?: boolean;
  error?: string;
};

const pad = (n: number) => String(n).padStart(2, '0');
/** 3:07 bzw. 1:02:07 */
function stamp(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h ? `${h}:${pad(m)}:${pad(s % 60)}` : `${m}:${pad(s % 60)}`;
}
/** 34 min bzw. 1 h 22 min */
function span(ms: number) {
  const min = Math.max(0, Math.round(ms / 60000));
  if (min < 60) return `${min} min`;
  return `${Math.floor(min / 60)} h ${pad(min % 60)} min`;
}
type T = ReturnType<typeof useT>;
function dayLabel(i: T, t: number) {
  const d = new Date(t);
  const today = new Date();
  const start = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((start(today) - start(d)) / 86400000);
  if (diff === 0) return i.t('history.today');
  if (diff === 1) return i.t('history.yesterday');
  if (diff < 7) return i.fmt.weekday(t);
  return i.fmt.dateShort(t);
}
const sessionEnd = (s: HistorySessionView) => (s.live ? Date.now() : (s.endedAt ?? s.lastSeenAt));

function trackList(session: HistorySessionView, plays: HistoryPlayView[]) {
  return plays
    .filter((p) => p.status !== 'skipped')
    .map((p) => `${stamp(p.startedAt - session.startedAt)} ${p.title}${p.artist ? ' – ' + p.artist : ''}`)
    .join('\n');
}

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  }
}

function Cover({ src, className }: { src: string; className: string }) {
  const [broken, setBroken] = useState(false);
  return src && !broken ? (
    <img className={className} src={src} alt="" loading="lazy" onError={() => setBroken(true)} />
  ) : (
    <span className={className + ' hv-cover-empty'} aria-hidden="true" />
  );
}

export default function HistoryView({
  connected,
  wallUrl,
  shelfUrl,
  onCopy,
}: {
  connected: boolean;
  /** OBS-Link der Album Wall ('' solange der Overlay-Key fehlt). */
  wallUrl: string;
  /** OBS-Link des StreamShelf-Regals ('' solange der Overlay-Key fehlt). */
  shelfUrl: string;
  onCopy: (text: string) => void;
}) {
  const i = useT();
  const { t } = i;
  const songs = (n: number) => i.tn('history.songs', n);
  const [data, setData] = useState<Overview | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [plays, setPlays] = useState<HistoryPlayView[] | null>(null);
  const [mode, setMode] = useState<'list' | 'wall' | 'shelf'>('list');
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState('');
  const [copied, setCopied] = useState(false);
  const selectedRef = useRef<string | null>(null);
  selectedRef.current = selected;

  const load = useCallback(async () => {
    try {
      const r = await fetch('/api/history', { cache: 'no-store' });
      const d = (await r.json()) as Overview;
      if (!r.ok) throw new Error(d.error || t('history.err.load'));
      setData(d);
      const sel = selectedRef.current;
      if (!sel || sel === d.current?.session.id) setPlays(d.current?.plays ?? []);
      else if (!d.sessions.some((s) => s.id === sel)) setSelected(null);
    } catch (e) {
      setNote(e instanceof Error ? e.message : t('history.err.load'));
    }
  }, []);

  useEffect(() => {
    void load();
    const t = setInterval(() => {
      if (document.visibilityState === 'visible') void load();
    }, 10000);
    return () => clearInterval(t);
  }, [load]);

  const pick = async (id: string) => {
    setSelected(id);
    setCopied(false);
    if (id === data?.current?.session.id) {
      setPlays(data.current.plays);
      return;
    }
    setPlays(null);
    try {
      const r = await fetch('/api/history?session=' + encodeURIComponent(id), { cache: 'no-store' });
      const d = (await r.json()) as { plays?: HistoryPlayView[]; error?: string };
      if (selectedRef.current === id) setPlays(d.plays ?? []);
    } catch {
      setNote(t('history.err.songs'));
    }
  };

  const post = async (body: object) => {
    setBusy(true);
    setNote('');
    try {
      const r = await fetch('/api/history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const d = (await r.json()) as { error?: string };
      if (!r.ok) throw new Error(d.error || t('history.err.generic'));
      await load();
    } catch (e) {
      setNote(e instanceof Error ? e.message : t('history.err.generic'));
    } finally {
      setBusy(false);
    }
  };

  const sessions = data?.sessions ?? [];
  const session = sessions.find((s) => s.id === (selected ?? data?.current?.session.id)) ?? null;
  const list = plays ?? [];
  const stats = useMemo(() => {
    const c = { completed: 0, partial: 0, skipped: 0, listened: 0 };
    for (const p of list) {
      if (p.status !== 'playing') c[p.status] += 1;
      c.listened += p.listenedMs;
    }
    return c;
  }, [list]);

  const copy = async () => {
    if (!session) return;
    const ok = await copyText(trackList(session, list));
    setCopied(ok);
    if (!ok) setNote(t('history.err.copy'));
  };

  return (
    <div className="v2-page hv-page">
      <div className="v2-page-head">
        <div>
          <h1>
            {t('history.title')}<span>.</span>
          </h1>
          <p>{t('history.subtitle')}</p>
        </div>
      </div>

      <div className="hv-layout">
        <aside className="hv-sessions" aria-label={t('history.streams')}>
          <div className="hv-sessions-head">
            <b>{t('history.streams')}</b>
            <label className="hv-record">
              {t('history.record')}
              <Switch
                checked={data?.recording ?? true}
                disabled={busy || !data || data.pending}
                onCheckedChange={(on) => void post({ action: 'record', on })}
                aria-label={t('history.recordAria')}
              />
            </label>
          </div>
          {sessions.map((s) => {
            const covers = s.covers;
            return (
              <button
                key={s.id}
                type="button"
                className={'hv-session' + (s.id === session?.id ? ' is-on' : '')}
                aria-current={s.id === session?.id ? 'true' : undefined}
                onClick={() => void pick(s.id)}
              >
                <span className="hv-mosaic" aria-hidden="true">
                  {[0, 1, 2, 3].map((i) =>
                    covers[i] ? <img key={i} src={covers[i]} alt="" loading="lazy" /> : <i key={i} />,
                  )}
                </span>
                <span className="hv-session-text">
                  <b>
                    {dayLabel(i, s.startedAt)}
                    {s.live && <em className="hv-live">LIVE</em>}
                  </b>
                  <span>
                    {s.live ? t('history.since', { time: i.fmt.time(s.startedAt) }) : i.fmt.dateShort(s.startedAt)}
                    {' · '}
                    {songs(s.trackCount)} · {span(sessionEnd(s) - s.startedAt)}
                  </span>
                </span>
              </button>
            );
          })}
          {data && !sessions.length && (
            <p className="hv-empty-side">{t('history.noStreams')}</p>
          )}
          <p className="hv-privacy">{t('history.privacy')}</p>
        </aside>

        <section className="hv-main" aria-label={t('history.songsAria')}>
          {!data ? (
            <p className="hv-empty">{t('history.loading')}</p>
          ) : data.pending ? (
            <p className="hv-empty">{t('history.pending')}</p>
          ) : !session ? (
            <p className="hv-empty">
              {!connected
                ? t('history.connectFirst')
                : data.recording
                  ? t('history.nothingYet')
                  : t('history.recordingOff')}
            </p>
          ) : (
            <>
              <div className="hv-head">
                <div className="hv-head-text">
                  <span className="hv-kicker">{session.live ? t('history.liveNow') : t('history.ended')}</span>
                  <h2>{t('history.streamOf', { date: i.fmt.dateLong(session.startedAt) })}</h2>
                  <span className="hv-meta">
                    {i.fmt.time(session.startedAt)} – {session.live ? t('history.now') : i.fmt.time(sessionEnd(session))} ·{' '}
                    {songs(session.trackCount)}
                  </span>
                </div>
                <div className="hv-actions">
                  <div className="hv-seg" role="tablist" aria-label={t('history.view')}>
                    <button type="button" role="tab" aria-selected={mode === 'list'} className={mode === 'list' ? 'is-on' : ''} onClick={() => setMode('list')}>
                      {t('history.view.list')}
                    </button>
                    <button type="button" role="tab" aria-selected={mode === 'wall'} className={mode === 'wall' ? 'is-on' : ''} onClick={() => setMode('wall')}>
                      {t('history.view.cover')}
                    </button>
                    <button type="button" role="tab" aria-selected={mode === 'shelf'} className={mode === 'shelf' ? 'is-on' : ''} onClick={() => setMode('shelf')}>
                      {t('history.view.shelf')}
                    </button>
                  </div>
                  <button type="button" className="hv-btn" onClick={() => void copy()} disabled={!list.length}>
                    {copied ? t('history.copied') : t('history.copy')}
                  </button>
                  {session.live && (
                    <button type="button" className="hv-btn is-strong" disabled={busy} onClick={() => void post({ action: 'end' })}>
                      {t('history.endStream')}
                    </button>
                  )}
                </div>
              </div>

              <div className="hv-stats">
                <span><b>{stats.completed}</b> {t('history.stat.completed')}</span>
                <span><b>{stats.partial}</b> {t('history.stat.partial')}</span>
                <span><b>{stats.skipped}</b> {t('history.stat.skipped')}</span>
                <span><b>{span(stats.listened)}</b> {t('history.stat.listened')}</span>
              </div>

              {plays === null ? (
                <p className="hv-empty">{t('history.loadingSongs')}</p>
              ) : mode === 'shelf' ? (
                <ArchiveShelf
                  sessionId={session.id}
                  title={session.live ? t('history.todayInStream') : `${i.fmt.weekday(session.startedAt)}, ${i.fmt.dateShort(session.startedAt)}`}
                />
              ) : mode === 'list' ? (
                <div className="hv-table" role="table" aria-label={t('history.songsTable')}>
                  <div className="hv-row hv-row-head" role="row">
                    <span role="columnheader">#</span>
                    <span role="columnheader" aria-label={t('history.col.cover')} />
                    <span role="columnheader">{t('history.col.song')}</span>
                    <span role="columnheader">{t('history.col.inStream')}</span>
                    <span role="columnheader">{t('history.col.listened')}</span>
                    <span role="columnheader">{t('history.col.status')}</span>
                  </div>
                  {list.map((p, idx) => {
                    const d = p.durationMs || 1;
                    const from = Math.min(100, (p.observedFromMs / d) * 100);
                    const w = Math.min(100 - from, (p.listenedMs / d) * 100);
                    const pct = Math.round((p.listenedMs / d) * 100);
                    const listen =
                      p.status === 'playing'
                        ? t('history.listen.playing')
                        : pct >= 95
                          ? t('history.listen.complete')
                          : t('history.listen.pct', { pct }) +
                            (p.observedFromMs > 15000 ? t('history.listen.from', { time: stamp(p.observedFromMs) }) : '');
                    return (
                      <div key={p.id} className={'hv-row is-' + p.status} role="row">
                        <span className="hv-n" role="cell">{idx + 1}</span>
                        <span role="cell"><Cover src={p.cover} className="hv-cover" /></span>
                        <span className="hv-song" role="cell">
                          <b title={p.title}>{p.title}</b>
                          <span title={p.artist}>{p.artist}</span>
                        </span>
                        <span className="hv-at" role="cell" title={i.fmt.time(p.startedAt)}>
                          +{stamp(p.startedAt - session.startedAt)}
                        </span>
                        <span className="hv-listen" role="cell">
                          <span className="hv-bar"><i style={{ left: from + '%', width: Math.max(0, w) + '%' }} /></span>
                          <span>{listen}</span>
                        </span>
                        <span role="cell"><span className={'hv-pill is-' + p.status}>{t(('history.status.' + p.status) as 'history.status.playing')}</span></span>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="hv-wall">
                  {list.map((p) => (
                    <div key={p.id} className={'hv-tile is-' + p.status} title={`${p.title} – ${p.artist}`}>
                      <Cover src={p.cover} className="hv-tile-cover" />
                      <b>{p.title}</b>
                      <span>{p.artist}</span>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
          {note && <p className="hv-note" role="status">{serverMsg(note)}</p>}
        </section>
      </div>
      {data && !data.pending && <AlbumWallPanel wallUrl={wallUrl} onCopy={onCopy} />}
      {data && !data.pending && <ShelfWallPanel shelfUrl={shelfUrl} onCopy={onCopy} />}
    </div>
  );
}
