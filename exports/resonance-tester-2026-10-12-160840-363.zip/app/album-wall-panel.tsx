'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Switch } from '@/components/ui/switch';
import { AlbumWall, type WallTile } from '@/lib/album-wall';
import { WALL_ACCENTS, WALL_DEFAULTS, type WallSettings } from '@/lib/album-wall-settings';
import { GALLERY_TRACKS } from '@/lib/gallery-demo';
import { estimatedProgress, type Track } from '@/lib/overlay';
import { serverMsg, type Key, useT } from '@/lib/i18n';

// F15 Album Wall – Einstellungen + Live-Vorschau im Studio-Tab „Verlauf“.

type WallResponse = {
  error?: string;
  settings: WallSettings;
  track: Track | null;
  plays: WallTile[];
  songNumber: number;
  lang?: string;
};

// Beispiel, solange noch nichts läuft: erfundene Demo-Songs (keine echten Cover).
const DEMO_TILES: WallTile[] = Array.from({ length: 12 }, (_, i) => {
  const t = GALLERY_TRACKS[(i % (GALLERY_TRACKS.length - 1)) + 1];
  return { id: 'demo-' + i, cover: t.cover, title: t.title, artist: t.artist, status: 'completed' };
});
const DEMO_TRACK: Track = { ...GALLERY_TRACKS[0], playing: true };

type Opt<T> = [T, Key];
const GROUPS: { key: keyof WallSettings; label: Key; opts: Opt<string | number | boolean>[] }[] = [
  { key: 'layout', label: 'wall.g.layout', opts: [['stage', 'wall.o.stage'], ['bar', 'wall.o.bar'], ['corner', 'wall.o.corner']] },
  { key: 'rows', label: 'wall.g.rows', opts: [[1, '1' as Key], [2, '2' as Key], [3, '3' as Key]] },
  { key: 'speed', label: 'wall.g.speed', opts: [['off', 'wall.o.off'], ['slow', 'wall.o.slow'], ['fast', 'wall.o.fast']] },
  { key: 'viz', label: 'wall.g.viz', opts: [['off', 'wall.o.off'], ['bars', 'wall.o.bars'], ['dots', 'wall.o.dots']] },
  { key: 'vizStrong', label: 'wall.g.vizStrong', opts: [[false, 'wall.o.subtle'], [true, 'wall.o.strong']] },
  { key: 'bg', label: 'wall.g.bg', opts: [['none', 'wall.o.none'], ['glass', 'wall.o.glass'], ['aura', 'wall.o.aura']] },
  { key: 'radius', label: 'wall.g.radius', opts: [['square', 'wall.o.square'], ['soft', 'wall.o.soft'], ['round', 'wall.o.round']] },
];
const TOGGLES: { key: 'vinyl' | 'artist' | 'hideSkipped'; label: Key }[] = [
  { key: 'vinyl', label: 'wall.t.vinyl' },
  { key: 'artist', label: 'wall.t.artist' },
  { key: 'hideSkipped', label: 'wall.t.hideSkipped' },
];
// Zahlen-Optionen (Reihen) sind keine Schlüssel und werden direkt angezeigt.
const label = (t: (k: Key) => string, k: Key) => (/^\d+$/.test(k) ? k : t(k));

export default function AlbumWallPanel({ wallUrl, onCopy }: { wallUrl: string; onCopy: (text: string) => void }) {
  const { t } = useT();
  const [settings, setSettings] = useState<WallSettings>(WALL_DEFAULTS);
  const [loaded, setLoaded] = useState(false);
  const [track, setTrack] = useState<Track | null>(null);
  const [plays, setPlays] = useState<WallTile[]>([]);
  const [songNumber, setSongNumber] = useState(0);
  const [note, setNote] = useState('');
  const [scale, setScale] = useState(0.4);
  const stageRef = useRef<HTMLDivElement>(null);
  const dirty = useRef(false);
  const lastSave = useRef(0);
  const [lang, setLang] = useState<string | undefined>(undefined);
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    const started = Date.now();
    try {
      const r = await fetch('/api/wall', { cache: 'no-store' });
      const d = (await r.json()) as WallResponse;
      if (!r.ok) throw new Error(d.error);
      // Antworten, die vor der letzten Änderung losgeschickt wurden, nicht übernehmen.
      if (!dirty.current && started > lastSave.current) setSettings(d.settings);
      setTrack(d.track ? { ...d.track, fetchedAt: Date.now() } : null);
      setPlays(d.plays);
      setSongNumber(d.songNumber);
      setLang(d.lang);
      setLoaded(true);
    } catch {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    void load();
    const t = setInterval(() => document.visibilityState === 'visible' && void load(), 5000);
    const tick = setInterval(
      () => setTrack((x) => (x?.playing ? { ...x, progress: estimatedProgress(x), fetchedAt: Date.now() } : x)),
      1000,
    );
    return () => {
      clearInterval(t);
      clearInterval(tick);
    };
  }, [load]);

  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setScale(el.clientWidth / 1920));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const save = async (next: WallSettings) => {
    setSettings(next);
    dirty.current = true;
    lastSave.current = Date.now();
    setNote('');
    try {
      const r = await fetch('/api/wall', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: next }),
      });
      const d = (await r.json()) as { error?: string; settings?: WallSettings };
      if (!r.ok) throw new Error(d.error || t('source.saveFailed'));
      if (d.settings) setSettings(d.settings);
    } catch (e) {
      setNote(e instanceof Error ? e.message : t('source.saveFailed'));
    } finally {
      dirty.current = false;
    }
  };
  const set = <K extends keyof WallSettings>(key: K, value: WallSettings[K]) => void save({ ...settings, [key]: value });

  const isDemo = loaded && !track && !plays.length;
  // Vorschau zeigt immer den laufenden Zustand – sonst steht bei pausiertem
  // Spotify alles still und man sieht die Bewegung beim Einstellen nicht.
  const spotifyPaused = !isDemo && !!track && !track.playing;
  const shownTrack = isDemo ? DEMO_TRACK : track;
  // Noch keine vorherigen Songs? Beispiel-Cover, damit man die Wand sieht.
  const noWallYet = !isDemo && !plays.length;
  const shownPlays = isDemo || noWallYet ? DEMO_TILES : plays;

  return (
    <section className="awp" aria-label={t('wall.title')}>
      <div className="awp-head">
        <div>
          <h2>{t('wall.title')}</h2>
          <p>{t('wall.intro')}</p>
        </div>
        <div className="awp-link">
          <button type="button" className="hv-btn is-strong" disabled={!wallUrl} onClick={() => {
              onCopy(wallUrl);
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            }}
          >
            {copied ? t('source.copied') : t('source.copyLink')}
          </button>
          {wallUrl && (
            <a className="hv-btn" href={wallUrl} target="_blank" rel="noreferrer">
              {t('source.open')}
            </a>
          )}
        </div>
      </div>
      <div className="awp-body">
        <div className="awp-preview">
          <div ref={stageRef} className="awp-stage">
            <div className="awp-scaler" style={{ transform: `scale(${scale})` }}>
              <AlbumWall settings={settings} track={shownTrack} plays={shownPlays} songNumber={isDemo ? 6 : songNumber} preview lang={lang} />
            </div>
          </div>
          <p className="awp-hint">
            {isDemo
              ? t('wall.hint.demo')
              : noWallYet
                ? t('wall.hint.empty')
                : spotifyPaused
                  ? t('wall.hint.paused')
                  : t('wall.hint.live')}
          </p>
        </div>
        <div className="awp-settings">
          {GROUPS.map((g) => (
            <div key={g.key} className="awp-group">
              <span>{t(g.label)}</span>
              <div className="hv-seg awp-seg" role="radiogroup" aria-label={t(g.label)}>
                {g.opts.map(([v, l]) => (
                  <button
                    key={String(v)}
                    type="button"
                    role="radio"
                    aria-checked={settings[g.key] === v}
                    className={settings[g.key] === v ? 'is-on' : ''}
                    disabled={g.key === 'rows' && settings.layout !== 'stage'}
                    onClick={() => set(g.key, v as never)}
                  >
                    {label(t, l)}
                  </button>
                ))}
              </div>
            </div>
          ))}
          <div className="awp-group">
            <span>{t('wall.g.accent')}</span>
            <div className="awp-swatches">
              <button
                type="button"
                className={'awp-auto' + (settings.accent ? '' : ' is-on')}
                aria-pressed={!settings.accent}
                onClick={() => set('accent', '')}
              >
                {t('wall.accentAuto')}
              </button>
              {WALL_ACCENTS.map((h) => (
                <button
                  key={h}
                  type="button"
                  className={'awp-swatch' + (settings.accent === h ? ' is-on' : '')}
                  style={{ background: h, color: h }}
                  aria-label={t('wall.accentAria', { hex: h })}
                  aria-pressed={settings.accent === h}
                  onClick={() => set('accent', h)}
                />
              ))}
            </div>
          </div>
          {TOGGLES.map((tg) => (
            <label key={tg.key} className="awp-toggle">
              {t(tg.label)}
              <Switch checked={settings[tg.key]} onCheckedChange={(on) => set(tg.key, on)} />
            </label>
          ))}
          {note && <p className="hv-note" role="status">{serverMsg(note)}</p>}
        </div>
      </div>
    </section>
  );
}
