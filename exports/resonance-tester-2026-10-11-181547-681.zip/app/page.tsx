'use client';
import {
  useEffect,
  useState,
  useRef,
  type CSSProperties,
  type ReactNode,
} from 'react';
import {
  AudioLines,
  ArrowUpRight,
  SlidersHorizontal,
  Radio,
  Check,
  Music2,
  Monitor,
  Sparkles,
  Copy,
  Save,
  RotateCcw,
  Pause,
  Play,
  ExternalLink,
  Lock,
  Unplug,
  RefreshCw,
  Info,
  MousePointer2,
  ChevronLeft,
  Image as ImageIcon,
  Gauge,
  Gamepad2,
  Tag,
  Box,
  Lightbulb,
  Type,
  Plus,
  Trash2,
  Download,
  Eye,
  EyeOff,
  X,
  ChevronDown,
  Star,
  Upload,
} from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import {
  Overlay,
  defaults,
  demo,
  FONT_LIBRARY,
  COVER_FILTERS,
  estimatedProgress,
  isAfterglow,
  type Config,
  type Track,
} from '@/lib/overlay';
import { presets } from '@/lib/presets';
import {
  editorElementsFor,
  editorTargetsFor,
  supportsField,
} from '@/lib/layout-capabilities';
import { detectMood, moodDemos } from '@/lib/mood';
import { getMoodMode, isMoodEffectivelyEnabled } from '@/lib/mood-capabilities';
import { fontFormatHint } from '@/lib/fonts';
async function api(path: string, body?: unknown) {
  const r = await fetch(path, {
    method: body ? 'POST' : 'GET',
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const d = (await r.json()) as {
    error?: string;
    config: Config;
    connected: boolean;
    overlayKey: string;
    redirect: string;
    url: string;
    track: Track | null;
    message?: string;
    retryAfter?: number;
    pinned_at?: number | null;
    look?: CustomLook;
  };
  if (!r.ok) throw new Error(d.error || 'Verbindung fehlgeschlagen.');
  return d;
}
type PlaylistItem = {
  id: string;
  name: string;
  image?: string;
  owner?: { id?: string };
  collaborative?: boolean;
};
type CustomFontMeta = {
  id: string;
  name: string;
  format: string;
  family: string;
  size: number;
  createdAt: number;
};
type CustomLook = {
  id: string;
  name: string;
  config: Config;
  created_at: number;
  pinned: number;
  pinned_at: number | null;
};
type ResonanceLookFile = {
  format: 'resonance-look';
  version: 1;
  name: string;
  config: unknown;
};
function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function configSnapshotKey(config: Config): string {
  return JSON.stringify(
    Object.fromEntries(
      Object.keys(config)
        .sort()
        .map((key) => [key, config[key as keyof Config]]),
    ),
  );
}
function Picker({
  label,
  value,
  options,
  onChange,
  field,
}: {
  label: string;
  value: string;
  options: [string, string][];
  onChange: (v: string) => void;
  field?: string;
}) {
  return (
    <label className="picker" data-field={field}>
      <span>{label}</span>
      <Select value={value} onValueChange={(v) => v && onChange(v)}>
        <SelectTrigger aria-label={label}>
          <SelectValue>{options.find((o) => o[0] === value)?.[1]}</SelectValue>
        </SelectTrigger>
        <SelectContent>
          {options.map(([v, l]) => (
            <SelectItem key={v} value={v}>
              {l}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </label>
  );
}
const LED_BEHAVIOR_LABELS: Record<string, string> = {
  solid: 'Solid',
  soft: 'Soft Pulse',
  breathe: 'Breathe',
  double: 'Double Pulse',
  heartbeat: 'Heartbeat',
  flicker: 'Flicker',
  off: 'Off',
};
const EDITOR_NAMES: Record<string, string> = {
  device: 'Gerät',
  cover: 'Albumcover',
  display: 'Display',
  led: 'LED',
  controls: 'Bedienelemente',
  progress: 'Wiedergabe',
  note: 'Notiz',
  title: 'Songtitel',
  artist: 'Interpret',
  'display-meta': 'Statuszeile',
  visualizer: 'Visualizer',
};
// Studio 2.0: kurze Namen für Element-Chips und Panel-Titel.
const CHIP_NAMES: Record<string, string> = {
  cover: 'Cover',
  title: 'Titel',
  artist: 'Interpret',
  'display-meta': 'Status',
  progress: 'Fortschritt',
  display: 'Display',
  led: 'LED',
  controls: 'Tasten',
  note: 'Notiz',
  visualizer: 'Visualizer',
};
// Gehäuse-Stile je Layout (Oberfläche; der Farbton kommt aus „Hintergrund“).
const BODY_STYLES: Record<string, [string, string][]> = {
  winamp: [
    ['default', 'Gebürstet'],
    ['gloss', 'Glanz'],
    ['matte', 'Matt'],
    ['carbon', 'Carbon'],
  ],
  pixel: [
    ['default', 'Dialog'],
    ['gameboy', 'Handheld-Grün'],
    ['parchment', 'Pergament'],
    ['midnight', 'Mitternacht'],
  ],
};
// Elemente, die über das Auge im Panel-Kopf ein-/ausgeblendet werden.
const VISIBILITY_FIELD: Record<
  string,
  'cover' | 'artist' | 'progress' | 'badge' | 'visualizerVisible'
> = {
  cover: 'cover',
  artist: 'artist',
  progress: 'progress',
  'display-meta': 'badge',
  visualizer: 'visualizerVisible',
};
const TIP_STORAGE_KEY = 'resonance.studio.tipDismissed';
function readableOn(hex: string) {
  const m = /^#([0-9a-f]{6})$/i.exec(hex);
  if (!m) return '#131811';
  const n = parseInt(m[1], 16);
  const lin = (c: number) => {
    const v = c / 255;
    return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
  };
  const l =
    0.2126 * lin((n >> 16) & 255) +
    0.7152 * lin((n >> 8) & 255) +
    0.0722 * lin(n & 255);
  return l > 0.36 ? '#131811' : '#ffffff';
}
function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="v2-section">
      <h4>{title}</h4>
      {children}
    </section>
  );
}
function Disclosure({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className={'v2-disclosure' + (open ? ' is-open' : '')}>
      <button
        type="button"
        className="v2-disclosure-toggle"
        data-disclosure=""
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
      >
        <span>{title}</span>
        <ChevronDown size={15} aria-hidden="true" />
      </button>
      {open && <div className="v2-disclosure-body">{children}</div>}
    </div>
  );
}
export default function Studio() {
  const [config, setConfig] = useState<Config>(defaults),
    [historyPast, setHistoryPast] = useState<Config[]>([]),
    [historyFuture, setHistoryFuture] = useState<Config[]>([]),
    [saved, setSaved] = useState(''),
    [connected, setConnected] = useState(false),
    [ready, setReady] = useState(false),
    [key, setKey] = useState(''),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState(''),
    [error, setError] = useState(''),
    [modal, setModal] = useState<'spotify' | 'obs' | null>(null),
    [track, setTrack] = useState<Track | null>(null),
    [demoMode, setDemoMode] = useState(true),
    [demoPlaying, setDemoPlaying] = useState(true),
    [canvas, setCanvas] = useState('ambient'),
    [canvasWidth, setCanvasWidth] = useState(600),
    [selectedElement, setSelectedElement] = useState<string | null>(null),
    [markerRect, setMarkerRect] = useState<{
      top: number;
      left: number;
      width: number;
      height: number;
    } | null>(null),
    [tick, setTick] = useState(0),
    [origin, setOrigin] = useState(''),
    [testerVersion, setTesterVersion] = useState<string | null>(null),
    [setupExpanded, setSetupExpanded] = useState(false),
    [spotifyRedirect, setSpotifyRedirect] = useState(''),
    [playlists, setPlaylists] = useState<PlaylistItem[]>([]),
    [currentUserId, setCurrentUserId] = useState(''),
    [demoIndex, setDemoIndex] = useState(0),
    [moodSettingsOpen, setMoodSettingsOpen] = useState(false),
    [moodSetupDismissed, setMoodSetupDismissed] = useState(false),
    [lastfmConfigured, setLastfmConfigured] = useState(false),
    [geniusConfigured, setGeniusConfigured] = useState(false),
    [lastfmKey, setLastfmKey] = useState(''),
    [geniusToken, setGeniusToken] = useState(''),
    [moodBusy, setMoodBusy] = useState(false),
    [lastfmTest, setLastfmTest] = useState<
      '' | 'testing' | 'connected' | 'invalid' | 'unavailable'
    >(''),
    [geniusTest, setGeniusTest] = useState<
      '' | 'testing' | 'connected' | 'invalid' | 'unavailable'
    >('');
  const [customFonts, setCustomFonts] = useState<CustomFontMeta[]>([]);
  const [customLooks, setCustomLooks] = useState<CustomLook[]>([]);
  const [view, setView] = useState<'studio' | 'looks' | 'setup'>('studio');
  const [tipDismissed, setTipDismissed] = useState(false);
  const [saveLookOpen, setSaveLookOpen] = useState(false);
  // Entwicklermodus (nur wenn das Vite-Dev-Plugin antwortet; Tester-Builds nie).
  const [devStatus, setDevStatus] = useState<{
    latest: { file: string; createdAt: string; size: number } | null;
    newestSourceChange: string | null;
    stale: boolean;
  } | null>(null);
  const [devBusy, setDevBusy] = useState(false);
  const [lookName, setLookName] = useState('');
  const lookImportRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [pendingUploadTarget, setPendingUploadTarget] = useState<
    'title' | 'artist' | 'meta' | null
  >(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{
    id: string;
    name: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sliderStart = useRef<Config | null>(null);
  const preview = useRef<HTMLDivElement>(null);
  const inspector = useRef<HTMLElement>(null);
  const liveTrackId = useRef('');
  const liveSlot = useRef(0);
  const configRef = useRef(config);
  const savedRef = useRef(saved);
  const persistRevision = useRef(0);
  const persisting = useRef(false);
  configRef.current = config;
  savedRef.current = saved;
  const dirty = saved !== JSON.stringify(config);
  const savedConfig = (() => {
    try {
      const parsed: unknown = JSON.parse(saved);
      return isRecord(parsed) ? (parsed as Config) : null;
    } catch {
      return null;
    }
  })();
  const activeLiveLookId = savedConfig
    ? customLooks.find(
        (look) =>
          !!look.pinned &&
          configSnapshotKey(look.config) === configSnapshotKey(savedConfig),
      )?.id
    : undefined;
  const liveLooks = customLooks
    .filter((look) => !!look.pinned)
    .sort(
      (a, b) =>
        (a.pinned_at ?? Number.MAX_SAFE_INTEGER) -
          (b.pinned_at ?? Number.MAX_SAFE_INTEGER) || a.id.localeCompare(b.id),
    );
  const isActivePreset = (preset: (typeof presets)[number]) =>
    preset.id === config.layout &&
    (preset.id !== 'glass' || isAfterglow(config));
  const chosen = presets.find(isActivePreset);
  const chosenName =
    config.layout === 'glass' && !isAfterglow(config)
      ? 'Glass'
      : chosen?.name;
  const editorTargets = editorTargetsFor(config.layout);
  const editorElements = editorElementsFor(config.layout);
  const canEdit = (field: keyof Config) => supportsField(config.layout, field);
  const demoTrack = {
    ...demo,
    ...moodDemos[demoIndex],
    slot: demoIndex + 1,
    playing: demoPlaying,
    progress: demoPlaying
      ? (demo.progress + tick * 1000) % demo.duration
      : demo.progress,
  };
  const shown = demoMode
    ? demoTrack
    : track
      ? { ...track, progress: estimatedProgress(track) }
      : null;
  const moodMode = getMoodMode(config);
  const moodEnabled = isMoodEffectivelyEnabled(config);
  const detected = moodEnabled
    ? detectMood(shown, shown?.lastfmTags)
    : null;
  const obsOrigin = origin.replace(/^http:\/\/localhost(?=[:/]|$)/, 'http://127.0.0.1');
  const obsUrl = obsOrigin + '/overlay#' + key;
  const afterglowMaskUrl =
    obsOrigin + '/overlay/afterglow-mask#' + key;
  const setupComplete = connected && !!key;
  const showSetupDetails = !setupComplete || setupExpanded;
  useEffect(() => {
    setOrigin(location.origin);
    if (new URLSearchParams(location.search).has('connect'))
      setModal('spotify');
    let alive = true;
    api('/api/studio')
      .then((d) => {
        if (!alive) return;
        configRef.current = d.config;
        setConfig(d.config);
        setHistoryPast([]);
        setHistoryFuture([]);
        const initialSaved = JSON.stringify(d.config);
        savedRef.current = initialSaved;
        setSaved(initialSaved);
        setConnected(d.connected);
        setDemoMode(!d.connected);
        setKey(d.overlayKey);
        setSpotifyRedirect(d.redirect);
        setReady(true);
      })
      .catch((e) => {
        if (alive) setError(e.message);
      });
    fetch('/api/mood/settings')
      .then(async (r) => {
        if (!alive || !r.ok) return;
        const d = (await r.json()) as {
          lastfmConfigured?: boolean;
          geniusConfigured?: boolean;
        };
        setLastfmConfigured(!!d.lastfmConfigured);
        setGeniusConfigured(!!d.geniusConfigured);
      })
      .catch(() => {});
    fetch('/resonance-version.json', { cache: 'no-store' })
      .then(async (r) =>
        r.ok
          ? ((await r.json()) as { version?: string | null })
          : { version: null },
      )
      .then((d) => {
        if (alive) setTesterVersion(d.version || null);
      })
      .catch(() => {});
    fetch('/api/looks')
      .then((r) => (r.ok ? r.json() : { looks: [] }))
      .then((d) => alive && setCustomLooks(d.looks || []))
      .catch(() => {});
    const status = new URLSearchParams(location.search).get('spotify');
    if (status) {
      setMessage(
        status === 'connected'
          ? 'Spotify ist verbunden. Starte einen Titel in Spotify.'
          : status === 'cancelled'
            ? 'Spotify-Anmeldung abgebrochen.'
            : status === 'expired'
              ? 'Anmeldung abgelaufen. Bitte erneut verbinden.'
              : status === 'token'
                ? 'Spotify hat die Anmeldung abgelehnt. Prüfe im Spotify Developer Dashboard die Redirect-URI: http://127.0.0.1:3000/api/spotify/callback'
                : 'Spotify-Anmeldung fehlgeschlagen. Prüfe die Redirect-URI und versuche es erneut.',
      );
      history.replaceState(null, '', '/');
    }
    return () => {
      alive = false;
    };
  }, []);
  useEffect(() => {
    if (!ready) return;
    let stopped = false;
    let inFlight = false;
    let requestSequence = 0;
    let timer: ReturnType<typeof setInterval> | undefined;

    async function syncLiveConfig(force = false) {
      if (
        stopped ||
        (inFlight && !force) ||
        persisting.current ||
        document.visibilityState !== 'visible'
      )
        return;
      inFlight = true;
      const requestId = ++requestSequence;
      const requestRevision = persistRevision.current;
      try {
        const d = await api('/api/studio');
        if (
          stopped ||
          requestId !== requestSequence ||
          persisting.current ||
          document.visibilityState !== 'visible' ||
          requestRevision !== persistRevision.current
        )
          return;

        const serverConfig = d.config;
        let persistedConfig: Config | null = null;
        try {
          const parsed: unknown = JSON.parse(savedRef.current);
          if (isRecord(parsed)) persistedConfig = parsed as Config;
        } catch {}
        if (
          persistedConfig &&
          configSnapshotKey(serverConfig) === configSnapshotKey(persistedConfig)
        )
          return;

        const localConfig = configRef.current;
        const editorWasClean =
          !!persistedConfig &&
          configSnapshotKey(localConfig) === configSnapshotKey(persistedConfig);
        const nextSaved = JSON.stringify(serverConfig);
        savedRef.current = nextSaved;
        setSaved(nextSaved);

        if (editorWasClean) {
          configRef.current = serverConfig;
          setConfig(serverConfig);
          setHistoryPast([]);
          setHistoryFuture([]);
          sliderStart.current = null;
        } else {
          setMessage(
            'Live-Konfiguration wurde extern geändert. Deine lokalen Änderungen wurden nicht überschrieben.',
          );
        }
      } catch {
        // Hintergrund-Sync bleibt bei temporären Fehlern absichtlich still.
      } finally {
        if (requestId === requestSequence) inFlight = false;
      }
    }

    function stopPolling() {
      if (timer) clearInterval(timer);
      timer = undefined;
    }
    function startPolling() {
      stopPolling();
      if (document.visibilityState !== 'visible') return;
      void syncLiveConfig(true);
      timer = setInterval(() => void syncLiveConfig(), 1000);
    }
    function handleVisibilityChange() {
      startPolling();
    }

    document.addEventListener('visibilitychange', handleVisibilityChange);
    startPolling();
    return () => {
      stopped = true;
      stopPolling();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [ready]);
  // Custom Fonts: Liste laden und @font-face-Regeln injizieren.
  useEffect(() => {
    let alive = true;
    fetch('/api/fonts')
      .then(async (r) => {
        const d = (await r.json()) as { fonts?: CustomFontMeta[] };
        if (!alive || !r.ok) return;
        setCustomFonts(d.fonts || []);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, []);
  useEffect(() => {
    if (customFonts.length === 0) return;
    const style = document.createElement('style');
    style.textContent = customFonts
      .map(
        (f) => `
  @font-face {
    font-family: '${f.family}';
    src: url('/api/fonts/${f.id}/file') format('${fontFormatHint(f.format)}');
    font-display: swap;
  }
`,
      )
      .join('\n');
    document.head.appendChild(style);
    return () => {
      style.remove();
    };
  }, [customFonts]);
  useEffect(() => {
    const timer = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    if (!preview.current) return;
    const ob = new ResizeObserver((entries) =>
      setCanvasWidth(entries[0].contentRect.width),
    );
    ob.observe(preview.current);
    return () => ob.disconnect();
  }, []);
  // Editor-Selection: Escape → Deselect (nur wenn kein Base-UI-Popup offen ist)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        // Offene Base-UI-Popups (Select/Popover/Dropdown/Dialog) schließt
        // Base UI selbst per Escape – hier kein Deselect auslösen.
        const openPopup = document.querySelector(
          '[data-base-ui-portal] [data-open]',
        );
        if (!openPopup) setSelectedElement(null);
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);
  useEffect(() => {
    inspector.current?.scrollTo({ top: 0, behavior: 'smooth' });
  }, [selectedElement]);
  // Editor-Selection: Marker-Position des gewählten Elements verfolgen
  // Studio 2.0: Ohne Auswahl ist der ganze Player (Gerät) markiert.
  const markerTarget = selectedElement ?? 'device';
  useEffect(() => {
    const canvas = preview.current;
    const sel = editorTargets.find(([n]) => n === markerTarget)?.[1];
    if (!sel) {
      const frame = requestAnimationFrame(() =>
        setMarkerRect((current) => (current === null ? current : null)),
      );
      return () => cancelAnimationFrame(frame);
    }
    if (!canvas || !sel) return;
    const update = () => {
      const el = canvas.querySelector(sel);
      if (!el) {
        setMarkerRect((current) => (current === null ? current : null));
        return;
      }
      const cr = canvas.getBoundingClientRect();
      const er = el.getBoundingClientRect();
      const next = {
        top: er.top - cr.top,
        left: er.left - cr.left,
        width: er.width,
        height: er.height,
      };
      setMarkerRect((current) => {
        if (
          current &&
          Math.abs(current.top - next.top) < 0.25 &&
          Math.abs(current.left - next.left) < 0.25 &&
          Math.abs(current.width - next.width) < 0.25 &&
          Math.abs(current.height - next.height) < 0.25
        )
          return current;
        return next;
      });
    };
    const frame = requestAnimationFrame(update);
    const ro = new ResizeObserver(update);
    ro.observe(canvas);
    const el = canvas.querySelector(sel);
    if (el) ro.observe(el);
    return () => {
      cancelAnimationFrame(frame);
      ro.disconnect();
    };
  }, [
    markerTarget,
    view,
    config,
    shown?.id,
    shown?.title,
    shown?.artist,
    shown?.playing,
  ]);
  useEffect(() => {
    if (!connected || demoMode) return;
    let stopped = false;
    let timeout: ReturnType<typeof setTimeout>;
    async function poll() {
      let wait = 5000;
      try {
        const d = await api('/api/now');
        if (stopped) return;
        if (d.track) {
          const id = d.track.id || d.track.title + '|' + d.track.artist;
          if (id !== liveTrackId.current) {
            liveTrackId.current = id;
            liveSlot.current += 1;
          }
          setTrack({
            ...d.track,
            slot: liveSlot.current,
            fetchedAt: Date.now(),
          });
        } else if (!d.message) setTrack(null);
        setError(d.message || '');
        if (!d.connected) {
          setConnected(false);
          setError('Spotify-Verbindung abgelaufen. Bitte erneut verbinden.');
        }
        wait = Math.max(5000, (d.retryAfter || 0) * 1000);
      } catch (e) {
        if (stopped) return;
        setError((e as Error).message);
        wait = 10000;
      }
      if (!stopped) timeout = setTimeout(poll, wait);
    }
    poll();
    return () => {
      stopped = true;
      clearTimeout(timeout);
    };
  }, [connected, demoMode]);
  useEffect(() => {
    if (!connected) return;
    let alive = true;
    fetch('/api/spotify/playlists')
      .then(async (r) => {
        const d = await r.json();
        if (!alive) return;
        if (!r.ok)
          throw new Error(d.error || 'Playlists konnten nicht geladen werden.');
        setCurrentUserId(d.currentUserId || '');
        setPlaylists(d.playlists || []);
      })
      .catch((e) => {
        if (alive) setError((e as Error).message);
      });
    return () => {
      alive = false;
    };
  }, [connected]);
  useEffect(() => {
    try {
      setTipDismissed(localStorage.getItem(TIP_STORAGE_KEY) === '1');
    } catch {}
  }, []);
  async function loadDevStatus() {
    try {
      const r = await fetch('/__resonance/dev/status', { cache: 'no-store' });
      if (!r.ok) return setDevStatus(null);
      const d = (await r.json()) as {
        devMode?: boolean;
        latest: { file: string; createdAt: string; size: number } | null;
        newestSourceChange: string | null;
        stale: boolean;
      };
      setDevStatus(d && d.devMode ? d : null);
    } catch {
      setDevStatus(null);
    }
  }
  useEffect(() => {
    if (view === 'setup') void loadDevStatus();
  }, [view]);
  async function buildTesterZip(download: boolean) {
    setDevBusy(true);
    setError('');
    try {
      const r = await fetch('/__resonance/dev/export-tester', { method: 'POST' });
      const d = (await r.json()) as {
        error?: string;
        latest?: { file: string };
      };
      if (!r.ok || !d.latest) throw new Error(d.error || 'Export fehlgeschlagen.');
      setMessage(`Tester-ZIP gebaut: ${d.latest.file}`);
      if (download) {
        const a = document.createElement('a');
        a.href = '/exports/' + encodeURIComponent(d.latest.file);
        a.download = d.latest.file;
        a.click();
      }
      await loadDevStatus();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setDevBusy(false);
    }
  }
  function dismissTip() {
    setTipDismissed(true);
    try {
      localStorage.setItem(TIP_STORAGE_KEY, '1');
    } catch {}
  }
  useEffect(() => {
    if (selectedElement) dismissTip();
  }, [selectedElement]);
  // Studio 2.0: Das gesamte Studio übernimmt die Akzentfarbe des Players.
  useEffect(() => {
    const root = document.documentElement;
    const accent = /^#[0-9a-f]{6}$/i.test(config.accent)
      ? config.accent
      : defaults.accent;
    root.style.setProperty('--primary', accent);
    root.style.setProperty('--studio-on-accent', readableOn(accent));
    return () => {
      root.style.removeProperty('--primary');
      root.style.removeProperty('--studio-on-accent');
    };
  }, [config.accent]);
  const update = <K extends keyof Config>(k: K, v: Config[K]) => {
    const current = configRef.current;
    if (Object.is(current[k], v)) return;
    const next = { ...current, [k]: v };
    configRef.current = next;
    setHistoryPast((past) => [...past, current].slice(-50));
    setHistoryFuture([]);
    setConfig(next);
  };
  const beginSlider = () => {
    if (!sliderStart.current) sliderStart.current = config;
  };
  const updateSlider = <K extends keyof Config>(k: K, v: Config[K]) => {
    beginSlider();
    setConfig((current) => ({ ...current, [k]: v }));
  };
  const commitSlider = () => {
    const start = sliderStart.current;
    sliderStart.current = null;
    if (!start || JSON.stringify(start) === JSON.stringify(config)) return;
    setHistoryPast((past) => [...past, start].slice(-50));
    setHistoryFuture([]);
  };
  const undo = () => {
    const previous = historyPast.at(-1);
    if (!previous) return;
    setHistoryPast((past) => past.slice(0, -1));
    setHistoryFuture((future) => [config, ...future].slice(0, 50));
    setConfig(previous);
  };
  const redo = () => {
    const next = historyFuture[0];
    if (!next) return;
    setHistoryFuture((future) => future.slice(1));
    setHistoryPast((past) => [...past, config].slice(-50));
    setConfig(next);
  };
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (
        target?.matches('input,textarea,[contenteditable="true"]') ||
        !event.ctrlKey
      )
        return;
      if (event.key.toLowerCase() === 'z') {
        event.preventDefault();
        event.shiftKey ? redo() : undo();
      } else if (event.key.toLowerCase() === 'y') {
        event.preventDefault();
        redo();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [historyPast, historyFuture, config]);
  const canObserve = (p: PlaylistItem) =>
    p.collaborative === true || p.owner?.id === currentUserId;
  const selectedObserved = playlists.find(
    (p) => p.id === config.observedPlaylistId,
  );
  async function save() {
    setBusy(true);
    setError('');
    persisting.current = true;
    persistRevision.current += 1;
    try {
      await api('/api/studio', { config });
      const nextSaved = JSON.stringify(config);
      savedRef.current = nextSaved;
      setSaved(nextSaved);
      setMessage(
        'Design gespeichert. Dein OBS-Overlay übernimmt die Änderungen.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      persisting.current = false;
      setBusy(false);
    }
  }
  async function saveLook() {
    const name = lookName.trim();
    if (!name) {
      setError('Bitte gib deinem Look einen Namen.');
      return;
    }
    try {
      const r = await api('/api/looks', { name, config });
      const look = r.look;
      if (!look) throw new Error('Look konnte nicht gespeichert werden.');
      setCustomLooks((looks) => [look, ...looks]);
      setLookName('');
      setMessage('Look gespeichert.');
    } catch (e) {
      setError((e as Error).message);
    }
  }
  async function deleteLook(id: string) {
    try {
      const r = await fetch('/api/looks?id=' + encodeURIComponent(id), {
        method: 'DELETE',
        headers: { Origin: location.origin },
      });
      if (!r.ok) throw new Error('Look konnte nicht gelöscht werden.');
      setCustomLooks((looks) => looks.filter((look) => look.id !== id));
    } catch (e) {
      setError((e as Error).message);
    }
  }
  async function pinLook(look: CustomLook) {
    try {
      const r = await api('/api/looks', {
        action: 'pin',
        id: look.id,
        pinned: !look.pinned,
      });
      if (!r) return;
      setCustomLooks((looks) =>
        looks.map((item) =>
          item.id === look.id
            ? {
                ...item,
                pinned: look.pinned ? 0 : 1,
                pinned_at: look.pinned ? null : (r.pinned_at ?? null),
              }
            : item,
        ),
      );
    } catch (e) {
      setError((e as Error).message);
    }
  }
  async function activateLook(look: CustomLook) {
    const previous = config;
    persisting.current = true;
    persistRevision.current += 1;
    configRef.current = look.config;
    setConfig(look.config);
    try {
      await api('/api/studio', { config: look.config });
      const nextSaved = JSON.stringify(look.config);
      savedRef.current = nextSaved;
      setSaved(nextSaved);
      setMessage(`${look.name} ist live aktiv.`);
    } catch (e) {
      configRef.current = previous;
      setConfig(previous);
      setError((e as Error).message);
    } finally {
      persisting.current = false;
    }
  }
  function exportLook(look: CustomLook) {
    const blob = new Blob(
      [
        JSON.stringify(
          {
            format: 'resonance-look',
            version: 1,
            name: look.name,
            config: look.config,
            exportedAt: new Date().toISOString(),
          },
          null,
          2,
        ),
      ],
      { type: 'application/json' },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `resonance-look-${
      look.name
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '') || 'custom-look'
    }.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
  async function importLook(file: File) {
    try {
      const parsed: unknown = JSON.parse(await file.text());
      if (!isRecord(parsed)) throw new Error('Die Look-Datei ist ungültig.');
      if (parsed.format !== 'resonance-look')
        throw new Error('Diese Datei ist keine Resonance-Look-Datei.');
      if (parsed.version !== 1)
        throw new Error(
          'Diese Look-Datei verwendet eine neuere, nicht unterstützte Version.',
        );
      const data: ResonanceLookFile = {
        format: 'resonance-look',
        version: 1,
        name: typeof parsed.name === 'string' ? parsed.name : '',
        config: parsed.config,
      };
      if (!data.name.trim() || !isRecord(data.config))
        throw new Error('Die Look-Datei ist unvollständig.');
      const r = await api('/api/looks', {
        name: data.name,
        config: data.config,
        import: true,
      });
      const look = r.look;
      if (!look) throw new Error('Look konnte nicht importiert werden.');
      setCustomLooks((looks) => [look, ...looks]);
      const fonts = [
        data.config.titleFont,
        data.config.artistFont,
        data.config.metaFont,
      ];
      if (
        fonts.some(
          (font) =>
            typeof font === 'string' &&
            font.startsWith('custom:') &&
            !customFonts.some((item) => `custom:${item.id}` === font),
        )
      )
        setMessage(
          'Look importiert. Dieser Look verwendet eine Custom Font, die auf diesem System nicht vorhanden ist.',
        );
      else setMessage('Look importiert.');
    } catch (e) {
      setError((e as Error).message || 'Look konnte nicht importiert werden.');
    }
  }
  async function connect() {
    setBusy(true);
    setError('');
    try {
      const d = await api('/api/spotify/start', {});
      window.location.assign(d.url);
    } catch (e) {
      setError((e as Error).message);
      setBusy(false);
    }
  }
  async function disconnect() {
    setBusy(true);
    try {
      await api('/api/studio', { action: 'disconnect' });
      setConnected(false);
      setDemoMode(true);
      setTrack(null);
      setMessage('Spotify wurde getrennt.');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function copy(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      setMessage('In die Zwischenablage kopiert.');
    } catch {
      setError('Bitte markiere die Adresse und kopiere sie manuell.');
    }
  }
  async function reloadCustomFonts() {
    const r = await fetch('/api/fonts');
    if (!r.ok) return;
    const d = (await r.json()) as { fonts?: CustomFontMeta[] };
    setCustomFonts(d.fonts || []);
  }
  async function uploadFont(file: File, target: 'title' | 'artist' | 'meta') {
    const fontKey = `${target}Font` as 'titleFont' | 'artistFont' | 'metaFont';
    setUploading(true);
    setError('');
    try {
      const fd = new FormData();
      fd.append('file', file);
      const r = await fetch('/api/fonts', { method: 'POST', body: fd });
      const d = (await r.json()) as {
        error?: string;
        duplicate?: boolean;
        message?: string;
        font?: CustomFontMeta;
      };
      if (!r.ok) throw new Error(d.error || 'Upload fehlgeschlagen.');
      if (d.duplicate) {
        // Font NICHT neu anwenden, wenn er schon angewendet ist; sonst anwenden
        if (d.font)
          update(fontKey, ('custom:' + d.font.id) as Config[typeof fontKey]);
        setMessage(
          (d.message || 'Font already uploaded.') +
            ' Design speichern, um die Auswahl dauerhaft zu übernehmen.',
        );
        return;
      }
      await reloadCustomFonts();
      if (d.font)
        update(fontKey, ('custom:' + d.font.id) as Config[typeof fontKey]);
      setMessage(
        'Font hochgeladen und angewendet. Design speichern, um die Auswahl dauerhaft zu übernehmen.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setUploading(false);
    }
  }
  async function doDeleteFont(id: string) {
    setBusy(true);
    setError('');
    try {
      const r = await fetch('/api/fonts/' + id, { method: 'DELETE' });
      const d = (await r.json()) as { error?: string };
      if (!r.ok) throw new Error(d.error || 'Löschen fehlgeschlagen.');
      await reloadCustomFonts();
      setMessage('Font gelöscht.');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  function requestDeleteFont(id: string, name: string) {
    const used =
      config.titleFont === 'custom:' + id ||
      config.artistFont === 'custom:' + id ||
      config.metaFont === 'custom:' + id;
    if (used) {
      setDeleteConfirm({ id, name });
      return;
    }
    void doDeleteFont(id);
  }
  async function confirmDeleteFont() {
    if (!deleteConfirm) return;
    const { id } = deleteConfirm;
    setDeleteConfirm(null);
    // Fallback: verwendete Felder auf Inter ('sans') zurücksetzen.
    const usedKeys = (['titleFont', 'artistFont', 'metaFont'] as const).filter(
      (k) => config[k] === 'custom:' + id,
    );
    if (usedKeys.length > 0) {
      setConfig((c) => {
        const next = { ...c };
        for (const k of usedKeys) next[k] = 'sans';
        return next;
      });
    }
    await doDeleteFont(id);
  }
  async function openMoodSettings() {
    setMoodSettingsOpen(true);
    setLastfmTest('');
    setGeniusTest('');
    setError('');
    try {
      const r = await fetch('/api/mood/settings');
      if (!r.ok) return;
      const d = (await r.json()) as {
        lastfmConfigured?: boolean;
        geniusConfigured?: boolean;
      };
      setLastfmConfigured(!!d.lastfmConfigured);
      setGeniusConfigured(!!d.geniusConfigured);
    } catch {
      // Status bleibt unverändert
    }
  }
  async function saveMoodCredential(provider: 'lastfm' | 'genius') {
    setMoodBusy(true);
    setError('');
    try {
      const body =
        provider === 'lastfm'
          ? { lastfmApiKey: lastfmKey.trim() }
          : { geniusAccessToken: geniusToken.trim() };
      const r = await fetch('/api/mood/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const d = (await r.json()) as {
        error?: string;
        lastfmConfigured?: boolean;
        geniusConfigured?: boolean;
      };
      if (!r.ok) throw new Error(d.error || 'Speichern fehlgeschlagen.');
      setLastfmConfigured(!!d.lastfmConfigured);
      setGeniusConfigured(!!d.geniusConfigured);
      setMessage(
        provider === 'lastfm'
          ? 'Last.fm-Key gespeichert.'
          : 'Genius-Token gespeichert.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setMoodBusy(false);
    }
  }
  async function removeMoodCredential(provider: 'lastfm' | 'genius') {
    setMoodBusy(true);
    setError('');
    try {
      const body =
        provider === 'lastfm'
          ? { lastfmApiKey: '' }
          : { geniusAccessToken: '' };
      const r = await fetch('/api/mood/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const d = (await r.json()) as {
        error?: string;
        lastfmConfigured?: boolean;
        geniusConfigured?: boolean;
      };
      if (!r.ok) throw new Error(d.error || 'Entfernen fehlgeschlagen.');
      setLastfmConfigured(!!d.lastfmConfigured);
      setGeniusConfigured(!!d.geniusConfigured);
      if (provider === 'lastfm') setLastfmKey('');
      else setGeniusToken('');
      setMessage(
        provider === 'lastfm'
          ? 'Last.fm-Key entfernt.'
          : 'Genius-Token entfernt.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setMoodBusy(false);
    }
  }
  async function testMoodCredential(provider: 'lastfm' | 'genius') {
    const setTest = provider === 'lastfm' ? setLastfmTest : setGeniusTest;
    setTest('testing');
    setError('');
    try {
      const r = await fetch('/api/mood/settings/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider }),
      });
      const d = (await r.json()) as {
        error?: string;
        status?: 'connected' | 'invalid' | 'unavailable';
      };
      if (!r.ok) throw new Error(d.error || 'Test fehlgeschlagen.');
      setTest(d.status || 'unavailable');
    } catch (e) {
      setTest('unavailable');
      setError((e as Error).message);
    }
  }
  function range(
    k:
      | 'radius'
      | 'opacity'
      | 'width'
      | 'spacing'
      | 'fontSize'
      | 'moodIntensity'
      | 'glassOpacity'
      | 'glassTintStrength'
      | 'glassHighlight'
      | 'spinSpeed'
      | 'ledBrightness'
      | 'ledGlow'
      | 'ledSize'
      | 'ledOffsetX'
      | 'ledOffsetY'
      | 'displayBrightness'
      | 'textGlow'
      | 'progressEdge'
      | 'progressWidth'
      | 'progressThickness'
      | 'progressOffsetX'
      | 'progressOffsetY'
      | 'progressRadius'
      | 'controlsSize'
      | 'controlsIconSize'
      | 'controlsGap'
      | 'controlsOffsetX'
      | 'controlsOffsetY'
      | 'coverBrightness'
      | 'coverSaturation'
      | 'coverContrast'
      | 'coverSize'
      | 'coverOffsetX'
      | 'coverOffsetY'
      | 'coverRadius'
      | 'noteSize'
      | 'noteOffsetX'
      | 'noteOffsetY'
      | 'noteRotation'
      | 'noteOpacity'
      | 'titleOffsetX'
      | 'titleOffsetY'
      | 'artistOffsetX'
      | 'artistOffsetY'
      | 'metaOffsetX'
      | 'metaOffsetY'
      | 'titleArtistSpacing'
      | 'scanlineStrength'
      | 'grainStrength'
      | 'vignetteStrength'
      | 'titleSize'
      | 'artistSize'
      | 'metaSize'
      | 'titleLetterSpacing'
      | 'artistLetterSpacing'
      | 'metaLetterSpacing',
    label: string,
    min: number,
    max: number,
    unit: string,
  ) {
    return (
      <div className="range-control" data-field={k}>
        <div className="range-label">
          <span>{label}</span>
          <code>
            {config[k]} {unit}
          </code>
        </div>
        <Slider
          aria-label={label}
          value={[config[k]]}
          min={min}
          max={max}
          onPointerDown={beginSlider}
          onValueChange={(v) => updateSlider(k, Array.isArray(v) ? v[0] : v)}
          onValueCommitted={commitSlider}
        />
      </div>
    );
  }
  function toggle(
    k:
      | 'glow'
      | 'cover'
      | 'progress'
      | 'artist'
      | 'badge'
      | 'hidePaused'
      | 'moodSwitch'
      | 'spin'
      | 'scanlinesEnabled'
      | 'grainEnabled'
      | 'linkAccentColors'
      | 'autoAccentFromCover'
      | 'titleAccent'
      | 'visualizerVisible'
      | 'controlsVisible'
      | 'volumeVisible'
      | 'gameLevel'
      | 'gameRarity'
      | 'gameCombo'
      | 'gameQuest'
      | 'gameAchievements'
      | 'gameParty',
    label: string,
  ) {
    return (
      <div className="switch-row" key={k} data-field={k}>
        <label htmlFor={k}>{label}</label>
        <Switch
          id={k}
          checked={config[k]}
          onCheckedChange={(v) => update(k, v)}
        />
      </div>
    );
  }
  function renderLedPanel() {
    const ledHidden = !(config.ledVisible && config.ledBehavior !== 'off');
    return (
      <div className="context-transition">
        <div
          className={'led-preview' + (config.moodSwitch ? ' led-muted' : '')}
          data-led-preview="playing"
          data-led-behavior={
            config.ledVisible && config.ledBehavior !== 'off'
              ? config.ledBehavior
              : 'off'
          }
          style={
            {
              '--memory-led-user-color': config.ledColor,
              '--memory-led-user-brightness': config.ledBrightness / 100,
              '--memory-led-user-glow': config.ledGlow / 100,
              '--memory-led-user-speed':
                (8 - (config.ledSpeed / 100) * 5.5).toFixed(2) + 's',
            } as CSSProperties
          }
        >
          <div className="led-preview-stage">
            <i className="memory-led" />
          </div>
          <div className="led-preview-meta">
            <span className="led-preview-title">LED Preview</span>
            <span className="led-preview-behavior">
              {
                LED_BEHAVIOR_LABELS[
                  config.ledVisible && config.ledBehavior !== 'off'
                    ? config.ledBehavior
                    : 'off'
                ]
              }
            </span>
          </div>
        </div>
        <div
          className={'switch-row' + (config.moodSwitch ? ' led-muted' : '')}
          data-field="ledVisible"
        >
          <label htmlFor="ledVisible">LED sichtbar</label>
          <Switch
            id="ledVisible"
            checked={config.ledVisible && config.ledBehavior !== 'off'}
            onCheckedChange={(v) => {
              update('ledVisible', v);
              if (v && config.ledBehavior === 'off')
                update('ledBehavior', 'soft');
            }}
          />
        </div>
        <div
          className={
            'led-controls' +
            (config.moodSwitch || ledHidden ? ' led-muted' : '')
          }
        >
          <label className="color-field" data-field="ledColor">
            <span>LED-Farbe</span>
            <code>{config.ledColor}</code>
            <input
              aria-label="LED Farbe"
              type="color"
              value={config.ledColor}
              onChange={(e) => update('ledColor', e.target.value)}
            />
          </label>
          <Picker
            label="LED-Verhalten"
            field="ledBehavior"
            value={config.ledBehavior}
            options={[
              ['solid', 'Solid'],
              ['soft', 'Soft Pulse'],
              ['breathe', 'Breathe'],
              ['double', 'Double Pulse'],
              ['heartbeat', 'Heartbeat'],
              ['flicker', 'Flicker'],
            ]}
            onChange={(v) => update('ledBehavior', v)}
          />
          {range('ledBrightness', 'Helligkeit', 10, 100, '%')}
          {range('ledGlow', 'Glow', 0, 100, '%')}
          <div className="range-control" data-field="ledSpeed">
            <div className="range-label">
              <span>Tempo</span>
              <code>
                {config.ledSpeed <= 33
                  ? 'Slow'
                  : config.ledSpeed <= 66
                    ? 'Normal'
                    : 'Fast'}
              </code>
            </div>
            <Slider
              aria-label="LED Speed"
              value={[config.ledSpeed]}
              min={0}
              max={100}
              onValueChange={(v) =>
                update('ledSpeed', Array.isArray(v) ? v[0] : v)
              }
            />
          </div>
          <Disclosure title="Feinjustierung">
            {range('ledSize', 'Größe', 80, 120, '%')}
            {range('ledOffsetX', 'Horizontal', -8, 8, 'px')}
            {range('ledOffsetY', 'Vertikal', -8, 8, 'px')}
            <button
              type="button"
              className="context-reset"
              onClick={() =>
                setConfig((current) => ({
                  ...current,
                  ledSize: defaults.ledSize,
                  ledOffsetX: defaults.ledOffsetX,
                  ledOffsetY: defaults.ledOffsetY,
                }))
              }
            >
              LED-Position zurücksetzen
            </button>
          </Disclosure>
        </div>
        {config.moodSwitch && (
          <small className="led-hint">
            Solange Mood aktiv ist, steuert Mood die LED.
          </small>
        )}
      </div>
    );
  }
  function renderDisplayPanel() {
    return (
      <div className="context-transition">
        <div
          className={'led-controls' + (config.moodSwitch ? ' led-muted' : '')}
        >
          <label className="color-field" data-field="displayColor">
            <span>Display-Farbe</span>
            <code>{config.displayColor}</code>
            <input
              aria-label="Display Farbe"
              type="color"
              value={config.displayColor}
              onChange={(e) => update('displayColor', e.target.value)}
            />
          </label>
          {range('displayBrightness', 'Helligkeit', 20, 100, '%')}
          {range('textGlow', 'Text Glow', 0, 100, '%')}
          {toggle('scanlinesEnabled', 'Scanlines')}
          <div className={config.scanlinesEnabled ? '' : 'led-muted'}>
            {range('scanlineStrength', 'Scanline Stärke', 0, 100, '%')}
          </div>
          {toggle('grainEnabled', 'Grain')}
          <div className={config.grainEnabled ? '' : 'led-muted'}>
            {range('grainStrength', 'Grain Stärke', 0, 100, '%')}
          </div>
          {range('vignetteStrength', 'Vignette', 0, 100, '%')}
        </div>
        {config.moodSwitch && (
          <small className="led-hint">
            Solange Mood aktiv ist, steuert Mood das Display.
          </small>
        )}
      </div>
    );
  }
  function renderTypographyPanel(target: 'title' | 'artist' | 'meta') {
    const fontKey = `${target}Font` as 'titleFont' | 'artistFont' | 'metaFont';
    const weightKey = `${target}Weight` as
      | 'titleWeight'
      | 'artistWeight'
      | 'metaWeight';
    const sizeKey = `${target}Size` as 'titleSize' | 'artistSize' | 'metaSize';
    const lsKey = `${target}LetterSpacing` as
      | 'titleLetterSpacing'
      | 'artistLetterSpacing'
      | 'metaLetterSpacing';
    const caseKey = `${target}Case` as 'titleCase' | 'artistCase' | 'metaCase';
    const currentFont = config[fontKey] as string;
    const currentWeight = config[weightKey] as number;
    const currentFontDef = FONT_LIBRARY.find((f) => f.id === currentFont);
    const fontOptions: [string, string][] = [
      ...FONT_LIBRARY.map(
        (f) => [f.id, f.name + ' · ' + f.category] as [string, string],
      ),
      ...customFonts.map(
        (f) => ['custom:' + f.id, f.name + ' · Custom'] as [string, string],
      ),
    ];
    return (
      <>
        {canEdit(fontKey) && (
          <>
            <Picker
              label="Schrift"
              field={fontKey}
              value={currentFont}
              options={fontOptions}
              onChange={(v) => update(fontKey, v)}
            />
            <button
              type="button"
              className="upload-font-button"
              onClick={() => {
                setPendingUploadTarget(target);
                fileInputRef.current?.click();
              }}
            >
              <Plus size={13} />
              Custom Font hochladen
            </button>
            {uploading && <p className="upload-status">Uploading…</p>}
            {customFonts.length > 0 && (
              <div className="custom-font-list">
                <span className="custom-font-list-label">Eigene Fonts</span>
                {customFonts.map((f) => (
                  <div key={f.id} className="custom-font-row">
                    <span className="custom-font-name" title={f.name}>
                      {f.name}
                    </span>
                    <button
                      className="custom-font-delete"
                      aria-label={'Font löschen: ' + f.name}
                      onClick={() => requestDeleteFont(f.id, f.name)}
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
        {canEdit(weightKey) && (
          <Picker
            label="Stärke"
            field={weightKey}
            value={String(currentWeight)}
            options={(currentFontDef?.weights || [400]).map((w) => [
              String(w),
              String(w),
            ])}
            onChange={(v) => update(weightKey, Number(v))}
          />
        )}
        {canEdit(sizeKey) &&
          range(
            sizeKey,
            'Größe',
            target === 'title' ? 14 : target === 'artist' ? 10 : 8,
            target === 'title' ? 48 : 24,
            'px',
          )}
        {(canEdit(lsKey) || canEdit(caseKey)) && (
          <Disclosure title="Laufweite & Schreibweise">
            {canEdit(lsKey) && range(lsKey, 'Laufweite', -2, 6, 'px')}
            {canEdit(caseKey) && (
          <Picker
            label="Schreibweise"
            field={caseKey}
            value={config[caseKey] as string}
            options={[
              ['normal', 'Normal'],
              ['uppercase', 'UPPERCASE'],
            ]}
            onChange={(v) => update(caseKey, v)}
          />
            )}
          </Disclosure>
        )}
      </>
    );
  }
  function renderGlassMaterialPanel() {
    if (!isAfterglow(config) || !canEdit('glassHighlight')) return null;
    return (
      <div className="glass-material-editor">
        <div className="context-divider" />
        <div className="glass-material-head">
          <span>Afterglow Material</span>
          <small>OBS-sicheres Liquid Glass</small>
        </div>
        {range('glassHighlight', 'Lichtbrechung', 0, 100, '%')}
        <small className="context-note">
          Lichtbrechung entsteht aus lokalen Materialebenen. Der
          OBS-Hintergrund bleibt transparent sichtbar.
        </small>
      </div>
    );
  }
  function contextHead(icon: ReactNode, title: string, description: string) {
    return (
      <div className="context-panel-head">
        <span className="context-icon" aria-hidden="true">
          {icon}
        </span>
        <div>
          <small>DIREKT BEARBEITEN</small>
          <h3>{title}</h3>
          <p>{description}</p>
        </div>
      </div>
    );
  }
  function renderAccentField(label = 'Akzentfarbe') {
    return (
      <label className="color-field color-field-featured" data-field="accent">
        <span>{label}</span>
        <code>{config.accent}</code>
        <input
          aria-label={label}
          type="color"
          value={config.accent}
          onChange={(e) => update('accent', e.target.value)}
        />
      </label>
    );
  }
  function renderColorField(
    k: 'progressColor' | 'controlAccentColor' | 'statusAccentColor',
    label: string,
    muted = false,
  ) {
    return (
      <label
        className={
          'color-field color-field-featured' + (muted ? ' led-muted' : '')
        }
        data-field={k}
      >
        <span>{label}</span>
        <code>{config[k]}</code>
        <input
          aria-label={label}
          type="color"
          value={config[k]}
          onChange={(e) => update(k, e.target.value)}
        />
      </label>
    );
  }
  const selectedVisibilityField = selectedElement
    ? VISIBILITY_FIELD[selectedElement]
    : undefined;
  const selectedHidden =
    !!selectedVisibilityField &&
    canEdit(selectedVisibilityField) &&
    !config[selectedVisibilityField];
  const panelTitle = selectedElement
    ? CHIP_NAMES[selectedElement] || EDITOR_NAMES[selectedElement]
    : 'Player';
  const showTip = !tipDismissed && !selectedElement;
  const essentialsDone = (connected ? 1 : 0) + (key ? 1 : 0);
  function applyPreset(p: (typeof presets)[number]) {
    setSelectedElement(null);
    setConfig({
      ...p.config,
      moodSwitch: config.moodSwitch,
      moodIntensity: config.moodIntensity,
    });
  }
  function loadLook(look: CustomLook) {
    setConfig(look.config);
    setSelectedElement(null);
    setMessage(
      `${look.name} geladen. Speichern, damit er live in OBS erscheint.`,
    );
  }
  function miniPreview(c: Config, small = false) {
    const width = c.layout === 'memory' ? 520 : c.width;
    return (
      <div
        className={'v2-mini-stage' + (small ? ' is-small' : '')}
        aria-hidden="true"
      >
        <div
          style={
            { zoom: (small ? 150 : 240) / Math.max(280, width) } as CSSProperties
          }
        >
          <Overlay
            config={{ ...c, animation: 'none', autoAccentFromCover: false }}
            track={{ ...demo, playing: true }}
          />
        </div>
      </div>
    );
  }
  function renderStatus() {
    return (
      <div className="status-area" aria-live="polite">
        {error && (
          <p className="error-message">
            {error}
            <button
              type="button"
              aria-label="Meldung schließen"
              onClick={() => setError('')}
            >
              <X size={14} />
            </button>
          </p>
        )}
        {message && (
          <p className="success-message">
            {message}
            <button
              type="button"
              aria-label="Meldung schließen"
              onClick={() => setMessage('')}
            >
              <X size={14} />
            </button>
          </p>
        )}
      </div>
    );
  }
  function renderSaveLookForm(compact: boolean) {
    return (
      <form
        className={'v2-save-look-form' + (compact ? ' is-compact' : '')}
        onSubmit={(e) => {
          e.preventDefault();
          void saveLook().then(() => setSaveLookOpen(false));
        }}
      >
        <input
          value={lookName}
          maxLength={50}
          autoFocus={compact}
          aria-label="Name für deinen Look"
          placeholder="Name, z. B. Midnight Purple"
          onChange={(e) => setLookName(e.target.value)}
        />
        <button type="submit" className="primary" disabled={!lookName.trim()}>
          Speichern
        </button>
        {compact && (
          <button
            type="button"
            className="v2-icon-btn"
            aria-label="Abbrechen"
            onClick={() => setSaveLookOpen(false)}
          >
            <X size={15} />
          </button>
        )}
      </form>
    );
  }
  function renderPlayerPanel() {
    return (
      <>
        {moodMode !== 'none' && (
          <div className="mood-card">
            <div className="mood-title" data-field="moodSwitch">
              <Sparkles size={17} />
              <label htmlFor="moodSwitch">Mood Switch</label>
              <Switch
                id="moodSwitch"
                checked={config.moodSwitch}
                onCheckedChange={(v) => update('moodSwitch', v)}
              />
            </div>
            <p>Dein Look fühlt mit. Farben folgen dem Song.</p>
            {config.moodSwitch && (
              <>
                {!moodSetupDismissed &&
                  (!lastfmConfigured || !geniusConfigured) && (
                    <div className="mood-setup-hint">
                      <b>Genauere Erkennung</b>
                      <p>
                        Last.fm {lastfmConfigured ? '✓' : '· nicht verbunden'}{' '}
                        · Genius {geniusConfigured ? '✓' : '· optional'}
                      </p>
                      <button onClick={openMoodSettings}>Einrichten</button>
                      <button onClick={() => setMoodSetupDismissed(true)}>
                        Später
                      </button>
                    </div>
                  )}
                <div
                  className="mood-result"
                  style={{ borderColor: detected?.mood.accent || '#54634b' }}
                >
                  <b>
                    {detected ? detected.mood.label : 'Dein Original-Look'}
                  </b>
                  <span>
                    {detected
                      ? 'Geschätzt aus ' +
                        detected.source +
                        ' · ' +
                        detected.confidence
                      : 'Kein klares Stimmungssignal'}
                  </span>
                </div>
                {range('moodIntensity', 'Intensität', 0, 100, '%')}
                {demoMode && (
                  <button
                    className="secondary"
                    onClick={() =>
                      setDemoIndex((i) => (i + 1) % moodDemos.length)
                    }
                  >
                    <RefreshCw size={13} />
                    Nächsten Demo-Mood testen
                  </button>
                )}
                <button className="text-button" onClick={openMoodSettings}>
                  Mood-Quellen verwalten
                </button>
              </>
            )}
          </div>
        )}
        <Section title="Farbe">
          <div className="swatches" data-field="accent">
            {['#b3f47c', '#c1a0ff', '#ffac75', '#71d6ff', '#fb88bd', '#ffffff'].map(
              (c) => (
                <button
                  key={c}
                  aria-label={'Akzent ' + c}
                  onClick={() => update('accent', c)}
                  style={{ background: c }}
                  className={c === config.accent ? 'chosen' : ''}
                >
                  {c === config.accent && <Check size={15} />}
                </button>
              ),
            )}
          </div>
          {canEdit('accent') && renderAccentField('Akzentfarbe')}
          {canEdit('accent') && toggle('autoAccentFromCover', 'Akzent aus Albumcover')}
          {config.autoAccentFromCover && (
            <small className="context-note">
              Folgt dem aktuellen Cover. Die Farbe oben bleibt Fallback.
            </small>
          )}
          {canEdit('linkAccentColors') && (
            <>
              {toggle('linkAccentColors', 'Akzente koppeln')}
              <small className="context-note">
                Ein Akzent für Tasten, Fortschritt und Status.
              </small>
            </>
          )}
          {canEdit('background') && !isAfterglow(config) && (
            <label className="color-field" data-field="background">
              <span>{config.layout === 'memory' ? 'Gehäusefarbe' : 'Hintergrund'}</span>
              <code>{config.background}</code>
              <input
                aria-label="Hintergrundfarbe"
                type="color"
                value={config.background}
                onChange={(e) => update('background', e.target.value)}
              />
            </label>
          )}
          {canEdit('text') && (
            <label className="color-field" data-field="text">
              <span>Textfarbe</span>
              <code>{config.text}</code>
              <input
                aria-label="Textfarbe"
                type="color"
                value={config.text}
                onChange={(e) => update('text', e.target.value)}
              />
            </label>
          )}
        </Section>
        <Section title="Form">
          {canEdit('width') && range('width', 'Breite', 280, 900, 'px')}
          {canEdit('spacing') && range('spacing', 'Innenabstand', 8, 48, 'px')}
          {canEdit('radius') && range('radius', 'Rundung', 0, 40, 'px')}
          {canEdit('opacity') &&
            !isAfterglow(config) &&
            range('opacity', 'Deckkraft', 0, 100, '%')}
          {canEdit('glow') &&
            config.layout !== 'memory' &&
            toggle('glow', 'Sanfter Glow')}
          {canEdit('align') && (
            <Picker
              label="Textausrichtung"
              field="align"
              value={config.align}
              options={[
                ['left', 'Links'],
                ['center', 'Zentriert'],
              ]}
              onChange={(v) => update('align', v)}
            />
          )}
          {renderGlassMaterialPanel()}
          {canEdit('bodyStyle') && BODY_STYLES[config.layout] && (
            <Picker
              label="Gehäuse"
              field="bodyStyle"
              value={config.bodyStyle}
              options={BODY_STYLES[config.layout]}
              onChange={(v) => update('bodyStyle', v)}
            />
          )}
        </Section>
        {canEdit('gameLevel') && (
          <Section title="Spielmechanik">
            {toggle('gameLevel', 'Level & Level-up')}
            {toggle('gameRarity', 'Seltenheit am Cover')}
            {toggle('gameCombo', 'Combo-Zähler')}
            {toggle('gameQuest', 'Quests')}
            {toggle('gameAchievements', 'Erfolge')}
            {toggle('gameParty', 'Party (letzte Songs)')}
            <small className="context-note">
              Alles aus echten Wiedergabedaten: Lieblingssong = legendär,
              beobachtete Playlist = episch. Fortschritt gilt pro Stream und
              setzt sich nach 12 Stunden Pause zurück.
            </small>
          </Section>
        )}
        <Section title="Songwechsel">
          <Picker
            label="Übergang"
            field="animation"
            value={config.animation}
            options={[
              ['fade', 'Sanft einblenden'],
              ['slide', 'Hineingleiten'],
              ['zoom', 'Pop-in'],
              ['blur', 'Aus der Unschärfe'],
              ['flip', '3D-Flip'],
              ['none', 'Ohne Animation'],
            ]}
            onChange={(v) => update('animation', v)}
          />
          {toggle('hidePaused', 'Bei Pause ausblenden')}
        </Section>
        {config.layout === 'memory' && (
          <Disclosure title="Beobachtete Playlist">
            <div className="playlist-picker" data-field="observedPlaylistId">
              <span>Playlist</span>
              <Select
                value={config.observedPlaylistId}
                onValueChange={(v) => {
                  if (!v || v === '__none__') {
                    update('observedPlaylistId', '');
                    update('observedPlaylistName', '');
                  } else {
                    const p = playlists.find((p) => p.id === v);
                    update('observedPlaylistId', v);
                    update('observedPlaylistName', p?.name || '');
                  }
                }}
              >
                <SelectTrigger aria-label="Observed Playlist">
                  <SelectValue>
                    {config.observedPlaylistId
                      ? playlists.find(
                          (p) => p.id === config.observedPlaylistId,
                        )?.name || config.observedPlaylistName
                      : 'Keine Playlist'}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">Keine Playlist</SelectItem>
                  {playlists.map((p) => (
                    <SelectItem
                      key={p.id}
                      value={p.id}
                      disabled={!canObserve(p)}
                    >
                      {p.image && (
                        <img src={p.image} alt="" className="playlist-cover" />
                      )}
                      {p.name}
                      {!canObserve(p) && (
                        <Lock size={12} className="playlist-access-mark" />
                      )}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {!connected && (
                <small>Verbinde Spotify, um eine Playlist auszuwählen.</small>
              )}
              {config.observedPlaylistId &&
                selectedObserved &&
                !canObserve(selectedObserved) && (
                  <small className="playlist-access-warn">
                    Nur eigene oder gemeinsame Playlists können beobachtet
                    werden.
                  </small>
                )}
              {track?.playlistAccess === 'denied' && (
                <small className="playlist-access-warn">
                  Kein Zugriff auf diese Playlist.
                </small>
              )}
              {track?.playlistAccess === 'rate_limited' && (
                <small className="playlist-access-warn">
                  Spotify-Limit erreicht – der Status aktualisiert sich
                  automatisch.
                </small>
              )}
              <div className="playlist-api-hint">
                <Info size={13} className="playlist-api-hint-icon" />
                <span>
                  Der Memory Slot fragt Spotify häufiger ab. Erreicht Spotify
                  sein Limit, pausiert nur die Gold-Markierung kurz – deine
                  Verbindung bleibt bestehen.
                </span>
              </div>
            </div>
          </Disclosure>
        )}
        {isAfterglow(config) && (
          <Disclosure title="Enhanced Blur für OBS">
            <section className="afterglow-blur-card">
              <p>
                Optional. Afterglow funktioniert bereits als transparentes Glas
                – für echte Hintergrundunschärfe richtest du Composite Blur
                1.5.2 und den Blur Companion ein.
              </p>
              <div className="afterglow-blur-actions">
                <a href="/api/downloads/resonance-blur-follow" download>
                  <Download size={14} aria-hidden="true" />
                  Blur Companion herunterladen
                </a>
                <button
                  type="button"
                  disabled={!key || dirty}
                  title={
                    !key
                      ? 'Masken-URL wird vorbereitet.'
                      : dirty
                        ? 'Speichere dein Design vor dem Kopieren.'
                        : 'Masken-URL kopieren'
                  }
                  onClick={() => copy(afterglowMaskUrl)}
                >
                  <Copy size={14} aria-hidden="true" />
                  Masken-URL kopieren
                </button>
              </div>
              <details className="afterglow-blur-guide">
                <summary>Einrichtung anzeigen</summary>
                <ol>
                  <li>Composite Blur 1.5.2 installieren.</li>
                  <li>
                    <code>resonance-blur-follow.lua</code> herunterladen und in
                    OBS unter <b>Werkzeuge → Skripte</b> hinzufügen.
                  </li>
                  <li>
                    Eine Browser-Quelle <b>Resonance Afterglow Mask</b>{' '}
                    hinzufügen, die kopierte Masken-URL einsetzen und die Größe
                    auf die OBS-Basisleinwand stellen.
                  </li>
                  <li>
                    Eine Szene <b>Resonance Blur Layer</b> erstellen.
                  </li>
                  <li>
                    Eine Referenz oder ein Duplikat des Game-/Backgrounds
                    hineinlegen.
                  </li>
                  <li>
                    Den Blur Layer in der Gaming-Szene direkt unter das normale
                    Resonance-Overlay legen.
                  </li>
                  <li>
                    Composite Blur auf den Blur Layer anwenden: Algorithmus{' '}
                    <b>Dual Kawase</b>, Effect Mask <b>Source</b>, Mask Source{' '}
                    <b>Resonance Afterglow Mask</b>, Channel <b>Alpha</b>.
                  </li>
                  <li>
                    Die Mask Source muss aktiviert bleiben. Lege sie unter das
                    normale Game-/Background, damit die weiße Maske unsichtbar
                    bleibt.
                  </li>
                  <li>
                    Das normale Resonance-Overlay frei bewegen und skalieren;
                    das Lua-Skript synchronisiert Position und Skalierung.
                  </li>
                </ol>
              </details>
            </section>
          </Disclosure>
        )}
      </>
    );
  }
  function renderElementPanel(sel: string) {
    if (sel === 'led') return renderLedPanel();
    if (sel === 'display') return renderDisplayPanel();
    if (sel === 'title')
      return (
        <div className="context-transition">
          {renderTypographyPanel('title')}
          {config.layout !== 'memory' &&
            toggle('titleAccent', 'Titel in Akzentfarbe')}
          {(canEdit('titleOffsetX') ||
            canEdit('titleOffsetY') ||
            canEdit('titleArtistSpacing')) && (
            <Disclosure title="Feinjustierung">
              {canEdit('titleOffsetX') &&
                range('titleOffsetX', 'Horizontal', -8, 8, 'px')}
              {canEdit('titleOffsetY') &&
                range('titleOffsetY', 'Vertikal', -6, 6, 'px')}
              {canEdit('titleArtistSpacing') &&
                range(
                  'titleArtistSpacing',
                  'Abstand zum Interpreten',
                  0,
                  8,
                  'px',
                )}
              <button
                type="button"
                className="context-reset"
                onClick={() =>
                  setConfig((current) => ({
                    ...current,
                    titleOffsetX: defaults.titleOffsetX,
                    titleOffsetY: defaults.titleOffsetY,
                  }))
                }
              >
                Titel-Position zurücksetzen
              </button>
            </Disclosure>
          )}
        </div>
      );
    if (sel === 'artist')
      return (
        <div className="context-transition">
          {renderTypographyPanel('artist')}
          {(canEdit('artistOffsetX') || canEdit('artistOffsetY')) && (
            <Disclosure title="Feinjustierung">
              {canEdit('artistOffsetX') &&
                range('artistOffsetX', 'Horizontal', -8, 8, 'px')}
              {canEdit('artistOffsetY') &&
                range('artistOffsetY', 'Vertikal', -6, 6, 'px')}
              <button
                type="button"
                className="context-reset"
                onClick={() =>
                  setConfig((current) => ({
                    ...current,
                    artistOffsetX: defaults.artistOffsetX,
                    artistOffsetY: defaults.artistOffsetY,
                  }))
                }
              >
                Interpret-Position zurücksetzen
              </button>
            </Disclosure>
          )}
        </div>
      );
    if (sel === 'display-meta')
      return (
        <div className="context-transition">
          {renderTypographyPanel('meta')}
          {canEdit('statusAccentColor') && (
            <>
              {renderColorField(
                'statusAccentColor',
                'Status-Akzent',
                config.linkAccentColors,
              )}
              {config.linkAccentColors && (
                <small className="context-note">
                  Folgt dem gekoppelten Akzent (Player → Akzente koppeln).
                </small>
              )}
            </>
          )}
          {(canEdit('metaOffsetX') || canEdit('metaOffsetY')) && (
            <Disclosure title="Feinjustierung">
              {canEdit('metaOffsetX') &&
                range('metaOffsetX', 'Horizontal', -8, 8, 'px')}
              {canEdit('metaOffsetY') &&
                range('metaOffsetY', 'Vertikal', -6, 6, 'px')}
              <button
                type="button"
                className="context-reset"
                onClick={() =>
                  setConfig((current) => ({
                    ...current,
                    metaOffsetX: defaults.metaOffsetX,
                    metaOffsetY: defaults.metaOffsetY,
                  }))
                }
              >
                Status-Position zurücksetzen
              </button>
            </Disclosure>
          )}
        </div>
      );
    if (sel === 'progress')
      return (
        <div className="context-transition">
          {canEdit('progressColor') ? (
            <>
              {renderColorField(
                'progressColor',
                'Farbe',
                config.linkAccentColors,
              )}
              {config.linkAccentColors && (
                <small className="context-note">
                  Folgt dem gekoppelten Akzent (Player → Akzente koppeln).
                </small>
              )}
            </>
          ) : (
            <small className="context-note">
              Die Farbe folgt dem Akzent des Players.
            </small>
          )}
          {canEdit('progressEdge') &&
            range('progressEdge', 'Lichtkante', 0, 100, '%')}
          {(canEdit('progressWidth') ||
            canEdit('progressThickness') ||
            canEdit('progressOffsetX') ||
            canEdit('progressOffsetY') ||
            canEdit('progressRadius')) && (
            <Disclosure title="Feinjustierung">
              {canEdit('progressWidth') &&
                range('progressWidth', 'Breite', 84, 100, '%')}
              {canEdit('progressThickness') &&
                range('progressThickness', 'Stärke', 72, 128, '%')}
              {canEdit('progressOffsetX') &&
                range('progressOffsetX', 'Horizontal', -6, 6, 'px')}
              {canEdit('progressOffsetY') &&
                range('progressOffsetY', 'Vertikal', -5, 5, 'px')}
              {canEdit('progressRadius') &&
                range('progressRadius', 'Rundung', 0, 12, 'px')}
              <button
                type="button"
                className="context-reset"
                onClick={() =>
                  setConfig((current) => ({
                    ...current,
                    progressWidth: defaults.progressWidth,
                    progressThickness: defaults.progressThickness,
                    progressOffsetX: defaults.progressOffsetX,
                    progressOffsetY: defaults.progressOffsetY,
                    progressRadius: defaults.progressRadius,
                  }))
                }
              >
                Fortschritt zurücksetzen
              </button>
            </Disclosure>
          )}
        </div>
      );
    if (sel === 'controls' && canEdit('controlsVisible'))
      return (
        <div className="context-transition">
          {toggle('controlsVisible', 'Tasten anzeigen')}
          {canEdit('volumeVisible') &&
            toggle('volumeVisible', 'Lautstärke anzeigen')}
          <small className="context-note">
            Die Tasten sind Deko im Stream – Spotify wird nicht ferngesteuert.
          </small>
        </div>
      );
    if (sel === 'visualizer')
      return (
        <div className="context-transition">
          <Section title="Farbe">
            <div className="switch-row" data-field="visualizerColor">
              <label htmlFor="visualizerAccent">Akzentfarbe nutzen</label>
              <Switch
                id="visualizerAccent"
                checked={!config.visualizerColor}
                onCheckedChange={(v) =>
                  update('visualizerColor', v ? '' : config.accent)
                }
              />
            </div>
            {!!config.visualizerColor && (
              <label className="color-field" data-field="visualizerColor">
                <span>Visualizer-Farbe</span>
                <code>{config.visualizerColor}</code>
                <input
                  aria-label="Visualizer-Farbe"
                  type="color"
                  value={config.visualizerColor}
                  onChange={(e) => update('visualizerColor', e.target.value)}
                />
              </label>
            )}
          </Section>
          <Section title="Position">
            <Picker
              label="Position"
              field="visualizerPosition"
              value={config.visualizerPosition}
              options={[
                ['right', 'Im Display oben rechts'],
                ['bottom', 'Im Display unten, breit'],
              ]}
              onChange={(v) => update('visualizerPosition', v)}
            />
          </Section>
        </div>
      );
    if (sel === 'controls')
      return (
        <div className="context-transition">
          {renderColorField(
            'controlAccentColor',
            'Tasten-Akzent',
            config.linkAccentColors,
          )}
          {config.linkAccentColors && (
            <small className="context-note">
              Folgt dem gekoppelten Akzent (Player → Akzente koppeln).
            </small>
          )}
          {canEdit('glow') && toggle('glow', 'Sanfter Tastenglow')}
          <Disclosure title="Feinjustierung">
            {range('controlsSize', 'Tastengröße', 85, 115, '%')}
            {range('controlsIconSize', 'Icongröße', 80, 120, '%')}
            {range('controlsGap', 'Abstand', 70, 140, '%')}
            {range('controlsOffsetX', 'Horizontal', -8, 8, 'px')}
            {range('controlsOffsetY', 'Vertikal', -6, 6, 'px')}
            <button
              type="button"
              className="context-reset"
              onClick={() =>
                setConfig((current) => ({
                  ...current,
                  controlsSize: defaults.controlsSize,
                  controlsIconSize: defaults.controlsIconSize,
                  controlsGap: defaults.controlsGap,
                  controlsOffsetX: defaults.controlsOffsetX,
                  controlsOffsetY: defaults.controlsOffsetY,
                }))
              }
            >
              Tasten zurücksetzen
            </button>
          </Disclosure>
          <small className="context-note">
            Die Tasten sind Deko im Stream – Spotify wird nicht ferngesteuert.
          </small>
        </div>
      );
    if (sel === 'cover')
      return (
        <div className="context-transition">
          {canEdit('coverFilter') && (
            <Section title="Filter">
              <div className="v2-filter-grid" data-field="coverFilter">
                {Object.entries(COVER_FILTERS).map(([id, f]) => (
                  <button
                    type="button"
                    key={id}
                    className={config.coverFilter === id ? 'active' : ''}
                    aria-pressed={config.coverFilter === id}
                    onClick={() => update('coverFilter', id)}
                  >
                    <span
                      className="v2-filter-swatch"
                      style={{ filter: f.css }}
                      aria-hidden="true"
                    />
                    {f.label}
                  </button>
                ))}
              </div>
            </Section>
          )}
          {(canEdit('coverBrightness') ||
            canEdit('coverSaturation') ||
            canEdit('coverContrast')) && (
            <Section title="Bild">
              {canEdit('coverBrightness') &&
                range('coverBrightness', 'Helligkeit', 40, 140, '%')}
              {canEdit('coverSaturation') &&
                range('coverSaturation', 'Sättigung', 0, 150, '%')}
              {canEdit('coverContrast') &&
                range('coverContrast', 'Kontrast', 60, 140, '%')}
            </Section>
          )}
          {canEdit('spin') && (
            <Section title="Bewegung">
              {toggle('spin', 'Cover drehen')}
              {config.spin && range('spinSpeed', 'Eine Umdrehung', 4, 40, 's')}
            </Section>
          )}
          {(canEdit('coverSize') ||
            canEdit('coverOffsetX') ||
            canEdit('coverOffsetY') ||
            canEdit('coverRadius') ||
            canEdit('coverFit')) && (
            <Disclosure title="Feinjustierung">
              {canEdit('coverSize') && range('coverSize', 'Größe', 84, 116, '%')}
              {canEdit('coverOffsetX') &&
                range('coverOffsetX', 'Horizontal', -8, 8, 'px')}
              {canEdit('coverOffsetY') &&
                range('coverOffsetY', 'Vertikal', -8, 8, 'px')}
              {canEdit('coverRadius') &&
                range('coverRadius', 'Eckenrundung', 0, 16, 'px')}
              {canEdit('coverFit') && (
                <Picker
                  label="Bildanpassung"
                  field="coverFit"
                  value={config.coverFit}
                  options={[
                    ['cover', 'Füllen'],
                    ['contain', 'Ganz zeigen'],
                  ]}
                  onChange={(v) => update('coverFit', v)}
                />
              )}
              <button
                type="button"
                className="context-reset"
                onClick={() =>
                  setConfig((current) => ({
                    ...current,
                    coverSize: defaults.coverSize,
                    coverOffsetX: defaults.coverOffsetX,
                    coverOffsetY: defaults.coverOffsetY,
                    coverRadius: defaults.coverRadius,
                    coverFit: defaults.coverFit,
                  }))
                }
              >
                Cover zurücksetzen
              </button>
            </Disclosure>
          )}
          {!canEdit('coverBrightness') && !canEdit('spin') && (
            <small className="context-note">
              Das Artwork folgt automatisch dem aktuellen Song. Ein- und
              ausblenden über das Auge oben.
            </small>
          )}
        </div>
      );
    if (sel === 'note')
      return (
        <div className="context-transition">
          <label
            className="memory-label-editor context-label-editor"
            data-field="memoryLabel"
          >
            <span>Text auf der Notiz</span>
            <input
              value={config.memoryLabel}
              maxLength={32}
              placeholder="GOOD MUSIC BETTER DAYS."
              onChange={(e) => update('memoryLabel', e.target.value)}
            />
            <small>Leer lassen, um die Notiz auszublenden.</small>
          </label>
          <Disclosure title="Feinjustierung">
            {range('noteSize', 'Größe', 88, 112, '%')}
            {range('noteOffsetX', 'Horizontal', -8, 8, 'px')}
            {range('noteOffsetY', 'Vertikal', -8, 8, 'px')}
            {range('noteRotation', 'Drehung', -6, 6, '°')}
            {range('noteOpacity', 'Deckkraft', 55, 100, '%')}
            <button
              type="button"
              className="context-reset"
              onClick={() =>
                setConfig((current) => ({
                  ...current,
                  noteSize: defaults.noteSize,
                  noteOffsetX: defaults.noteOffsetX,
                  noteOffsetY: defaults.noteOffsetY,
                  noteRotation: defaults.noteRotation,
                  noteOpacity: defaults.noteOpacity,
                }))
              }
            >
              Notiz zurücksetzen
            </button>
          </Disclosure>
        </div>
      );
    return null;
  }
  return (
    <main className="studio v2">
      <input
        ref={fileInputRef}
        type="file"
        accept=".woff2,.woff,.ttf,.otf"
        style={{ display: 'none' }}
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = '';
          if (file && pendingUploadTarget) {
            void uploadFont(file, pendingUploadTarget);
          }
          setPendingUploadTarget(null);
        }}
      />
      <header className="topbar v2-topbar">
        <a className="brand" href="/">
          <AudioLines />
          <span>
            resonance<span className="brand-dot">.</span>
          </span>
        </a>
        <nav className="v2-nav" aria-label="Bereiche">
          {(
            [
              ['studio', 'Studio'],
              ['looks', 'Looks'],
              ['setup', 'Setup'],
            ] as const
          ).map(([v, l]) => (
            <button
              key={v}
              type="button"
              className={view === v ? 'active' : ''}
              aria-current={view === v ? 'page' : undefined}
              onClick={() => setView(v)}
            >
              {l}
              {v === 'setup' && !setupComplete && (
                <i className="v2-nav-dot" aria-label="Setup offen" />
              )}
            </button>
          ))}
        </nav>
        <div className="top-actions">
          <span className="demo-badge">
            <i className={connected ? 'is-connected' : ''} />
            {connected ? 'Spotify verbunden' : 'Demo-Modus'}
          </span>
          <button className="primary" onClick={() => setModal('obs')}>
            Ab in OBS <ArrowUpRight size={16} />
          </button>
        </div>
      </header>
      {view === 'studio' && (
        <div className="workspace v2-workspace">
          <section className="v2-stage-column">
            <div className="v2-stage-toolbar">
              <span className="v2-stage-name">
                {chosenName || 'Eigener Stil'}
                <small>{config.width} px</small>
              </span>
              <div className="canvas-modes" role="group" aria-label="Hintergrund der Vorschau">
                {[
                  ['ambient', 'Stream'],
                  ['checker', 'Transparent'],
                  ['light', 'Hell'],
                ].map(([v, l]) => (
                  <button
                    key={v}
                    aria-pressed={canvas === v}
                    className={canvas === v ? 'active' : ''}
                    onClick={() => setCanvas(v)}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>
            <div
              ref={preview}
              data-selected={selectedElement || undefined}
              className={
                'preview-canvas canvas-' +
                canvas +
                ' allow-motion editor-selecting'
              }
              onClick={(e) => {
                const t = e.target as HTMLElement;
                for (const [name, sel] of editorTargets) {
                  if (name === 'device') continue;
                  if (t.closest(sel)) {
                    setSelectedElement(name);
                    return;
                  }
                }
                // Leere Fläche im Player oder daneben: ganzer Player.
                setSelectedElement(null);
              }}
            >
              <div className="v2-stage-hint" aria-hidden="true">
                <span className="v2-stage-hint-icon">
                  <MousePointer2 size={12} />
                </span>
                {selectedElement
                  ? 'Du bearbeitest: ' +
                    panelTitle +
                    ' · daneben klicken = ganzer Player'
                  : 'Klick auf irgendwas im Player'}
              </div>
              <div
                style={
                  {
                    zoom: Math.min(1, (canvasWidth - 50) / config.width),
                  } as CSSProperties
                }
              >
                <Overlay config={config} track={shown} />
              </div>
              {markerRect && (
                <div
                  className="editor-selection"
                  data-label={panelTitle}
                  style={{
                    top: markerRect.top,
                    left: markerRect.left,
                    width: markerRect.width,
                    height: markerRect.height,
                  }}
                >
                  <i className="corner tl" />
                  <i className="corner tr" />
                  <i className="corner bl" />
                  <i className="corner br" />
                </div>
              )}
              {!shown && (
                <div className="empty-track">
                  <Music2 />
                  <b>Bereit für deinen nächsten Track.</b>
                  <span>Starte einen Song in Spotify oder sieh dir die Demo an.</span>
                </div>
              )}
              {shown && !shown.playing && config.hidePaused && (
                <div className="empty-track">
                  <Pause />
                  <span>Bei Pause ausgeblendet.</span>
                </div>
              )}
            </div>
            <div className="canvas-bottom v2-canvas-bottom">
              <div className="preview-play">
                <button
                  onClick={() =>
                    demoMode ? setDemoPlaying(!demoPlaying) : setDemoMode(true)
                  }
                  aria-label={
                    demoMode
                      ? demoPlaying
                        ? 'Demo pausieren'
                        : 'Demo abspielen'
                      : 'Demo anzeigen'
                  }
                >
                  {demoMode && demoPlaying ? (
                    <Pause size={14} />
                  ) : (
                    <Play size={14} />
                  )}
                </button>
                <span>{demoMode ? 'Demo' : 'Spotify live'}</span>
                {connected && (
                  <button
                    className={!demoMode ? 'live-active' : ''}
                    onClick={() => setDemoMode(!demoMode)}
                  >
                    {demoMode ? 'Live ansehen' : 'Demo ansehen'}
                  </button>
                )}
              </div>
              <button
                type="button"
                className="v2-ghost"
                onClick={() => {
                  setDemoMode(true);
                  setDemoIndex((i) => (i + 1) % moodDemos.length);
                }}
              >
                <RefreshCw size={13} />
                Songwechsel testen
              </button>
            </div>
            <section className="v2-styles-strip" aria-label="Stile">
              <div className="v2-looks-strip-head">
                <b>Stile</b>
                <span className="v2-strip-hint">Klick zum Ausprobieren · speichern macht ihn live</span>
              </div>
              <div className="preset-grid v2-preset-grid">
                {presets.map((p) => {
                  const active = isActivePreset(p);
                  return (
                    <button
                      type="button"
                      key={p.id}
                      data-preset={p.name}
                      className={'preset' + (active ? ' selected' : '')}
                      aria-pressed={active}
                      onClick={() => {
                        applyPreset(p);
                        setView('studio');
                      }}
                    >
                      <div className={'preset-art art-' + p.id} aria-hidden="true">
                        <div className="mini-chrome">
                          <i />
                          <i />
                          <i />
                        </div>
                        <span className="mini-cover" />
                        <span className="mini-lines">
                          <b />
                          <i />
                          <em />
                        </span>
                        {p.id === 'sticker' && <span className="mini-star">✦</span>}
                      </div>
                      <div className="v2-preset-name">
                        <span>{p.name}</span>
                        {active ? <Check size={14} /> : <ArrowUpRight size={14} />}
                      </div>
                      <p>{p.note}</p>
                    </button>
                  );
                })}
              </div>
            </section>
            <section className="v2-looks-strip" aria-label="Deine Looks">
              <div className="v2-looks-strip-head">
                <b>Deine Looks</b>
                <button
                  type="button"
                  className="v2-ghost"
                  onClick={() => setView('looks')}
                >
                  Alle Looks <ArrowUpRight size={13} />
                </button>
              </div>
              <div className="v2-looks-strip-row">
                {saveLookOpen ? (
                  renderSaveLookForm(true)
                ) : (
                  <button
                    type="button"
                    className="v2-save-look"
                    onClick={() => setSaveLookOpen(true)}
                  >
                    <Plus size={15} />
                    Als Look speichern
                  </button>
                )}
                {customLooks.map((look) => {
                  const live = look.id === activeLiveLookId;
                  return (
                    <button
                      type="button"
                      key={look.id}
                      className={'v2-look-chip' + (live ? ' is-live' : '')}
                      title={
                        look.pinned
                          ? 'Live Look – Laden in den Editor'
                          : 'In den Editor laden'
                      }
                      onClick={() => loadLook(look)}
                    >
                      {look.pinned ? (
                        <Star size={12} fill="currentColor" aria-hidden="true" />
                      ) : null}
                      {look.name}
                      {live && <i className="v2-live-dot" aria-label="live" />}
                    </button>
                  );
                })}
                {customLooks.length === 0 && !saveLookOpen && (
                  <span className="v2-strip-empty">
                    Noch keine Looks – speichere deinen ersten.
                  </span>
                )}
              </div>
            </section>
            {renderStatus()}
          </section>
          <aside className="inspector v2-inspector" ref={inspector} data-inspector="">
            <div className="v2-inspector-head">
              <div className="v2-inspector-title">
                {selectedElement && (
                  <button
                    type="button"
                    className="v2-icon-btn"
                    onClick={() => setSelectedElement(null)}
                    aria-label="Zurück zum ganzen Player"
                  >
                    <ChevronLeft size={16} />
                  </button>
                )}
                <span>
                  <small>{selectedElement ? 'Ausgewählt' : 'Gesamter Look'}</small>
                  <b>{panelTitle}</b>
                </span>
              </div>
              {selectedVisibilityField && canEdit(selectedVisibilityField) && (
                <button
                  type="button"
                  className={'v2-eye' + (selectedHidden ? ' is-hidden' : '')}
                  data-field={selectedVisibilityField}
                  aria-pressed={!selectedHidden}
                  onClick={() =>
                    update(selectedVisibilityField, !config[selectedVisibilityField])
                  }
                >
                  {selectedHidden ? <EyeOff size={14} /> : <Eye size={14} />}
                  {selectedHidden ? 'Ausgeblendet' : 'Sichtbar'}
                </button>
              )}
            </div>
            <div className="v2-chips" role="tablist" aria-label="Element wählen">
              <button
                type="button"
                role="tab"
                aria-selected={!selectedElement}
                className={!selectedElement ? 'active' : ''}
                onClick={() => setSelectedElement(null)}
              >
                Player
              </button>
              {editorElements.map((el) => {
                const vis = VISIBILITY_FIELD[el];
                const hidden = !!vis && canEdit(vis) && !config[vis];
                return (
                  <button
                    type="button"
                    role="tab"
                    key={el}
                    aria-selected={selectedElement === el}
                    className={
                      (selectedElement === el ? 'active' : '') +
                      (hidden ? ' is-hidden' : '')
                    }
                    onClick={() => setSelectedElement(el)}
                  >
                    {CHIP_NAMES[el] || EDITOR_NAMES[el]}
                  </button>
                );
              })}
            </div>
            <div className="v2-inspector-body">
              {showTip && (
                <div className="v2-tip">
                  <span className="v2-tip-glow" aria-hidden="true" />
                  <b>
                    <Sparkles size={15} aria-hidden="true" /> Mach ihn zu deinem
                  </b>
                  <p>
                    Klick einfach auf ein Element im Player, zum Beispiel aufs
                    Cover oder den Titel. Hier tauchen dann nur dessen
                    Einstellungen auf.
                  </p>
                  <div>
                    {editorElements.includes('cover') && (
                      <button
                        type="button"
                        className="primary"
                        onClick={() => setSelectedElement('cover')}
                      >
                        Zeig mal: Cover
                      </button>
                    )}
                    <button type="button" className="v2-ghost" onClick={dismissTip}>
                      Hab&apos;s verstanden
                    </button>
                  </div>
                </div>
              )}
              {selectedHidden && (
                <div className="v2-hidden-note">
                  <span>Dieses Element ist gerade ausgeblendet.</span>
                  <button
                    type="button"
                    className="v2-ghost"
                    onClick={() =>
                      selectedVisibilityField &&
                      update(selectedVisibilityField, true)
                    }
                  >
                    Einblenden
                  </button>
                </div>
              )}
              <div className="v2-panel" key={selectedElement || 'player'}>
                {selectedElement
                  ? renderElementPanel(selectedElement)
                  : renderPlayerPanel()}
              </div>
            </div>
            <div className="v2-inspector-foot">
              <div className="save-row">
                <button
                  type="button"
                  className="icon-button"
                  onClick={undo}
                  disabled={!historyPast.length}
                  aria-label="Rückgängig (Strg+Z)"
                  title="Rückgängig (Strg+Z)"
                >
                  <RotateCcw size={16} />
                </button>
                <button
                  type="button"
                  className="icon-button"
                  onClick={redo}
                  disabled={!historyFuture.length}
                  aria-label="Wiederholen (Strg+Y)"
                  title="Wiederholen (Strg+Y)"
                >
                  <RotateCcw size={16} style={{ transform: 'scaleX(-1)' }} />
                </button>
                <button
                  className="primary"
                  disabled={busy || !ready || !dirty}
                  onClick={save}
                >
                  <Save size={16} />
                  {busy ? 'Speichert …' : 'Speichern'}
                </button>
                <button
                  className="icon-button"
                  title="Auf den Stil zurücksetzen"
                  aria-label="Auf den Stil zurücksetzen"
                  onClick={() => setConfig({ ...(chosen?.config || defaults) })}
                >
                  <X size={16} />
                </button>
              </div>
              <p className="save-hint">
                {!ready
                  ? 'Studio wird verbunden …'
                  : dirty
                    ? 'Ungespeicherte Änderungen'
                    : 'Gespeichert · live in OBS'}
              </p>
            </div>
          </aside>
        </div>
      )}
      {view === 'looks' && (
        <div className="v2-page">
          <div className="v2-page-head">
            <div>
              <h1>
                Looks<span>.</span>
              </h1>
              <p>Starte mit einem Stil oder lade einen deiner gespeicherten Looks.</p>
            </div>
          </div>
          <section className="v2-looks-section" aria-label="Meine Looks">
            <div className="v2-section-head">
              <h2>Meine Looks</h2>
              <div className="v2-section-actions">
                {renderSaveLookForm(false)}
                <input
                  ref={lookImportRef}
                  type="file"
                  accept="application/json,.json"
                  hidden
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) void importLook(file);
                    e.currentTarget.value = '';
                  }}
                />
                <button
                  type="button"
                  className="v2-ghost"
                  onClick={() => lookImportRef.current?.click()}
                >
                  <Upload size={14} /> Importieren
                </button>
              </div>
            </div>
            {customLooks.length === 0 ? (
              <p className="v2-empty">
                Noch keine gespeicherten Looks. Gestalte im Studio deinen Player
                und speichere ihn hier unter einem Namen.
              </p>
            ) : (
              <div className="v2-card-grid">
                {customLooks.map((look) => {
                  const live = look.id === activeLiveLookId;
                  return (
                    <article
                      className={'v2-look-card' + (live ? ' is-live' : '')}
                      key={look.id}
                    >
                      <button
                        type="button"
                        className="v2-card-preview"
                        aria-label={look.name + ' in den Editor laden'}
                        onClick={() => {
                          loadLook(look);
                          setView('studio');
                        }}
                      >
                        {miniPreview(look.config)}
                      </button>
                      <div className="v2-card-meta">
                        <b>{look.name}</b>
                        {live && <span className="v2-live-pill">LIVE</span>}
                      </div>
                      <div className="v2-card-actions">
                        <button
                          type="button"
                          className="primary"
                          onClick={() => {
                            loadLook(look);
                            setView('studio');
                          }}
                        >
                          Laden
                        </button>
                        <button
                          type="button"
                          className="v2-ghost"
                          onClick={() => activateLook(look)}
                        >
                          Live schalten
                        </button>
                        <button
                          type="button"
                          className={'v2-icon-btn' + (look.pinned ? ' is-on' : '')}
                          aria-pressed={!!look.pinned}
                          aria-label={
                            look.pinned
                              ? look.name + ' aus Live Looks entfernen'
                              : look.name + ' als Live Look anheften'
                          }
                          title="Live Look (Schnellzugriff & Streamer.bot)"
                          onClick={() => pinLook(look)}
                        >
                          <Star
                            size={14}
                            fill={look.pinned ? 'currentColor' : 'none'}
                          />
                        </button>
                        <button
                          type="button"
                          className="v2-icon-btn"
                          aria-label={look.name + ' exportieren'}
                          title="Exportieren"
                          onClick={() => exportLook(look)}
                        >
                          <Download size={14} />
                        </button>
                        <button
                          type="button"
                          className="v2-icon-btn"
                          aria-label={look.name + ' löschen'}
                          title="Löschen"
                          onClick={() => deleteLook(look.id)}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </section>
          <section className="v2-looks-section" aria-label="Stile">
            <div className="v2-section-head">
              <h2>Stile</h2>
              <span className="v2-section-note">{presets.length} Signature Styles</span>
            </div>
            <div className="preset-grid v2-preset-grid">
                {presets.map((p) => {
                const active = isActivePreset(p);
                return (
                  <button
                    type="button"
                    key={p.id}
                    data-preset={p.name}
                    className={'preset' + (active ? ' selected' : '')}
                    aria-pressed={active}
                    onClick={() => {
                      applyPreset(p);
                      setView('studio');
                    }}
                  >
                    <div className={'preset-art art-' + p.id} aria-hidden="true">
                      <div className="mini-chrome">
                        <i />
                        <i />
                        <i />
                      </div>
                      <span className="mini-cover" />
                      <span className="mini-lines">
                        <b />
                        <i />
                        <em />
                      </span>
                      {p.id === 'sticker' && <span className="mini-star">✦</span>}
                    </div>
                    <div className="v2-preset-name">
                      <span>{p.name}</span>
                      {active ? <Check size={14} /> : <ArrowUpRight size={14} />}
                    </div>
                    <p>{p.note}</p>
                  </button>
                );
              })}
            </div>
          </section>
          {renderStatus()}
        </div>
      )}
      {view === 'setup' && (
        <div className="v2-page v2-setup">
          <div className="v2-page-head">
            <div>
              <h1>
                Setup<span>.</span>
              </h1>
              <p>
                {essentialsDone === 2
                  ? 'Alles Wichtige ist erledigt – bereit für deinen Stream.'
                  : `${essentialsDone} von 2 Essentials erledigt. Danach kann's losgehen.`}
              </p>
            </div>
            <div className="v2-setup-progress" aria-hidden="true">
              <i style={{ width: (essentialsDone / 2) * 100 + '%' }} />
            </div>
          </div>

          <section className="v2-setup-group">
            <div className="v2-section-head">
              <h2>Essentials</h2>
              <span className="v2-section-note">Brauchst du, damit Resonance läuft</span>
            </div>
            <div className="v2-setup-cards">
              <article className={'v2-setup-card' + (connected ? ' is-done' : '')}>
                <header>
                  <span className="v2-setup-icon">
                    <Music2 size={17} />
                  </span>
                  <div>
                    <b>Spotify verbinden</b>
                    <small>
                      {connected ? 'Verbunden' : 'Noch nicht verbunden'}
                    </small>
                  </div>
                  <span className={'v2-status-pill' + (connected ? ' ok' : '')}>
                    {connected ? 'Erledigt' : 'Offen'}
                  </span>
                </header>
                <p className="v2-setup-why">
                  <b>Was es bringt:</b> Resonance zeigt live, was du gerade in
                  Spotify hörst. Gelesen werden nur der aktuelle Titel, deine
                  Lieblingssongs und Playlists – nichts wird verändert.
                </p>
                <details className="v2-tutorial">
                  <summary>So geht&apos;s · 1 Minute</summary>
                  <ol>
                    <li>
                      Dein Spotify-Konto muss für die Resonance-App
                      freigeschaltet sein. In der Testphase sind das maximal 5
                      Personen – schick dem Entwickler die E-Mail deines
                      Spotify-Kontos.
                    </li>
                    <li>
                      Klick auf <b>Spotify verbinden</b> und melde dich bei
                      Spotify an.
                    </li>
                    <li>
                      Bestätige den Zugriff. Du landest automatisch wieder hier.
                    </li>
                    <li>Spiel einen Song ab – er erscheint sofort im Studio.</li>
                  </ol>
                </details>
                <div className="v2-setup-actions">
                  <button
                    className={connected ? 'secondary' : 'primary'}
                    onClick={() => setModal('spotify')}
                  >
                    {connected ? 'Verbindung verwalten' : 'Spotify verbinden'}
                  </button>
                </div>
              </article>

              <article className={'v2-setup-card' + (key ? ' is-done' : '')}>
                <header>
                  <span className="v2-setup-icon">
                    <Monitor size={17} />
                  </span>
                  <div>
                    <b>In OBS einbinden</b>
                    <small>Als Browser-Quelle</small>
                  </div>
                  <span className={'v2-status-pill' + (key ? ' ok' : '')}>
                    {key ? 'Adresse bereit' : 'Wird vorbereitet'}
                  </span>
                </header>
                <p className="v2-setup-why">
                  <b>Was es bringt:</b> Dein Player erscheint im Stream. Alles,
                  was du im Studio speicherst, übernimmt OBS automatisch.
                </p>
                <div className="setup-url">
                  <code>{key ? obsUrl : 'Overlay-Adresse wird vorbereitet …'}</code>
                  <button
                    type="button"
                    aria-label="OBS-Adresse kopieren"
                    title="OBS-Adresse kopieren"
                    disabled={!key}
                    onClick={() => copy(obsUrl)}
                  >
                    <Copy size={15} />
                  </button>
                  {key && (
                    <a href={obsUrl} target="_blank" rel="noreferrer" title="Overlay öffnen">
                      <ExternalLink size={15} />
                    </a>
                  )}
                </div>
                <details className="v2-tutorial">
                  <summary>So geht&apos;s · 1 Minute</summary>
                  <ol>
                    <li>Kopiere die Adresse oben.</li>
                    <li>
                      In OBS: bei <b>Quellen</b> auf <b>+</b> →{' '}
                      <b>Browser</b> → Namen vergeben, z. B. „Resonance“.
                    </li>
                    <li>
                      Adresse bei <b>URL</b> einfügen, Breite <b>1920</b> und
                      Höhe <b>1080</b> eintragen, mit OK bestätigen.
                    </li>
                    <li>
                      Player an die gewünschte Stelle ziehen. Resonance muss
                      während des Streams laufen (Startfenster offen lassen).
                    </li>
                  </ol>
                  <small>
                    Die Adresse enthält deinen persönlichen Schlüssel – teile
                    sie nicht öffentlich.
                  </small>
                </details>
              </article>
            </div>
          </section>

          <section className="v2-setup-group">
            <div className="v2-section-head">
              <h2>Zusatz-Features</h2>
              <span className="v2-section-note">Optional – machen Resonance schlauer</span>
            </div>
            <div className="v2-setup-cards">
              <article className={'v2-setup-card' + (lastfmConfigured ? ' is-done' : '')}>
                <header>
                  <span className="v2-setup-icon">
                    <Sparkles size={17} />
                  </span>
                  <div>
                    <b>Last.fm</b>
                    <small>Für Mood Switch</small>
                  </div>
                  <span className={'v2-status-pill' + (lastfmConfigured ? ' ok' : '')}>
                    {lastfmConfigured ? 'Aktiv' : 'Optional'}
                  </span>
                </header>
                <p className="v2-setup-why">
                  <b>Was es bringt:</b> Genres und Tags aus Last.fm – damit
                  erkennt Mood Switch die Stimmung eines Songs deutlich genauer.
                  Ohne Key nutzt Resonance Spotify-Genres und freie Quellen.
                </p>
                <details className="v2-tutorial">
                  <summary>So bekommst du den API-Key · 2 Minuten</summary>
                  <ol>
                    <li>
                      Öffne{' '}
                      <a
                        href="https://www.last.fm/api/account/create"
                        target="_blank"
                        rel="noreferrer"
                      >
                        last.fm/api/account/create ↗
                      </a>{' '}
                      und melde dich an (kostenloses Konto reicht).
                    </li>
                    <li>
                      Name z. B. „Resonance“, Beschreibung beliebig. Callback
                      und Homepage kannst du leer lassen.
                    </li>
                    <li>
                      Nach dem Absenden siehst du den <b>API key</b> – nur
                      diesen brauchst du, nicht das „Shared secret“.
                    </li>
                    <li>Hier einfügen, speichern und testen.</li>
                  </ol>
                </details>
                <div className="v2-key-row">
                  <input
                    type="password"
                    autoComplete="off"
                    aria-label="Last.fm API-Key"
                    placeholder={lastfmConfigured ? '•••••••• gespeichert' : 'API-Key einfügen'}
                    value={lastfmKey}
                    onChange={(e) => setLastfmKey(e.target.value)}
                  />
                  <button
                    className="primary"
                    disabled={moodBusy || !lastfmKey.trim()}
                    onClick={() => saveMoodCredential('lastfm')}
                  >
                    Speichern
                  </button>
                </div>
                {lastfmConfigured && (
                  <div className="v2-setup-actions">
                    <button
                      className="v2-ghost"
                      disabled={lastfmTest === 'testing'}
                      onClick={() => testMoodCredential('lastfm')}
                    >
                      {lastfmTest === 'testing'
                        ? 'Teste …'
                        : lastfmTest === 'connected'
                          ? 'Funktioniert ✓'
                          : lastfmTest === 'invalid'
                            ? 'Key ungültig – erneut testen'
                            : 'Verbindung testen'}
                    </button>
                    <button
                      className="v2-ghost"
                      disabled={moodBusy}
                      onClick={() => removeMoodCredential('lastfm')}
                    >
                      Entfernen
                    </button>
                  </div>
                )}
              </article>

              <article className={'v2-setup-card' + (geniusConfigured ? ' is-done' : '')}>
                <header>
                  <span className="v2-setup-icon">
                    <Type size={17} />
                  </span>
                  <div>
                    <b>Genius</b>
                    <small>Für Mood Switch</small>
                  </div>
                  <span className={'v2-status-pill' + (geniusConfigured ? ' ok' : '')}>
                    {geniusConfigured ? 'Aktiv' : 'Optional'}
                  </span>
                </header>
                <p className="v2-setup-why">
                  <b>Was es bringt:</b> Songtexte als zusätzliche Quelle. Hilft
                  Mood Switch bei Songs, zu denen es kaum Genre-Infos gibt.
                </p>
                <details className="v2-tutorial">
                  <summary>So bekommst du den Token · 3 Minuten</summary>
                  <ol>
                    <li>
                      Öffne{' '}
                      <a
                        href="https://genius.com/api-clients"
                        target="_blank"
                        rel="noreferrer"
                      >
                        genius.com/api-clients ↗
                      </a>{' '}
                      und melde dich an.
                    </li>
                    <li>
                      <b>New API Client</b>: App-Name „Resonance“, bei App
                      Website URL z. B. <code>http://127.0.0.1:3000</code>.
                    </li>
                    <li>
                      Speichern, dann <b>Generate Access Token</b> klicken.
                    </li>
                    <li>
                      Den <b>Client Access Token</b> hier einfügen, speichern
                      und testen.
                    </li>
                  </ol>
                </details>
                <div className="v2-key-row">
                  <input
                    type="password"
                    autoComplete="off"
                    aria-label="Genius Access Token"
                    placeholder={geniusConfigured ? '•••••••• gespeichert' : 'Access Token einfügen'}
                    value={geniusToken}
                    onChange={(e) => setGeniusToken(e.target.value)}
                  />
                  <button
                    className="primary"
                    disabled={moodBusy || !geniusToken.trim()}
                    onClick={() => saveMoodCredential('genius')}
                  >
                    Speichern
                  </button>
                </div>
                {geniusConfigured && (
                  <div className="v2-setup-actions">
                    <button
                      className="v2-ghost"
                      disabled={geniusTest === 'testing'}
                      onClick={() => testMoodCredential('genius')}
                    >
                      {geniusTest === 'testing'
                        ? 'Teste …'
                        : geniusTest === 'connected'
                          ? 'Funktioniert ✓'
                          : geniusTest === 'invalid'
                            ? 'Token ungültig – erneut testen'
                            : 'Verbindung testen'}
                    </button>
                    <button
                      className="v2-ghost"
                      disabled={moodBusy}
                      onClick={() => removeMoodCredential('genius')}
                    >
                      Entfernen
                    </button>
                  </div>
                )}
              </article>

              <article className="v2-setup-card is-info">
                <header>
                  <span className="v2-setup-icon">
                    <Gamepad2 size={17} />
                  </span>
                  <div>
                    <b>Live Looks per Taste</b>
                    <small>Streamer.bot</small>
                  </div>
                  <span className="v2-status-pill">
                    {liveLooks.length} angeheftet
                  </span>
                </header>
                <p className="v2-setup-why">
                  <b>Was es bringt:</b> Wechsle deinen Look mitten im Stream per
                  Tastendruck, Stream Deck oder Makro-Pad.
                </p>
                <details className="v2-tutorial">
                  <summary>So geht&apos;s</summary>
                  <ol>
                    <li>
                      Unter <b>Looks</b> bis zu 5 Looks mit dem Stern als Live
                      Look anheften.
                    </li>
                    <li>
                      In Streamer.bot eine Action mit <b>Execute C# Code</b>{' '}
                      anlegen und den Code aus{' '}
                      <code>integrations/streamerbot/resonance-live-look.cs</code>{' '}
                      einfügen.
                    </li>
                    <li>
                      Argument <code>resonanceSlot</code> auf 1–5 setzen und der
                      Action einen Hotkey oder eine Taste zuweisen.
                    </li>
                  </ol>
                </details>
              </article>

              <article className="v2-setup-card is-info">
                <header>
                  <span className="v2-setup-icon">
                    <Box size={17} />
                  </span>
                  <div>
                    <b>Enhanced Blur</b>
                    <small>Für Afterglow in OBS</small>
                  </div>
                  <span className="v2-status-pill">Optional</span>
                </header>
                <p className="v2-setup-why">
                  <b>Was es bringt:</b> Echte Hintergrund-Unschärfe hinter dem
                  Afterglow-Glas. Afterglow funktioniert auch ohne.
                </p>
                <div className="v2-setup-actions">
                  <button
                    className="v2-ghost"
                    onClick={() => {
                      const p = presets.find((x) => x.id === 'glass');
                      if (p && !isAfterglow(config)) applyPreset(p);
                      setView('studio');
                    }}
                  >
                    Im Studio bei Afterglow einrichten →
                  </button>
                </div>
              </article>
            </div>
          </section>

          <section className="v2-setup-group">
            <div className="v2-section-head">
              <h2>System</h2>
            </div>
            <div className="v2-setup-cards is-compact">
              <article className="v2-setup-card is-info">
                <header>
                  <span className="v2-setup-icon">
                    <RefreshCw size={17} />
                  </span>
                  <div>
                    <b>Version</b>
                    <small>
                      {testerVersion ? `Tester ${testerVersion}` : 'Entwicklungsmodus'}
                    </small>
                  </div>
                </header>
                <p className="v2-setup-why">
                  Updates holst du mit <code>Update-Resonance.cmd</code> im
                  Resonance-Ordner. Deine Looks, Fonts und Verbindungen bleiben
                  erhalten.
                </p>
              </article>
              <article className="v2-setup-card is-info">
                <header>
                  <span className="v2-setup-icon">
                    <Gauge size={17} />
                  </span>
                  <div>
                    <b>QA Lab</b>
                    <small>Mood-Erkennung & Visuals prüfen</small>
                  </div>
                </header>
                <div className="v2-setup-actions">
                  <a className="v2-ghost" href="/mood-visual-check">
                    QA Lab öffnen <ArrowUpRight size={13} />
                  </a>
                </div>
              </article>
              {devStatus && (
                <article className={'v2-setup-card is-dev' + (devStatus.stale ? '' : ' is-done')}>
                  <header>
                    <span className="v2-setup-icon">
                      <Download size={17} />
                    </span>
                    <div>
                      <b>Tester-ZIP</b>
                      <small>Nur im Entwicklermodus sichtbar</small>
                    </div>
                    <span className={'v2-status-pill' + (devStatus.stale ? ' warn' : ' ok')}>
                      {devStatus.stale ? 'Veraltet' : 'Aktuell'}
                    </span>
                  </header>
                  <p className="v2-setup-why">
                    {devStatus.latest
                      ? `Letzter Build: ${new Date(devStatus.latest.createdAt).toLocaleString('de-DE')} · ${(devStatus.latest.size / 1024 / 1024).toFixed(1)} MB`
                      : 'Noch kein Tester-ZIP gebaut.'}
                    {devStatus.stale && devStatus.newestSourceChange && (
                      <>
                        {' '}
                        · Code geändert am{' '}
                        {new Date(devStatus.newestSourceChange).toLocaleString('de-DE')}
                      </>
                    )}
                  </p>
                  <div className="v2-setup-actions">
                    <button
                      className="primary"
                      disabled={devBusy}
                      onClick={() => buildTesterZip(true)}
                    >
                      {devBusy ? 'Baue ZIP …' : 'Neu bauen & herunterladen'}
                    </button>
                    {devStatus.latest && !devStatus.stale && (
                      <a
                        className="v2-ghost"
                        href={'/exports/' + encodeURIComponent(devStatus.latest.file)}
                        download
                      >
                        Aktuelles ZIP laden
                      </a>
                    )}
                  </div>
                </article>
              )}
            </div>
          </section>
          {renderStatus()}
        </div>
      )}
      <Dialog
        open={modal !== null}
        onOpenChange={(open) => !open && setModal(null)}
      >
        <DialogContent className="setup-dialog">
          <DialogTitle>
            {modal === 'spotify'
              ? 'Spotify verbinden'
              : 'Bereit für deinen Stream.'}
          </DialogTitle>
          <DialogDescription>
            {modal === 'spotify'
              ? 'Deine Developer-App ist vorbereitet. Es wird nur der aktuelle Titel gelesen.'
              : 'Speichere dein Design und füge das Overlay als Browser-Quelle in OBS hinzu.'}
          </DialogDescription>
          {modal === 'spotify' ? (
            <>
              <div className="setup-step">
                <span>01</span>
                <div>
                  <h3>Redirect-URI eintragen</h3>
                  <p>
                    Öffne deine App im{' '}
                    <a
                      href="https://developer.spotify.com/dashboard"
                      target="_blank"
                      rel="noreferrer"
                    >
                      Spotify Developer Dashboard ↗
                    </a>
                    . Füge unter Settings diese Redirect-URI hinzu und speichere
                    sie.
                  </p>
                  <div className="copy-field">
                    <input
                      aria-label="Spotify Redirect-URI"
                      readOnly
                      value={spotifyRedirect}
                    />
                    <button
                      aria-label="Redirect-URI kopieren"
                      onClick={() => copy(spotifyRedirect)}
                    >
                      <Copy size={16} />
                    </button>
                  </div>
                </div>
              </div>
              <div className="setup-step">
                <span>02</span>
                <div>
                  <h3>Mit Spotify anmelden</h3>
                  <p>
                    Client-ID: <code>6dde544e…790b338</code>. Bestätige danach
                    den Zugriff in Spotify.
                  </p>
                </div>
              </div>
              <button
                className="primary"
                disabled={busy || !ready}
                onClick={connect}
              >
                <Music2 size={17} />
                {connected
                  ? 'Erneut mit Spotify verbinden'
                  : 'Mit Spotify verbinden'}
              </button>
              {connected && (
                <button
                  className="secondary"
                  disabled={busy}
                  onClick={disconnect}
                >
                  <Unplug size={15} />
                  Spotify trennen
                </button>
              )}
            </>
          ) : (
            <>
              <div className="setup-step">
                <span>01</span>
                <div>
                  <h3>Design übernehmen</h3>
                  <p>
                    {dirty
                      ? 'Dein Entwurf enthält Änderungen. Speichere sie vor dem Kopieren.'
                      : 'Dein aktuelles Design ist gespeichert.'}
                  </p>
                  {dirty && (
                    <button
                      className="secondary"
                      disabled={!ready || busy}
                      onClick={save}
                    >
                      <Save size={15} />
                      Jetzt speichern
                    </button>
                  )}
                </div>
              </div>
              <div className="setup-step">
                <span>02</span>
                <div>
                  <h3>Browser-Quelle hinzufügen</h3>
                  <p>
                    OBS → Quellen → + → Browser. Setze die Breite auf{' '}
                    <b>{config.width + 100} px</b>, die Höhe auf <b>600 px</b>.
                    Die Fläche ist transparent.
                  </p>
                  <div className="copy-field">
                    <input
                      aria-label="OBS Overlay-Adresse"
                      readOnly
                      value={key ? obsUrl : 'Studio wird geladen …'}
                    />
                    <button
                      aria-label="Overlay-Adresse kopieren"
                      disabled={!key || dirty}
                      onClick={() => copy(obsUrl)}
                    >
                      <Copy size={16} />
                    </button>
                  </div>
                </div>
              </div>
              {!connected && (
                <button className="primary" onClick={() => setModal('spotify')}>
                  <Music2 size={17} />
                  Zuerst Spotify verbinden
                </button>
              )}
              {key && (
                <a
                  className="secondary"
                  href={obsUrl}
                  target="_blank"
                  rel="noreferrer"
                >
                  <ExternalLink size={15} />
                  Overlay öffnen
                </a>
              )}
              <p className="privacy-note">
                Der Overlay-Link erlaubt das Lesen deines aktuellen Titels.
                Behalte ihn für dich.
              </p>
              <button
                className="text-button"
                disabled={!ready || busy}
                onClick={async () => {
                  setBusy(true);
                  try {
                    const d = await api('/api/studio', { action: 'rotate' });
                    setKey(d.overlayKey);
                    setMessage(
                      'Neuer Overlay-Link erstellt. Aktualisiere ihn auch in OBS.',
                    );
                  } catch (e) {
                    setError((e as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                <RefreshCw size={13} />
                Neuen Overlay-Link erstellen
              </button>
            </>
          )}
          <div aria-live="polite">
            {error && <p className="error-message">{error}</p>}
            {message && <p className="success-message">{message}</p>}
          </div>
        </DialogContent>
      </Dialog>
      <Dialog
        open={moodSettingsOpen}
        onOpenChange={(open) => !open && setMoodSettingsOpen(false)}
      >
        <DialogContent className="setup-dialog">
          <DialogTitle>Mood Switch Settings</DialogTitle>
          <DialogDescription>
            Optionale Datenquellen für genauere Mood-Erkennung. Ohne Keys
            funktioniert Mood Switch weiterhin.
          </DialogDescription>
          <div className="mood-settings-section">
            <h3>Last.fm</h3>
            <p>Genres, Tags und Metadaten für die Mood-Erkennung.</p>
            <div
              className={
                'mood-settings-status' + (lastfmConfigured ? ' connected' : '')
              }
            >
              {lastfmConfigured ? 'Connected' : 'Not configured'}
            </div>
            <input
              className="mood-settings-input"
              type="password"
              value={lastfmKey}
              placeholder="Last.fm API Key"
              autoComplete="off"
              spellCheck={false}
              onChange={(e) => setLastfmKey(e.target.value)}
            />
            <div className="mood-settings-actions">
              <button
                className="secondary"
                disabled={moodBusy}
                onClick={() => saveMoodCredential('lastfm')}
              >
                <Save size={15} />
                Speichern
              </button>
              <button
                className="secondary"
                disabled={moodBusy}
                onClick={() => testMoodCredential('lastfm')}
              >
                Test Connection
              </button>
              {lastfmConfigured && (
                <button
                  className="text-button"
                  disabled={moodBusy}
                  onClick={() => removeMoodCredential('lastfm')}
                >
                  Entfernen
                </button>
              )}
            </div>
            {lastfmTest && (
              <p className={'mood-settings-test ' + lastfmTest}>
                {lastfmTest === 'testing'
                  ? 'Teste Verbindung …'
                  : lastfmTest === 'connected'
                    ? 'Connected'
                    : lastfmTest === 'invalid'
                      ? 'Invalid key'
                      : 'Dienst nicht erreichbar'}
              </p>
            )}
            <a
              href="https://www.last.fm/api/account/create"
              target="_blank"
              rel="noreferrer"
            >
              How to get a key ↗
            </a>
          </div>
          <div className="mood-settings-section">
            <h3>
              Genius <em>Optional</em>
            </h3>
            <p>Zusätzlicher Lyrics-Fallback für die Mood-Erkennung.</p>
            <div
              className={
                'mood-settings-status' + (geniusConfigured ? ' connected' : '')
              }
            >
              {geniusConfigured ? 'Connected' : 'Not configured'}
            </div>
            <input
              className="mood-settings-input"
              type="password"
              value={geniusToken}
              placeholder="Genius Access Token"
              autoComplete="off"
              spellCheck={false}
              onChange={(e) => setGeniusToken(e.target.value)}
            />
            <div className="mood-settings-actions">
              <button
                className="secondary"
                disabled={moodBusy}
                onClick={() => saveMoodCredential('genius')}
              >
                <Save size={15} />
                Speichern
              </button>
              <button
                className="secondary"
                disabled={moodBusy}
                onClick={() => testMoodCredential('genius')}
              >
                Test Connection
              </button>
              {geniusConfigured && (
                <button
                  className="text-button"
                  disabled={moodBusy}
                  onClick={() => removeMoodCredential('genius')}
                >
                  Entfernen
                </button>
              )}
            </div>
            {geniusTest && (
              <p className={'mood-settings-test ' + geniusTest}>
                {geniusTest === 'testing'
                  ? 'Teste Verbindung …'
                  : geniusTest === 'connected'
                    ? 'Connected'
                    : geniusTest === 'invalid'
                      ? 'Invalid token'
                      : 'Dienst nicht erreichbar'}
              </p>
            )}
            <a
              href="https://genius.com/api-clients"
              target="_blank"
              rel="noreferrer"
            >
              How to get a token ↗
            </a>
          </div>
          <div aria-live="polite">
            {error && <p className="error-message">{error}</p>}
            {message && <p className="success-message">{message}</p>}
          </div>
        </DialogContent>
      </Dialog>
      <Dialog
        open={deleteConfirm !== null}
        onOpenChange={(open) => !open && setDeleteConfirm(null)}
      >
        <DialogContent className="setup-dialog">
          <DialogTitle>Font löschen</DialogTitle>
          <DialogDescription>
            Dieser Font wird aktuell verwendet. Beim Löschen fällt der Player
            auf Inter zurück.
          </DialogDescription>
          <p className="delete-font-name">
            „{deleteConfirm?.name}“ wird gelöscht.
          </p>
          <div className="dialog-actions">
            <button
              className="primary"
              disabled={busy}
              onClick={() => void confirmDeleteFont()}
            >
              Delete and fall back to Inter
            </button>
            <button
              className="secondary"
              disabled={busy}
              onClick={() => setDeleteConfirm(null)}
            >
              Cancel
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </main>
  );
}
