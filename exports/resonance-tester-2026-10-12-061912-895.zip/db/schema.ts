import { sqliteTable, text, integer, blob } from 'drizzle-orm/sqlite-core';
export const studios = sqliteTable('studios', {
  owner: text('owner').primaryKey(),
  overlayKey: text('overlay_key').notNull().unique(),
  config: text('config').notNull(),
  accessToken: text('access_token'),
  refreshToken: text('refresh_token'),
  expires: integer('expires').notNull().default(0),
  verifier: text('verifier'),
  oauthState: text('oauth_state'),
  oauthExpires: integer('oauth_expires').notNull().default(0),
  cached: text('cached'),
  polled: integer('polled').notNull().default(0),
  retryAt: integer('retry_at').notNull().default(0),
  lastfmApiKey: text('lastfm_api_key'),
  geniusAccessToken: text('genius_access_token'),
});
export const artistGenres = sqliteTable('artist_genres', {
  id: text('id').primaryKey(),
  genres: text('genres').notNull(),
  expires: integer('expires').notNull(),
});
export const customFonts = sqliteTable('custom_fonts', {
  id: text('id').primaryKey(),
  owner: text('owner').notNull(),
  name: text('name').notNull(),
  originalFilename: text('original_filename').notNull(),
  format: text('format').notNull(),
  family: text('family').notNull(),
  data: blob('data').notNull(),
  size: integer('size').notNull(),
  hash: text('hash'),
  createdAt: integer('created_at').notNull(),
});
export const customLooks = sqliteTable('custom_looks', {
  id: text('id').primaryKey(),
  owner: text('owner').notNull(),
  name: text('name').notNull(),
  config: text('config').notNull(),
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
  pinned: integer('pinned').notNull().default(0),
  pinnedAt: integer('pinned_at'),
});

// F03 Track History (Migration 0008): gemeinsamer Verlauf für Song-Verlauf,
// Album Wall und StreamShelf.
export const streamSessions = sqliteTable('stream_sessions', {
  id: text('id').primaryKey(),
  owner: text('owner').notNull(),
  startedAt: integer('started_at').notNull(),
  lastSeenAt: integer('last_seen_at').notNull(),
  endedAt: integer('ended_at'),
  endedReason: text('ended_reason'),
  title: text('title'),
  trackCount: integer('track_count').notNull().default(0),
});
export const trackPlays = sqliteTable('track_plays', {
  id: text('id').primaryKey(),
  owner: text('owner').notNull(),
  sessionId: text('session_id').notNull(),
  seq: integer('seq').notNull(),
  trackId: text('track_id'),
  title: text('title').notNull(),
  artist: text('artist').notNull(),
  album: text('album').notNull(),
  coverUrl: text('cover_url').notNull().default(''),
  durationMs: integer('duration_ms').notNull(),
  startedAt: integer('started_at').notNull(),
  lastSeenAt: integer('last_seen_at').notNull(),
  firstProgressMs: integer('first_progress_ms').notNull().default(0),
  lastProgressMs: integer('last_progress_ms').notNull().default(0),
  maxProgressMs: integer('max_progress_ms').notNull().default(0),
  listenedMs: integer('listened_ms').notNull().default(0),
  status: text('status').notNull().default('playing'),
  endedAt: integer('ended_at'),
});
