// --- Pocket Quest: Spielmechanik (Player-Redesign 2/4, 2026-10-11) ---
// Level, Combo, Quests, Erfolge und Party ausschließlich aus echten
// Wiedergabedaten (Trackwechsel, Künstler, Lieblingssong, Uhrzeit, Dauer).
// Zustand pro Browser (OBS-Quelle bzw. Studio), im localStorage gemerkt und
// nach 12 Stunden ohne Musik zurückgesetzt („neuer Stream“).
import { useEffect, useRef, useState } from 'react';

export type PocketTrack = {
  id?: string;
  title: string;
  artist: string;
  cover: string;
  duration: number;
  favorite?: boolean;
};

export type Quest = { id: string; label: string; goal: number };
export const QUESTS: Quest[] = [
  { id: 'streak', label: '5 SONGS AM STÜCK', goal: 5 },
  { id: 'fav', label: '3 LIEBLINGSSONGS', goal: 3 },
  { id: 'artists', label: '4 NEUE KÜNSTLER', goal: 4 },
];

export const ACHIEVEMENTS: Record<string, string> = {
  nightOwl: 'Nachteule',
  fan: 'Treuer Fan',
  combo: 'Combo-König',
  explorer: 'Entdecker',
  marathon: 'Marathon',
  quest: 'Quest erfüllt',
};

type State = {
  level: number;
  combo: number;
  lastArtist: string;
  lastId: string;
  lastDuration: number;
  party: string[];
  artists: string[];
  questIdx: number;
  questProgress: number;
  listenedMs: number;
  unlocked: string[];
  savedAt: number;
};

const KEY = 'resonance.pocketQuest.v1';
const RESET_MS = 12 * 60 * 60 * 1000;

const fresh = (): State => ({
  level: 0,
  combo: 0,
  lastArtist: '',
  lastId: '',
  lastDuration: 0,
  party: [],
  artists: [],
  questIdx: 0,
  questProgress: 0,
  listenedMs: 0,
  unlocked: [],
  savedAt: Date.now(),
});

function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return fresh();
    const s = JSON.parse(raw) as State;
    if (!s || typeof s.level !== 'number' || Date.now() - s.savedAt > RESET_MS)
      return fresh();
    return { ...fresh(), ...s };
  } catch {
    return fresh();
  }
}

function save(s: State) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {}
}

export type PocketQuestView = {
  level: number;
  combo: number;
  party: string[];
  quest: Quest;
  questProgress: number;
  toast: string | null;
  levelUp: boolean;
};

/** Spielzustand für Pocket Quest. Ohne `enabled` passiert nichts. */
export function usePocketQuest(
  track: PocketTrack | null,
  enabled: boolean,
): PocketQuestView {
  const [state, setState] = useState<State>(fresh);
  const [toast, setToast] = useState<string | null>(null);
  const [levelUp, setLevelUp] = useState(false);
  const loaded = useRef(false);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const pending = useRef<{ toast: string | null; levelUp: boolean } | null>(
    null,
  );
  const prevCover = useRef('');

  useEffect(() => {
    if (!enabled || loaded.current) return;
    loaded.current = true;
    setState(load());
  }, [enabled]);

  const id = track ? track.id || track.title + '|' + track.artist : '';

  useEffect(() => {
    if (!enabled || !track || !loaded.current) return;
    setState((prev) => {
      if (prev.lastId === id) return prev;
      const s: State = { ...prev, savedAt: Date.now() };
      const newAchievements: string[] = [];
      const unlock = (key: string) => {
        if (!s.unlocked.includes(key)) {
          s.unlocked = [...s.unlocked, key];
          newAchievements.push(ACHIEVEMENTS[key]);
        }
      };
      // Vorheriger Song zählt zur Hördauer.
      if (prev.lastId) s.listenedMs += prev.lastDuration;
      s.level = prev.level + 1;
      s.combo =
        prev.lastArtist && prev.lastArtist === track.artist ? prev.combo + 1 : 1;
      const newArtist = !prev.artists.includes(track.artist);
      if (newArtist) s.artists = [...prev.artists, track.artist].slice(-200);
      // Party: Cover der letzten Songs (neuester zuerst).
      s.party = prev.lastId
        ? [prevCover.current, ...prev.party].filter(Boolean).slice(0, 3)
        : prev.party;
      s.lastArtist = track.artist;
      s.lastId = id;
      s.lastDuration = track.duration || 0;
      // Quest-Fortschritt
      const quest = QUESTS[prev.questIdx % QUESTS.length];
      let p = prev.questProgress;
      if (quest.id === 'streak') p += 1;
      if (quest.id === 'fav' && track.favorite) p += 1;
      if (quest.id === 'artists' && newArtist) p += 1;
      if (p >= quest.goal) {
        s.questIdx = (prev.questIdx + 1) % QUESTS.length;
        s.questProgress = 0;
        newAchievements.push(ACHIEVEMENTS.quest);
      } else s.questProgress = p;
      // Erfolge (einmal pro Session)
      const hour = new Date().getHours();
      if (hour < 4) unlock('nightOwl');
      if (track.favorite) unlock('fan');
      if (s.combo >= 3) unlock('combo');
      if (s.artists.length >= 10) unlock('explorer');
      if (s.listenedMs >= 60 * 60 * 1000) unlock('marathon');
      save(s);
      pending.current = {
        toast: newAchievements[0] || null,
        levelUp: prev.lastId !== '',
      };
      return s;
    });
    prevCover.current = track.cover;
  }, [id, enabled]); // eslint-disable-line react-hooks/exhaustive-deps

  // Toasts / Level-up nach dem State-Update anzeigen.
  useEffect(() => {
    const p = pending.current;
    if (!p) return;
    pending.current = null;
    timers.current.forEach(clearTimeout);
    timers.current = [];
    if (p.levelUp) {
      setLevelUp(true);
      timers.current.push(setTimeout(() => setLevelUp(false), 2600));
    }
    if (p.toast) {
      const t = p.toast;
      timers.current.push(
        setTimeout(() => setToast(t), p.levelUp ? 900 : 0),
        setTimeout(() => setToast(null), (p.levelUp ? 900 : 0) + 4000),
      );
    }
  }, [state]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  return {
    level: Math.max(1, state.level),
    combo: state.combo,
    party: state.party,
    quest: QUESTS[state.questIdx % QUESTS.length],
    questProgress: state.questProgress,
    toast,
    levelUp,
  };
}
