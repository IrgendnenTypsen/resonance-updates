// --- Dynamic Accent from Cover (V1.1) ---
// Leitet aus dem aktuell angezeigten Albumcover einen brauchbaren Akzent ab.
// Rein clientseitig: Spotify-Cover (i.scdn.co) liefern
// Access-Control-Allow-Origin: *, daher genügt ein eigenes Image mit
// crossOrigin = 'anonymous' (nie das sichtbare <img> wiederverwenden).
// Jeder Fehler (kein Cover, CORS, Decode, Canvas, kein guter Kandidat)
// liefert still null → Aufrufer fällt auf den manuellen Akzent zurück.

const SAMPLE_SIZE = 32;
const CACHE_LIMIT = 48;
const LOAD_TIMEOUT_MS = 8000;

// Pro exakter Cover-URL genau eine Analyse (Promise-Cache), plus synchron
// lesbares Ergebnis, damit bereits bekannte Cover ohne Fallback-Frame
// gerendert werden können.
const pending = new Map<string, Promise<string | null>>();
const resolved = new Map<string, string | null>();

// Nur für Diagnose/Validierung: Anzahl tatsächlich gestarteter Analysen.
let analysisCount = 0;
export function coverAccentAnalysisCount() {
  return analysisCount;
}

/** Synchrones Ergebnis, falls die URL bereits analysiert wurde. */
export function peekCoverAccent(url: string): string | null | undefined {
  return resolved.has(url) ? resolved.get(url) : undefined;
}

/** Gecachte Analyse eines Covers. Wirft nie; Fehler → null. */
export function getCoverAccent(url: string): Promise<string | null> {
  if (!url || typeof window === 'undefined') return Promise.resolve(null);
  const hit = pending.get(url);
  if (hit) {
    // LRU: zuletzt genutzte Einträge ans Ende.
    pending.delete(url);
    pending.set(url, hit);
    return hit;
  }
  analysisCount += 1;
  const job = extractFromUrl(url)
    .catch(() => null)
    .then((accent) => {
      if (pending.has(url)) resolved.set(url, accent);
      return accent;
    });
  pending.set(url, job);
  while (pending.size > CACHE_LIMIT) {
    const oldest = pending.keys().next().value as string;
    pending.delete(oldest);
    resolved.delete(oldest);
  }
  return job;
}

function extractFromUrl(url: string): Promise<string | null> {
  return new Promise((resolve) => {
    const image = new Image();
    image.crossOrigin = 'anonymous';
    image.decoding = 'async';
    const timer = setTimeout(() => finish(null), LOAD_TIMEOUT_MS);
    function finish(value: string | null) {
      clearTimeout(timer);
      image.onload = null;
      image.onerror = null;
      resolve(value);
    }
    image.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = SAMPLE_SIZE;
        canvas.height = SAMPLE_SIZE;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (!ctx) return finish(null);
        ctx.drawImage(image, 0, 0, SAMPLE_SIZE, SAMPLE_SIZE);
        // Wirft SecurityError bei getainteter Canvas (CORS) → catch → null.
        const { data } = ctx.getImageData(0, 0, SAMPLE_SIZE, SAMPLE_SIZE);
        finish(pickAccent(data));
      } catch {
        finish(null);
      }
    };
    image.onerror = () => finish(null);
    image.src = url;
  });
}

// --- Farbauswahl (bewusst einfach, kein Palette-Engine) ---
// Pixel nach Farbton in 24 Bins sortieren, unbrauchbare Pixel verwerfen
// (transparent, fast schwarz/weiß, entsättigt), den stärksten Farbton-Cluster
// (inkl. Nachbar-Bins) wählen, gewichtet mitteln und moderat normalisieren,
// damit der Akzent auf dunklen Overlays sichtbar bleibt.

const HUE_BINS = 24;
const MIN_ALPHA = 200;
const MIN_LIGHTNESS = 0.1;
const MAX_LIGHTNESS = 0.94;
const MIN_CHROMA = 0.16;
const MIN_CLUSTER_SHARE = 0.025;
const OUT_SAT: [number, number] = [0.5, 0.9];
const OUT_LIGHT: [number, number] = [0.55, 0.72];

/** Reine Funktion auf RGBA-Daten (testbar ohne DOM). */
export function pickAccent(data: ArrayLike<number>): string | null {
  const total = Math.floor(data.length / 4);
  if (total === 0) return null;
  const score = new Array<number>(HUE_BINS).fill(0);
  const count = new Array<number>(HUE_BINS).fill(0);
  const sums = Array.from({ length: HUE_BINS }, () => [0, 0, 0, 0]);
  for (let i = 0; i < total; i++) {
    const a = data[i * 4 + 3];
    if (a < MIN_ALPHA) continue;
    const r = data[i * 4] / 255;
    const g = data[i * 4 + 1] / 255;
    const b = data[i * 4 + 2] / 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const chroma = max - min;
    const l = (max + min) / 2;
    if (l < MIN_LIGHTNESS || l > MAX_LIGHTNESS || chroma < MIN_CHROMA)
      continue;
    const bin = Math.floor((hue(r, g, b, max, chroma) / 360) * HUE_BINS) % HUE_BINS;
    // Kräftige, mittelhelle Pixel zählen mehr als blasse/extreme.
    const w = chroma * (1 - Math.abs(l - 0.5));
    score[bin] += w;
    count[bin] += 1;
    sums[bin][0] += r * w;
    sums[bin][1] += g * w;
    sums[bin][2] += b * w;
    sums[bin][3] += w;
  }
  let best = -1;
  let bestScore = 0;
  for (let i = 0; i < HUE_BINS; i++) {
    const prev = (i + HUE_BINS - 1) % HUE_BINS;
    const next = (i + 1) % HUE_BINS;
    const s = score[i] + 0.5 * (score[prev] + score[next]);
    const n = count[i] + count[prev] + count[next];
    if (n / total < MIN_CLUSTER_SHARE) continue;
    if (s > bestScore) {
      bestScore = s;
      best = i;
    }
  }
  if (best < 0) return null;
  let r = 0;
  let g = 0;
  let b = 0;
  let w = 0;
  for (const i of [best - 1, best, best + 1]) {
    const s = sums[(i + HUE_BINS) % HUE_BINS];
    r += s[0];
    g += s[1];
    b += s[2];
    w += s[3];
  }
  if (w <= 0) return null;
  const [h, s, l] = rgbToHsl(r / w, g / w, b / w);
  return hslToHex(h, clamp(s, OUT_SAT), clamp(l, OUT_LIGHT));
}

/**
 * Titel in Akzentfarbe: Farbton/Sättigung des Akzents behalten, Helligkeit an
 * die Textfarbe angleichen (heller Text → helle Variante, dunkler Text →
 * dunkle Variante), damit der Titel so lesbar bleibt wie normaler Text.
 */
export function titleAccentColor(accent: string, text: string): string {
  const a = hexToRgb(accent);
  const t = hexToRgb(text);
  if (!a || !t) return accent;
  const [h, s, l] = rgbToHsl(a[0], a[1], a[2]);
  const textLight = (Math.max(...t) + Math.min(...t)) / 2 >= 0.5;
  const nl = textLight ? Math.max(l, 0.72) : Math.min(l, 0.38);
  return hslToHex(h, Math.min(s, 0.95), nl);
}

function hexToRgb(hex: string): [number, number, number] | null {
  const m = /^#([0-9a-f]{6})$/i.exec(hex);
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}

function hue(r: number, g: number, b: number, max: number, chroma: number) {
  let h: number;
  if (max === r) h = ((g - b) / chroma) % 6;
  else if (max === g) h = (b - r) / chroma + 2;
  else h = (r - g) / chroma + 4;
  h *= 60;
  return h < 0 ? h + 360 : h;
}

function clamp(v: number, [lo, hi]: [number, number]) {
  return Math.max(lo, Math.min(hi, v));
}

function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  const d = max - min;
  if (d === 0) return [0, 0, l];
  const s = d / (1 - Math.abs(2 * l - 1));
  return [hue(r, g, b, max, d), s, l];
}

function hslToHex(h: number, s: number, l: number) {
  const k = (n: number) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) =>
    l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  const hex = (x: number) =>
    Math.round(Math.max(0, Math.min(1, x)) * 255)
      .toString(16)
      .padStart(2, '0');
  return '#' + hex(f(0)) + hex(f(8)) + hex(f(4));
}
