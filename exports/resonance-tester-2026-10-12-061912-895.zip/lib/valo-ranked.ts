// --- VALORANT Ranked: Abfrage + RR-Ticker-Ereignisse ---
// Fragt /__resonance/valo/rank ab (Vite-Plugin → HenrikDev, Schlüssel bleibt
// in Node) und erkennt neue Matches über die Elo-Änderung.
import { useEffect, useRef, useState } from 'react';

export type ValoMatch = {
  result: 'win' | 'loss' | 'draw';
  score: string;
  map: string;
  kills: number;
  deaths: number;
  assists: number;
  agent: string;
};
export type ValoRanked = {
  status: 'ok' | 'unranked' | 'not-configured' | 'error' | 'loading';
  reason?: string;
  account?: { name: string; tag: string };
  tier?: number;
  tierName?: string;
  rr?: number;
  lastChange?: number;
  elo?: number;
  leaderboardRank?: number;
  peakTier?: number;
  main?: { id: string; name: string; games: number } | null;
  lastMatch?: ValoMatch | null;
  stale?: boolean;
  fetchedAt?: number;
};
export type ValoRrEvent = { id: number; delta: number; promoted: boolean };

// Rang-Gruppen ab Tier-ID (3 Stufen je Gruppe, Radiant = 27). Englisch, wie im Spiel.
const GROUPS: [number, string, string, string][] = [
  [3, 'IRON', '#8a8f99', '#c8ccd4'],
  [6, 'BRONZE', '#b0703f', '#e2a777'],
  [9, 'SILVER', '#b9c4cf', '#eef3f7'],
  [12, 'GOLD', '#e0b84f', '#fff0b0'],
  [15, 'PLATINUM', '#3fb6c8', '#a8eef6'],
  [18, 'DIAMOND', '#c27bff', '#ead2ff'],
  [21, 'ASCENDANT', '#2fbf74', '#9ef5c3'],
  [24, 'IMMORTAL', '#e0434b', '#ffb0b4'],
  [27, 'RADIANT', '#ffe9a6', '#fffaf0'],
];

/** „DIAMOND 2“ usw. + Farben für eine Tier-ID. */
export function valoTier(tier = 0) {
  const g = [...GROUPS].reverse().find((x) => tier >= x[0]);
  if (!g) return { name: 'UNRANKED', color: '#8a8f99', hi: '#c8ccd4' };
  const name = g[1] === 'RADIANT' ? g[1] : g[1] + ' ' + (tier - g[0] + 1);
  return { name, color: g[2], hi: g[3] };
}

/** Freigestelltes Agent-Portrait (valorant-api.com Medien-CDN). */
export function valoAgentPortrait(uuid?: string | null) {
  if (!uuid || !/^[0-9a-f-]{36}$/i.test(uuid)) return null;
  return `https://media.valorant-api.com/agents/${uuid.toLowerCase()}/fullportrait.png`;
}

export const VALO_DEMO: ValoRanked = {
  status: 'ok',
  account: { name: 'Demo', tag: 'EUW' },
  tier: 18,
  tierName: 'Diamond 1',
  rr: 38,
  lastChange: 18,
  elo: 1538,
  main: { id: 'add6443a-41bd-e414-f6ad-e58d267f4e95', name: 'Jett', games: 6 },
  lastMatch: {
    result: 'win',
    score: '13:9',
    map: 'Ascent',
    kills: 21,
    deaths: 12,
    assists: 5,
    agent: 'Jett',
  },
};

/** Neues Match zwischen zwei Abfragen? (Elo geändert) */
export function rrEventBetween(prev: ValoRanked | null, next: ValoRanked) {
  if (!prev || prev.status !== 'ok' || next.status !== 'ok') return null;
  if ((prev.elo || 0) === (next.elo || 0)) return null;
  const delta = next.lastChange || (next.elo || 0) - (prev.elo || 0);
  return { delta, promoted: (next.tier || 0) > (prev.tier || 0) };
}

/** Pollt den Rang (Standard alle 30 s; der Server cached 60 s). */
export function useValoRanked(enabled: boolean, intervalMs = 30000) {
  const [data, setData] = useState<ValoRanked>({ status: 'loading' });
  const [event, setEvent] = useState<ValoRrEvent | null>(null);
  const prev = useRef<ValoRanked | null>(null);
  const counter = useRef(0);
  useEffect(() => {
    if (!enabled) return;
    let stopped = false;
    let clear: ReturnType<typeof setTimeout> | null = null;
    const load = async () => {
      try {
        const r = (await fetch('/__resonance/valo/rank', { cache: 'no-store' }).then(
          (x) => x.json(),
        )) as ValoRanked;
        if (stopped) return;
        const ev = rrEventBetween(prev.current, r);
        if (r.status === 'ok') prev.current = r;
        setData(r);
        if (ev && ev.delta !== 0) {
          counter.current += 1;
          setEvent({ id: counter.current, ...ev });
          if (clear) clearTimeout(clear);
          clear = setTimeout(() => setEvent(null), 4000);
        }
      } catch {
        if (!stopped) setData({ status: 'error', reason: 'offline' });
      }
    };
    void load();
    const timer = setInterval(load, intervalMs);
    return () => {
      stopped = true;
      clearInterval(timer);
      if (clear) clearTimeout(clear);
    };
  }, [enabled, intervalMs]);
  return { data, event };
}
