// --- Album Wall (F15): Einstellungen der eigenen OBS-Quelle ---
// Bewusst getrennt von der Player-Config (Looks überschreiben sie nicht).
// Gespeichert in wall_settings (Migration 0010), je Besitzer.

export type WallLayout = 'stage' | 'bar' | 'corner';
export type WallSettings = {
  layout: WallLayout;
  rows: 1 | 2 | 3;
  speed: 'off' | 'slow' | 'fast';
  viz: 'off' | 'bars' | 'dots';
  vizStrong: boolean;
  bg: 'none' | 'glass' | 'aura';
  radius: 'square' | 'soft' | 'round';
  /** '' = automatisch aus dem Cover */
  accent: string;
  vinyl: boolean;
  artist: boolean;
  hideSkipped: boolean;
};

export const WALL_DEFAULTS: WallSettings = {
  layout: 'stage',
  rows: 2,
  speed: 'slow',
  viz: 'bars',
  vizStrong: false,
  bg: 'glass',
  radius: 'soft',
  accent: '',
  vinyl: true,
  artist: true,
  hideSkipped: true,
};

export const WALL_ACCENTS = ['#b3f47c', '#7a5cff', '#ff4655', '#7ad7f0'];

const pick = <T extends string | number>(v: unknown, allowed: readonly T[], fallback: T): T =>
  allowed.includes(v as T) ? (v as T) : fallback;

export function cleanWallSettings(value: unknown): WallSettings {
  const v = value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
  const d = WALL_DEFAULTS;
  const bool = (x: unknown, f: boolean) => (typeof x === 'boolean' ? x : f);
  return {
    layout: pick(v.layout, ['stage', 'bar', 'corner'] as const, d.layout),
    rows: pick(v.rows, [1, 2, 3] as const, d.rows),
    speed: pick(v.speed, ['off', 'slow', 'fast'] as const, d.speed),
    viz: pick(v.viz, ['off', 'bars', 'dots'] as const, d.viz),
    vizStrong: bool(v.vizStrong, d.vizStrong),
    bg: pick(v.bg, ['none', 'glass', 'aura'] as const, d.bg),
    radius: pick(v.radius, ['square', 'soft', 'round'] as const, d.radius),
    accent: typeof v.accent === 'string' && /^#[0-9a-f]{6}$/i.test(v.accent) ? v.accent.toLowerCase() : '',
    vinyl: bool(v.vinyl, d.vinyl),
    artist: bool(v.artist, d.artist),
    hideSkipped: bool(v.hideSkipped, d.hideSkipped),
  };
}
