// --- Album Wall (F15): Einstellungen lesen/schreiben (Tabelle wall_settings) ---
import { cleanWallSettings, WALL_DEFAULTS, type WallSettings } from './album-wall-settings';

export async function getWallSettings(d1: D1Database, owner: string): Promise<WallSettings> {
  try {
    const r = await d1
      .prepare('SELECT config FROM wall_settings WHERE owner=?')
      .bind(owner)
      .first<{ config: string }>();
    return r ? cleanWallSettings(JSON.parse(r.config)) : { ...WALL_DEFAULTS };
  } catch {
    // Tabelle fehlt (Migration 0010 noch nicht gelaufen) oder kaputtes JSON.
    return { ...WALL_DEFAULTS };
  }
}

export async function saveWallSettings(d1: D1Database, owner: string, value: unknown) {
  const settings = cleanWallSettings(value);
  await d1
    .prepare(
      `INSERT INTO wall_settings (owner, config, updated_at) VALUES (?,?,?)
       ON CONFLICT(owner) DO UPDATE SET config=excluded.config, updated_at=excluded.updated_at`,
    )
    .bind(owner, JSON.stringify(settings), Date.now())
    .run();
  return settings;
}
