// --- StreamShelf V2 (F21): Einstellungen des Live-Regals (eigene OBS-Quelle) ---
// Getrennt von der Player-Config (Looks überschreiben sie nicht).
// Gespeichert in shelf_settings (Migration 0011), je Besitzer.

export type ShelfWallSettings = {
  material: 'wood' | 'glass' | 'metal';
  back: 'none' | 'dark' | 'wood';
  rows: 2 | 3 | 4;
  wide: boolean;
  now: 'side' | 'off';
  spotlight: boolean;
  led: boolean;
  faves: boolean;
  dividers: boolean;
  artist: boolean;
  hideSkipped: boolean;
};

export const SHELF_WALL_DEFAULTS: ShelfWallSettings = {
  material: 'wood',
  back: 'dark',
  rows: 3,
  wide: false,
  now: 'side',
  spotlight: true,
  led: true,
  faves: true,
  dividers: true,
  artist: true,
  hideSkipped: false,
};

const pick = <T extends string | number>(v: unknown, allowed: readonly T[], fallback: T): T =>
  allowed.includes(v as T) ? (v as T) : fallback;

export function cleanShelfWallSettings(value: unknown): ShelfWallSettings {
  const v = value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
  const d = SHELF_WALL_DEFAULTS;
  const bool = (x: unknown, f: boolean) => (typeof x === 'boolean' ? x : f);
  return {
    material: pick(v.material, ['wood', 'glass', 'metal'] as const, d.material),
    back: pick(v.back, ['none', 'dark', 'wood'] as const, d.back),
    rows: pick(v.rows, [2, 3, 4] as const, d.rows),
    wide: bool(v.wide, d.wide),
    now: pick(v.now, ['side', 'off'] as const, d.now),
    spotlight: bool(v.spotlight, d.spotlight),
    led: bool(v.led, d.led),
    faves: bool(v.faves, d.faves),
    dividers: bool(v.dividers, d.dividers),
    artist: bool(v.artist, d.artist),
    hideSkipped: bool(v.hideSkipped, d.hideSkipped),
  };
}
