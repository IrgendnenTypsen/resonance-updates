// --- Track History (F03): Datenbank-Schicht für den gemeinsamen Verlauf ---
// Tabellen: stream_sessions + track_plays (Migration 0008_track_history).
// Wird einmal pro echtem Spotify-Abruf aufgerufen (Single-flight in
// fetchCurrentlyPlaying), nie pro Overlay-Anfrage. Fehler hier dürfen
// /api/now niemals stören – sie werden gefangen und gedrosselt geloggt.
import type { Track } from './overlay';
import {
  planEnd,
  planObservation,
  trackKey,
  type HistoryOp,
  type HistoryPlay,
  type HistorySession,
  type ObservedTrack,
  type PlayStatus,
} from './track-history-core';

type SessionRow = {
  id: string;
  started_at: number;
  last_seen_at: number;
  ended_at: number | null;
  ended_reason: string | null;
  track_count: number;
};
type PlayRow = {
  id: string;
  session_id: string;
  seq: number;
  track_id: string | null;
  title: string;
  artist: string;
  album: string;
  cover_url: string;
  duration_ms: number;
  started_at: number;
  last_seen_at: number;
  first_progress_ms: number;
  last_progress_ms: number;
  max_progress_ms: number;
  listened_ms: number;
  status: PlayStatus;
  ended_at: number | null;
};

let pausedUntil = 0;
// Aufzeichnung an/aus je Besitzer (Tabelle history_settings, Migration 0009).
// Fehlt die Tabelle, gilt „an“.
const recordingCache = new Map<string, { on: boolean; at: number }>();
const RECORDING_TTL = 30_000;
let warned = false;
const queue = new Map<string, Promise<void>>();

const uid = () =>
  globalThis.crypto?.randomUUID?.() ??
  Date.now().toString(36) + Math.random().toString(36).slice(2);

export function observedFrom(track: Track | null): ObservedTrack | null {
  if (!track || track.demo) return null;
  return {
    trackId: track.id || null,
    title: String(track.title || '').slice(0, 300),
    artist: String(track.artist || '').slice(0, 300),
    album: String(track.album || '').slice(0, 300),
    coverUrl: /^https:\/\//.test(track.cover || '') ? track.cover.slice(0, 500) : '',
    durationMs: Number.isFinite(track.duration) ? Math.max(0, Math.round(track.duration)) : 0,
    progressMs: Number.isFinite(track.progress) ? Math.max(0, Math.round(track.progress)) : 0,
    playing: !!track.playing,
  };
}

async function loadState(d1: D1Database, owner: string) {
  const s = await d1
    .prepare(
      'SELECT * FROM stream_sessions WHERE owner=? AND ended_at IS NULL ORDER BY last_seen_at DESC LIMIT 1',
    )
    .bind(owner)
    .first<SessionRow>();
  if (!s) return { session: null, play: null };
  const p = await d1
    .prepare(
      'SELECT * FROM track_plays WHERE session_id=? AND ended_at IS NULL ORDER BY seq DESC LIMIT 1',
    )
    .bind(s.id)
    .first<PlayRow>();
  const session: HistorySession = {
    id: s.id,
    startedAt: s.started_at,
    lastSeenAt: s.last_seen_at,
    trackCount: s.track_count,
  };
  const play: HistoryPlay | null = p
    ? {
        id: p.id,
        sessionId: p.session_id,
        seq: p.seq,
        key: trackKey({ trackId: p.track_id, title: p.title, artist: p.artist }),
        trackId: p.track_id,
        title: p.title,
        artist: p.artist,
        album: p.album,
        coverUrl: p.cover_url,
        durationMs: p.duration_ms,
        startedAt: p.started_at,
        lastSeenAt: p.last_seen_at,
        firstProgressMs: p.first_progress_ms,
        lastProgressMs: p.last_progress_ms,
        maxProgressMs: p.max_progress_ms,
        listenedMs: p.listened_ms,
      }
    : null;
  return { session, play };
}

function statement(d1: D1Database, owner: string, o: HistoryOp) {
  switch (o.op) {
    case 'openSession':
      return d1
        .prepare(
          'INSERT INTO stream_sessions (id,owner,started_at,last_seen_at,track_count) VALUES (?,?,?,?,0)',
        )
        .bind(o.session.id, owner, o.session.startedAt, o.session.lastSeenAt);
    case 'touchSession':
      return d1
        .prepare('UPDATE stream_sessions SET last_seen_at=?, track_count=? WHERE id=?')
        .bind(o.lastSeenAt, o.trackCount, o.id);
    case 'closeSession':
      return d1
        .prepare('UPDATE stream_sessions SET ended_at=?, ended_reason=? WHERE id=? AND ended_at IS NULL')
        .bind(o.endedAt, o.reason, o.id);
    case 'openPlay': {
      const p = o.play;
      return d1
        .prepare(
          `INSERT INTO track_plays (id,owner,session_id,seq,track_id,title,artist,album,cover_url,duration_ms,
            started_at,last_seen_at,first_progress_ms,last_progress_ms,max_progress_ms,listened_ms,status)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'playing')`,
        )
        .bind(
          p.id, owner, p.sessionId, p.seq, p.trackId, p.title, p.artist, p.album, p.coverUrl,
          p.durationMs, p.startedAt, p.lastSeenAt, p.firstProgressMs, p.lastProgressMs,
          p.maxProgressMs, p.listenedMs,
        );
    }
    case 'updatePlay':
      return d1
        .prepare(
          'UPDATE track_plays SET last_seen_at=?, last_progress_ms=?, max_progress_ms=?, listened_ms=? WHERE id=?',
        )
        .bind(o.lastSeenAt, o.lastProgressMs, o.maxProgressMs, o.listenedMs, o.id);
    case 'closePlay':
      return d1
        .prepare(
          'UPDATE track_plays SET ended_at=?, status=?, listened_ms=?, max_progress_ms=? WHERE id=? AND ended_at IS NULL',
        )
        .bind(o.endedAt, o.status, o.listenedMs, o.maxProgressMs, o.id);
  }
}

/** Eine Spotify-Beobachtung in den Verlauf übernehmen (nie werfend). */
export function recordObservation(
  d1: D1Database,
  owner: string,
  track: Track | null,
  at = Date.now(),
): Promise<void> {
  if (at < pausedUntil) return Promise.resolve();
  return enqueue(owner, async () => {
    if (!(await isRecording(d1, owner))) return;
    const state = await loadState(d1, owner);
    const { ops } = planObservation(state, observedFrom(track), at, uid);
    if (ops.length) await d1.batch(ops.map((o) => statement(d1, owner, o)));
  }).catch((e: unknown) => {
    const msg = e instanceof Error ? e.message : String(e);
    const missing = /no such table/i.test(msg);
    // Tabelle fehlt (Migration noch nicht gelaufen) → eine Minute Ruhe.
    pausedUntil = Date.now() + 60_000;
    if (!warned || !missing) {
      warned = true;
      console.warn(
        '[TRACK HISTORY]',
        missing ? 'Verlaufstabellen fehlen – Resonance einmal neu starten (Migration 0008).' : msg,
      );
    }
  });
}

/** Läuft die Aufzeichnung für diesen Besitzer? (gecacht, Standard: an) */
export async function isRecording(d1: D1Database, owner: string): Promise<boolean> {
  const hit = recordingCache.get(owner);
  if (hit && Date.now() - hit.at < RECORDING_TTL) return hit.on;
  let on = true;
  try {
    const r = await d1
      .prepare('SELECT recording FROM history_settings WHERE owner=?')
      .bind(owner)
      .first<{ recording: number }>();
    if (r) on = r.recording !== 0;
  } catch {
    // Tabelle fehlt (Migration 0009 noch nicht gelaufen) → Standard „an“.
  }
  recordingCache.set(owner, { on, at: Date.now() });
  return on;
}

function enqueue(owner: string, job: () => Promise<void>): Promise<void> {
  const prev = queue.get(owner) ?? Promise.resolve();
  const next = prev.catch(() => {}).then(job);
  const tail = next.catch(() => {});
  queue.set(owner, tail);
  void tail.finally(() => {
    if (queue.get(owner) === tail) queue.delete(owner);
  });
  return next;
}

/** Laufende Session beenden (Button „Stream beenden“). Wirft bei DB-Fehlern. */
export function endLiveSession(d1: D1Database, owner: string, at = Date.now()) {
  return enqueue(owner, async () => {
    const ops = planEnd(await loadState(d1, owner), at);
    if (ops.length) await d1.batch(ops.map((o) => statement(d1, owner, o)));
  });
}

/** Aufzeichnung an/aus. „Aus“ beendet zusätzlich die laufende Session. */
export async function setRecording(d1: D1Database, owner: string, on: boolean, at = Date.now()) {
  await d1
    .prepare(
      `INSERT INTO history_settings (owner, recording, updated_at) VALUES (?,?,?)
       ON CONFLICT(owner) DO UPDATE SET recording=excluded.recording, updated_at=excluded.updated_at`,
    )
    .bind(owner, on ? 1 : 0, at)
    .run();
  recordingCache.set(owner, { on, at: Date.now() });
  if (!on) await endLiveSession(d1, owner, at);
}

// --- Lesen (für Verlauf-UI, Album Wall, StreamShelf) ---

export type HistorySessionView = {
  id: string;
  startedAt: number;
  lastSeenAt: number;
  endedAt: number | null;
  trackCount: number;
  live: boolean;
  /** Bis zu 4 Cover für die Mosaik-Vorschau. */
  covers: string[];
};
export type HistoryPlayView = {
  id: string;
  seq: number;
  trackId: string | null;
  title: string;
  artist: string;
  album: string;
  cover: string;
  durationMs: number;
  startedAt: number;
  endedAt: number | null;
  listenedMs: number;
  observedFromMs: number;
  status: PlayStatus;
};

export async function listSessions(d1: D1Database, owner: string, limit = 20) {
  const r = await d1
    .prepare(
      'SELECT * FROM stream_sessions WHERE owner=? AND track_count>0 ORDER BY started_at DESC LIMIT ?',
    )
    .bind(owner, Math.max(1, Math.min(100, limit)))
    .all<SessionRow>();
  const rows = r.results || [];
  const covers = new Map<string, string[]>();
  if (rows.length) {
    const c = await d1
      .prepare(
        `SELECT session_id, cover_url FROM track_plays WHERE owner=? AND cover_url<>'' AND session_id IN (${rows.map(() => '?').join(',')}) ORDER BY seq ASC`,
      )
      .bind(owner, ...rows.map((x) => x.id))
      .all<{ session_id: string; cover_url: string }>();
    for (const x of c.results || []) {
      const list = covers.get(x.session_id) ?? [];
      if (list.length < 4 && !list.includes(x.cover_url)) list.push(x.cover_url);
      covers.set(x.session_id, list);
    }
  }
  return rows.map(
    (s): HistorySessionView => ({
      id: s.id,
      startedAt: s.started_at,
      lastSeenAt: s.last_seen_at,
      endedAt: s.ended_at,
      trackCount: s.track_count,
      live: s.ended_at == null,
      covers: covers.get(s.id) ?? [],
    }),
  );
}

export async function sessionPlays(d1: D1Database, owner: string, sessionId: string) {
  const r = await d1
    .prepare('SELECT * FROM track_plays WHERE owner=? AND session_id=? ORDER BY seq ASC')
    .bind(owner, sessionId)
    .all<PlayRow>();
  return (r.results || []).map(
    (p): HistoryPlayView => ({
      id: p.id,
      seq: p.seq,
      trackId: p.track_id,
      title: p.title,
      artist: p.artist,
      album: p.album,
      cover: p.cover_url,
      durationMs: p.duration_ms,
      startedAt: p.started_at,
      endedAt: p.ended_at,
      listenedMs: p.listened_ms,
      observedFromMs: p.first_progress_ms,
      status: p.status,
    }),
  );
}
