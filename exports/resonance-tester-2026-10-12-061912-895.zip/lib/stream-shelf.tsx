'use client';
// --- StreamShelf V1 (F21): CD-Player mit Regal ---
// Das Regal links zeigt die zuletzt gespielten Songs des LAUFENDEN Streams
// aus dem gemeinsamen Song-Verlauf (F03, /api/history) – kein eigener Speicher.
// OBS-Quelle: Overlay-Key aus dem Link (#key) als Bearer, Studio: Anmeldung.
import { useEffect, useRef, useState } from 'react';
import { getCoverAccent, peekCoverAccent } from './cover-accent';
import type { Track } from './overlay';

export type ShelfSpine = { id: string; title: string; artist: string; cover: string };

const SPINE_FALLBACK = ['#e8455f', '#b3f47c', '#c8b8ff', '#ffb3c7', '#4fd18b', '#ff9f43', '#7ad7f0', '#ffd166'];

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

/** Schlüssel eines Songs (wie im Verlauf: Spotify-ID, sonst Titel + Interpret). */
function songKey(x: { id?: string | null; trackId?: string | null; title: string; artist: string }) {
  return (('trackId' in x ? x.trackId : x.id) || '') || x.title + '\u0000' + x.artist;
}

/**
 * Letzte Songs + Songnummer des laufenden Streams.
 * - Stream-Anfang: Regal leer.
 * - Songwechsel: der vorherige Song wird SOFORT eingeräumt (auch wenn er
 *   übersprungen wurde) und danach mit dem Verlauf abgeglichen.
 * - Demo (Galerie/Vorschau ohne Spotify): startet leer, füllt sich lokal.
 */
export function useShelfHistory(enabled: boolean, track: Track | null) {
  const [server, setServer] = useState<{ spines: ShelfSpine[]; count: number; live: boolean } | null>(null);
  const [local, setLocal] = useState<ShelfSpine[]>([]);
  const demo = !!track?.demo;
  const key = track ? songKey(track) : '';
  const prevTrack = useRef<Track | null>(null);
  const prevKey = useRef('');
  const currentKey = useRef('');
  currentKey.current = key;

  // Songwechsel: alten Song sofort einräumen.
  useEffect(() => {
    if (!enabled || !key) return;
    const before = prevTrack.current;
    if (before && prevKey.current && prevKey.current !== key) {
      const spine: ShelfSpine = {
        id: 'local-' + prevKey.current + '-' + Date.now(),
        title: before.title,
        artist: before.artist,
        cover: before.cover,
      };
      setLocal((l) => [...l, spine].slice(-12));
    }
    prevTrack.current = track;
    prevKey.current = key;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, key]);

  // Verlauf laden (nicht im Demo-Modus): direkt, kurz nach jedem Wechsel und jede Minute.
  useEffect(() => {
    if (!enabled || demo) return;
    let alive = true;
    const load = async () => {
      try {
        const k = typeof location !== 'undefined' ? location.hash.slice(1) : '';
        const onOverlay = typeof location !== 'undefined' && location.pathname.startsWith('/overlay');
        const r = await fetch('/api/history', {
          cache: 'no-store',
          headers: onOverlay && k ? { Authorization: 'Bearer ' + k } : undefined,
        });
        if (!r.ok) return;
        const d = (await r.json()) as {
          current?: {
            session: { live: boolean; trackCount: number };
            plays: { id: string; trackId: string | null; title: string; artist: string; cover: string; status: string }[];
          } | null;
        };
        if (!alive) return;
        const cur = d.current;
        if (!cur || !cur.session.live) {
          setServer({ spines: [], count: 0, live: false });
          setLocal([]);
          return;
        }
        const plays = [...cur.plays];
        // Der gerade laufende Song steht noch nicht im Regal (letzter Eintrag
        // mit seinem Schlüssel – auch wenn der Verlauf ihn noch nicht kennt).
        const last = plays[plays.length - 1];
        if (last && songKey(last) === currentKey.current) plays.pop();
        setServer({
          spines: plays.map((p) => ({ id: p.id, title: p.title, artist: p.artist, cover: p.cover })),
          count: cur.session.trackCount,
          live: true,
        });
        setLocal([]);
      } catch {
        // Verlauf nicht erreichbar → Regal bleibt, wie es ist.
      }
    };
    void load();
    const t1 = setTimeout(load, 3500);
    const t2 = setTimeout(load, 9000);
    const t = setInterval(load, 60000);
    return () => {
      alive = false;
      clearTimeout(t1);
      clearTimeout(t2);
      clearInterval(t);
    };
  }, [enabled, demo, key]);

  if (demo) return { spines: local, count: local.length + 1 };
  const base = server?.spines ?? [];
  // Lokal eingeräumte Songs, die der Verlauf noch nicht kennt, hinten anhängen.
  const tail = base.length ? songKey({ ...base[base.length - 1], id: null }) : '';
  const pending = local.filter((l) => songKey({ ...l, id: null }) !== tail);
  const spines = [...base, ...pending];
  return { spines, count: Math.max(server?.count ?? 0, spines.length + (track ? 1 : 0)) };
}

function luminance(hex: string) {
  const m = /^#([0-9a-f]{6})$/i.exec(hex);
  if (!m) return 0;
  const n = parseInt(m[1], 16);
  return (0.2126 * ((n >> 16) & 255) + 0.7152 * ((n >> 8) & 255) + 0.0722 * (n & 255)) / 255;
}

function Spine({ spine, lean, fresh }: { spine: ShelfSpine; lean: boolean; fresh: boolean }) {
  const fallback = SPINE_FALLBACK[hash(spine.title + spine.artist) % SPINE_FALLBACK.length];
  const [color, setColor] = useState<string>(
    () => (spine.cover && peekCoverAccent(spine.cover)) || fallback,
  );
  useEffect(() => {
    if (!spine.cover) return;
    let alive = true;
    void getCoverAccent(spine.cover).then((c) => alive && c && setColor(c));
    return () => {
      alive = false;
    };
  }, [spine.cover]);
  const ink = luminance(color) > 0.6 ? '#1d1a16' : '#ffffffeb';
  return (
    <span
      className={'sh-spine' + (lean ? ' is-lean' : '') + (fresh ? ' is-fresh' : '')}
      style={{ '--sh-spine': color, color: ink } as React.CSSProperties}
      title={spine.artist + ' – ' + spine.title}
    >
      <span>{(spine.artist ? spine.artist + ' – ' : '') + spine.title}</span>
    </span>
  );
}

export function ShelfSpines({ spines, max, lean }: { spines: ShelfSpine[]; max: number; lean: boolean }) {
  // Stabile Schlüssel (Titel + Interpret + Vorkommen), damit ein lokal
  // eingeräumter Rücken beim Abgleich mit dem Verlauf nicht neu hineinfällt.
  const seen = new Map<string, number>();
  const keyed = spines.map((s) => {
    const base = s.title + '\u0000' + s.artist;
    const n = (seen.get(base) || 0) + 1;
    seen.set(base, n);
    return { s, k: base + '#' + n };
  });
  const shown = keyed.slice(-max);
  if (!shown.length) return null;
  return (
    <div className="sh-spines" aria-hidden="true">
      {shown.map(({ s, k }, i) => (
        <Spine key={k} spine={s} lean={lean && i === shown.length - 1} fresh={i === shown.length - 1} />
      ))}
    </div>
  );
}
