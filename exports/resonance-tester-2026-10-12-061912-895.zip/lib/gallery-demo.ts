// --- Galerie: Demo-Playlist ohne Spotify („Try before you connect“) ---
// Fünf erfundene Songs mit generierten Covern (SVG-Data-URLs, keine echten
// Albumcover). Die Galerie spielt sie nacheinander ab, damit Songwechsel-
// Effekte der Player (Sticky Notes, Pocket Quest, Transitions) sichtbar werden.
import type { Track } from './overlay';

function cover(a: string, b: string, c: string, shape: string) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset=".6" stop-color="${b}"/><stop offset="1" stop-color="${c}"/></linearGradient></defs><rect width="120" height="120" fill="url(#g)"/>${shape}</svg>`;
  return 'data:image/svg+xml,' + encodeURIComponent(svg);
}

export const GALLERY_TRACKS: Track[] = [
  {
    id: 'gallery-1',
    title: 'Midnight in Motion',
    artist: 'Resonance Radio',
    album: 'Starlight',
    cover: cover('#7a5cff', '#3a1f7a', '#120a2a', '<circle cx="78" cy="42" r="18" fill="#ffd6f6" opacity=".85"/><path d="M0 92 L40 70 L70 84 L120 60 L120 120 L0 120Z" fill="#0b0618" opacity=".7"/>'),
    duration: 224000,
    progress: 61000,
    playing: true,
    demo: true,
  },
  {
    id: 'gallery-2',
    title: 'Fire & Adrenaline',
    artist: 'Voltage Club',
    album: 'Voltage',
    cover: cover('#ff7a3d', '#d4213a', '#3a0614', '<path d="M60 18 L84 64 L66 64 L76 102 L36 52 L56 52Z" fill="#fff2b0" opacity=".9"/>'),
    duration: 198000,
    progress: 44000,
    playing: true,
    demo: true,
  },
  {
    id: 'gallery-3',
    title: 'Quiet Ocean',
    artist: 'Slow Breathing',
    album: 'Tides',
    cover: cover('#9ff0e6', '#2a8c9a', '#0b2a3a', '<path d="M0 70 Q30 58 60 70 T120 70 L120 120 L0 120Z" fill="#0b2a3a" opacity=".55"/><path d="M0 86 Q30 74 60 86 T120 86 L120 120 L0 120Z" fill="#06161f" opacity=".7"/>'),
    duration: 251000,
    progress: 98000,
    playing: true,
    demo: true,
  },
  {
    id: 'gallery-4',
    title: 'Sunshine Smile',
    artist: 'Good Times',
    album: 'Golden Hour',
    cover: cover('#fff27a', '#ff9ec4', '#ff5c8a', '<circle cx="60" cy="60" r="26" fill="#fff" opacity=".85"/><circle cx="60" cy="60" r="36" fill="none" stroke="#fff" stroke-width="3" stroke-dasharray="6 8" opacity=".8"/>'),
    duration: 187000,
    progress: 33000,
    playing: true,
    demo: true,
  },
  {
    id: 'gallery-5',
    title: 'Shadows & Ghosts',
    artist: 'Nocturne',
    album: 'Afterhours',
    cover: cover('#5a5f73', '#24263a', '#08080f', '<rect x="30" y="30" width="60" height="60" fill="none" stroke="#c8b8ff" stroke-width="2" transform="rotate(12 60 60)" opacity=".7"/><rect x="40" y="40" width="40" height="40" fill="#c8b8ff" opacity=".25" transform="rotate(-8 60 60)"/>'),
    duration: 236000,
    progress: 120000,
    playing: true,
    demo: true,
  },
];
