// --- Overlay Stress Lab (F06): deterministische Grenzfälle für alle Player ---
// Keine echten Daten, keine Netzwerkabhängigkeit (Cover als SVG-Data-URL).
import type { Track } from './overlay';

const svgCover = (a: string, b: string) =>
  'data:image/svg+xml,' +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="64" height="64" fill="url(#g)"/></svg>`,
  );

const base: Track = {
  id: 'stress-base',
  title: 'Midnight in Motion',
  artist: 'Resonance Radio',
  album: 'Starlight',
  cover: svgCover('#7a5cff', '#120a2a'),
  duration: 224000,
  progress: 87000,
  playing: true,
};

export type StressScenario = {
  id: string;
  label: string;
  note: string;
  track: Track;
  /** Schnelle Songwechsel: diese Tracks werden reihum gesetzt. */
  rapid?: Track[];
};

export const STRESS_SCENARIOS: StressScenario[] = [
  {
    id: 'long',
    label: 'Extrem langer Titel',
    note: 'Titel + Künstler weit über jede Breite',
    track: {
      ...base,
      id: 'stress-long',
      title:
        'Ein wirklich extrem langer Songtitel der niemals in eine Zeile passt (feat. Noch Ein Künstler & Freunde) [Remastered 2026 Deluxe Edition]',
      artist:
        'The Very Long Artist Name Collective feat. Somebody Else, Another Person & The Orchestra',
    },
  },
  {
    id: 'nocover',
    label: 'Kein Cover',
    note: 'Leere Cover-URL',
    track: { ...base, id: 'stress-nocover', cover: '' },
  },
  {
    id: 'noartist',
    label: 'Kein Künstler',
    note: 'Leerer Künstlername',
    track: { ...base, id: 'stress-noartist', artist: '' },
  },
  {
    id: 'unicode',
    label: 'Emoji & Sonderzeichen',
    note: 'Emoji, CJK, Arabisch, Akzente',
    track: {
      ...base,
      id: 'stress-unicode',
      title: '🔥 Ñandú — 東京ナイト ✨ (ﾟ∀ﾟ) حب',
      artist: 'Björk & Ølafur Ärnalds 🎧',
    },
  },
  {
    id: 'paused',
    label: 'Pausiert',
    note: 'playing = false',
    track: { ...base, id: 'stress-paused', playing: false },
  },
  {
    id: 'short',
    label: 'Sehr kurzer Song',
    note: '15 s, fast am Ende',
    track: { ...base, id: 'stress-short', duration: 15000, progress: 14500 },
  },
  {
    id: 'marathon',
    label: 'Sehr langer Song',
    note: '3 h Mix, fast am Ende',
    track: { ...base, id: 'stress-marathon', duration: 10800000, progress: 10790000 },
  },
  {
    id: 'zero',
    label: 'Dauer 0',
    note: 'Dauer und Fortschritt 0 (Division durch 0?)',
    track: { ...base, id: 'stress-zero', duration: 0, progress: 0 },
  },
  {
    id: 'rapid',
    label: 'Schnelle Songwechsel',
    note: 'Alle 400 ms ein neuer Song',
    track: base,
    rapid: [0, 1, 2, 3, 4].map((i) => ({
      ...base,
      id: 'stress-rapid-' + i,
      title: ['Alpha', 'Bravo Bravo', 'Charlie', 'Delta Delta Delta', 'Echo'][i],
      cover: svgCover(['#ff4655', '#0ac8b9', '#ffd166', '#c27bff', '#4fd18b'][i], '#111'),
    })),
  },
];

/** Breiten der simulierten OBS-Browserquelle. */
export const STRESS_WIDTHS = [320, 480, 900];
