import type { Config, Track } from './overlay';
import { isMoodEffectivelyEnabled } from './mood-capabilities';

type MoodWord = { w: string; n: number }; // w = Wort, n = Gewicht (0.3–1.0)

export const moods = [
  {
    id: 'energy',
    label: 'Energisch',
    accent: '#ff9068',
    dark: '#301b21',
    light: '#ffe3cc',
    speed: 0.42,
    genres: [
      'edm',
      'dance',
      'techno',
      'hardstyle',
      'drum and bass',
      'punk',
      'metal',
      'rock',
    ],
    words: [
      { w: 'fire', n: 1.0 },
      { w: 'feuer', n: 1.0 },
      { w: 'rage', n: 0.9 },
      { w: 'wut', n: 0.8 },
      { w: 'wütend', n: 0.8 },
      { w: 'hass', n: 0.8 },
      { w: 'hasse', n: 0.8 },
      { w: 'power', n: 0.9 },
      { w: 'kraft', n: 0.8 },
      { w: 'wild', n: 0.8 },
      { w: 'wildness', n: 0.8 },
      { w: 'run', n: 0.7 },
      { w: 'rave', n: 0.9 },
      { w: 'adrenaline', n: 0.9 },
      { w: 'adrenalin', n: 0.9 },
      { w: 'storm', n: 0.7 },
      { w: 'sturm', n: 0.7 },
      { w: 'hard', n: 0.7 },
      { w: 'hart', n: 0.7 },
      { w: 'bass', n: 0.8 },
      { w: 'drop', n: 0.7 },
      { w: 'hype', n: 0.9 },
      { w: 'party', n: 0.8 },
      { w: 'techno', n: 0.7 },
      { w: 'punk', n: 0.7 },
      { w: 'metal', n: 0.7 },
      { w: 'rock', n: 0.6 },
      { w: 'schnell', n: 0.7 },
      { w: 'energie', n: 0.8 },
      { w: 'energy', n: 0.8 },
      { w: 'treiben', n: 0.6 },
      { w: 'brennen', n: 0.8 },
      { w: 'burn', n: 0.8 },
      { w: 'zerstören', n: 0.7 },
      { w: 'destroy', n: 0.7 },
      { w: 'kämpfen', n: 0.7 },
      { w: 'fight', n: 0.7 },
      { w: 'krieg', n: 0.8 },
      { w: 'war', n: 0.8 },
    ],
  },
  {
    id: 'angry',
    label: 'Wütend',
    accent: '#ff9b83',
    dark: '#210e12',
    light: '#ffe3d6',
    speed: 0.5,
    genres: ['metal', 'hardcore', 'thrash', 'punk'],
    words: [
      { w: 'hate', n: 1.0 },
      { w: 'hass', n: 1.0 },
      { w: 'hasse', n: 1.0 },
      { w: 'wut', n: 1.0 },
      { w: 'rage', n: 1.0 },
      { w: 'wütend', n: 1.0 },
      { w: 'fury', n: 0.9 },
      { w: 'furious', n: 0.9 },
      { w: 'mad', n: 0.8 },
      { w: 'kill', n: 0.8 },
      { w: 'zerstören', n: 0.8 },
      { w: 'destroy', n: 0.8 },
      { w: 'kämpfen', n: 0.7 },
      { w: 'fight', n: 0.7 },
      { w: 'krieg', n: 0.8 },
      { w: 'war', n: 0.8 },
    ],
  },
  {
    id: 'calm',
    label: 'Ruhig',
    accent: '#75dbc7',
    dark: '#162c2a',
    light: '#d4f5e9',
    speed: 1.6,
    genres: [
      'ambient',
      'chill',
      'lo fi',
      'lounge',
      'meditation',
      'downtempo',
      'classical',
    ],
    words: [
      { w: 'calm', n: 1.0 },
      { w: 'ruhig', n: 1.0 },
      { w: 'peace', n: 0.9 },
      { w: 'frieden', n: 0.9 },
      { w: 'quiet', n: 0.8 },
      { w: 'still', n: 0.8 },
      { w: 'leise', n: 0.8 },
      { w: 'sanft', n: 0.8 },
      { w: 'gentle', n: 0.8 },
      { w: 'breathe', n: 0.8 },
      { w: 'atmen', n: 0.7 },
      { w: 'sleep', n: 0.7 },
      { w: 'schlaf', n: 0.7 },
      { w: 'meer', n: 0.7 },
      { w: 'ocean', n: 0.7 },
      { w: 'relax', n: 0.8 },
      { w: 'entspannung', n: 0.8 },
      { w: 'nacht', n: 0.6 },
      { w: 'night', n: 0.6 },
      { w: 'regen', n: 0.6 },
      { w: 'rain', n: 0.6 },
      { w: 'langsam', n: 0.7 },
      { w: 'slow', n: 0.7 },
      { w: 'träume', n: 0.7 },
      { w: 'traum', n: 0.7 },
      { w: 'dream', n: 0.7 },
      { w: 'mond', n: 0.6 },
      { w: 'moon', n: 0.6 },
      { w: 'midnight', n: 0.7 },
      { w: 'mitternacht', n: 0.7 },
      { w: 'stars', n: 0.6 },
      { w: 'sterne', n: 0.6 },
      { w: 'cosmic', n: 0.7 },
      { w: 'kosmisch', n: 0.7 },
      { w: 'floating', n: 0.7 },
      { w: 'schweben', n: 0.7 },
      { w: 'nebel', n: 0.6 },
      { w: 'fog', n: 0.6 },
      { w: 'hazy', n: 0.5 },
      { w: 'unscharf', n: 0.5 },
      { w: 'ether', n: 0.6 },
      { w: 'wolkig', n: 0.5 },
      { w: 'cloudy', n: 0.5 },
    ],
  },
  {
    id: 'sad',
    label: 'Melancholisch',
    accent: '#94b5ff',
    dark: '#1b243a',
    light: '#dbe8ff',
    speed: 1.4,
    genres: ['sad', 'sadcore', 'slowcore', 'blues', 'emo'],
    words: [
      { w: 'sad', n: 1.0 },
      { w: 'traurig', n: 1.0 },
      { w: 'tears', n: 0.8 },
      { w: 'tränen', n: 0.8 },
      { w: 'weinen', n: 0.8 },
      { w: 'cry', n: 0.8 },
      { w: 'lonely', n: 0.9 },
      { w: 'einsam', n: 0.9 },
      { w: 'allein', n: 0.8 },
      { w: 'alone', n: 0.8 },
      { w: 'goodbye', n: 0.9 },
      { w: 'abschied', n: 0.9 },
      { w: 'broken', n: 0.9 },
      { w: 'zerbrochen', n: 0.9 },
      { w: 'kaputt', n: 0.8 },
      { w: 'weh', n: 0.8 },
      { w: 'schmerz', n: 0.8 },
      { w: 'pain', n: 0.8 },
      { w: 'missing', n: 0.8 },
      { w: 'vermissen', n: 0.9 },
      { w: 'vermisse', n: 0.9 },
      { w: 'vergessen', n: 0.7 },
      { w: 'lost', n: 0.8 },
      { w: 'verloren', n: 0.9 },
      { w: 'leer', n: 0.7 },
      { w: 'empty', n: 0.7 },
      { w: 'hoffnungslos', n: 0.9 },
      { w: 'hopeless', n: 0.9 },
      { w: 'verlassen', n: 0.8 },
      { w: 'ungeliebt', n: 0.8 },
      { w: 'tod', n: 0.8 },
      { w: 'death', n: 0.8 },
      { w: 'sterben', n: 0.8 },
      { w: 'dull', n: 0.6 },
      { w: 'fade', n: 0.7 },
      { w: 'blue', n: 0.6 },
      { w: 'blau', n: 0.6 },
      { w: 'regen', n: 0.5 },
      { w: 'rain', n: 0.5 },
    ],
  },
  {
    id: 'happy',
    label: 'Fröhlich',
    accent: '#ffcc60',
    dark: '#302719',
    light: '#fff1c8',
    speed: 0.7,
    genres: ['disco', 'funk', 'ska', 'sunshine pop'],
    words: [
      { w: 'happy', n: 1.0 },
      { w: 'glücklich', n: 1.0 },
      { w: 'sunshine', n: 0.9 },
      { w: 'sonne', n: 0.9 },
      { w: 'joy', n: 0.9 },
      { w: 'freude', n: 0.9 },
      { w: 'celebrate', n: 0.8 },
      { w: 'feiern', n: 0.8 },
      { w: 'smile', n: 0.8 },
      { w: 'lächeln', n: 0.8 },
      { w: 'lachen', n: 0.8 },
      { w: 'laugh', n: 0.8 },
      { w: 'sunny', n: 0.8 },
      { w: 'sommer', n: 0.8 },
      { w: 'summer', n: 0.8 },
      { w: 'good times', n: 0.7 },
      { w: 'gut', n: 0.6 },
      { w: 'good', n: 0.6 },
      { w: 'liebe', n: 0.7 },
      { w: 'love', n: 0.7 },
      { w: 'frei', n: 0.8 },
      { w: 'free', n: 0.8 },
      { w: 'freiheit', n: 0.8 },
      { w: 'freedom', n: 0.8 },
      { w: 'leben', n: 0.7 },
      { w: 'live', n: 0.7 },
      { w: 'tanzen', n: 0.8 },
      { w: 'dance', n: 0.8 },
      { w: 'feuer', n: 0.6 },
      { w: 'bright', n: 0.7 },
    ],
  },
  {
    id: 'dark',
    label: 'Düster',
    accent: '#df7da9',
    dark: '#2d172a',
    light: '#f7dce9',
    speed: 0.9,
    genres: ['darkwave', 'gothic', 'black metal', 'industrial', 'dark ambient'],
    words: [
      { w: 'dark', n: 1.0 },
      { w: 'dunkel', n: 1.0 },
      { w: 'shadows', n: 0.9 },
      { w: 'schatten', n: 0.9 },
      { w: 'nightmare', n: 0.9 },
      { w: 'albtraum', n: 0.9 },
      { w: 'haunted', n: 0.9 },
      { w: 'geist', n: 0.8 },
      { w: 'ghost', n: 0.8 },
      { w: 'finsternis', n: 0.9 },
      { w: 'black', n: 0.8 },
      { w: 'schwarz', n: 0.8 },
      { w: 'tot', n: 0.8 },
      { w: 'dead', n: 0.8 },
      { w: 'blut', n: 0.8 },
      { w: 'blood', n: 0.8 },
      { w: 'dämon', n: 0.8 },
      { w: 'demon', n: 0.8 },
      { w: 'hölle', n: 0.8 },
      { w: 'hell', n: 0.8 },
      { w: 'toxisch', n: 0.8 },
      { w: 'toxic', n: 0.8 },
      { w: 'gefahr', n: 0.7 },
      { w: 'danger', n: 0.7 },
      { w: 'angst', n: 0.8 },
      { w: 'fear', n: 0.8 },
      { w: 'pest', n: 0.7 },
      { w: 'plague', n: 0.7 },
      { w: 'grab', n: 0.8 },
      { w: 'grave', n: 0.8 },
      { w: 'sarg', n: 0.8 },
      { w: 'coffin', n: 0.8 },
      { w: 'nacht', n: 0.6 },
      { w: 'night', n: 0.6 },
    ],
  },
  {
    id: 'romantic',
    label: 'Romantisch',
    accent: '#ff7eb3',
    dark: '#2d1a24',
    light: '#f7dce9',
    speed: 1.1,
    genres: ['romantic', 'love songs', 'ballad'],
    words: [
      { w: 'liebe', n: 1.0 }, { w: 'love', n: 1.0 },
      { w: 'kuss', n: 0.9 }, { w: 'kiss', n: 0.9 },
      { w: 'herz', n: 0.8 }, { w: 'heart', n: 0.8 },
      { w: 'forever', n: 0.7 }, { w: 'für immer', n: 0.7 },
      { w: 'sehnsucht', n: 0.8 }, { w: 'yearning', n: 0.8 },
      { w: 'starlight', n: 0.6 }, { w: 'sternenlicht', n: 0.6 },
      { w: 'glitzer', n: 0.6 }, { w: 'glimmer', n: 0.6 }, { w: 'schimmer', n: 0.6 },
    ],
  },
  {
    id: 'lonely',
    label: 'Einsam',
    accent: '#8ba4c7',
    dark: '#1a2033',
    light: '#d4e0f0',
    speed: 1.5,
    genres: ['loner', 'bedroom pop', 'sadcore'],
    words: [
      { w: 'einsam', n: 1.0 }, { w: 'lonely', n: 1.0 },
      { w: 'allein', n: 0.9 }, { w: 'alone', n: 0.9 },
      { w: 'niemand', n: 0.8 }, { w: 'nobody', n: 0.8 },
      { w: 'verlassen', n: 0.8 }, { w: 'abandoned', n: 0.8 },
    ],
  },
  {
    id: 'hopeful',
    label: 'Hoffnungsvoll',
    accent: '#7dd3a8',
    dark: '#1a2d22',
    light: '#d4f5e4',
    speed: 0.9,
    genres: ['uplifting', 'inspirational'],
    words: [
      { w: 'hoffnung', n: 1.0 }, { w: 'hope', n: 1.0 },
      { w: 'morgen', n: 0.7 }, { w: 'tomorrow', n: 0.7 },
      { w: 'besser', n: 0.6 }, { w: 'better', n: 0.6 },
      { w: 'weiter', n: 0.7 }, { w: 'keep going', n: 0.7 },
      { w: 'himmel', n: 0.6 }, { w: 'sky', n: 0.6 },
    ],
  },
  {
    id: 'nostalgic',
    label: 'Nostalgisch',
    accent: '#d4a574',
    dark: '#2d2419',
    light: '#f0e4d4',
    speed: 1.3,
    genres: ['retro', 'vintage', 'classic rock'],
    words: [
      { w: 'damals', n: 1.0 }, { w: 'remember', n: 0.9 },
      { w: 'erinnerung', n: 0.9 }, { w: 'memories', n: 0.9 },
      { w: 'früher', n: 0.8 }, { w: 'back then', n: 0.8 },
      { w: 'alte', n: 0.6 }, { w: 'old', n: 0.5 },
    ],
  },
] as const;
const normalize = (s: string) =>
  s
    .toLowerCase()
    .normalize('NFKC')
    .replace(/[\p{P}\p{S}]+/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
function contains(text: string, term: string) {
  return (' ' + normalize(text) + ' ').includes(' ' + normalize(term) + ' ');
}
// --- Last.fm Metadata Cache ---
const LASTFM_CACHE_TTL = 86400000; // 24 Stunden
const lastfmTagCache = new Map<
  string,
  {
    tags: Array<{ tag: string; count: number }>;
    checkedAt: number;
  }
>();
const lastfmInFlight = new Map<
  string,
  Promise<Array<{ tag: string; count: number }>>
>();

// --- MusicBrainz Cache ---
const MB_CACHE_TTL = 86400000 * 7; // 7 Tage (ISRC→MBID ändert sich fast nie)
const mbRecordingCache = new Map<
  string,
  { mbid: string | null; checkedAt: number }
>();
const mbInFlight = new Map<string, Promise<string | null>>();

// --- ListenBrainz Cache ---
const LB_CACHE_TTL = 86400000; // 24 Stunden
const lbTagCache = new Map<
  string,
  { tags: Array<{ tag: string; count: number }>; checkedAt: number }
>();
const lbInFlight = new Map<
  string,
  Promise<Array<{ tag: string; count: number }>>
>();

export type LastfmTag = {
  tag: string;
  count: number;
  source: 'track' | 'album' | 'artist' | 'listenbrainz';
};

function lastfmCacheKey(
  source: 'track' | 'album' | 'artist',
  artist: string,
  title?: string,
  album?: string,
): string {
  const a = normalize(artist);
  if (source === 'track') return `lastfm:track:${a}::${normalize(title!)}`;
  if (source === 'album') return `lastfm:album:${a}::${normalize(album!)}`;
  return `lastfm:artist:${a}`;
}

async function lastfmGetTopTags(
  apiKey: string,
  method: string,
  params: Record<string, string>,
): Promise<Array<{ tag: string; count: number }>> {
  const qs = new URLSearchParams({
    api_key: apiKey,
    format: 'json',
    autocorrect: '1',
    ...params,
  });
  const url = `https://ws.audioscrobbler.com/2.0/?method=${method}&${qs}`;
  try {
    const r = await fetch(url, { signal: AbortSignal.timeout(4000) });
    if (!r.ok) return [];
    const d = (await r.json()) as {
      toptags?: { tag?: Array<{ name: string; count: number }> };
    };
    return (d.toptags?.tag || []).map((t) => ({
      tag: t.name.toLowerCase().trim(),
      count: t.count,
    }));
  } catch {
    return [];
  }
}

// --- Mood-Provider Debug-Logging (nur Logging, keine Verhaltensänderung) ---
function usableMoodTagNames(tags: Array<{ tag: string }>): string[] {
  return tags
    .map((t) => t.tag.toLowerCase().trim())
    .filter((tag) => TAG_TO_MOOD[tag]?.length);
}

function logLastfmProvider(
  level: 'track' | 'album' | 'artist',
  tags: LastfmTag[],
): void {
  const usable = usableMoodTagNames(tags);
  console.log('[MOOD PROVIDER]', {
    provider: 'lastfm',
    level,
    tags: tags.map((t) => t.tag),
    usableMoodTags: usable,
    hasUsableMoodSignal: usable.length > 0,
  });
}

export async function fetchLastfmTagsWithFallback(
  artist: string,
  title: string,
  album?: string,
): Promise<LastfmTag[]> {
  const apiKey =
    (globalThis as any).LASTFM_API_KEY ||
    (typeof process !== 'undefined' && process.env?.LASTFM_API_KEY) ||
    '';
  if (!apiKey) return [];

  const results: LastfmTag[] = [];

  // === 1. TRACK TAGS ===
  const trackKey = lastfmCacheKey('track', artist, title);
  const cachedTrack = lastfmTagCache.get(trackKey);
  let trackTags: Array<{ tag: string; count: number }>;
  if (cachedTrack && Date.now() - cachedTrack.checkedAt < LASTFM_CACHE_TTL) {
    trackTags = cachedTrack.tags;
  } else {
    const inflight = lastfmInFlight.get(trackKey);
    if (inflight) {
      trackTags = await inflight;
    } else {
      const promise = lastfmGetTopTags(apiKey, 'track.getTopTags', {
        artist,
        track: title,
      }).finally(() => lastfmInFlight.delete(trackKey));
      lastfmInFlight.set(trackKey, promise);
      trackTags = await promise;
      lastfmTagCache.set(trackKey, { tags: trackTags, checkedAt: Date.now() });
    }
  }
  for (const t of trackTags) {
    results.push({ ...t, source: 'track' });
  }

  // Wenn Track-Tags vorhanden: keine weiteren Fallbacks
  if (results.length > 0) {
    logLastfmProvider('track', results);
    return results;
  }

  // === 2. ALBUM FALLBACK ===
  if (album) {
    const albumKey = lastfmCacheKey('album', artist, undefined, album);
    const cachedAlbum = lastfmTagCache.get(albumKey);
    let albumTags: Array<{ tag: string; count: number }>;
    if (cachedAlbum && Date.now() - cachedAlbum.checkedAt < LASTFM_CACHE_TTL) {
      albumTags = cachedAlbum.tags;
    } else {
      const inflight = lastfmInFlight.get(albumKey);
      if (inflight) {
        albumTags = await inflight;
      } else {
        const promise = lastfmGetTopTags(apiKey, 'album.getTopTags', {
          artist,
          album,
        }).finally(() => lastfmInFlight.delete(albumKey));
        lastfmInFlight.set(albumKey, promise);
        albumTags = await promise;
        lastfmTagCache.set(albumKey, {
          tags: albumTags,
          checkedAt: Date.now(),
        });
      }
    }
    for (const t of albumTags) {
      results.push({ ...t, source: 'album' });
    }
    if (results.length > 0) {
      logLastfmProvider('album', results);
      return results;
    }
  }

  // === 3. ARTIST FALLBACK ===
  const artistKey = lastfmCacheKey('artist', artist);
  const cachedArtist = lastfmTagCache.get(artistKey);
  let artistTags: Array<{ tag: string; count: number }>;
  if (cachedArtist && Date.now() - cachedArtist.checkedAt < LASTFM_CACHE_TTL) {
    artistTags = cachedArtist.tags;
  } else {
    const inflight = lastfmInFlight.get(artistKey);
    if (inflight) {
      artistTags = await inflight;
    } else {
      const promise = lastfmGetTopTags(apiKey, 'artist.getTopTags', {
        artist,
      }).finally(() => lastfmInFlight.delete(artistKey));
      lastfmInFlight.set(artistKey, promise);
      artistTags = await promise;
      lastfmTagCache.set(artistKey, {
        tags: artistTags,
        checkedAt: Date.now(),
      });
    }
  }
  for (const t of artistTags) {
    results.push({ ...t, source: 'artist' });
  }

  logLastfmProvider('artist', results);
  return results;
}

// --- MusicBrainz ISRC Lookup ---
async function fetchMusicBrainzRecording(isrc: string): Promise<string | null> {
  const key = `musicbrainz:isrc:${isrc}`;

  const cached = mbRecordingCache.get(key);
  if (cached && Date.now() - cached.checkedAt < MB_CACHE_TTL) return cached.mbid;

  const inflight = mbInFlight.get(key);
  if (inflight) return inflight;

  const promise = (async () => {
    try {
      const url = `https://musicbrainz.org/ws/2/isrc/${encodeURIComponent(isrc)}?fmt=json&inc=tags+genres+artist-credits`;
      const r = await fetch(url, {
        signal: AbortSignal.timeout(6000),
        headers: { 'User-Agent': 'Resonance/1.0 (https://resonance-app.com)' },
      });
      if (!r.ok) return null;
      const d = (await r.json()) as {
        recordings?: Array<{
          id: string;
          title?: string;
          'artist-credit'?: Array<{ name?: string }>;
        }>;
      };
      const recordings = d.recordings || [];
      if (recordings.length === 0) return null;
      // Mehrere Recordings: Ersten zurückgeben (Standard-Heuristik)
      const mbid = recordings[0].id;
      return mbid;
    } catch {
      return null;
    } finally {
      mbInFlight.delete(key);
    }
  })();

  mbInFlight.set(key, promise);
  const mbid = await promise;
  mbRecordingCache.set(key, { mbid, checkedAt: Date.now() });
  return mbid;
}

// --- ListenBrainz Recording Tags ---
async function fetchListenBrainzTags(
  mbid: string,
): Promise<Array<{ tag: string; count: number }>> {
  const key = `listenbrainz:recording:${mbid}`;

  const cached = lbTagCache.get(key);
  if (cached && Date.now() - cached.checkedAt < LB_CACHE_TTL) return cached.tags;

  const inflight = lbInFlight.get(key);
  if (inflight) return inflight;

  const promise = (async () => {
    try {
      const url = `https://api.listenbrainz.org/1/metadata/recording/?recording_mbids=${encodeURIComponent(mbid)}&inc=tag`;
      const r = await fetch(url, { signal: AbortSignal.timeout(6000) });
      if (!r.ok) return [];
      const d = (await r.json()) as {
        [mbid: string]: {
          tag?: { tag: string; count: number }[];
        };
      };
      const data = d[mbid];
      const tags = (data?.tag || []).map((t) => ({
        tag: t.tag.toLowerCase().trim(),
        count: t.count,
      }));
      lbTagCache.set(key, { tags, checkedAt: Date.now() });
      return tags;
    } catch {
      return [];
    } finally {
      lbInFlight.delete(key);
    }
  })();

  lbInFlight.set(key, promise);
  return promise;
}

// --- Genius Lyrics Cache ---
const GENIUS_CACHE_TTL = 86400000 * 7; // 7 Tage
const GENIUS_TRANSIENT_BACKOFF = 120000; // 2 Minuten

type GeniusFailurePhase = 'search' | 'match' | 'lyrics-fetch' | 'lyrics-parse';
type GeniusFailure = {
  kind: 'no_match' | 'transient_error';
  phase: GeniusFailurePhase;
  status: number | null;
  retryAfterSeconds: number | null;
  reason: string;
};
type GeniusStepResult<T> = { kind: 'success'; value: T } | GeniusFailure;
type GeniusCacheEntry = {
  state: 'success' | 'no_match' | 'transient_error';
  lyrics: string | null;
  songId: number | null;
  matchConfidence: 'high' | 'medium' | null;
  fetchedAt: number;
  retryAt?: number;
};
type GeniusLyricsSuccess = {
  lyrics: string;
  songId: number;
  matchConfidence: 'high' | 'medium';
  cacheHit: boolean;
  cacheState: 'success';
};

const geniusCache = new Map<string, GeniusCacheEntry>();
const geniusInFlight = new Map<string, Promise<GeniusLyricsSuccess | null>>();

// --- Lyrics-Mood Cache ---
const LYRICS_MOOD_CACHE_TTL = 86400000 * 7; // 7 Tage
const lyricsMoodCache = new Map<string, {
  scores: Record<string, number>;
  confidence: 'high' | 'medium' | 'low';
  fetchedAt: number;
}>();

function geniusCacheKey(artist: string, title: string, spotifyId?: string): string {
  if (spotifyId) return `genius:${spotifyId}`;
  return `genius:${normalize(artist)}::${normalize(title)}`;
}

function geniusGetToken(): string {
  return (
    (globalThis as any).GENIUS_ACCESS_TOKEN ||
    (typeof process !== 'undefined' && process.env?.GENIUS_ACCESS_TOKEN) ||
    ''
  );
}

function normalizeForMatch(s: string): string {
  return s
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .normalize('NFC')
    .replace(/['']/g, "'")
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\b(feat|ft|featuring|remix|edit|version|live|acoustic|deluxe|single|album)\b/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function titleSimilarity(a: string, b: string): number {
  const na = normalizeForMatch(a);
  const nb = normalizeForMatch(b);
  if (!na || !nb) return 0;
  if (na === nb) return 1.0;
  if (na.includes(nb) || nb.includes(na)) return 0.8;
  // Einfache Token-basierte Überlappung
  const tokensA = new Set(na.split(' ').filter(Boolean));
  const tokensB = new Set(nb.split(' ').filter(Boolean));
  const intersection = [...tokensA].filter(t => tokensB.has(t)).length;
  const union = new Set([...tokensA, ...tokensB]).size;
  return union > 0 ? intersection / union : 0;
}

function artistSimilarity(a: string, b: string): number {
  const na = normalizeForMatch(a);
  const nb = normalizeForMatch(b);
  if (!na || !nb) return 0;
  if (na === nb) return 1.0;
  if (na.includes(nb) || nb.includes(na)) return 0.7;
  const tokensA = new Set(na.split(' ').filter(Boolean));
  const tokensB = new Set(nb.split(' ').filter(Boolean));
  const intersection = [...tokensA].filter(t => tokensB.has(t)).length;
  const union = new Set([...tokensA, ...tokensB]).size;
  return union > 0 ? intersection / union : 0;
}

function geniusRetryAfterSeconds(value: string | null): number | null {
  if (!value) return null;
  const seconds = Number(value);
  if (Number.isFinite(seconds) && seconds >= 0) return Math.ceil(seconds);
  const date = Date.parse(value);
  if (!Number.isFinite(date)) return null;
  return Math.max(0, Math.ceil((date - Date.now()) / 1000));
}

function geniusFailure(
  kind: 'no_match' | 'transient_error',
  phase: GeniusFailurePhase,
  reason: string,
  status: number | null = null,
  retryAfterSeconds: number | null = null,
): GeniusFailure {
  const failure = { kind, phase, status, retryAfterSeconds, reason };
  if (kind === 'transient_error') {
    console.warn('[GENIUS ERROR]', {
      phase,
      status,
      classification: kind,
      retryAfter: retryAfterSeconds,
      reason,
    });
  }
  return failure;
}

function geniusTransientRetryAt(failure: GeniusFailure): number {
  const providerBackoff = (failure.retryAfterSeconds ?? 0) * 1000;
  return Date.now() + Math.max(GENIUS_TRANSIENT_BACKOFF, providerBackoff);
}

async function geniusSearch(
  token: string,
  title: string,
  artist: string,
): Promise<GeniusStepResult<{
  songId: number;
  title: string;
  artist: string;
  url: string;
  confidence: 'high' | 'medium';
}>> {
  const query = `${title} ${artist}`;
  const url = `https://api.genius.com/search?q=${encodeURIComponent(query)}`;

  let r: Response;
  try {
    r = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(5000),
    });
  } catch (error) {
    return geniusFailure(
      'transient_error',
      'search',
      error instanceof Error ? error.name : 'network_error',
    );
  }

  const retryAfter = geniusRetryAfterSeconds(r.headers.get('retry-after'));
  if (!r.ok) {
    return geniusFailure(
      'transient_error',
      'search',
      'http_error',
      r.status,
      retryAfter,
    );
  }

  let d: {
    meta?: { status?: number; message?: string };
    response?: {
      hits?: Array<{
        type: string;
        result: {
          id: number;
          title: string;
          full_title?: string;
          primary_artist: { name: string };
          url: string;
        };
      }>;
    };
  };
  try {
    d = (await r.json()) as typeof d;
  } catch {
    return geniusFailure('transient_error', 'search', 'invalid_json', r.status);
  }

  if (d.meta?.status !== undefined && d.meta.status !== 200) {
    return geniusFailure(
      'transient_error',
      'search',
      'unexpected_api_status',
      d.meta.status,
      retryAfter,
    );
  }

  if (!d.response || !Array.isArray(d.response.hits)) {
    return geniusFailure(
      'transient_error',
      'search',
      'unexpected_response_shape',
      r.status,
    );
  }

  const allHits = d.response.hits;
  const hits = allHits.filter(h => h.type === 'song');

  if (hits.length === 0)
    return geniusFailure('no_match', 'search', 'no_song_hits', r.status);

  let bestMatch: typeof hits[0] | null = null;
  let bestScore = 0;

  for (const hit of hits) {
    const titleSim = titleSimilarity(title, hit.result.title);
    const artistSim = artistSimilarity(artist, hit.result.primary_artist.name);
    const score = titleSim * 0.7 + artistSim * 0.3;
    if (score > bestScore) {
      bestScore = score;
      bestMatch = hit;
    }
  }

  if (!bestMatch || bestScore < 0.3)
    return geniusFailure('no_match', 'match', 'below_match_threshold', r.status);

  const titleSim = titleSimilarity(title, bestMatch.result.title);
  const confidence: 'high' | 'medium' =
    titleSim >= 0.8 && bestScore >= 0.7 ? 'high' : 'medium';

  return {
    kind: 'success',
    value: {
      songId: bestMatch.result.id,
      title: bestMatch.result.title,
      artist: bestMatch.result.primary_artist.name,
      url: bestMatch.result.url,
      confidence,
    },
  };
}

async function geniusFetchLyrics(
  geniusUrl: string,
): Promise<GeniusStepResult<string>> {
  let r: Response;
  try {
    r = await fetch(geniusUrl, {
      signal: AbortSignal.timeout(10000),
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
      },
    });
  } catch (error) {
    return geniusFailure(
      'transient_error',
      'lyrics-fetch',
      error instanceof Error ? error.name : 'network_error',
    );
  }

  const retryAfter = geniusRetryAfterSeconds(r.headers.get('retry-after'));
  if (!r.ok) {
    return geniusFailure(
      'transient_error',
      'lyrics-fetch',
      'http_error',
      r.status,
      retryAfter,
    );
  }

  let html: string;
  try {
    html = await r.text();
  } catch (error) {
    return geniusFailure(
      'transient_error',
      'lyrics-fetch',
      error instanceof Error ? error.name : 'body_read_error',
      r.status,
    );
  }

  // Nur echte Blockade-Marker erkennen. Breite Marker wie "captcha" oder "challenge"
  // schlagen auf normalen Genius-Seiten falsch-positiv an (useGoogleReCaptcha-Script,
  // Cloudflare-Precursor-Script /cdn-cgi/challenge-platform/ auf jeder CF-Seite).
  const hasLyricsMarker = html.includes('data-lyrics-container');
  const lyricsContainerCount = (
    html.match(/data-lyrics-container="true"/g) || []
  ).length + (
    html.match(/data-lyrics-container='true'/g) || []
  ).length;
  const hasChallenge = /cf-chl-|challenge-form|just\.a\.moment|attention\.required|access\.denied/i.test(html);

  if (hasChallenge) {
    return geniusFailure(
      'transient_error',
      'lyrics-fetch',
      'provider_challenge',
      r.status,
    );
  }

  if (!hasLyricsMarker || lyricsContainerCount === 0) {
    return geniusFailure(
      'transient_error',
      'lyrics-parse',
      'missing_lyrics_container',
      r.status,
    );
  }

  // === ROBUSTE EXTRACTION ===
  // Finde alle data-lyrics-container="true" Blöcke
  // Verwende Tag-Counting statt Regex für verschachtelte DIVs
  try {
    const lyrics = extractLyricsFromHtml(html);
    if (!lyrics) {
      return geniusFailure(
        'transient_error',
        'lyrics-parse',
        'empty_lyrics_after_parse',
        r.status,
      );
    }
    return { kind: 'success', value: lyrics };
  } catch (error) {
    return geniusFailure(
      'transient_error',
      'lyrics-parse',
      error instanceof Error ? error.name : 'parser_error',
      r.status,
    );
  }
}

function extractLyricsFromHtml(html: string): string | null {
  const parts: string[] = [];

  // Finde alle Positionen von data-lyrics-container="true"
  const marker = 'data-lyrics-container="true"';
  let searchFrom = 0;
  while (true) {
    const markerIdx = html.indexOf(marker, searchFrom);
    if (markerIdx === -1) break;

    // Finde das abschließende > des öffnenden Tags
    const tagStart = html.lastIndexOf('<', markerIdx);
    const tagEnd = html.indexOf('>', markerIdx);
    if (tagEnd === -1) { searchFrom = markerIdx + marker.length; continue; }

    // Tag-Counting: Finde das passende schließende </div>
    let depth = 1;
    let pos = tagEnd + 1;
    while (depth > 0 && pos < html.length) {
      const nextOpen = html.indexOf('<div', pos);
      const nextClose = html.indexOf('</div>', pos);

      if (nextClose === -1) break; // Kein schließendes div

      if (nextOpen !== -1 && nextOpen < nextClose) {
        // Nächstes Öffnen kommt vor nächstem Schließen
        // Prüfe ob es ein selbstschließendes <div.../> ist
        const selfClose = html.indexOf('/>', nextOpen);
        const nextAngle = html.indexOf('>', nextOpen);
        if (selfClose !== -1 && selfClose < nextAngle) {
          // Selbstschließendes div, depth unchanged
          pos = selfClose + 2;
        } else {
          depth++;
          pos = nextAngle + 1;
        }
      } else {
        depth--;
        if (depth === 0) {
          // Inhalt zwischen tagEnd+1 und nextClose
          const content = html.slice(tagEnd + 1, nextClose);
          parts.push(content);
        }
        pos = nextClose + 6; // strlen("</div>")
      }
    }

    searchFrom = markerIdx + marker.length;
  }

  if (parts.length === 0) return null;

  // HTML dekodieren und bereinigen
  let lyrics = parts
    .join('\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#x27;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/\[[\w\s\d]+\]/gi, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  return lyrics.length > 0 ? lyrics : null;
}

export async function fetchGeniusLyrics(
  artist: string,
  title: string,
  spotifyId?: string,
): Promise<GeniusLyricsSuccess | null> {
  const token = geniusGetToken();

  if (!token) {
    geniusFailure('transient_error', 'search', 'missing_access_token');
    return null;
  }

  const key = geniusCacheKey(artist, title, spotifyId);

  // Cache-Check
  const cached = geniusCache.get(key);
  if (cached) {
    const now = Date.now();
    if (cached.state === 'transient_error' && now < (cached.retryAt ?? 0)) {
      console.log('[GENIUS CACHE]', {
        cacheHit: 'transient_backoff',
        retryAfter: Math.max(0, Math.ceil(((cached.retryAt ?? now) - now) / 1000)),
      });
      return null;
    }
    if (
      cached.state === 'no_match' &&
      now - cached.fetchedAt < GENIUS_CACHE_TTL
    ) {
      console.log('[GENIUS CACHE]', { cacheHit: 'no_match' });
      return null;
    }
    if (
      cached.state === 'success' &&
      cached.lyrics &&
      cached.songId !== null &&
      cached.matchConfidence &&
      now - cached.fetchedAt < GENIUS_CACHE_TTL
    ) {
      console.log('[GENIUS CACHE]', { cacheHit: 'success' });
      return {
        lyrics: cached.lyrics,
        songId: cached.songId,
        matchConfidence: cached.matchConfidence,
        cacheHit: true,
        cacheState: 'success',
      };
    }
    geniusCache.delete(key);
  }

  // Single-flight
  const inflight = geniusInFlight.get(key);
  if (inflight) {
    const result = await inflight;
    if (!result) return null;
    return { ...result, cacheHit: true };
  }

  const promise: Promise<GeniusLyricsSuccess | null> = (async () => {
    try {
      // 1. Search
      const searchResult = await geniusSearch(token, title, artist);

      if (searchResult.kind !== 'success') {
        const fetchedAt = Date.now();
        if (searchResult.kind === 'no_match') {
          geniusCache.set(key, {
            state: 'no_match',
            lyrics: null,
            songId: null,
            matchConfidence: null,
            fetchedAt,
          });
        } else {
          geniusCache.set(key, {
            state: 'transient_error',
            lyrics: null,
            songId: null,
            matchConfidence: null,
            fetchedAt,
            retryAt: geniusTransientRetryAt(searchResult),
          });
        }
        return null;
      }

      // 2. Lyrics abrufen
      const lyricsResult = await geniusFetchLyrics(searchResult.value.url);

      if (lyricsResult.kind !== 'success') {
        geniusCache.set(key, {
          state: 'transient_error',
          lyrics: null,
          songId: searchResult.value.songId,
          matchConfidence: searchResult.value.confidence,
          fetchedAt: Date.now(),
          retryAt: geniusTransientRetryAt(lyricsResult),
        });
        return null;
      }

      // 3. Cache befüllen
      geniusCache.set(key, {
        state: 'success',
        lyrics: lyricsResult.value,
        songId: searchResult.value.songId,
        matchConfidence: searchResult.value.confidence,
        fetchedAt: Date.now(),
      });

      return {
        lyrics: lyricsResult.value,
        songId: searchResult.value.songId,
        matchConfidence: searchResult.value.confidence,
        cacheHit: false,
        cacheState: 'success',
      };
    } catch (error) {
      const failure = geniusFailure(
        'transient_error',
        'search',
        error instanceof Error ? error.name : 'unexpected_error',
      );
      geniusCache.set(key, {
        state: 'transient_error',
        lyrics: null,
        songId: null,
        matchConfidence: null,
        fetchedAt: Date.now(),
        retryAt: geniusTransientRetryAt(failure),
      });
      return null;
    } finally {
      geniusInFlight.delete(key);
    }
  })();

  geniusInFlight.set(key, promise);
  return promise;
}

// --- MusicBrainz + ListenBrainz Fallback (ISRC → MBID → Tags) ---
export async function fetchMusicBrainzTags(
  isrc: string,
): Promise<LastfmTag[]> {
  const mbid = await fetchMusicBrainzRecording(isrc);
  if (!mbid) return [];

  const lbTags = await fetchListenBrainzTags(mbid);
  const usable = usableMoodTagNames(lbTags);
  console.log('[MOOD PROVIDER]', {
    provider: 'listenbrainz',
    tags: lbTags.map((t) => t.tag),
    usableMoodTags: usable,
  });
  return lbTags.map((t) => ({
    tag: t.tag,
    count: t.count,
    source: 'listenbrainz' as const,
  }));
}

// Last.fm Tag → Mood-Gewichtung
// Jeder Tag kann zu mehreren Moods beitragen
const TAG_TO_MOOD: Record<string, Array<{ moodId: string; weight: number }>> = {
  // Sad / Melancholic
  melancholic: [{ moodId: 'sad', weight: 1.0 }],
  melancholy: [{ moodId: 'sad', weight: 1.0 }],
  sad: [{ moodId: 'sad', weight: 1.0 }],
  depressive: [{ moodId: 'sad', weight: 0.9 }],
  depression: [{ moodId: 'sad', weight: 0.9 }],
  emotional: [{ moodId: 'sad', weight: 0.6 }],
  heartbreak: [{ moodId: 'sad', weight: 0.9 }],
  heartbreaking: [{ moodId: 'sad', weight: 0.9 }],
  sorrow: [{ moodId: 'sad', weight: 0.9 }],
  grief: [{ moodId: 'sad', weight: 0.8 }],
  mourning: [{ moodId: 'sad', weight: 0.8 }],
  'post-punk': [{ moodId: 'sad', weight: 0.4 }],

  // Dark
  dark: [{ moodId: 'dark', weight: 1.0 }],
  gothic: [{ moodId: 'dark', weight: 0.9 }],
  'dark wave': [{ moodId: 'dark', weight: 0.8 }],
  doom: [{ moodId: 'dark', weight: 0.8 }],
  horror: [{ moodId: 'dark', weight: 0.7 }],
  ominous: [{ moodId: 'dark', weight: 0.7 }],
  eerie: [{ moodId: 'dark', weight: 0.6 }],
  spooky: [{ moodId: 'dark', weight: 0.5 }],
  haunting: [{ moodId: 'dark', weight: 0.7 }],
  night: [{ moodId: 'dark', weight: 0.3 }],

  // Angry / Aggressive
  aggressive: [{ moodId: 'energy', weight: 0.8 }],
  angry: [{ moodId: 'energy', weight: 0.9 }],
  rage: [{ moodId: 'energy', weight: 0.9 }],
  furious: [{ moodId: 'energy', weight: 0.8 }],
  heavy: [{ moodId: 'energy', weight: 0.6 }],
  hardcore: [{ moodId: 'energy', weight: 0.7 }],
  thrash: [{ moodId: 'energy', weight: 0.7 }],
  brutality: [{ moodId: 'energy', weight: 0.8 }],

  // Energy / Energetic
  energetic: [{ moodId: 'energy', weight: 1.0 }],
  dance: [{ moodId: 'energy', weight: 0.7 }],
  party: [{ moodId: 'energy', weight: 0.7 }],
  upbeat: [{ moodId: 'energy', weight: 0.8 }],
  pumping: [{ moodId: 'energy', weight: 0.8 }],
  rave: [{ moodId: 'energy', weight: 0.9 }],
  techno: [{ moodId: 'energy', weight: 0.7 }],
  edm: [{ moodId: 'energy', weight: 0.7 }],
  hardstyle: [{ moodId: 'energy', weight: 0.9 }],
  drumandbass: [{ moodId: 'energy', weight: 0.7 }],
  punk: [{ moodId: 'energy', weight: 0.6 }],
  metal: [{ moodId: 'energy', weight: 0.6 }],
  rock: [{ moodId: 'energy', weight: 0.4 }],
  workout: [{ moodId: 'energy', weight: 0.7 }],

  // Calm / Relaxing
  chill: [{ moodId: 'calm', weight: 0.8 }],
  relaxing: [{ moodId: 'calm', weight: 0.9 }],
  calm: [{ moodId: 'calm', weight: 1.0 }],
  ambient: [{ moodId: 'calm', weight: 0.9 }],
  peaceful: [{ moodId: 'calm', weight: 0.9 }],
  serene: [{ moodId: 'calm', weight: 0.9 }],
  tranquil: [{ moodId: 'calm', weight: 0.9 }],
  meditation: [{ moodId: 'calm', weight: 0.8 }],
  soothing: [{ moodId: 'calm', weight: 0.8 }],
  gentle: [{ moodId: 'calm', weight: 0.7 }],
  soft: [{ moodId: 'calm', weight: 0.6 }],
  acoustic: [{ moodId: 'calm', weight: 0.5 }],
  downtempo: [{ moodId: 'calm', weight: 0.6 }],
  lounge: [{ moodId: 'calm', weight: 0.6 }],
  sleep: [{ moodId: 'calm', weight: 0.7 }],
  rainfall: [{ moodId: 'calm', weight: 0.6 }],

  // Happy / Positive
  happy: [{ moodId: 'happy', weight: 1.0 }],
  joyful: [{ moodId: 'happy', weight: 0.9 }],
  cheerful: [{ moodId: 'happy', weight: 0.8 }],
  feelgood: [{ moodId: 'happy', weight: 0.8 }],
  'feel good': [{ moodId: 'happy', weight: 0.8 }],
  sunshine: [{ moodId: 'happy', weight: 0.7 }],
  summer: [{ moodId: 'happy', weight: 0.6 }],
  fun: [{ moodId: 'happy', weight: 0.6 }],
  funky: [{ moodId: 'happy', weight: 0.5 }],
  pop: [{ moodId: 'happy', weight: 0.3 }],
  disco: [{ moodId: 'happy', weight: 0.5 }],

  // Dreamy (migriert auf calm/romantic/nostalgic)
  dreamy: [
    { moodId: 'calm', weight: 0.6 },
    { moodId: 'romantic', weight: 0.4 },
  ],
  ethereal: [
    { moodId: 'calm', weight: 0.6 },
    { moodId: 'romantic', weight: 0.3 },
  ],
  shoegaze: [
    { moodId: 'calm', weight: 0.5 },
    { moodId: 'nostalgic', weight: 0.3 },
  ],
  'dream pop': [
    { moodId: 'calm', weight: 0.5 },
    { moodId: 'romantic', weight: 0.4 },
  ],
  atmospheric: [{ moodId: 'calm', weight: 0.7 }],
  space: [{ moodId: 'calm', weight: 0.6 }],
  cosmic: [{ moodId: 'calm', weight: 0.7 }],
  psychedelic: [
    { moodId: 'calm', weight: 0.4 },
    { moodId: 'nostalgic', weight: 0.2 },
  ],
  synthwave: [{ moodId: 'nostalgic', weight: 0.5 }],
  newage: [{ moodId: 'calm', weight: 0.6 }],

  // Genre / Stil-Ergänzungen
  crust: [
    { moodId: 'energy', weight: 0.8 },
    { moodId: 'dark', weight: 0.5 },
  ],
  dubstep: [
    { moodId: 'energy', weight: 0.9 },
    { moodId: 'dark', weight: 0.3 },
  ],
  'post-hardcore': [
    { moodId: 'energy', weight: 0.8 },
    { moodId: 'sad', weight: 0.4 },
  ],
  sludge: [
    { moodId: 'dark', weight: 0.9 },
    { moodId: 'energy', weight: 0.5 },
  ],
  screamo: [
    { moodId: 'energy', weight: 0.8 },
    { moodId: 'sad', weight: 0.5 },
  ],

  // Romantic
  romantic: [{ moodId: 'romantic', weight: 0.9 }],
  'love songs': [{ moodId: 'romantic', weight: 0.8 }],
  romance: [{ moodId: 'romantic', weight: 0.8 }],
  'love song': [{ moodId: 'romantic', weight: 0.8 }],

  // Lonely
  lonely: [{ moodId: 'lonely', weight: 0.9 }],
  loneliness: [{ moodId: 'lonely', weight: 0.9 }],

  // Hopeful
  hopeful: [{ moodId: 'hopeful', weight: 0.9 }],
  uplifting: [
    { moodId: 'hopeful', weight: 0.6 },
    { moodId: 'happy', weight: 0.4 },
  ],

  // Nostalgic
  nostalgic: [{ moodId: 'nostalgic', weight: 0.9 }],
  nostalgia: [{ moodId: 'nostalgic', weight: 0.9 }],
};

export function hasUsableMoodTags(tags: LastfmTag[] | undefined): boolean {
  return !!tags?.some((tag) => TAG_TO_MOOD[tag.tag.toLowerCase().trim()]?.length);
}

// Genre → Mood-Gewichtung (schwache Heuristik für Genre-basierte Erkennung)
const GENRE_TO_MOOD: Record<string, Array<{ moodId: string; weight: number }>> = {
  // Energetic
  hardstyle: [{ moodId: 'energy', weight: 1.0 }],
  edm: [{ moodId: 'energy', weight: 0.8 }],
  dance: [{ moodId: 'energy', weight: 0.7 }],
  techno: [{ moodId: 'energy', weight: 0.8 }],
  'drum and bass': [{ moodId: 'energy', weight: 0.8 }],
  'drum & bass': [{ moodId: 'energy', weight: 0.8 }],
  dnb: [{ moodId: 'energy', weight: 0.8 }],
  punk: [{ moodId: 'energy', weight: 0.7 }, { moodId: 'dark', weight: 0.2 }],
  metal: [{ moodId: 'energy', weight: 0.7 }, { moodId: 'dark', weight: 0.3 }],
  rock: [{ moodId: 'energy', weight: 0.5 }],
  trap: [{ moodId: 'energy', weight: 0.4 }, { moodId: 'dark', weight: 0.4 }],
  rap: [{ moodId: 'energy', weight: 0.3 }, { moodId: 'dark', weight: 0.2 }],
  'hip hop': [{ moodId: 'energy', weight: 0.3 }, { moodId: 'dark', weight: 0.2 }],
  hiphop: [{ moodId: 'energy', weight: 0.3 }, { moodId: 'dark', weight: 0.2 }],
  house: [{ moodId: 'energy', weight: 0.6 }],
  dubstep: [{ moodId: 'energy', weight: 0.7 }, { moodId: 'dark', weight: 0.3 }],
  hardcore: [{ moodId: 'energy', weight: 0.8 }],
  trance: [{ moodId: 'energy', weight: 0.6 }],

  // Calm
  ambient: [{ moodId: 'calm', weight: 1.0 }],
  'lo fi': [{ moodId: 'calm', weight: 0.8 }],
  'lofi': [{ moodId: 'calm', weight: 0.8 }],
  chill: [{ moodId: 'calm', weight: 0.7 }],
  acoustic: [{ moodId: 'calm', weight: 0.8 }],
  classical: [{ moodId: 'calm', weight: 0.8 }],
  downtempo: [{ moodId: 'calm', weight: 0.7 }],
  lounge: [{ moodId: 'calm', weight: 0.6 }],
  jazz: [{ moodId: 'calm', weight: 0.6 }],
  meditation: [{ moodId: 'calm', weight: 0.8 }],

  // Sad / Melancholic
  emo: [{ moodId: 'sad', weight: 0.9 }, { moodId: 'dark', weight: 0.5 }],
  'sadcore': [{ moodId: 'sad', weight: 1.0 }],
  'slowcore': [{ moodId: 'sad', weight: 0.9 }],
  blues: [{ moodId: 'sad', weight: 0.7 }],
  'post-punk': [{ moodId: 'sad', weight: 0.4 }, { moodId: 'dark', weight: 0.3 }],

  // Dark
  gothic: [{ moodId: 'dark', weight: 0.9 }],
  'darkwave': [{ moodId: 'dark', weight: 0.8 }],
  'dark wave': [{ moodId: 'dark', weight: 0.8 }],
  industrial: [{ moodId: 'dark', weight: 0.7 }, { moodId: 'energy', weight: 0.3 }],
  'black metal': [{ moodId: 'dark', weight: 0.8 }, { moodId: 'energy', weight: 0.4 }],
  doom: [{ moodId: 'dark', weight: 0.8 }],
  'dark ambient': [{ moodId: 'dark', weight: 0.7 }, { moodId: 'calm', weight: 0.3 }],

  // Dreamy (migriert auf calm/romantic/nostalgic)
  'dream pop': [
    { moodId: 'calm', weight: 0.5 },
    { moodId: 'romantic', weight: 0.4 },
  ],
  shoegaze: [
    { moodId: 'calm', weight: 0.5 },
    { moodId: 'nostalgic', weight: 0.3 },
  ],
  synthwave: [{ moodId: 'nostalgic', weight: 0.5 }],
  ethereal: [
    { moodId: 'calm', weight: 0.6 },
    { moodId: 'romantic', weight: 0.3 },
  ],
  chillwave: [{ moodId: 'calm', weight: 0.6 }],
  'new age': [{ moodId: 'calm', weight: 0.7 }],

  // Happy
  disco: [{ moodId: 'happy', weight: 0.7 }],
  funk: [{ moodId: 'happy', weight: 0.6 }],
  ska: [{ moodId: 'happy', weight: 0.6 }],
  'sunshine pop': [{ moodId: 'happy', weight: 0.7 }],
  pop: [{ moodId: 'happy', weight: 0.4 }],

  // Romantic
  'love songs': [{ moodId: 'romantic', weight: 0.8 }],
  'romantic pop': [{ moodId: 'romantic', weight: 0.8 }],
  'ballad': [{ moodId: 'romantic', weight: 0.4 }, { moodId: 'sad', weight: 0.3 }],

  // Lonely
  'loner': [{ moodId: 'lonely', weight: 0.7 }],
  'bedroom pop': [{ moodId: 'lonely', weight: 0.5 }, { moodId: 'calm', weight: 0.3 }],

  // Hopeful
  'uplifting': [{ moodId: 'hopeful', weight: 0.7 }, { moodId: 'happy', weight: 0.3 }],

  // Nostalgic
  'retro': [{ moodId: 'nostalgic', weight: 0.6 }],
  'vintage': [{ moodId: 'nostalgic', weight: 0.6 }],
};

const SOURCE_FACTOR: Record<string, number> = {
  track: 1.0,
  album: 0.5,
  artist: 0.25,
  listenbrainz: 0.8,
};

// --- Lyrics-basierte Mood-Analyse ---
type LyricsMoodResult = {
  scores: Record<string, number>;
  confidence: 'high' | 'medium' | 'low';
  coverage: number;
  signalCount: number;
  uniqueSignalCount: number;
  winnerMargin: number;
  sourceQuality: number;
  positiveSignals: string[];
  negativeSignals: string[];
  calmSignals: string[];
  intenseSignals: string[];
};

// Signal-Wörter mit Valence/Arousal-Gewichtung
type LyricsSignal = {
  patterns: RegExp[];
  valence: number;  // -1 bis +1 (negativ bis positiv)
  arousal: number;  // -1 bis +1 (ruhig bis intensiv)
  directScores?: Record<string, number>; // NEU: Direkte Mood-Beiträge
};

const LYRICS_MOOD_SCORE_CAP = 2.0;

function countLyricsUnits(text: string): number {
  if (!text) return 0;
  if (typeof Intl.Segmenter === 'function') {
    return [...new Intl.Segmenter(undefined, { granularity: 'word' }).segment(text)]
      .filter((part) => part.isWordLike).length;
  }
  const spacedWords = text.split(/\s+/).filter(Boolean).length;
  const unspacedLetters = (text.match(/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/gu) || []).length;
  return Math.max(spacedWords, unspacedLetters);
}

const LYRICS_SIGNALS: LyricsSignal[] = [
  // Negativ + Intensiv → angry/dark/energy
  { patterns: [/\bhass[et]?\b/i, /\bhate\b/i, /\bwut\b/i, /\brage\b/i, /\bfury\b/i, /\bhasse\b/i, /\bhassen\b/i, /\bmad\b/i, /\bfurious\b/i, /\bkill\b/i, /\bzerstor\b/i, /\bdestroy\b/i, /\bfuck\b/i, /\bscheiss\b/i, /\bschlag\b/i],
    valence: -0.9, arousal: 0.9,
    directScores: { angry: 0.8, energy: 0.3, dark: 0.2 } },

  { patterns: [/\bkampf[en]?\b/i, /\bfight\b/i, /\bstruggle\b/i, /\brebel\b/i],
    valence: -0.5, arousal: 0.8,
    directScores: { angry: 0.4, energy: 0.5 } },

  { patterns: [/\bbrenn[en]?\b/i, /\bburn\b/i, /\bfeuer\b/i, /\bfire\b/i, /\bflame\b/i],
    valence: -0.4, arousal: 0.9,
    directScores: { energy: 0.6, dark: 0.3 } },

  { patterns: [/\bkaputt\b/i, /\bbroken\b/i, /\bcrash\b/i],
    valence: -0.8, arousal: 0.7,
    directScores: { sad: 0.5, dark: 0.4 } },

  // Negativ + Ruhig → sad/dark
  { patterns: [/\btraurig\b/i, /\bsad\b/i, /\bweep\b/i, /\bwein[en]\b/i, /\bcry\b/i, /\btears\b/i, /\btranen\b/i],
    valence: -0.9, arousal: -0.3,
    directScores: { sad: 0.8 } },

  { patterns: [/\beinsam\b/i, /\blonely\b/i, /\balone\b/i, /\ballein\b/i, /\bnobody\b/i, /\bniemand\b/i],
    valence: -0.7, arousal: -0.5,
    directScores: { lonely: 0.7, sad: 0.3 } },

  { patterns: [/\bverloren\b/i, /\blost\b/i, /\bmissing\b/i, /\bvermiss\b/i],
    valence: -0.7, arousal: -0.4,
    directScores: { sad: 0.5, lonely: 0.3 } },

  { patterns: [/\bempty\b/i, /\bleer\b/i, /\bvoid\b/i, /\bnichts\b/i],
    valence: -0.6, arousal: -0.6,
    directScores: { sad: 0.4, lonely: 0.3, dark: 0.2 } },

  { patterns: [/\btod[es]?\b/i, /\bdead\b/i, /\bdeath\b/i, /\bsterb[en]\b/i, /\bgrave\b/i, /\bgrab\b/i],
    valence: -0.9, arousal: -0.2,
    directScores: { dark: 0.6, sad: 0.4 } },

  { patterns: [/\bangst\b/i, /\bfear\b/i, /\bscar[ey]\b/i, /\bhorror\b/i],
    valence: -0.8, arousal: 0.3,
    directScores: { dark: 0.6, sad: 0.3 } },

  { patterns: [/\bsilence\b/i, /\bstill[en]?\b/i, /\bschweig\b/i],
    valence: -0.4, arousal: -0.7,
    directScores: { calm: 0.4, sad: 0.2 } },

  // Positiv + Intensiv → happy/energy
  { patterns: [/\bglucklich\b/i, /\bhappy\b/i, /\bjoy\b/i, /\bfreude\b/i],
    valence: 0.9, arousal: 0.6,
    directScores: { happy: 0.8 } },

  { patterns: [/\blieb[en]?\b/i, /\blove\b/i, /\bheart\b/i, /\bherz\b/i],
    valence: 0.8, arousal: 0.5,
    directScores: { romantic: 0.5, happy: 0.3 } },

  { patterns: [/\bfeier[n]?\b/i, /\bcelebrat\b/i, /\bparty\b/i, /\bdance\b/i, /\btanzen\b/i],
    valence: 0.7, arousal: 0.8,
    directScores: { happy: 0.5, energy: 0.5 } },

  { patterns: [/\bfree\b/i, /\bfrei\b/i, /\bfreedom\b/i, /\bfreiheit\b/i],
    valence: 0.7, arousal: 0.6,
    directScores: { happy: 0.5, energy: 0.3 } },

  { patterns: [/\bsmile\b/i, /\blachen\b/i, /\blaugh\b/i, /\bgrin\b/i],
    valence: 0.8, arousal: 0.5,
    directScores: { happy: 0.7 } },

  { patterns: [/\bsonn[en]?\b/i, /\bsun\b/i, /\bbright\b/i, /\blicht\b/i, /\bsky\b/i, /\bhimmel\b/i],
    valence: 0.6, arousal: 0.4,
    directScores: { happy: 0.4, hopeful: 0.3 } },

  // Positiv + Ruhig → calm
  { patterns: [/\bcalm\b/i, /\bruhig\b/i, /\bpeace\b/i, /\bfriede\b/i],
    valence: 0.5, arousal: -0.7,
    directScores: { calm: 0.8 } },

  { patterns: [/\bsleep\b/i, /\bschlaf\b/i, /\bdream\b/i, /\btraum\b/i],
    valence: 0.3, arousal: -0.8,
    directScores: { calm: 0.6 } },

  { patterns: [/\bgentle\b/i, /\bsanft\b/i, /\bsoft\b/i, /\bweich\b/i],
    valence: 0.4, arousal: -0.6,
    directScores: { calm: 0.6 } },

  { patterns: [/\bnacht\b/i, /\bnight\b/i, /\bmoon\b/i, /\bmond\b/i, /\bstars\b/i, /\bsterne\b/i],
    valence: 0.2, arousal: -0.5,
    directScores: { calm: 0.3, dark: 0.2 } },

  // Dunkel/Neutral
  { patterns: [/\bdunkel\b/i, /\bdark\b/i, /\bshadow\b/i, /\bschatten\b/i, /\bnightmare\b/i],
    valence: -0.5, arousal: 0.1,
    directScores: { dark: 0.7 } },

  { patterns: [/\bhaunt\b/i, /\bghost\b/i, /\bgeist\b/i, /\bspook\b/i],
    valence: -0.4, arousal: 0.2,
    directScores: { dark: 0.6 } },

  // === Romantic ===
  { patterns: [/\bverlieb\b/i, /\bkuss[en]?\b/i, /\bkuss\b/i, /\bkiss\b/i],
    valence: 0.7, arousal: 0.3,
    directScores: { romantic: 0.8 } },

  { patterns: [/\bnahe\b/i, /\bhold me\b/i, /\bbei dir\b/i, /\bin my arms\b/i],
    valence: 0.6, arousal: 0.2,
    directScores: { romantic: 0.7 } },

  { patterns: [/\bforever\b/i, /\bfur immer\b/i, /\bzusammen\b/i, /\btogether\b/i, /\bneed you\b/i, /\bwant you\b/i],
    valence: 0.5, arousal: 0.3,
    directScores: { romantic: 0.5, hopeful: 0.2 } },

  { patterns: [/\bsehnsucht\b/i, /\byearning\b/i, /\blonging\b/i],
    valence: 0.2, arousal: 0.2,
    directScores: { romantic: 0.5, lonely: 0.3 } },

  // === Lonely (ZUSÄTZLICH zu den bestehenden einsam/alone Signalen) ===
  { patterns: [/\babandoned\b/i, /\bverlassen\b/i, /\bwithout you\b/i, /\bohne dich\b/i, /\bno one\b/i, /\bkeiner da\b/i],
    valence: -0.7, arousal: -0.4,
    directScores: { lonely: 0.7, sad: 0.3 } },

  { patterns: [/\bisoliert\b/i, /\bisolated\b/i],
    valence: -0.6, arousal: -0.6,
    directScores: { lonely: 0.7 } },

  // === Hopeful ===
  { patterns: [/\bhope\b/i, /\bhoffnung\b/i, /\bbelieve\b/i, /\bglaub\b/i],
    valence: 0.6, arousal: 0.4,
    directScores: { hopeful: 0.8 } },

  { patterns: [/\btomorrow\b/i, /\bmorgen\b/i, /\bbetter days\b/i, /\bbesser werden\b/i, /\bsomehow\b/i, /\birgendwann\b/i],
    valence: 0.5, arousal: 0.3,
    directScores: { hopeful: 0.7 } },

  { patterns: [/\bkeep going\b/i, /\bweiter\b/i, /\bsurvive\b/i, /\bdurchhalten\b/i, /\brise\b/i, /\baufstehen\b/i, /\bmake it through\b/i],
    valence: 0.4, arousal: 0.5,
    directScores: { hopeful: 0.6, energy: 0.2 } },

  // === Nostalgic ===
  { patterns: [/\bremember\b/i, /\berinner\b/i, /\bmemories\b/i, /\berinnerung\b/i],
    valence: 0.1, arousal: -0.3,
    directScores: { nostalgic: 0.7 } },

  { patterns: [/\bback then\b/i, /\bdamals\b/i, /\bfruher\b/i, /\bused to\b/i, /\balt[en]?\b/i],
    valence: 0.0, arousal: -0.4,
    directScores: { nostalgic: 0.7 } },

  { patterns: [/\bmiss those days\b/i, /\balte zeiten\b/i, /\bchildhood\b/i, /\bkindheit\b/i, /\bold times\b/i, /\bzuruck\b/i],
    valence: -0.1, arousal: -0.3,
    directScores: { nostalgic: 0.6, sad: 0.2 } },

  { patterns: [/\btake me back\b/i, /\bvergangen\b/i],
    valence: -0.1, arousal: -0.2,
    directScores: { nostalgic: 0.5 } },
];

type LocalizedLyricsSignal = LyricsSignal & {
  locale: 'es' | 'ja' | 'ko' | 'ru' | 'zh';
};

const SPANISH_LYRICS_SIGNALS: LocalizedLyricsSignal[] = [
  { locale: 'es', patterns: [/\btrist(?:e|es)\b/i, /\bllor(?:ar|o|as|a|amos|an|ando|ado)\b/i, /\bdolor(?:es)?\b/i, /\brot[oa]s?\b/i, /\bperd(?:er|ido|ida|idos|idas)\b/i], valence: -0.9, arousal: -0.3, directScores: { sad: 0.8 } },
  { locale: 'es', patterns: [/\bsol[oa]s?\b/i, /\bsoledad\b/i, /\bextran(?:o|a|ar|as|amos|an)\b/i], valence: -0.7, arousal: -0.5, directScores: { lonely: 0.7, sad: 0.3 } },
  { locale: 'es', patterns: [/\bfeliz(?:es)?\b/i, /\balegria\b/i, /\bsonre(?:ir|i|imos|is|ia|ian)\b/i], valence: 0.9, arousal: 0.6, directScores: { happy: 0.8 } },
  { locale: 'es', patterns: [/\bamor\b/i, /\bcorazon(?:es)?\b/i, /\bbes(?:o|os|ar|as|a|amos|an)\b/i, /\bte quiero\b/i, /\bte amo\b/i], valence: 0.8, arousal: 0.5, directScores: { romantic: 0.8 } },
  { locale: 'es', patterns: [/\besperanza\b/i, /\bmanana\b/i, /\bmejor(?:es)?\b/i, /\bvolver a empezar\b/i, /\bmejores dias\b/i], valence: 0.6, arousal: 0.4, directScores: { hopeful: 0.8 } },
  { locale: 'es', patterns: [/\brecuerdo(?:s)?\b/i, /\brecord(?:ar|ando|aba|e|amos)\b/i, /\bantes\b/i, /\baquellos dias\b/i], valence: 0.0, arousal: -0.4, directScores: { nostalgic: 0.7 } },
  { locale: 'es', patterns: [/\bodio\b/i, /\brabia\b/i, /\bfuria\b/i], valence: -0.9, arousal: 0.9, directScores: { angry: 0.8, energy: 0.3, dark: 0.2 } },
  { locale: 'es', patterns: [/\bpaz\b/i, /\btranquil[oa]s?\b/i, /\bcalma\b/i], valence: 0.5, arousal: -0.7, directScores: { calm: 0.8 } },
  { locale: 'es', patterns: [/\bbail(?:ar|o|as|a|amos|an)\b/i, /\bfiesta\b/i, /\bfuego\b/i], valence: 0.7, arousal: 0.8, directScores: { happy: 0.5, energy: 0.5 } },
  { locale: 'es', patterns: [/\boscur(?:idad|o|a|os|as)\b/i, /\bmuerte\b/i, /\bsombra(?:s)?\b/i], valence: -0.7, arousal: 0.1, directScores: { dark: 0.7 } },
];

const JAPANESE_LYRICS_SIGNALS: LocalizedLyricsSignal[] = [
  { locale: 'ja', patterns: [/悲し/u, /涙/u, /泣(?:く|いた|いて|き)/u], valence: -0.9, arousal: -0.3, directScores: { sad: 0.8 } },
  { locale: 'ja', patterns: [/寂し/u, /一人/u, /孤独/u], valence: -0.7, arousal: -0.5, directScores: { lonely: 0.7, sad: 0.3 } },
  { locale: 'ja', patterns: [/嬉し/u, /幸せ/u, /笑(?:う|って|顔)/u], valence: 0.9, arousal: 0.6, directScores: { happy: 0.8 } },
  { locale: 'ja', patterns: [/君が好き/u, /愛/u, /恋/u, /好き/u], valence: 0.8, arousal: 0.5, directScores: { romantic: 0.8 } },
  { locale: 'ja', patterns: [/希望/u, /明日(?:へ)?/u, /未来/u], valence: 0.6, arousal: 0.4, directScores: { hopeful: 0.8 } },
  { locale: 'ja', patterns: [/思い出/u, /懐かし/u], valence: 0.0, arousal: -0.4, directScores: { nostalgic: 0.7 } },
  { locale: 'ja', patterns: [/怒り/u, /憎い/u], valence: -0.9, arousal: 0.9, directScores: { angry: 0.8, energy: 0.3, dark: 0.2 } },
  { locale: 'ja', patterns: [/静か/u, /平和/u], valence: 0.5, arousal: -0.7, directScores: { calm: 0.8 } },
  { locale: 'ja', patterns: [/踊る/u, /燃える/u, /熱い/u], valence: 0.7, arousal: 0.8, directScores: { energy: 0.8 } },
  { locale: 'ja', patterns: [/闇/u, /死/u, /黒い/u], valence: -0.7, arousal: 0.1, directScores: { dark: 0.7 } },
];

const KOREAN_LYRICS_SIGNALS: LocalizedLyricsSignal[] = [
  { locale: 'ko', patterns: [/슬프/u, /슬퍼/u, /눈물/u, /울(?:다|어|고)?/u], valence: -0.9, arousal: -0.3, directScores: { sad: 0.8 } },
  { locale: 'ko', patterns: [/외롭/u, /외로운/u, /혼자/u, /고독/u], valence: -0.7, arousal: -0.5, directScores: { lonely: 0.7, sad: 0.3 } },
  { locale: 'ko', patterns: [/행복/u, /기쁘/u, /웃(?:다|어|고)?/u], valence: 0.9, arousal: 0.6, directScores: { happy: 0.8 } },
  { locale: 'ko', patterns: [/사랑/u, /사랑해 너를/u, /좋아해/u], valence: 0.8, arousal: 0.5, directScores: { romantic: 0.8 } },
  { locale: 'ko', patterns: [/희망/u, /내일(?: 다시)?/u, /미래/u], valence: 0.6, arousal: 0.4, directScores: { hopeful: 0.8 } },
  { locale: 'ko', patterns: [/추억/u, /그리워/u, /기억/u], valence: 0.0, arousal: -0.4, directScores: { nostalgic: 0.7 } },
  { locale: 'ko', patterns: [/분노/u, /미워/u, /화가 나/u], valence: -0.9, arousal: 0.9, directScores: { angry: 0.8, energy: 0.3, dark: 0.2 } },
  { locale: 'ko', patterns: [/평화/u, /조용/u, /편안/u], valence: 0.5, arousal: -0.7, directScores: { calm: 0.8 } },
  { locale: 'ko', patterns: [/춤/u, /불타/u, /열정/u], valence: 0.7, arousal: 0.8, directScores: { energy: 0.8 } },
  { locale: 'ko', patterns: [/어둠/u, /죽음/u, /검은/u], valence: -0.7, arousal: 0.1, directScores: { dark: 0.7 } },
];

// Kyrillisch ist nur die Schrifterkennung; dieses Modul enthält bewusst
// ausschließlich konkrete russische Signale und kann später ergänzt werden.
const RUSSIAN_LYRICS_SIGNALS: LocalizedLyricsSignal[] = [
  { locale: 'ru', patterns: [/(?<!\p{L})грустн\p{L}*(?!\p{L})/u, /(?<!\p{L})печал\p{L}*(?!\p{L})/u, /(?<!\p{L})слез\p{L}*(?!\p{L})/u, /(?<!\p{L})плак\p{L}*(?!\p{L})/u], valence: -0.9, arousal: -0.3, directScores: { sad: 0.8 } },
  { locale: 'ru', patterns: [/(?<!\p{L})один(?!\p{L})/u, /(?<!\p{L})одна(?!\p{L})/u, /(?<!\p{L})одинок\p{L}*(?!\p{L})/u, /(?<!\p{L})одиночеств\p{L}*(?!\p{L})/u], valence: -0.7, arousal: -0.5, directScores: { lonely: 0.7, sad: 0.3 } },
  { locale: 'ru', patterns: [/(?<!\p{L})счаст\p{L}*(?!\p{L})/u, /(?<!\p{L})радост\p{L}*(?!\p{L})/u, /(?<!\p{L})улыб\p{L}*(?!\p{L})/u], valence: 0.9, arousal: 0.6, directScores: { happy: 0.8 } },
  { locale: 'ru', patterns: [/(?<!\p{L})любов\p{L}*(?!\p{L})/u, /(?<!\p{L})любл\p{L}*(?!\p{L})/u, /(?<!\p{L})сердц\p{L}*(?!\p{L})/u, /(?<!\p{L})поцел\p{L}*(?!\p{L})/u], valence: 0.8, arousal: 0.5, directScores: { romantic: 0.8 } },
  { locale: 'ru', patterns: [/(?<!\p{L})надежд\p{L}*(?!\p{L})/u, /(?<!\p{L})завтра(?!\p{L})/u, /(?<!\p{L})будущ\p{L}*(?!\p{L})/u], valence: 0.6, arousal: 0.4, directScores: { hopeful: 0.8 } },
  { locale: 'ru', patterns: [/(?<!\p{L})воспомин\p{L}*(?!\p{L})/u, /(?<!\p{L})помн\p{L}*(?!\p{L})/u, /(?<!\p{L})раньше(?!\p{L})/u], valence: 0.0, arousal: -0.4, directScores: { nostalgic: 0.7 } },
  { locale: 'ru', patterns: [/(?<!\p{L})злост\p{L}*(?!\p{L})/u, /(?<!\p{L})ненавиж\p{L}*(?!\p{L})/u, /(?<!\p{L})ярост\p{L}*(?!\p{L})/u], valence: -0.9, arousal: 0.9, directScores: { angry: 0.8, energy: 0.3, dark: 0.2 } },
  { locale: 'ru', patterns: [/(?<!\p{L})спокой\p{L}*(?!\p{L})/u, /(?<!\p{L})тишин\p{L}*(?!\p{L})/u, /(?<!\p{L})мир(?!\p{L})/u], valence: 0.5, arousal: -0.7, directScores: { calm: 0.8 } },
  { locale: 'ru', patterns: [/(?<!\p{L})танцев\p{L}*(?!\p{L})/u, /(?<!\p{L})огон\p{L}*(?!\p{L})/u, /(?<!\p{L})энерг\p{L}*(?!\p{L})/u], valence: 0.7, arousal: 0.8, directScores: { energy: 0.8 } },
  { locale: 'ru', patterns: [/(?<!\p{L})тьм\p{L}*(?!\p{L})/u, /(?<!\p{L})смерт\p{L}*(?!\p{L})/u, /(?<!\p{L})тен\p{L}*(?!\p{L})/u], valence: -0.7, arousal: 0.1, directScores: { dark: 0.7 } },
];

// Han-Schrift allein bestimmt keine Sprache. Das Mandarin-Modul wird erst
// durch konkrete chinesische Lexeme oder Phrasen aktiviert; gemeinsame
// Einzelzeichen dürfen danach innerhalb eines bestätigten Textes beitragen.
const CHINESE_ACTIVATION_PATTERNS = [
  /我(?:爱|愛|喜欢|喜歡|想)你/u,
  /(?:悲伤|悲傷|难过|難過|眼泪|眼淚|孤独|孤獨|寂寞|一个人|一個人)/u,
  /(?:开心|開心|快乐|快樂|爱你|愛你|喜欢|喜歡)/u,
  /(?:明天|未来|未來|想起|回忆|回憶|曾经|曾經|过去|過去)/u,
  /(?:生气|生氣|愤怒|憤怒|安静|安靜|宁静|寧靜|温柔)/u,
  /(?:跳舞|燃烧|燃燒|热血|熱血|黑暗|阴影|陰影|深渊|深淵)/u,
  /(?:还有|還有|这里|這裡|一起|充满|充滿|只有|不停)/u,
];

const CHINESE_LYRICS_SIGNALS: LocalizedLyricsSignal[] = [
  { locale: 'zh', patterns: [/悲伤|悲傷/u, /难过|難過/u, /眼泪|眼淚/u, /哭/u], valence: -0.9, arousal: -0.3, directScores: { sad: 0.8 } },
  { locale: 'zh', patterns: [/孤独|孤獨/u, /寂寞/u, /一个人|一個人/u], valence: -0.7, arousal: -0.5, directScores: { lonely: 0.7, sad: 0.3 } },
  { locale: 'zh', patterns: [/开心|開心/u, /快乐|快樂/u, /幸福/u, /笑/u], valence: 0.9, arousal: 0.6, directScores: { happy: 0.8 } },
  { locale: 'zh', patterns: [/我爱你|我愛你/u, /我喜欢你|我喜歡你/u, /爱你|愛你/u, /喜欢|喜歡/u, /爱|愛/u, /(?<![开開])心/u, /吻/u], valence: 0.8, arousal: 0.5, directScores: { romantic: 0.8 } },
  { locale: 'zh', patterns: [/明天会更好|明天會更好/u, /希望/u, /明天/u, /未来|未來/u, /相信/u], valence: 0.6, arousal: 0.4, directScores: { hopeful: 0.8 } },
  { locale: 'zh', patterns: [/回到过去|回到過去/u, /回忆|回憶/u, /想起/u, /曾经|曾經/u, /过去|過去/u], valence: 0.0, arousal: -0.4, directScores: { nostalgic: 0.7 } },
  { locale: 'zh', patterns: [/生气|生氣/u, /愤怒|憤怒/u, /恨/u, /怒/u], valence: -0.9, arousal: 0.9, directScores: { angry: 0.8, energy: 0.3, dark: 0.2 } },
  { locale: 'zh', patterns: [/平静|平靜/u, /安静|安靜/u, /宁静|寧靜/u, /温柔/u], valence: 0.5, arousal: -0.7, directScores: { calm: 0.8 } },
  { locale: 'zh', patterns: [/跳舞/u, /燃烧|燃燒/u, /热血|熱血/u, /火/u], valence: 0.7, arousal: 0.8, directScores: { energy: 0.8 } },
  { locale: 'zh', patterns: [/黑暗/u, /死亡/u, /阴影|陰影/u, /深渊|深淵/u], valence: -0.7, arousal: 0.1, directScores: { dark: 0.7 } },
];

const LOCALIZED_LYRICS_SIGNALS = [
  ...SPANISH_LYRICS_SIGNALS,
  ...JAPANESE_LYRICS_SIGNALS,
  ...KOREAN_LYRICS_SIGNALS,
  ...RUSSIAN_LYRICS_SIGNALS,
  ...CHINESE_LYRICS_SIGNALS,
];

// Negations-Prefixe
const NEGATION_PATTERN = /\b(nicht|kein[er]?\b|keine\b|keinem\b|keinen\b|don'?t\b|doesn'?t\b|isn'?t\b|no\b|not\b|never\b|without\b|niemals\b|nichts\b)/i;

function findPhraseMatch(text: string, patterns: RegExp[]): string | null {
  for (const pattern of patterns) {
    if (!pattern.source.includes(' ')) continue;
    const match = text.match(pattern);
    if (match?.[0]) return match[0];
  }
  return null;
}

function normalizeLyricsText(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .normalize('NFC')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

type LocalizedSignalMatch = {
  signal: LocalizedLyricsSignal;
  text: string;
  index: number;
  negated: boolean;
};

function segmentLocalizedText(text: string, locale: 'ja' | 'ko' | 'ru' | 'zh'): string[] {
  if (typeof Intl.Segmenter !== 'function') return text.split(/\s+/).filter(Boolean);
  return [...new Intl.Segmenter(locale, { granularity: 'word' }).segment(text)]
    .filter((part) => part.isWordLike)
    .map((part) => part.segment);
}

function isLocalizedNegation(
  text: string,
  matchIndex: number,
  matchText: string,
  locale: 'es' | 'ja' | 'ko' | 'ru' | 'zh',
): boolean {
  const before = text.slice(Math.max(0, matchIndex - 24), matchIndex).trim();
  const previousWords = before.split(/\s+/).filter(Boolean).slice(-2);
  if (locale === 'es')
    return previousWords.some((word) => /^(?:no|nunca|jamas)$/.test(word));
  if (locale === 'ko')
    return previousWords.slice(-1).some((word) => /^(?:안|못)$/.test(word));
  if (locale === 'ru')
    return previousWords.some((word) => /^(?:не|никогда)$/.test(word));
  if (locale === 'zh')
    return /(?:不|没|沒|不是)$/u.test(text.slice(Math.max(0, matchIndex - 2), matchIndex));
  const after = text.slice(matchIndex + matchText.length, matchIndex + matchText.length + 6);
  return /^(?:じゃない|ではない|くない)/.test(after);
}

function findLocalizedSignalMatches(text: string): LocalizedSignalMatch[] {
  const hasKana = /[\p{Script=Hiragana}\p{Script=Katakana}]/u.test(text);
  const hasHan = /\p{Script=Han}/u.test(text);
  const hasChineseLexeme = hasHan && CHINESE_ACTIVATION_PATTERNS.some((pattern) => pattern.test(text));
  const hasJapanese = hasKana || (hasHan && !hasChineseLexeme);
  const hasChinese = hasChineseLexeme;
  const hasKorean = /\p{Script=Hangul}/u.test(text);
  const hasCyrillic = /\p{Script=Cyrillic}/u.test(text);
  const japaneseSegments = hasJapanese ? segmentLocalizedText(text, 'ja') : [];
  const koreanSegments = hasKorean ? segmentLocalizedText(text, 'ko') : [];
  const russianSegments = hasCyrillic ? segmentLocalizedText(text, 'ru') : [];
  const chineseSegments = hasChinese ? segmentLocalizedText(text, 'zh') : [];
  const matches: LocalizedSignalMatch[] = [];

  for (const signal of LOCALIZED_LYRICS_SIGNALS) {
    if (signal.locale === 'ja' && !hasJapanese) continue;
    if (signal.locale === 'ko' && !hasKorean) continue;
    if (signal.locale === 'ru' && !hasCyrillic) continue;
    if (signal.locale === 'zh' && !hasChinese) continue;
    const segments = signal.locale === 'ja'
      ? japaneseSegments
      : signal.locale === 'ko'
        ? koreanSegments
        : signal.locale === 'ru'
          ? russianSegments
          : signal.locale === 'zh'
            ? chineseSegments
          : [];
    let foundText = '';
    let foundIndex = -1;
    for (const pattern of signal.patterns) {
      const fullMatch = text.match(pattern);
      if (fullMatch?.[0] && fullMatch.index !== undefined) {
        foundText = fullMatch[0];
        foundIndex = fullMatch.index;
        break;
      }
      for (const segment of segments) {
        const segmentMatch = segment.match(pattern);
        if (!segmentMatch?.[0]) continue;
        foundText = segmentMatch[0];
        foundIndex = text.indexOf(segment);
        break;
      }
      if (foundText) break;
    }
    if (!foundText || foundIndex < 0) continue;
    matches.push({
      signal,
      text: foundText,
      index: foundIndex,
      negated: isLocalizedNegation(text, foundIndex, foundText, signal.locale),
    });
  }
  return matches;
}

export function analyzeLyricsMood(lyrics: string): LyricsMoodResult {
  // Tokenisierung: normalisieren und in Wörter zerlegen
  const normalized = normalizeLyricsText(lyrics);
  const words = normalized ? normalized.split(' ') : [];
  const localizedMatches = findLocalizedSignalMatches(normalized);
  const textUnitCount = countLyricsUnits(normalized);

  // Diminishing Returns: Deduplizierte Zeilen
  const lines = lyrics.split('\n').map(l => l.trim()).filter(Boolean);
  const uniqueLines = [...new Set(lines.map(normalizeLyricsText))];
  const repeatFactor = lines.length > 0 ? Math.min(1, uniqueLines.length / Math.max(lines.length, 1)) : 1;

  let valenceSum = 0;
  let arousalSum = 0;
  let signalCount = 0;
  const recognizedSignals = new Set<string>();
  const moodSignalSupport = new Map<string, Set<string>>();
  const lexicalMatchWeights = new Map<string, number>();
  const lexicalOccurrenceCounts = new Map<number, number>();
  const positiveSignals: string[] = [];
  const negativeSignals: string[] = [];
  const calmSignals: string[] = [];
  const intenseSignals: string[] = [];

  // Für jedes Wort: Signal prüfen mit Negations-Kontext
  for (let i = 0; i < words.length; i++) {
    const word = words[i];

    // Prüfe ob vorheriges Wort eine Negation ist
    const prevWord = i > 0 ? words[i - 1] : '';
    const isNegated = NEGATION_PATTERN.test(prevWord);

    for (let signalIndex = 0; signalIndex < LYRICS_SIGNALS.length; signalIndex++) {
      const signal = LYRICS_SIGNALS[signalIndex];
      for (const pattern of signal.patterns) {
        if (pattern.test(word)) {
          const occurrence = lexicalOccurrenceCounts.get(signalIndex) ?? 0;
          const occurrenceWeight = 0.5 ** Math.min(occurrence, 6);
          lexicalOccurrenceCounts.set(signalIndex, occurrence + 1);
          lexicalMatchWeights.set(`${i}:${signalIndex}`, occurrenceWeight);
          let valence = signal.valence;
          let arousal = signal.arousal;

          // Negation: Valence invertieren, Arousal abschwächen
          if (isNegated) {
            valence = valence * -0.6;
            arousal = arousal * 0.3;
          }

          valenceSum += valence * occurrenceWeight;
          arousalSum += arousal * occurrenceWeight;
          signalCount++;
          recognizedSignals.add(word);

          // Signal-Typen sammeln
          if (valence > 0.3) positiveSignals.push(word);
          else if (valence < -0.3) negativeSignals.push(word);
          if (arousal < -0.3) calmSignals.push(word);
          else if (arousal > 0.3) intenseSignals.push(word);
          break; // Nur erstes Match pro Wort
        }
      }
    }
  }

  // Mehrwort-Regeln gegen den vollständigen normalisierten Text prüfen.
  for (const signal of LYRICS_SIGNALS) {
    const phrase = findPhraseMatch(normalized, signal.patterns);
    if (!phrase) continue;
    valenceSum += signal.valence;
    arousalSum += signal.arousal;
    signalCount++;
    recognizedSignals.add(phrase);
    if (signal.valence > 0.3) positiveSignals.push(phrase);
    else if (signal.valence < -0.3) negativeSignals.push(phrase);
    if (signal.arousal < -0.3) calmSignals.push(phrase);
    else if (signal.arousal > 0.3) intenseSignals.push(phrase);
  }

  // Sprachspezifische Signale laufen additiv neben Englisch/Deutsch.
  for (const match of localizedMatches) {
    let valence = match.signal.valence;
    let arousal = match.signal.arousal;
    if (match.negated) {
      valence *= -0.6;
      arousal *= 0.3;
    }
    valenceSum += valence;
    arousalSum += arousal;
    signalCount++;
    recognizedSignals.add(match.text);
    if (valence > 0.3) positiveSignals.push(match.text);
    else if (valence < -0.3) negativeSignals.push(match.text);
    if (arousal < -0.3) calmSignals.push(match.text);
    else if (arousal > 0.3) intenseSignals.push(match.text);
  }

  // Wiederholungs-Faktor anwenden
  valenceSum *= repeatFactor;
  arousalSum *= repeatFactor;

  // Durchschnittliche Valence/Arousal
  const avgValence = signalCount > 0 ? valenceSum / signalCount : 0;
  const avgArousal = signalCount > 0 ? arousalSum / signalCount : 0;

  // Mood-Scores initialisieren (10 Kategorien)
  const scores: Record<string, number> = {
    happy: 0, sad: 0, dark: 0, angry: 0, calm: 0, energy: 0,
    romantic: 0, lonely: 0, hopeful: 0, nostalgic: 0,
  };
  const addMoodSignal = (moodId: string, signalText: string) => {
    const signals = moodSignalSupport.get(moodId) ?? new Set<string>();
    signals.add(signalText);
    moodSignalSupport.set(moodId, signals);
  };

  // === METHODE 1: Direkte Score-Beiträge pro Signal ===
  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    const prevWord = i > 0 ? words[i - 1] : '';
    const isNegated = NEGATION_PATTERN.test(prevWord);

    for (let signalIndex = 0; signalIndex < LYRICS_SIGNALS.length; signalIndex++) {
      const signal = LYRICS_SIGNALS[signalIndex];
      for (const pattern of signal.patterns) {
        if (pattern.test(word)) {
          if (signal.directScores) {
            for (const [moodId, weight] of Object.entries(signal.directScores)) {
              let w = weight;
              if (isNegated) {
                // Bei Negation: Positiv → neutral, Negativ → leicht positiv
                w = w * -0.3;
              }
              const contribution = w * (lexicalMatchWeights.get(`${i}:${signalIndex}`) ?? 1);
              scores[moodId] = (scores[moodId] || 0) + contribution;
              if (contribution > 0) addMoodSignal(moodId, word);
            }
          }
          break;
        }
      }
    }
  }

  // Vorhandene Mehrwort-Regeln einmal pro Signal auf den Gesamttext anwenden.
  for (const signal of LYRICS_SIGNALS) {
    const phrase = findPhraseMatch(normalized, signal.patterns);
    if (!phrase || !signal.directScores) continue;
    for (const [moodId, weight] of Object.entries(signal.directScores)) {
      scores[moodId] = (scores[moodId] || 0) + weight;
      if (weight > 0) addMoodSignal(moodId, phrase);
    }
  }

  for (const match of localizedMatches) {
    if (!match.signal.directScores) continue;
    for (const [moodId, weight] of Object.entries(match.signal.directScores)) {
      const contribution = match.negated ? weight * -0.3 : weight;
      scores[moodId] = (scores[moodId] || 0) + contribution;
      if (contribution > 0) addMoodSignal(moodId, match.text);
    }
  }

  // === METHODE 2: Valence/Arousal als Backup-Fallback ===
  // Nur wenn direkte Scores zu schwach sind
  const maxDirectScore = Math.max(...Object.values(scores).map(Math.abs));
  if (maxDirectScore < 0.3 && signalCount > 2) {
    // Valence/Arousal-Mapping als Fallback
    if (avgValence > 0.2 && avgArousal > 0.2) {
      scores.happy += avgValence * 0.5;
      scores.energy += avgArousal * 0.4;
    } else if (avgValence > 0.2 && avgArousal <= 0.2) {
      scores.calm += Math.abs(avgArousal) * 0.5;
      scores.happy += avgValence * 0.3;
    } else if (avgValence <= -0.2 && avgArousal > 0.2) {
      scores.angry += avgArousal * 0.5;
      scores.energy += avgArousal * 0.3;
      scores.dark += Math.abs(avgValence) * 0.3;
    } else if (avgValence <= -0.2 && avgArousal <= -0.2) {
      scores.sad += Math.abs(avgValence) * 0.5;
      scores.dark += Math.abs(avgValence) * 0.3;
    }
  }

  // Wiederholungs-Faktor anwenden
  for (const key of Object.keys(scores)) {
    scores[key] *= repeatFactor;
  }

  // Negative Beiträge clampen und Lyrics pro Mood konservativ deckeln.
  for (const key of Object.keys(scores)) {
    scores[key] = Math.min(LYRICS_MOOD_SCORE_CAP, Math.max(0, scores[key]));
  }

  // Confidence: Textabdeckung, unabhängige Gewinner-Signale und Gewinnerabstand.
  const rankedScores = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const [winnerId, winnerScore] = rankedScores[0] ?? ['', 0];
  const secondScore = rankedScores[1]?.[1] ?? 0;
  const winnerMargin = winnerScore > 0 ? (winnerScore - secondScore) / winnerScore : 0;
  const uniqueSignalCount = recognizedSignals.size;
  const coverageTarget = Math.max(3, Math.ceil(textUnitCount * 0.08));
  const coverage = Math.min(1, uniqueSignalCount / coverageTarget);
  const winnerSignalCount = moodSignalSupport.get(winnerId)?.size ?? 0;
  const winnerSupport = Math.min(1, winnerSignalCount / 3);
  const confidenceScore = coverage * 0.35 + winnerSupport * 0.35 + winnerMargin * 0.3;

  let confidence: 'high' | 'medium' | 'low' = 'low';
  if (
    confidenceScore >= 0.72 &&
    winnerSignalCount >= 3 &&
    winnerMargin >= 0.3
  ) {
    confidence = 'high';
  } else if (
    confidenceScore >= 0.45 &&
    winnerSignalCount >= 2 &&
    winnerMargin >= 0.12
  ) {
    confidence = 'medium';
  }

  const sourceQuality = confidence === 'high' ? 1 : confidence === 'medium' ? 0.75 : 0.55;
  for (const key of Object.keys(scores)) scores[key] *= sourceQuality;

  return {
    scores,
    confidence,
    coverage,
    signalCount,
    uniqueSignalCount,
    winnerMargin,
    sourceQuality,
    positiveSignals: [...new Set(positiveSignals)].slice(0, 5),
    negativeSignals: [...new Set(negativeSignals)].slice(0, 5),
    calmSignals: [...new Set(calmSignals)].slice(0, 5),
    intenseSignals: [...new Set(intenseSignals)].slice(0, 5),
  };
}

export function detectMood(
  track: Track | null,
  externalTags?: LastfmTag[],
) {
  if (!track) return null;
  const title = track.title || '';
  const album = track.album || '';
  const genres = track.genres || [];

  // === LOKALE TEXTANALYSE (synchron, primär) ===
  const localRanked = moods
    .map((m) => {
      const titleScore = m.words.reduce((sum, mw) => {
        return sum + (contains(title, mw.w) ? mw.n : 0);
      }, 0);
      const albumScore = m.words.reduce((sum, mw) => {
        return sum + (contains(album, mw.w) ? mw.n * 0.5 : 0);
      }, 0);
      const genreScore = m.genres.reduce((sum, g) => {
        return sum + (genres.some((actual) => contains(actual, g))
          ? 2 + g.split(' ').length - 1
          : 0);
      }, 0);
      const score = titleScore * 3 + albumScore;
      const matchedTitle = m.words
        .filter((mw) => contains(title, mw.w))
        .map((mw) => mw.w);
      const matchedAlbum = m.words
        .filter((mw) => contains(album, mw.w))
        .map((mw) => mw.w);
      const matchedGenre = m.genres.filter((g) =>
        genres.some((actual) => contains(actual, g)),
      );
      return {
        mood: m,
        localScore: score,
        localGenreScore: genreScore,
        source: matchedTitle.length
          ? 'Songtitel'
          : matchedAlbum.length
              ? 'Albumtitel'
              : matchedGenre.length
                ? 'Künstler-Genre'
                : '',
        terms: [...matchedTitle, ...matchedGenre, ...matchedAlbum],
      };
    })
    .sort((a, b) => b.localScore - a.localScore);

  // === GENRE-HEURISTIK (schwache, aber nützliche Quelle) ===
  const genreRanked = moods.map((m) => {
    let genreScore = 0;
    const matchedGenreTerms: string[] = [];
    for (const genre of genres) {
      const g = normalize(genre);
      const mapping = GENRE_TO_MOOD[g];
      if (mapping) {
        const moodContrib = mapping.find((mm) => mm.moodId === m.id);
        if (moodContrib) {
          genreScore += moodContrib.weight;
          matchedGenreTerms.push(genre);
        }
      }
    }
    return {
      moodId: m.id,
      genreScore,
      matchedGenreTerms,
    };
  });

  // Genre-Scores als Map speichern
  const genreScoreMap: Record<string, number> = {};
  const genreTermsMap: Record<string, string[]> = {};
  for (const g of genreRanked) {
    genreScoreMap[g.moodId] = g.genreScore;
    genreTermsMap[g.moodId] = g.matchedGenreTerms;
  }

  // === LAST.FM TAGS (extern geladen, fallback) ===
  let tagScores: Record<string, number> = {};
  const tagQualityMap: Record<string, number> = {};
  const tagProviderMap: Record<string, Set<LastfmTag['source']>> = {};
  let tagSource: string[] = [];
  if (externalTags && externalTags.length > 0) {
    // Tag-Stärke normalisieren (höchster Count → 1.0)
    const maxCount = Math.max(...externalTags.map((t) => t.count), 1);
    for (const { tag, count, source } of externalTags) {
      const normalizedTag = tag.toLowerCase().trim();
      const mapping = TAG_TO_MOOD[normalizedTag];
      if (!mapping) continue;
      const strength = Math.min(count / maxCount, 1);
      const factor = SOURCE_FACTOR[source] ?? 1.0;
      for (const { moodId, weight } of mapping) {
        tagScores[moodId] =
          (tagScores[moodId] || 0) + weight * strength * factor;
        tagQualityMap[moodId] = Math.max(tagQualityMap[moodId] || 0, factor);
        const providers = tagProviderMap[moodId] ?? new Set<LastfmTag['source']>();
        providers.add(source);
        tagProviderMap[moodId] = providers;
      }
      tagSource.push(normalizedTag);
    }
  }

  // === SCORES KOMBINIEREN ===
  const combined = localRanked
    .map((r) => {
      const tagContrib = tagScores[r.mood.id] || 0;
      const tagCapped = Math.min(tagContrib, 3.0);
      const localPart = r.localScore + tagCapped * (r.localScore < 1.5 ? 1.0 : 0.4);
      // Denselben Spotify-Genre-Hinweis nicht über beide Heuristiken doppelt zählen.
      const genreContrib = Math.max(
        r.localGenreScore,
        genreScoreMap[r.mood.id] || 0,
      );
      const combinedScore = localPart + genreContrib;
      return {
        ...r,
        combinedScore,
        tagScore: tagContrib,
        tagCapped,
        tagQuality: tagQualityMap[r.mood.id] || 0,
        tagProviders: tagProviderMap[r.mood.id] ?? new Set<LastfmTag['source']>(),
        genreScore: genreContrib,
        lyricsScore: 0,
      };
    })
    .sort((a, b) => b.combinedScore - a.combinedScore);

  // === LYRICS-MOOD (aus serverseitiger Analyse) ===
  let lyricsQuality = 0;
  if (track?.lyricMoodScores) {
    const lyricRanking = Object.values(track.lyricMoodScores).sort((a, b) => b - a);
    const lyricTop = lyricRanking[0] || 0;
    const lyricSecond = lyricRanking[1] || 0;
    const lyricMargin = lyricTop > 0 ? (lyricTop - lyricSecond) / lyricTop : 0;
    lyricsQuality = Math.min(0.85, Math.min(1, lyricTop / LYRICS_MOOD_SCORE_CAP) * 0.5 + lyricMargin * 0.35);
    for (const r of combined) {
      const lyricsContrib = track.lyricMoodScores[r.mood.id] || 0;
      r.lyricsScore = Math.min(2.0, lyricsContrib * 1.3);
      r.combinedScore += r.lyricsScore;
    }
    combined.sort((a, b) => b.combinedScore - a.combinedScore);
  }

  const best = combined[0];
  const second = combined[1];
  const margin = second ? best.combinedScore - second.combinedScore : Infinity;

  // Nur null zurückgeben, wenn WIRKLICH ALLE Scores 0 sind
  const maxScore = best.combinedScore;
  if (maxScore <= 0) return null;

  // Confidence nach Quellenqualität und Eindeutigkeit bestimmen.
  const marginRatio = Number.isFinite(margin) && maxScore > 0 ? margin / maxScore : 1;
  const localQuality = best.localScore > 0
    ? best.source === 'Songtitel'
      ? 0.95
      : best.source === 'Albumtitel'
        ? 0.55
        : 0
    : 0;
  const genreQuality = best.genreScore > 0 ? 0.45 : 0;
  const winnerLyricsQuality = best.lyricsScore > 0 ? lyricsQuality : 0;
  const evidence = [
    { score: best.localScore, quality: localQuality },
    { score: best.tagCapped, quality: best.tagQuality },
    { score: best.genreScore, quality: genreQuality },
    { score: best.lyricsScore, quality: winnerLyricsQuality },
  ];
  const strongestQuality = Math.max(...evidence.map((item) => item.quality), 0);
  const strongIndependentSources = evidence.filter(
    (item) => item.score >= 0.35 && item.quality >= 0.6,
  ).length;

  let confidence: 'high' | 'medium' | 'low' = 'low';
  if (
    marginRatio >= 0.35 &&
    maxScore >= 1.2 &&
    (
      strongIndependentSources >= 2 ||
      (winnerLyricsQuality >= 0.75 && best.lyricsScore >= 1.2) ||
      (localQuality >= 0.9 && maxScore >= 2.2)
    )
  ) {
    confidence = 'high';
  } else if (
    marginRatio >= 0.12 &&
    maxScore >= 0.7 &&
    strongestQuality >= 0.45
  ) {
    confidence = 'medium';
  }

  // Source bestimmen
  const sources: string[] = [];
  if (best.localScore > 0) sources.push('text');
  if (best.tagScore > 0) {
    if (best.tagProviders.has('listenbrainz')) sources.push('listenbrainz');
    if ([...best.tagProviders].some((source) => source !== 'listenbrainz'))
      sources.push('lastfm');
  }
  if (best.lyricsScore > 0) sources.push('lyrics');

  // Nahezu exakte Gleichstände bleiben unsicher oder liefern bei Minimalscores nichts.
  if (marginRatio < 0.05) {
    if (best.combinedScore > 0.3) {
      confidence = 'low';
    } else {
      return null;
    }
  }

  return {
    mood: best.mood,
    score: best.combinedScore,
    source: sources.join('+') || best.source || 'genre',
    terms: [...best.terms, ...tagSource.slice(0, 5), ...(genreTermsMap[best.mood.id] || [])],
    confidence,
    genreScore: best.genreScore,
  };
}
export function blend(a: string, b: string, amount: number) {
  const channels = [1, 3, 5].map((i) =>
    Math.round(
      parseInt(a.slice(i, i + 2), 16) * (1 - amount) +
        parseInt(b.slice(i, i + 2), 16) * amount,
    ),
  );
  return '#' + channels.map((c) => c.toString(16).padStart(2, '0')).join('');
}
function light(c: string) {
  const a = [1, 3, 5].map((i) => {
    const v = parseInt(c.slice(i, i + 2), 16) / 255;
    return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
  });
  return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
}
export function moodConfig(
  base: Config,
  track: Track | null,
  externalTags?: LastfmTag[],
): Config {
  if (!isMoodEffectivelyEnabled(base)) return base;
  const match = detectMood(track, externalTags);
  if (!match) return base;
  const amount = (base.moodIntensity ?? 70) / 100;
  if (amount === 0) return base;
  const pale = light(base.background) > 0.45;
  const background = blend(
    base.background,
    pale ? match.mood.light : match.mood.dark,
    amount * 0.8,
  );
  let accent = blend(base.accent, match.mood.accent, amount);
  if (pale) accent = blend(accent, '#302138', 0.4);
  const contrast =
    (Math.max(light(background), light(base.text)) + 0.05) /
    (Math.min(light(background), light(base.text)) + 0.05);
  return {
    ...base,
    accent,
    background,
    text: contrast < 4.5 ? (pale ? '#292333' : '#f5f5f7') : base.text,
  };
}
export const moodDemos = [
  { title: 'Midnight in Motion', album: 'Starlight', genres: ['synthwave'] },
  { title: 'Fire & Adrenaline', album: 'Voltage', genres: ['techno'] },
  { title: 'Quiet Ocean', album: 'Slow Breathing', genres: ['ambient'] },
  {
    title: 'Goodbye, Lonely Heart',
    album: 'Blue Letters',
    genres: ['slowcore'],
  },
  { title: 'Sunshine Smile', album: 'Good Times', genres: ['funk'] },
  { title: 'Shadows & Ghosts', album: 'Nocturne', genres: ['darkwave'] },
  { title: 'Track 07', album: 'Volume II', genres: [] },
  // NEU: Deutsche Testfälle
  { title: 'Ich bin verloren', album: 'Leere Räume', genres: [] },
  { title: 'Alles ist leer', album: 'Stille', genres: [] },
  { title: 'Ich vermisse dich', album: 'Erinnerungen', genres: [] },
  { title: 'Wir brennen', album: 'Flammen', genres: ['punk'] },
  { title: 'Sommernacht', album: 'Licht', genres: [] },
  { title: 'Leise durch die Nacht', album: 'Mond', genres: ['ambient'] },
];
