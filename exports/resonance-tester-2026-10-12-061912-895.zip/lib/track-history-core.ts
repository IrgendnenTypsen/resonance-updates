// --- Track History (F03): reine Entscheidungslogik, ohne Datenbank ---
// Gemeinsame Grundlage für Song-Verlauf (F03), Album Wall (F15) und
// StreamShelf (F21). Es gibt genau EINEN Verlaufsspeicher.
//
// Aufgezeichnet wird nur, was Resonance tatsächlich beobachtet (Abfragen von
// /api/now, solange ein Overlay oder das Studio offen ist). Das ist bewusst
// KEIN vollständiger Spotify-Hörverlauf.
//
// Regeln:
// - Stream-Session: beginnt mit dem ersten laufenden Song und endet, wenn
//   länger als HISTORY_SESSION_GAP keine Musik lief (Pause zählt als „keine
//   Musik“). Ein OBS-Refresh oder Neustart ändert daran nichts, weil der
//   Zustand in der Datenbank liegt.
// - Pause erzeugt keinen neuen Eintrag.
// - Ein wiederholter Song (lief bis zum Ende, startet neu) ist ein neuer Eintrag.
// - Übersprungene Songs werden als „skipped“ markiert, nie als „completed“.
// - Songs, die erst kurz vor Schluss beobachtet wurden, heißen „partial“.

export const HISTORY_SESSION_GAP = 30 * 60_000; // 30 min ohne Musik → neue Session
const END_WINDOW = 20_000; // so nah am Ende gilt ein Song als „bis zum Schluss gehört“
const SKIP_LISTEN = 30_000; // weniger gehört + nicht am Ende → übersprungen
const RESTART_PROGRESS = 15_000; // Neustart erkannt, wenn wieder im Anfang
const POLL_SLACK = 1_500; // Toleranz zwischen Abfragezeit und Fortschritt

export type PlayStatus = 'playing' | 'completed' | 'skipped' | 'partial';

export type HistorySession = {
  id: string;
  startedAt: number;
  lastSeenAt: number;
  trackCount: number;
};

export type HistoryPlay = {
  id: string;
  sessionId: string;
  seq: number;
  key: string;
  trackId: string | null;
  title: string;
  artist: string;
  album: string;
  coverUrl: string;
  durationMs: number;
  startedAt: number;
  lastSeenAt: number;
  firstProgressMs: number;
  lastProgressMs: number;
  maxProgressMs: number;
  listenedMs: number;
};

export type ObservedTrack = {
  trackId: string | null;
  title: string;
  artist: string;
  album: string;
  coverUrl: string;
  durationMs: number;
  progressMs: number;
  playing: boolean;
};

export type HistoryState = { session: HistorySession | null; play: HistoryPlay | null };

export type HistoryOp =
  | { op: 'closeSession'; id: string; endedAt: number; reason: 'idle' | 'manual' }
  | { op: 'openSession'; session: HistorySession }
  | { op: 'touchSession'; id: string; lastSeenAt: number; trackCount: number }
  | {
      op: 'closePlay';
      id: string;
      endedAt: number;
      status: Exclude<PlayStatus, 'playing'>;
      listenedMs: number;
      maxProgressMs: number;
    }
  | { op: 'openPlay'; play: HistoryPlay }
  | {
      op: 'updatePlay';
      id: string;
      lastSeenAt: number;
      lastProgressMs: number;
      maxProgressMs: number;
      listenedMs: number;
    };

export function trackKey(t: Pick<ObservedTrack, 'trackId' | 'title' | 'artist'>) {
  return t.trackId || `${t.title}\u0000${t.artist}`;
}

function reachedEnd(p: Pick<HistoryPlay, 'durationMs' | 'maxProgressMs'>) {
  return p.durationMs > 0 && p.durationMs - p.maxProgressMs <= END_WINDOW;
}

/** Abschlussstatus eines Eintrags aus dem, was beobachtet wurde. */
export function finalStatus(
  p: Pick<HistoryPlay, 'durationMs' | 'maxProgressMs' | 'listenedMs'>,
  /** false, wenn kein anderer Song folgte (Stream/Musik endete) → nie „skipped“. */
  replaced = true,
): Exclude<PlayStatus, 'playing'> {
  const need = Math.min(SKIP_LISTEN, p.durationMs * 0.5);
  if (reachedEnd(p)) return p.listenedMs >= need ? 'completed' : 'partial';
  if (replaced && p.listenedMs < need) return 'skipped';
  return 'partial';
}

function closeOp(p: HistoryPlay, endedAt: number, replaced = true): HistoryOp {
  return {
    op: 'closePlay',
    id: p.id,
    endedAt,
    status: finalStatus(p, replaced),
    listenedMs: p.listenedMs,
    maxProgressMs: p.maxProgressMs,
  };
}

/**
 * Plant die Datenbankänderungen für eine Beobachtung.
 * `track = null` bedeutet: Spotify meldet nichts (204 / kein Song).
 */
export function planObservation(
  state: HistoryState,
  track: ObservedTrack | null,
  at: number,
  newId: () => string,
): { ops: HistoryOp[]; state: HistoryState } {
  const ops: HistoryOp[] = [];
  let session = state.session ? { ...state.session } : null;
  let play = state.play ? { ...state.play } : null;
  if (play && (!session || play.sessionId !== session.id)) play = null;

  // 1. Session abgelaufen? Offenen Eintrag mit seinem letzten Stand abschließen.
  if (session && at - session.lastSeenAt > HISTORY_SESSION_GAP) {
    if (play) ops.push(closeOp(play, play.lastSeenAt, false));
    ops.push({ op: 'closeSession', id: session.id, endedAt: session.lastSeenAt, reason: 'idle' });
    session = null;
    play = null;
  }

  const duration = Math.max(0, track?.durationMs || 0);
  const progress = Math.max(0, Math.min(track?.progressMs || 0, duration || Infinity));

  // 2. Pause / nichts läuft: kein neuer Eintrag, Session wird nicht verlängert.
  //    Beim selben Song nur den Fortschritt merken (Vorspulen in der Pause
  //    zählt später nicht als gehört).
  if (!track || !track.playing) {
    if (track && play && play.key === trackKey(track)) {
      play.lastProgressMs = progress;
      play.lastSeenAt = at;
      ops.push({
        op: 'updatePlay',
        id: play.id,
        lastSeenAt: at,
        lastProgressMs: progress,
        maxProgressMs: play.maxProgressMs,
        listenedMs: play.listenedMs,
      });
    }
    return { ops, state: { session, play } };
  }

  // 3. Musik läuft.
  if (!session) {
    session = { id: newId(), startedAt: at, lastSeenAt: at, trackCount: 0 };
    ops.push({ op: 'openSession', session: { ...session } });
  }
  const key = trackKey(track);
  const same = !!play && play.key === key;
  const restarted =
    same &&
    progress < RESTART_PROGRESS &&
    progress + 5_000 < play!.lastProgressMs &&
    reachedEnd(play!);

  if (play && (!same || restarted)) {
    ops.push(closeOp(play, at));
    play = null;
  }

  if (!play) {
    session.trackCount += 1;
    play = {
      id: newId(),
      sessionId: session.id,
      seq: session.trackCount,
      key,
      trackId: track.trackId,
      title: track.title,
      artist: track.artist,
      album: track.album,
      coverUrl: track.coverUrl,
      durationMs: duration,
      startedAt: at,
      lastSeenAt: at,
      firstProgressMs: progress,
      lastProgressMs: progress,
      maxProgressMs: progress,
      listenedMs: 0,
    };
    ops.push({ op: 'openPlay', play: { ...play } });
  } else {
    const wall = Math.max(0, at - play.lastSeenAt);
    const moved = progress - play.lastProgressMs;
    // Gehört = Fortschritt, aber nie mehr als die vergangene Zeit (Vorspulen).
    const inc = moved > 0 ? Math.min(moved, wall + POLL_SLACK) : 0;
    play.listenedMs = Math.min(play.durationMs || Infinity, play.listenedMs + inc);
    play.maxProgressMs = Math.max(play.maxProgressMs, progress);
    play.lastProgressMs = progress;
    play.lastSeenAt = at;
    ops.push({
      op: 'updatePlay',
      id: play.id,
      lastSeenAt: at,
      lastProgressMs: progress,
      maxProgressMs: play.maxProgressMs,
      listenedMs: play.listenedMs,
    });
  }

  session.lastSeenAt = at;
  ops.push({ op: 'touchSession', id: session.id, lastSeenAt: at, trackCount: session.trackCount });
  return { ops, state: { session, play } };
}

/**
 * Laufende Session von Hand beenden („Stream beenden“ / Aufzeichnung aus).
 * Der offene Song gilt nicht als übersprungen – die Musik endete einfach.
 */
export function planEnd(state: HistoryState, at: number): HistoryOp[] {
  const ops: HistoryOp[] = [];
  const { session, play } = state;
  if (!session) return ops;
  if (play && play.sessionId === session.id) ops.push(closeOp(play, at, false));
  ops.push({ op: 'closeSession', id: session.id, endedAt: at, reason: 'manual' });
  return ops;
}
