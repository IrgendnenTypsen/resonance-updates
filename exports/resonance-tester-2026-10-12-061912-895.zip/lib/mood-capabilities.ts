export type MoodMode = 'none' | 'palette' | 'immersive';

type MoodCapabilityConfig = {
  layout: string;
  glassMaterial?: 'legacy' | 'afterglow';
};

const MOOD_MODES: Readonly<Record<string, MoodMode>> = {
  memory: 'immersive',
  'glass:legacy': 'none',
  'glass:afterglow': 'none',
};

function moodCapabilityKey(config: MoodCapabilityConfig): string {
  return config.layout === 'glass'
    ? `glass:${config.glassMaterial ?? 'legacy'}`
    : config.layout;
}

export function getMoodMode(config: MoodCapabilityConfig): MoodMode {
  return MOOD_MODES[moodCapabilityKey(config)] ?? 'none';
}

export function isMoodEffectivelyEnabled(
  config: MoodCapabilityConfig & { moodSwitch: boolean },
): boolean {
  return config.moodSwitch && getMoodMode(config) !== 'none';
}
