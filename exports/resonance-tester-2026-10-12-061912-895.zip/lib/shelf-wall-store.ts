// --- StreamShelf V2 (F21): Einstellungen + Lieblingssongs (serverseitig) ---
import { cleanShelfWallSettings, SHELF_WALL_DEFAULTS, type ShelfWallSettings } from './shelf-wall-settings';

export async function getShelfWallSettings(d1: D1Database, owner: string): Promise<ShelfWallSettings> {
  try {
    const r = await d1.prepare('SELECT config FROM shelf_settings WHERE owner=?').bind(owner).first<{ config: string }>();
    return r ? cleanShelfWallSettings(JSON.parse(r.config)) : { ...SHELF_WALL_DEFAULTS };
  } catch {
    // Tabelle fehlt (Migration 0011 noch nicht gelaufen) oder kaputtes JSON.
    return { ...SHELF_WALL_DEFAULTS };
  }
}

export async function saveShelfWallSettings(d1: D1Database, owner: string, value: unknown) {
  const settings = cleanShelfWallSettings(value);
  await d1
    .prepare(
      `INSERT INTO shelf_settings (owner, config, updated_at) VALUES (?,?,?)
       ON CONFLICT(owner) DO UPDATE SET config=excluded.config, updated_at=excluded.updated_at`,
    )
    .bind(owner, JSON.stringify(settings), Date.now())
    .run();
  return settings;
}

// Lieblingssongs gebündelt prüfen (Spotify /me/library/contains, bis 40 URIs
// pro Anfrage). Ergebnis 15 min gecacht; bei Limit/Fehler: bekannte Werte.
const faveCache = new Map<string, { v: boolean; at: number }>();
const FAVE_TTL = 15 * 60_000;
let faveBlockedUntil = 0;

export async function favoritesFor(trackIds: string[], access: string | null): Promise<Set<string>> {
  const now = Date.now();
  const ids = [...new Set(trackIds.filter((id) => /^[A-Za-z0-9]{10,40}$/.test(id)))];
  const unknown = ids.filter((id) => {
    const c = faveCache.get(id);
    return !c || now - c.at > FAVE_TTL;
  });
  if (access && unknown.length && now > faveBlockedUntil) {
    for (let i = 0; i < unknown.length; i += 40) {
      const chunk = unknown.slice(i, i + 40);
      try {
        const r = await fetch(
          'https://api.spotify.com/v1/me/library/contains?uris=' +
            encodeURIComponent(chunk.map((id) => 'spotify:track:' + id).join(',')),
          { headers: { Authorization: 'Bearer ' + access }, signal: AbortSignal.timeout(5000), cache: 'no-store' },
        );
        if (r.status === 429) {
          faveBlockedUntil = now + Math.max(30, Number(r.headers.get('retry-after')) || 30) * 1000;
          break;
        }
        if (!r.ok) break;
        const flags = (await r.json()) as boolean[];
        chunk.forEach((id, k) => faveCache.set(id, { v: flags[k] === true, at: now }));
      } catch {
        break;
      }
    }
  }
  return new Set(ids.filter((id) => faveCache.get(id)?.v));
}
