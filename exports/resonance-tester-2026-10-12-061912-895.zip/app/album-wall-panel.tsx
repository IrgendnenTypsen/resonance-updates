'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Switch } from '@/components/ui/switch';
import { AlbumWall, type WallTile } from '@/lib/album-wall';
import { WALL_ACCENTS, WALL_DEFAULTS, type WallSettings } from '@/lib/album-wall-settings';
import { GALLERY_TRACKS } from '@/lib/gallery-demo';
import { estimatedProgress, type Track } from '@/lib/overlay';

// F15 Album Wall – Einstellungen + Live-Vorschau im Studio-Tab „Verlauf“.

type WallResponse = {
  error?: string;
  settings: WallSettings;
  track: Track | null;
  plays: WallTile[];
  songNumber: number;
};

// Beispiel, solange noch nichts läuft: erfundene Demo-Songs (keine echten Cover).
const DEMO_TILES: WallTile[] = Array.from({ length: 12 }, (_, i) => {
  const t = GALLERY_TRACKS[(i % (GALLERY_TRACKS.length - 1)) + 1];
  return { id: 'demo-' + i, cover: t.cover, title: t.title, artist: t.artist, status: 'completed' };
});
const DEMO_TRACK: Track = { ...GALLERY_TRACKS[0], playing: true };

type Opt<T> = [T, string];
const GROUPS: { key: keyof WallSettings; label: string; opts: Opt<string | number | boolean>[] }[] = [
  { key: 'layout', label: 'Layout', opts: [['stage', 'Bühne'], ['bar', 'Leiste'], ['corner', 'Ecke']] },
  { key: 'rows', label: 'Cover-Reihen', opts: [[1, '1'], [2, '2'], [3, '3']] },
  { key: 'speed', label: 'Bewegung der Wand', opts: [['off', 'Aus'], ['slow', 'Langsam'], ['fast', 'Schnell']] },
  { key: 'viz', label: 'Visualizer', opts: [['off', 'Aus'], ['bars', 'Balken'], ['dots', 'Punkte']] },
  { key: 'vizStrong', label: 'Visualizer-Stärke', opts: [[false, 'Dezent'], [true, 'Kräftig']] },
  { key: 'bg', label: 'Hintergrund', opts: [['none', 'Keiner'], ['glass', 'Glas'], ['aura', 'Aura']] },
  { key: 'radius', label: 'Ecken', opts: [['square', 'Eckig'], ['soft', 'Weich'], ['round', 'Rund']] },
];
const TOGGLES: { key: 'vinyl' | 'artist' | 'hideSkipped'; label: string }[] = [
  { key: 'vinyl', label: 'Platte hinter dem Cover' },
  { key: 'artist', label: 'Künstler zeigen' },
  { key: 'hideSkipped', label: 'Übersprungene ausblenden' },
];

export default function AlbumWallPanel({ wallUrl, onCopy }: { wallUrl: string; onCopy: (text: string) => void }) {
  const [settings, setSettings] = useState<WallSettings>(WALL_DEFAULTS);
  const [loaded, setLoaded] = useState(false);
  const [track, setTrack] = useState<Track | null>(null);
  const [plays, setPlays] = useState<WallTile[]>([]);
  const [songNumber, setSongNumber] = useState(0);
  const [note, setNote] = useState('');
  const [scale, setScale] = useState(0.4);
  const stageRef = useRef<HTMLDivElement>(null);
  const dirty = useRef(false);
  const lastSave = useRef(0);
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    const started = Date.now();
    try {
      const r = await fetch('/api/wall', { cache: 'no-store' });
      const d = (await r.json()) as WallResponse;
      if (!r.ok) throw new Error(d.error);
      // Antworten, die vor der letzten Änderung losgeschickt wurden, nicht übernehmen.
      if (!dirty.current && started > lastSave.current) setSettings(d.settings);
      setTrack(d.track ? { ...d.track, fetchedAt: Date.now() } : null);
      setPlays(d.plays);
      setSongNumber(d.songNumber);
      setLoaded(true);
    } catch {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    void load();
    const t = setInterval(() => document.visibilityState === 'visible' && void load(), 5000);
    const tick = setInterval(
      () => setTrack((x) => (x?.playing ? { ...x, progress: estimatedProgress(x), fetchedAt: Date.now() } : x)),
      1000,
    );
    return () => {
      clearInterval(t);
      clearInterval(tick);
    };
  }, [load]);

  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setScale(el.clientWidth / 1920));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const save = async (next: WallSettings) => {
    setSettings(next);
    dirty.current = true;
    lastSave.current = Date.now();
    setNote('');
    try {
      const r = await fetch('/api/wall', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: next }),
      });
      const d = (await r.json()) as { error?: string; settings?: WallSettings };
      if (!r.ok) throw new Error(d.error || 'Speichern hat nicht geklappt.');
      if (d.settings) setSettings(d.settings);
    } catch (e) {
      setNote(e instanceof Error ? e.message : 'Speichern hat nicht geklappt.');
    } finally {
      dirty.current = false;
    }
  };
  const set = <K extends keyof WallSettings>(key: K, value: WallSettings[K]) => void save({ ...settings, [key]: value });

  const isDemo = loaded && !track && !plays.length;
  // Vorschau zeigt immer den laufenden Zustand – sonst steht bei pausiertem
  // Spotify alles still und man sieht die Bewegung beim Einstellen nicht.
  const spotifyPaused = !isDemo && !!track && !track.playing;
  const shownTrack = isDemo ? DEMO_TRACK : track;
  // Noch keine vorherigen Songs? Beispiel-Cover, damit man die Wand sieht.
  const noWallYet = !isDemo && !plays.length;
  const shownPlays = isDemo || noWallYet ? DEMO_TILES : plays;

  return (
    <section className="awp" aria-label="Album Wall">
      <div className="awp-head">
        <div>
          <h2>Album Wall</h2>
          <p>
            Eigene OBS-Quelle mit den Covern deines laufenden Streams – für Pause, „Gleich geht’s los“ und Just
            Chatting. Browserquelle mit 1920 × 1080.
          </p>
        </div>
        <div className="awp-link">
          <button type="button" className="hv-btn is-strong" disabled={!wallUrl} onClick={() => {
              onCopy(wallUrl);
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            }}
          >
            {copied ? '✓ Link kopiert' : 'Link für OBS kopieren'}
          </button>
          {wallUrl && (
            <a className="hv-btn" href={wallUrl} target="_blank" rel="noreferrer">
              Öffnen
            </a>
          )}
        </div>
      </div>
      <div className="awp-body">
        <div className="awp-preview">
          <div ref={stageRef} className="awp-stage">
            <div className="awp-scaler" style={{ transform: `scale(${scale})` }}>
              <AlbumWall settings={settings} track={shownTrack} plays={shownPlays} songNumber={isDemo ? 6 : songNumber} preview />
            </div>
          </div>
          <p className="awp-hint">
            {isDemo
              ? 'Beispiel-Vorschau mit erfundenen Songs. Sobald Musik läuft, zeigt die Wand deinen echten Stream.'
              : noWallYet
                ? 'Die Wand füllt sich ab dem zweiten Song deines Streams – bis dahin zeigt die Vorschau Beispiel-Cover.'
                : spotifyPaused
                  ? 'Die Vorschau zeigt immer die Bewegung. In OBS stehen Reihen, Platte und Visualizer still, solange Spotify pausiert ist.'
                : 'Live-Vorschau deines laufenden Streams. Neue Cover reihen sich bei jedem Songwechsel ein.'}
          </p>
        </div>
        <div className="awp-settings">
          {GROUPS.map((g) => (
            <div key={g.key} className="awp-group">
              <span>{g.label}</span>
              <div className="hv-seg awp-seg" role="radiogroup" aria-label={g.label}>
                {g.opts.map(([v, l]) => (
                  <button
                    key={String(v)}
                    type="button"
                    role="radio"
                    aria-checked={settings[g.key] === v}
                    className={settings[g.key] === v ? 'is-on' : ''}
                    disabled={g.key === 'rows' && settings.layout !== 'stage'}
                    onClick={() => set(g.key, v as never)}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>
          ))}
          <div className="awp-group">
            <span>Akzentfarbe</span>
            <div className="awp-swatches">
              <button
                type="button"
                className={'awp-auto' + (settings.accent ? '' : ' is-on')}
                aria-pressed={!settings.accent}
                onClick={() => set('accent', '')}
              >
                Aus Cover
              </button>
              {WALL_ACCENTS.map((h) => (
                <button
                  key={h}
                  type="button"
                  className={'awp-swatch' + (settings.accent === h ? ' is-on' : '')}
                  style={{ background: h, color: h }}
                  aria-label={'Akzentfarbe ' + h}
                  aria-pressed={settings.accent === h}
                  onClick={() => set('accent', h)}
                />
              ))}
            </div>
          </div>
          {TOGGLES.map((t) => (
            <label key={t.key} className="awp-toggle">
              {t.label}
              <Switch checked={settings[t.key]} onCheckedChange={(on) => set(t.key, on)} />
            </label>
          ))}
          {note && <p className="hv-note" role="status">{note}</p>}
        </div>
      </div>
    </section>
  );
}
