'use client';
import { useEffect } from 'react';
import { Overlay } from '@/lib/overlay';
import { useOverlayFeed } from './use-overlay-feed';

export default function OBS() {
  const { config, track, notice } = useOverlayFeed();

  useEffect(() => {
    document.body.classList.add('obs-page', 'allow-motion');
    document.documentElement.style.background = 'transparent';
    return () => {
      document.body.classList.remove('obs-page', 'allow-motion');
      document.documentElement.style.background = '';
    };
  }, []);
  return (
    <>
      {notice && <div className="obs-notice">{notice}</div>}
      <div className="obs-canvas">
        {config && <Overlay config={config} track={track} />}
      </div>
    </>
  );
}
