'use client';
import { useEffect, useRef } from 'react';
import { Overlay, demo, isAfterglow } from '@/lib/overlay';
import { useOverlayFeed } from '../use-overlay-feed';

// Afterglow Blur Mask V1.1: Rendert die Afterglow-Player-Form als weiße,
// opake Fläche auf einer vollständigen Canvas-Textur (Default 1920×1080).
// Position und Skalierung werden über Query-Parameter gesteuert, damit
// Composite Blur in OBS ohne Scene-Item-Transform der Maskenquelle
// auskommt. Die Geometrie stammt unverändert aus dem echten Overlay-
// Rendering (gleiche Config, gleiche Komponente); nur Füllung und Inhalt
// werden über .afterglow-mask maskiert.
type MaskParams = {
  canvasW: number;
  canvasH: number;
  x: number;
  y: number;
  scaleX: number;
  scaleY: number;
};

const DEFAULT_MASK_PARAMS: MaskParams = {
  canvasW: 1920,
  canvasH: 1080,
  x: 0,
  y: 0,
  scaleX: 1,
  scaleY: 1,
};

function finiteNumber(value: string | null, fallback: number): number {
  if (value === null) return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function readMaskParams(): MaskParams {
  const params = new URLSearchParams(location.search);
  return {
    canvasW: finiteNumber(params.get('canvasW'), DEFAULT_MASK_PARAMS.canvasW),
    canvasH: finiteNumber(params.get('canvasH'), DEFAULT_MASK_PARAMS.canvasH),
    x: finiteNumber(params.get('x'), DEFAULT_MASK_PARAMS.x),
    y: finiteNumber(params.get('y'), DEFAULT_MASK_PARAMS.y),
    scaleX: finiteNumber(params.get('scaleX'), DEFAULT_MASK_PARAMS.scaleX),
    scaleY: finiteNumber(params.get('scaleY'), DEFAULT_MASK_PARAMS.scaleY),
  };
}

export default function AfterglowMask() {
  const { config, track, notice } = useOverlayFeed();
  const canvasRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    document.body.classList.add('obs-page', 'afterglow-mask');
    document.documentElement.style.background = 'transparent';
    const p = readMaskParams();
    const canvas = canvasRef.current;
    const stage = stageRef.current;
    if (canvas) {
      canvas.style.width = p.canvasW + 'px';
      canvas.style.height = p.canvasH + 'px';
    }
    if (stage) {
      stage.style.left = p.x + 'px';
      stage.style.top = p.y + 'px';
      stage.style.transform = `scale(${p.scaleX}, ${p.scaleY})`;
    }
    return () => {
      document.body.classList.remove('obs-page', 'afterglow-mask');
      document.documentElement.style.background = '';
    };
  }, []);

  return (
    <>
      {notice && <div className="obs-notice">{notice}</div>}
      <div ref={canvasRef} className="afterglow-mask-canvas">
        <div ref={stageRef} className="afterglow-mask-stage">
          {config && isAfterglow(config) && (
            <Overlay config={config} track={track ?? demo} />
          )}
        </div>
      </div>
    </>
  );
}