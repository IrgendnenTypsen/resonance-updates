'use client';

import { useEffect, useRef, useState } from 'react';
import { fontFormatHint } from '@/lib/fonts';
import { estimatedProgress, type Config, type Track } from '@/lib/overlay';

type CustomFontMeta = { id: string; family: string; format: string };

type OverlayResponse = {
  error?: string;
  config: Config;
  track: Track | null;
  message?: string;
  retryAfter?: number;
  customFonts?: CustomFontMeta[];
};

export function useOverlayFeed() {
  const [config, setConfig] = useState<Config | null>(null);
  const [track, setTrack] = useState<Track | null>(null);
  const [notice, setNotice] = useState('');
  const [customFonts, setCustomFonts] = useState<CustomFontMeta[]>([]);
  const lastTrackId = useRef('');
  const slot = useRef(0);
  const fontsKey = useRef('');

  useEffect(() => {
    if (customFonts.length === 0) return;
    const style = document.createElement('style');
    style.textContent = customFonts
      .map(
        (font) => `
  @font-face {
    font-family: '${font.family}';
    src: url('/api/fonts/${font.id}/file') format('${fontFormatHint(font.format)}');
    font-display: swap;
  }
`,
      )
      .join('\n');
    document.head.appendChild(style);
    return () => {
      style.remove();
    };
  }, [customFonts]);

  useEffect(() => {
    const key = location.hash.slice(1);
    if (!key) {
      setNotice(
        'Öffne das Overlay mit dem vollständigen Link aus deinem Studio.',
      );
      return;
    }

    let stopped = false;
    let timeout: ReturnType<typeof setTimeout> | undefined;
    let lastGood = 0;

    async function poll() {
      let wait = 5000;
      try {
        const response = await fetch('/api/now', {
          headers: { Authorization: 'Bearer ' + key },
          cache: 'no-store',
        });
        const data = (await response.json()) as OverlayResponse;
        if (stopped) return;
        if (!response.ok) {
          if (response.status === 401) {
            setNotice(
              'Dieser Overlay-Link ist ungültig. Kopiere den aktuellen Link aus dem Studio.',
            );
            setTrack(null);
            return;
          }
          throw new Error(data.error);
        }

        setConfig(data.config);
        const nextFontsKey = JSON.stringify(data.customFonts || []);
        if (nextFontsKey !== fontsKey.current) {
          fontsKey.current = nextFontsKey;
          setCustomFonts(data.customFonts || []);
        }

        if (data.track) {
          const id = data.track.id || data.track.title + '|' + data.track.artist;
          if (id !== lastTrackId.current) {
            lastTrackId.current = id;
            slot.current += 1;
          }
          setTrack({
            ...data.track,
            slot: slot.current,
            fetchedAt: Date.now(),
          });
        } else if (!data.message) {
          setTrack(null);
        }

        lastGood = Date.now();
        setNotice('');
        wait = Math.max(5000, (data.retryAfter || 0) * 1000);
      } catch {
        if (!stopped && Date.now() - lastGood > 15000) setTrack(null);
        wait = 10000;
      }

      if (!stopped) timeout = setTimeout(poll, wait);
    }

    poll();
    const tick = setInterval(
      () =>
        setTrack((current) =>
          current?.playing
            ? {
                ...current,
                progress: estimatedProgress(current),
                fetchedAt: Date.now(),
              }
            : current,
        ),
      1000,
    );

    return () => {
      stopped = true;
      if (timeout) clearTimeout(timeout);
      clearInterval(tick);
    };
  }, []);

  return { config, track, notice };
}
