import { csrf, db, getStudio, json, now, type Row } from '@/lib/server';
import { listSessions, sessionPlays } from '@/lib/track-history';
import { getWallSettings, saveWallSettings } from '@/lib/album-wall-store';

// F15 Album Wall.
// GET  /api/wall  → { settings, track, plays, live, songNumber }
//      OBS-Quelle mit Bearer-Overlay-Key (wie /api/now), Studio über die Anmeldung.
//      plays = bereits gespielte Songs des LAUFENDEN Streams, neueste zuerst.
// POST /api/wall  → Einstellungen speichern (nur Studio: csrf + Anmeldung).
export async function GET(req: Request) {
  try {
    const auth = req.headers.get('authorization');
    const key = auth?.startsWith('Bearer ') ? auth.slice(7) : null;
    const row = key
      ? await db().prepare('SELECT * FROM studios WHERE overlay_key=?').bind(key).first<Row>()
      : await getStudio(req);
    if (!row) return json({ error: 'Overlay nicht gefunden.' }, 401);

    const [playback, settings] = await Promise.all([now(row), getWallSettings(db(), row.owner)]);
    let plays: { id: string; cover: string; title: string; artist: string; status: string }[] = [];
    let live = false;
    let songNumber = 0;
    try {
      const [session] = await listSessions(db(), row.owner, 1);
      if (session?.live) {
        live = true;
        songNumber = session.trackCount;
        const all = await sessionPlays(db(), row.owner, session.id);
        plays = all
          .filter((p) => p.status !== 'playing')
          .reverse()
          .slice(0, 60)
          .map((p) => ({ id: p.id, cover: p.cover, title: p.title, artist: p.artist, status: p.status }));
      }
    } catch {
      // Verlauf noch nicht eingerichtet → Wand ohne vorherige Songs.
    }
    return json({
      settings,
      track: playback.track,
      retryAfter: playback.retryAfter,
      plays,
      live,
      songNumber,
    });
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : 'Verbindung unterbrochen.', track: null }, 503);
  }
}

export async function POST(req: Request) {
  try {
    csrf(req);
    const row = await getStudio(req);
    if (!row) return json({ error: 'Studio nicht gefunden.' }, 401);
    const body = (await req.json()) as { settings?: unknown };
    const settings = await saveWallSettings(db(), row.owner, body.settings);
    return json({ ok: true, settings });
  } catch (e) {
    const msg = e instanceof Error ? e.message : '';
    if (/no such table/i.test(msg))
      return json({ error: 'Bitte Resonance einmal neu starten (Datenbank-Update).' }, 409);
    return json({ error: 'Einstellungen konnten nicht gespeichert werden.' }, 400);
  }
}
