import { csrf, db, freshAccess, getStudio, identity, json, now, type Row } from '@/lib/server';
import { listSessions, sessionPlays } from '@/lib/track-history';
import { favoritesFor, getShelfWallSettings, saveShelfWallSettings } from '@/lib/shelf-wall-store';

// F21 StreamShelf V2/V3.
// GET  /api/shelf             → Live-Regal: laufender Stream + aktueller Song
// GET  /api/shelf?session=ID  → Archiv: Regal eines (vergangenen) Streams
//      OBS-Quelle mit Bearer-Overlay-Key, Studio über die Anmeldung.
// POST /api/shelf             → Einstellungen speichern (nur Studio).
export async function GET(req: Request) {
  try {
    const auth = req.headers.get('authorization');
    const key = auth?.startsWith('Bearer ') ? auth.slice(7) : null;
    const row = key
      ? await db().prepare('SELECT * FROM studios WHERE overlay_key=?').bind(key).first<Row>()
      : await getStudio(req);
    if (!row) return json({ error: 'Overlay nicht gefunden.' }, 401);
    if (!key) identity(req);

    const url = new URL(req.url);
    const sessionId = url.searchParams.get('session');
    if (sessionId && !/^[A-Za-z0-9-]{8,64}$/.test(sessionId)) return json({ error: 'Ungültige Session.' }, 400);

    const settings = await getShelfWallSettings(db(), row.owner);
    let session: { id: string; startedAt: number; endedAt: number | null; trackCount: number; live: boolean } | null = null;
    let plays: Awaited<ReturnType<typeof sessionPlays>> = [];
    try {
      const sessions = await listSessions(db(), row.owner, 50);
      const s = sessionId ? sessions.find((x) => x.id === sessionId) : sessions[0]?.live ? sessions[0] : undefined;
      if (s) {
        session = { id: s.id, startedAt: s.startedAt, endedAt: s.endedAt, trackCount: s.trackCount, live: s.live };
        plays = await sessionPlays(db(), row.owner, s.id);
      }
    } catch {
      // Verlauf noch nicht eingerichtet.
    }
    const live = !sessionId;
    const playback = live ? await now(row) : { track: null };
    let faves = new Set<string>();
    if (settings.faves && plays.length) {
      try {
        faves = await favoritesFor(
          plays.map((p) => p.trackId || ''),
          row.refresh_token ? await freshAccess(row) : null,
        );
      } catch {
        // ohne Lieblingssongs weiter
      }
    }
    return json({
      settings,
      session,
      track: playback.track,
      plays: plays
        .filter((p) => !(live && p.status === 'playing'))
        .map((p) => ({
          id: p.id,
          trackId: p.trackId,
          title: p.title,
          artist: p.artist,
          cover: p.cover,
          startedAt: p.startedAt,
          status: p.status,
          fave: !!p.trackId && faves.has(p.trackId),
        })),
    });
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : 'Verbindung unterbrochen.' }, 503);
  }
}

export async function POST(req: Request) {
  try {
    csrf(req);
    const row = await getStudio(req);
    if (!row) return json({ error: 'Studio nicht gefunden.' }, 401);
    const body = (await req.json()) as { settings?: unknown };
    return json({ ok: true, settings: await saveShelfWallSettings(db(), row.owner, body.settings) });
  } catch (e) {
    const msg = e instanceof Error ? e.message : '';
    if (/no such table/i.test(msg)) return json({ error: 'Bitte Resonance einmal neu starten (Datenbank-Update).' }, 409);
    return json({ error: 'Einstellungen konnten nicht gespeichert werden.' }, 400);
  }
}
