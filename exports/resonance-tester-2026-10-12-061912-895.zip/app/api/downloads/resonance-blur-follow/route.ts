import luaSource from '@/obs/resonance-blur-follow.lua?raw';

export function GET() {
  return new Response(luaSource, {
    headers: {
      'Content-Type': 'text/x-lua; charset=utf-8',
      'Content-Disposition':
        'attachment; filename="resonance-blur-follow.lua"',
      'X-Content-Type-Options': 'nosniff',
    },
  });
}
