import { csrf, db, identity, json, type Row } from '@/lib/server';
import {
  endLiveSession,
  isRecording,
  listSessions,
  sessionPlays,
  setRecording,
} from '@/lib/track-history';

// F03 Track History.
// GET  /api/history            → { sessions, current: { session, plays }, recording }
// GET  /api/history?session=ID → { plays }
//      Studio über die Anmeldung (identity); Overlays (Album Wall /
//      StreamShelf später) lesen mit Bearer-Overlay-Key wie /api/now.
// POST /api/history            → nur Studio (csrf + identity), nie per Overlay-Key:
//      { action: 'end' }                 laufenden Stream beenden
//      { action: 'record', on: boolean } Aufzeichnung an/aus
export async function GET(req: Request) {
  try {
    const auth = req.headers.get('authorization');
    const key = auth?.startsWith('Bearer ') ? auth.slice(7) : null;
    let owner: string;
    if (key) {
      const row = await db()
        .prepare('SELECT owner FROM studios WHERE overlay_key=?')
        .bind(key)
        .first<Pick<Row, 'owner'>>();
      if (!row) return json({ error: 'Overlay nicht gefunden.' }, 401);
      owner = row.owner;
    } else owner = identity(req);

    const url = new URL(req.url);
    const sessionId = url.searchParams.get('session');
    if (sessionId) {
      if (!/^[A-Za-z0-9-]{8,64}$/.test(sessionId))
        return json({ error: 'Ungültige Session.' }, 400);
      return json({ plays: await sessionPlays(db(), owner, sessionId) });
    }
    const limit = Number(url.searchParams.get('limit')) || 30;
    const [sessions, recording] = await Promise.all([
      listSessions(db(), owner, limit),
      isRecording(db(), owner),
    ]);
    const first = sessions[0];
    return json({
      sessions,
      recording,
      current: first ? { session: first, plays: await sessionPlays(db(), owner, first.id) } : null,
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : '';
    if (/no such table/i.test(msg))
      return json({ sessions: [], current: null, recording: true, pending: true });
    return json({ error: 'Verlauf konnte nicht geladen werden.' }, 400);
  }
}

export async function POST(req: Request) {
  try {
    csrf(req);
    const owner = identity(req);
    const body = (await req.json()) as { action?: unknown; on?: unknown };
    if (body.action === 'end') {
      await endLiveSession(db(), owner);
      return json({ ok: true });
    }
    if (body.action === 'record' && typeof body.on === 'boolean') {
      await setRecording(db(), owner, body.on);
      return json({ ok: true, recording: body.on });
    }
    return json({ error: 'Unbekannte Aktion.' }, 400);
  } catch (e) {
    const msg = e instanceof Error ? e.message : '';
    if (/no such table/i.test(msg))
      return json({ error: 'Bitte Resonance einmal neu starten (Datenbank-Update).' }, 409);
    return json({ error: 'Verlauf konnte nicht geändert werden.' }, 400);
  }
}
