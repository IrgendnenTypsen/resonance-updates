'use client';
import { Component, useEffect, useRef, useState, type ReactNode } from 'react';
import { Overlay, defaults, type Config, type Track } from '@/lib/overlay';
import { presets } from '@/lib/presets';
import { STRESS_SCENARIOS, STRESS_WIDTHS } from '@/lib/stress-fixtures';
import './stress.css';

// Overlay Stress Lab (F06, 2026-10-11): alle Player × Grenzfälle in einer
// simulierten OBS-Browserquelle. Automatische Prüfungen je Zelle:
// Absturz, Text läuft ohne Kürzung über, Player breiter als die Quelle,
// ungültige Zeiten (NaN/Infinity/undefined), kaputtes Bild.

type Issue = { code: string; text: string };

class CellBoundary extends Component<
  { children: ReactNode; onCrash: (msg: string) => void },
  { crashed: string }
> {
  state = { crashed: '' };
  static getDerivedStateFromError(e: unknown) {
    return { crashed: e instanceof Error ? e.message : String(e) };
  }
  componentDidCatch(e: unknown) {
    this.props.onCrash(e instanceof Error ? e.message : String(e));
  }
  render() {
    return this.state.crashed ? (
      <div className="sl-crash">Absturz: {this.state.crashed}</div>
    ) : (
      this.props.children
    );
  }
}

function inspect(frame: HTMLElement, frameWidth: number): Issue[] {
  const issues: Issue[] = [];
  const overlay = frame.querySelector<HTMLElement>('.overlay');
  if (!overlay) return [{ code: 'empty', text: 'Nichts gerendert' }];
  // Einmalige Einflug-Animationen (z. B. Sticky Notes) zuerst beenden, sonst
  // misst die Prüfung den Startframe (in versteckten Tabs bleiben sie stehen).
  overlay.getAnimations().forEach((a) => {
    if (a.effect?.getTiming().iterations !== Infinity) a.finish();
  });
  const r = overlay.getBoundingClientRect();
  const fr = frame.getBoundingClientRect();
  const scale = fr.width / frameWidth || 1;
  if (r.width / scale > frameWidth + 1)
    issues.push({ code: 'wide', text: `Breiter als Quelle (${Math.round(r.width / scale)} px)` });
  for (const sel of ['.track-title', '.track-artist', '.now-playing']) {
    overlay.querySelectorAll<HTMLElement>(sel).forEach((el) => {
      const cs = getComputedStyle(el);
      const clipped =
        cs.textOverflow === 'ellipsis' ||
        cs.webkitLineClamp !== 'none' ||
        el.querySelector('.ns-marquee');
      if (el.scrollWidth > el.clientWidth + 1 && !clipped && cs.overflow !== 'visible')
        issues.push({ code: 'overflow', text: `${sel} abgeschnitten ohne „…“` });
      if (cs.overflow === 'visible' && el.getBoundingClientRect().right > r.right + 2)
        issues.push({ code: 'overflow', text: `${sel} ragt aus dem Player` });
    });
  }
  // Zeilen, deren Inhalt nicht hineinpasst (Steuerung, Fortschritt, Fußzeilen).
  for (const sel of [
    '.track-progress',
    '.player-chrome',
    '.lol-foot',
    '.valo-match',
    '.pq-footer',
    '.overlay-main',
  ]) {
    overlay.querySelectorAll<HTMLElement>(sel).forEach((el) => {
      const er = el.getBoundingClientRect();
      // display:contents-Container haben keine eigene Box → nicht prüfbar.
      if (getComputedStyle(el).display === 'contents' || er.width === 0) return;
      const kids = Array.from(el.querySelectorAll<HTMLElement>('*'));
      // Kinder in absichtlich abgeschnittenen Bereichen (Laufschrift,
      // overflow:hidden) zählen nicht – das ist gewolltes Kürzen.
      const clippedInside = (k: HTMLElement) => {
        for (let p = k.parentElement; p && p !== el; p = p.parentElement)
          if (getComputedStyle(p).overflowX !== 'visible') return true;
        return false;
      };
      const over = kids.some((k) => {
        const kr = k.getBoundingClientRect();
        return (
          kr.width > 0 &&
          kr.right > er.right + 2 &&
          getComputedStyle(k).position !== 'absolute' &&
          !clippedInside(k)
        );
      });
      if (over) issues.push({ code: 'row', text: `${sel}: Inhalt passt nicht in die Zeile` });
    });
  }
  const text = overlay.textContent || '';
  if (/NaN|Infinity|undefined/.test(text))
    issues.push({ code: 'time', text: 'Ungültiger Wert im Text (NaN/undefined)' });
  overlay.querySelectorAll('img').forEach((img) => {
    if (img.complete && img.naturalWidth === 0 && !img.closest('.valo-agent'))
      issues.push({ code: 'img', text: 'Bild lädt nicht' });
  });
  // Doppelte Meldungen zusammenfassen.
  return issues.filter((x, i, a) => a.findIndex((y) => y.text === x.text) === i);
}

function Cell({
  config,
  track,
  frameWidth,
  runKey,
  onResult,
}: {
  config: Config;
  track: Track;
  frameWidth: number;
  /** Stabiler Schlüssel (Player + Szenario + Breite): nur er startet die Prüfung neu. */
  runKey: string;
  onResult: (issues: Issue[]) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [crash, setCrash] = useState('');
  useEffect(() => {
    const t = setTimeout(() => {
      if (!ref.current) return;
      onResult(crash ? [{ code: 'crash', text: 'Absturz: ' + crash }] : inspect(ref.current, frameWidth));
    }, 1400);
    return () => clearTimeout(t);
  }, [runKey, crash]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="sl-frame" ref={ref} style={{ width: frameWidth }}>
      <CellBoundary onCrash={setCrash}>
        <Overlay config={{ ...config, width: Math.min(config.width, frameWidth) }} track={track} />
      </CellBoundary>
    </div>
  );
}

export default function StressLab() {
  const [scenario, setScenario] = useState('long');
  const [frameWidth, setFrameWidth] = useState(480);
  const [rapidIdx, setRapidIdx] = useState(0);
  const [results, setResults] = useState<Record<string, Issue[]>>({});
  const [errors, setErrors] = useState(0);
  const sc = STRESS_SCENARIOS.find((s) => s.id === scenario) || STRESS_SCENARIOS[0];

  useEffect(() => {
    if (!sc.rapid) return;
    const t = setInterval(() => setRapidIdx((i) => (i + 1) % sc.rapid!.length), 400);
    return () => clearInterval(t);
  }, [sc]);
  useEffect(() => {
    setResults({});
  }, [scenario, frameWidth]);
  useEffect(() => {
    // console.error während der Tests mitzählen (React-Warnungen, Renderfehler).
    const orig = console.error;
    console.error = (...a: unknown[]) => {
      setErrors((n) => n + 1);
      orig(...a);
    };
    return () => {
      console.error = orig;
    };
  }, []);

  const track = sc.rapid ? sc.rapid[rapidIdx] : sc.track;
  const done = Object.keys(results).length;
  const failing = Object.values(results).filter((r) => r.length).length;

  return (
    <main className="sl-page">
      <header className="sl-top">
        <a className="sl-back" href="/mood-visual-check">
          ← QA Lab
        </a>
        <div className="sl-title">
          <span>QA Lab</span>
          <b>Overlay Stress Lab</b>
        </div>
        <span className={'sl-pill' + (failing ? ' is-warn' : done ? ' is-ok' : '')}>
          {done < presets.length
            ? `Prüfe … ${done}/${presets.length}`
            : failing
              ? `${failing} von ${presets.length} Playern mit Auffälligkeiten`
              : `Alle ${presets.length} Player OK`}
          {errors ? ` · ${errors} Konsolenfehler` : ''}
        </span>
      </header>

      <section className="sl-controls" aria-label="Szenario">
        <div className="sl-chips" role="tablist">
          {STRESS_SCENARIOS.map((s) => (
            <button
              key={s.id}
              type="button"
              role="tab"
              aria-selected={s.id === scenario}
              className={s.id === scenario ? 'is-on' : ''}
              onClick={() => setScenario(s.id)}
              title={s.note}
            >
              {s.label}
            </button>
          ))}
        </div>
        <div className="sl-chips" aria-label="Breite der Browserquelle">
          {STRESS_WIDTHS.map((w) => (
            <button
              key={w}
              type="button"
              className={w === frameWidth ? 'is-on' : ''}
              onClick={() => setFrameWidth(w)}
            >
              Quelle {w} px
            </button>
          ))}
        </div>
        <p className="sl-note">{sc.note}</p>
      </section>

      <section className="sl-grid" aria-label="Alle Player">
        {presets.map((p) => {
          const res = results[p.id];
          return (
            <article key={p.id} className={'sl-cell' + (res?.length ? ' is-warn' : res ? ' is-ok' : '')}>
              <div className="sl-cell-head">
                <b>{p.name}</b>
                <span>{!res ? 'prüft …' : res.length ? `${res.length} Auffälligkeit${res.length > 1 ? 'en' : ''}` : 'OK'}</span>
              </div>
              <div className="sl-stage">
                <Cell
                  config={{ ...defaults, ...p.config, animation: sc.rapid ? p.config.animation : 'none' } as Config}
                  track={track}
                  frameWidth={frameWidth}
                  runKey={p.id + '|' + scenario + '|' + frameWidth}
                  onResult={(issues) => setResults((r) => ({ ...r, [p.id]: issues }))}
                />
              </div>
              {!!res?.length && (
                <ul className="sl-issues">
                  {res.map((i) => (
                    <li key={i.text}>{i.text}</li>
                  ))}
                </ul>
              )}
            </article>
          );
        })}
      </section>
    </main>
  );
}
