'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Switch } from '@/components/ui/switch';
import { ShelfWall, type ShelfItem } from '@/lib/shelf-wall';
import { SHELF_WALL_DEFAULTS, type ShelfWallSettings } from '@/lib/shelf-wall-settings';
import { GALLERY_TRACKS } from '@/lib/gallery-demo';
import { estimatedProgress, type Track } from '@/lib/overlay';

// F21 StreamShelf V2 – Live-Regal: Einstellungen + Vorschau im Tab „Verlauf“.

type ShelfResponse = {
  error?: string;
  settings: ShelfWallSettings;
  session: { startedAt: number; endedAt: number | null; trackCount: number; live: boolean } | null;
  track: Track | null;
  plays: ShelfItem[];
};

// Beispiel, solange der Stream noch leer ist (erfundene Demo-Songs).
const DEMO_START = Date.now() - 95 * 60000;
const DEMO_ITEMS: ShelfItem[] = Array.from({ length: 22 }, (_, i) => {
  const t = GALLERY_TRACKS[i % GALLERY_TRACKS.length];
  return {
    id: 'demo-' + i,
    trackId: null,
    title: t.title,
    artist: t.artist,
    cover: t.cover,
    startedAt: DEMO_START + i * 4 * 60000,
    status: i % 7 === 3 ? 'skipped' : 'completed',
    fave: i % 6 === 2,
  };
});

type Opt = [string | number | boolean, string];
const GROUPS: { key: keyof ShelfWallSettings; label: string; opts: Opt[] }[] = [
  { key: 'material', label: 'Material', opts: [['wood', 'Holz'], ['glass', 'Glas'], ['metal', 'Metall']] },
  { key: 'back', label: 'Rückwand', opts: [['none', 'Keine'], ['dark', 'Dunkel'], ['wood', 'Holz']] },
  { key: 'rows', label: 'Böden', opts: [[2, '2'], [3, '3'], [4, '4']] },
  { key: 'wide', label: 'CD-Rücken', opts: [[false, 'Schmal'], [true, 'Breit']] },
  { key: 'now', label: 'Aktueller Song', opts: [['side', 'Groß daneben'], ['off', 'Nur Regal']] },
];
const TOGGLES: { key: 'spotlight' | 'led' | 'faves' | 'dividers' | 'artist' | 'hideSkipped'; label: string }[] = [
  { key: 'spotlight', label: 'Spotlight (zieht CDs heraus)' },
  { key: 'led', label: 'LED-Leiste unter den Böden' },
  { key: 'faves', label: 'Lieblingssongs mit Cover nach vorne' },
  { key: 'dividers', label: 'Trennkarten pro Stunde' },
  { key: 'artist', label: 'Interpret auf dem Rücken' },
  { key: 'hideSkipped', label: 'Übersprungene weglassen' },
];

export default function ShelfWallPanel({ shelfUrl, onCopy }: { shelfUrl: string; onCopy: (text: string) => void }) {
  const [settings, setSettings] = useState<ShelfWallSettings>(SHELF_WALL_DEFAULTS);
  const [data, setData] = useState<ShelfResponse | null>(null);
  const [track, setTrack] = useState<Track | null>(null);
  const [note, setNote] = useState('');
  const [copied, setCopied] = useState(false);
  const [scale, setScale] = useState(0.4);
  const stageRef = useRef<HTMLDivElement>(null);
  const lastSave = useRef(0);
  const dirty = useRef(false);

  const load = useCallback(async () => {
    const started = Date.now();
    try {
      const r = await fetch('/api/shelf', { cache: 'no-store' });
      const d = (await r.json()) as ShelfResponse;
      if (!r.ok) throw new Error(d.error);
      if (!dirty.current && started > lastSave.current) setSettings(d.settings);
      setData(d);
      setTrack(d.track ? { ...d.track, fetchedAt: Date.now() } : null);
    } catch {
      setData((x) => x ?? { settings: SHELF_WALL_DEFAULTS, session: null, track: null, plays: [] });
    }
  }, []);

  useEffect(() => {
    void load();
    const t = setInterval(() => document.visibilityState === 'visible' && void load(), 6000);
    const tick = setInterval(
      () => setTrack((x) => (x?.playing ? { ...x, progress: estimatedProgress(x), fetchedAt: Date.now() } : x)),
      1000,
    );
    return () => {
      clearInterval(t);
      clearInterval(tick);
    };
  }, [load]);

  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setScale(el.clientWidth / 1920));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const save = async (next: ShelfWallSettings) => {
    setSettings(next);
    dirty.current = true;
    lastSave.current = Date.now();
    setNote('');
    try {
      const r = await fetch('/api/shelf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: next }),
      });
      const d = (await r.json()) as { error?: string; settings?: ShelfWallSettings };
      if (!r.ok) throw new Error(d.error || 'Speichern hat nicht geklappt.');
      if (d.settings) setSettings(d.settings);
    } catch (e) {
      setNote(e instanceof Error ? e.message : 'Speichern hat nicht geklappt.');
    } finally {
      dirty.current = false;
    }
  };
  const set = <K extends keyof ShelfWallSettings>(key: K, value: ShelfWallSettings[K]) => void save({ ...settings, [key]: value });

  const isDemo = !!data && !data.plays.length;
  const shownTrack = track ?? (isDemo ? { ...GALLERY_TRACKS[2], playing: true } : null);

  return (
    <section className="awp" aria-label="StreamShelf-Regal">
      <div className="awp-head">
        <div>
          <h2>StreamShelf-Regal</h2>
          <p>
            Eigene OBS-Quelle: Jeder Song deines Streams wird als CD eingeräumt, das Regal wächst Boden für Boden.
            Browserquelle mit 1920 × 1080. Nach dem Stream findest du es oben unter „Regal“ als Archiv.
          </p>
        </div>
        <div className="awp-link">
          <button
            type="button"
            className="hv-btn is-strong"
            disabled={!shelfUrl}
            onClick={() => {
              onCopy(shelfUrl);
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            }}
          >
            {copied ? '✓ Link kopiert' : 'Link für OBS kopieren'}
          </button>
          {shelfUrl && (
            <a className="hv-btn" href={shelfUrl} target="_blank" rel="noreferrer">
              Öffnen
            </a>
          )}
        </div>
      </div>
      <div className="awp-body">
        <div className="awp-preview">
          <div ref={stageRef} className="awp-stage">
            <div className="awp-scaler is-interactive" style={{ transform: `scale(${scale})` }}>
              <ShelfWall
                settings={settings}
                plays={isDemo ? DEMO_ITEMS : data?.plays ?? []}
                track={shownTrack}
                songNumber={isDemo ? 23 : data?.session?.trackCount ?? 0}
                mode="preview"
                title="Heute im Stream"
                startedAt={isDemo ? DEMO_START : data?.session?.startedAt ?? null}
                endedAt={null}
              />
            </div>
          </div>
          <p className="awp-hint">
            {isDemo
              ? 'Beispiel-Vorschau mit erfundenen Songs. Im Stream startet das Regal leer und füllt sich mit jedem Song.'
              : 'Live-Vorschau deines laufenden Streams. Fahr mit der Maus über eine CD – im Stream übernimmt das Spotlight.'}
          </p>
        </div>
        <div className="awp-settings">
          {GROUPS.map((g) => (
            <div key={g.key} className="awp-group">
              <span>{g.label}</span>
              <div className="hv-seg awp-seg" role="radiogroup" aria-label={g.label}>
                {g.opts.map(([v, l]) => (
                  <button
                    key={String(v)}
                    type="button"
                    role="radio"
                    aria-checked={settings[g.key] === v}
                    className={settings[g.key] === v ? 'is-on' : ''}
                    onClick={() => set(g.key, v as never)}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>
          ))}
          {TOGGLES.map((t) => (
            <label key={t.key} className="awp-toggle">
              {t.label}
              <Switch checked={settings[t.key]} onCheckedChange={(on) => set(t.key, on)} />
            </label>
          ))}
          {note && <p className="hv-note" role="status">{note}</p>}
        </div>
      </div>
    </section>
  );
}
