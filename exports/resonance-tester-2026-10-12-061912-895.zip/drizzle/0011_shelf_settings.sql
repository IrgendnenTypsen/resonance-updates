-- F21 StreamShelf V2: Einstellungen des Live-Regals (eigene OBS-Quelle) je
-- Besitzer. Rein additiv; getrennt von der Player-Config.
CREATE TABLE shelf_settings (
  owner TEXT PRIMARY KEY,
  config TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
