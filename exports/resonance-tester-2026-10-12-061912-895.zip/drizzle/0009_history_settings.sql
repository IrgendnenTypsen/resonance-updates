-- F03 Track History: Aufzeichnung an/aus je Besitzer. Rein additiv.
CREATE TABLE history_settings (
  owner TEXT PRIMARY KEY,
  recording INTEGER NOT NULL DEFAULT 1,
  updated_at INTEGER NOT NULL
);
