-- F03 Track History: gemeinsamer Verlauf für Song-Verlauf, Album Wall und
-- StreamShelf. Rein additiv – bestehende Tabellen bleiben unverändert.
CREATE TABLE stream_sessions (
  id TEXT PRIMARY KEY,
  owner TEXT NOT NULL,
  started_at INTEGER NOT NULL,
  last_seen_at INTEGER NOT NULL,
  ended_at INTEGER,
  ended_reason TEXT,
  title TEXT,
  track_count INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX stream_sessions_owner_started ON stream_sessions(owner, started_at DESC);
CREATE INDEX stream_sessions_owner_open ON stream_sessions(owner, ended_at, last_seen_at DESC);

CREATE TABLE track_plays (
  id TEXT PRIMARY KEY,
  owner TEXT NOT NULL,
  session_id TEXT NOT NULL,
  seq INTEGER NOT NULL,
  track_id TEXT,
  title TEXT NOT NULL,
  artist TEXT NOT NULL,
  album TEXT NOT NULL,
  cover_url TEXT NOT NULL DEFAULT '',
  duration_ms INTEGER NOT NULL,
  started_at INTEGER NOT NULL,
  last_seen_at INTEGER NOT NULL,
  first_progress_ms INTEGER NOT NULL DEFAULT 0,
  last_progress_ms INTEGER NOT NULL DEFAULT 0,
  max_progress_ms INTEGER NOT NULL DEFAULT 0,
  listened_ms INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'playing',
  ended_at INTEGER
);
CREATE INDEX track_plays_session_seq ON track_plays(session_id, seq);
CREATE INDEX track_plays_owner_started ON track_plays(owner, started_at DESC);
