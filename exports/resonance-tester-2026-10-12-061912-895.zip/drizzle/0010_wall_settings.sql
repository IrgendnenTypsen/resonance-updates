-- F15 Album Wall: Einstellungen der eigenen OBS-Quelle je Besitzer.
-- Rein additiv; getrennt von der Player-Config, damit Looks sie nicht ändern.
CREATE TABLE wall_settings (
  owner TEXT PRIMARY KEY,
  config TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
