@echo off
title RESONANCE Updater

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update-Resonance.ps1"
set "exitCode=%ERRORLEVEL%"

echo.
pause

exit /b %exitCode%
