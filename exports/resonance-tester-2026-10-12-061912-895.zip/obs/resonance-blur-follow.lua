-- Resonance Blur Follow V1
-- Synchronisiert die Afterglow-Mask-URL (canvasW/canvasH/x/y/scaleX/scaleY)
-- mit dem Scene-Item-Transform der normalen Resonance Browser Source.
--
-- Die Masken-Browser-Source bleibt full-canvas; Composite Blur liest die
-- Textur der Quelle selbst. Position/Skalierung werden daher in die
-- Mask-URL kodiert, nicht in den Scene-Item-Transform der Maskenquelle.
--
-- V1 unterstützt nur Position X/Y und Scale X/Y. Rotation, Crop, Bounds,
-- Gruppen und verschachtelte Szenen werden erkannt und NICHT angenähert.

obs = obslua

local DEBOUNCE_MS = 200
local NORMAL_URL_MARKER = "/overlay#"
local MASK_URL_MARKER = "/overlay/afterglow-mask"

local normal_source_name = nil
local mask_source_name = nil
local debounce_active = false
local last_sync = nil
local connected_handler = nil
local connected_scene_source = nil

-- ---------------------------------------------------------------------------
-- URL-Helfer
-- ---------------------------------------------------------------------------

-- Ersetzt/ergänzt genau einen Query-Parameter in einer URL und erhält
-- Route, übrige Parameter und Hash/Key unverändert. Der Key wird nie
-- geloggt.
function set_url_param(url, key, value)
	local base = url
	local hash = ""
	local hash_pos = url:find("#", 1, true)
	if hash_pos ~= nil then
		base = url:sub(1, hash_pos - 1)
		hash = url:sub(hash_pos + 1)
	end

	local path = base
	local query = ""
	local query_pos = base:find("?", 1, true)
	if query_pos ~= nil then
		path = base:sub(1, query_pos - 1)
		query = base:sub(query_pos + 1)
	end

	local parts = {}
	if query ~= "" then
		for k, v in query:gmatch("([^&=]+)=([^&=]*)") do
			table.insert(parts, { k, v })
		end
	end

	local replaced = false
	for _, part in ipairs(parts) do
		if part[1] == key then
			part[2] = value
			replaced = true
		end
	end
	if not replaced then
		table.insert(parts, { key, value })
	end

	local new_query_parts = {}
	for _, part in ipairs(parts) do
		table.insert(new_query_parts, part[1] .. "=" .. part[2])
	end

	local new_url = path
	if #new_query_parts > 0 then
		new_url = new_url .. "?" .. table.concat(new_query_parts, "&")
	end
	if hash ~= "" then
		new_url = new_url .. "#" .. hash
	end
	return new_url
end

-- Zahl als String mit maximal 6 Nachkommastellen, ohne überflüssige Nullen.
function fmt_num(n)
	local s = string.format("%.6f", n)
	s = s:gsub("0+$", "")
	s = s:gsub("%.$", "")
	return s
end

-- ---------------------------------------------------------------------------
-- Quellen-Detektion (URL-basiert, kein Raten über Namen)
-- ---------------------------------------------------------------------------

function find_sources()
	local normal_candidates = {}
	local mask_candidates = {}

	local sources = obs.obs_enum_sources()
	if sources ~= nil then
		for _, source in ipairs(sources) do
			local id = obs.obs_source_get_unversioned_id(source)
			if id == "browser_source" then
				local settings = obs.obs_source_get_settings(source)
				local url = obs.obs_data_get_string(settings, "url")
				if url ~= nil and url ~= "" then
					if string.find(url, MASK_URL_MARKER, 1, true) then
						table.insert(mask_candidates, obs.obs_source_get_name(source))
					elseif string.find(url, NORMAL_URL_MARKER, 1, true) then
						table.insert(normal_candidates, obs.obs_source_get_name(source))
					end
				end
				obs.obs_data_release(settings)
			end
		end
		-- source_list_release gibt sowohl das Array als auch alle Sources frei.
		obs.source_list_release(sources)
	end

	if #normal_candidates == 1 and #mask_candidates == 1 then
		normal_source_name = normal_candidates[1]
		mask_source_name = mask_candidates[1]
		return true
	end

	normal_source_name = nil
	mask_source_name = nil

	if #normal_candidates == 0 then
		print("[resonance-blur-follow] Normale Resonance Browser Source nicht gefunden (URL muss /overlay# enthalten). Sync gestoppt.")
	elseif #normal_candidates > 1 then
		print("[resonance-blur-follow] Mehrere normale Resonance Browser Sources gefunden. Sync gestoppt.")
	end
	if #mask_candidates == 0 then
		print("[resonance-blur-follow] Afterglow-Mask Browser Source nicht gefunden (URL muss /overlay/afterglow-mask enthalten). Sync gestoppt.")
	elseif #mask_candidates > 1 then
		print("[resonance-blur-follow] Mehrere Afterglow-Mask Browser Sources gefunden. Sync gestoppt.")
	end
	return false
end

-- ---------------------------------------------------------------------------
-- Transform lesen
-- ---------------------------------------------------------------------------

-- Liest den Transform der normalen Source als direktes Scene-Item der
-- aktuellen Szene. Liefert nil, wenn nicht gefunden (auch bei Gruppen /
-- verschachtelten Szenen, die V1 nicht unterstützt).
function read_normal_transform(scene, source_name)
	local items = obs.obs_scene_enum_items(scene)
	if items == nil then
		return nil
	end

	local result = nil
	for _, item in ipairs(items) do
		-- obs_sceneitem_get_source liefert eine BORROWED-Referenz (kein
		-- Refcount-Increment) und darf NICHT an obs_source_release gehen.
		local source = obs.obs_sceneitem_get_source(item)
		if source ~= nil then
			local name = obs.obs_source_get_name(source)
			if name == source_name then
				local pos = obs.vec2()
				obs.obs_sceneitem_get_pos(item, pos)
				local scale = obs.vec2()
				obs.obs_sceneitem_get_scale(item, scale)
				local rot = obs.obs_sceneitem_get_rot(item)
				local crop = obs.obs_sceneitem_crop()
				obs.obs_sceneitem_get_crop(item, crop)
				local bounds_type = obs.obs_sceneitem_get_bounds_type(item)
				result = {
					x = pos.x,
					y = pos.y,
					scaleX = scale.x,
					scaleY = scale.y,
					rotation = rot,
					crop_top = crop.top,
					crop_bottom = crop.bottom,
					crop_left = crop.left,
					crop_right = crop.right,
					bounds_type = bounds_type,
				}
				break
			end
		end
	end
	obs.sceneitem_list_release(items)
	return result
end

-- ---------------------------------------------------------------------------
-- Sync
-- ---------------------------------------------------------------------------

function sync_mask()
	if normal_source_name == nil or mask_source_name == nil then
		if not find_sources() then
			return
		end
	end

	local scene_source = obs.obs_frontend_get_current_scene()
	if scene_source == nil then
		print("[resonance-blur-follow] Keine aktuelle Szene. Sync übersprungen.")
		return
	end
	-- scene_source ist OWNED (obs_source_t) und wird genau einmal freigegeben.
	-- scene ist BORROWED (obs_scene_t) und darf NICHT freigegeben werden.
	local scene = obs.obs_scene_from_source(scene_source)

	local t = read_normal_transform(scene, normal_source_name)
	obs.obs_source_release(scene_source)
	if t == nil then
		print("[resonance-blur-follow] Normale Source '" .. normal_source_name .. "' nicht als direktes Scene-Item der aktuellen Szene gefunden (Gruppen/verschachtelte Szenen werden in V1 nicht unterstützt). Sync übersprungen.")
		return
	end

	-- Nicht unterstützte Transforms: warnen und nicht näherungsweise syncen.
	if t.rotation ~= 0 then
		print("[resonance-blur-follow] Warnung: Rotation wird in V1 nicht unterstützt. Sync übersprungen.")
		return
	end
	if t.crop_top ~= 0 or t.crop_bottom ~= 0 or t.crop_left ~= 0 or t.crop_right ~= 0 then
		print("[resonance-blur-follow] Warnung: Crop wird in V1 nicht unterstützt. Sync übersprungen.")
		return
	end
	if t.bounds_type ~= obs.OBS_BOUNDS_NONE then
		print("[resonance-blur-follow] Warnung: Bounds werden in V1 nicht unterstützt. Sync übersprungen.")
		return
	end

	local video_info = obs.obs_video_info()
	if not obs.obs_get_video_info(video_info) then
		print("[resonance-blur-follow] Warnung: Canvas-Auflösung nicht verfügbar. Sync übersprungen.")
		return
	end
	local canvasW = video_info.base_width
	local canvasH = video_info.base_height

	-- Redundante Updates vermeiden (kein Reload-Spam).
	if last_sync ~= nil and
		last_sync.canvasW == canvasW and last_sync.canvasH == canvasH and
		last_sync.x == t.x and last_sync.y == t.y and
		last_sync.scaleX == t.scaleX and last_sync.scaleY == t.scaleY then
		return
	end

	local mask_source = obs.obs_get_source_by_name(mask_source_name)
	if mask_source == nil then
		print("[resonance-blur-follow] Mask-Source '" .. mask_source_name .. "' nicht gefunden. Sync übersprungen.")
		return
	end

	local settings = obs.obs_source_get_settings(mask_source)
	local url = obs.obs_data_get_string(settings, "url")
	if url == nil or url == "" then
		print("[resonance-blur-follow] Mask-Source hat keine URL. Sync übersprungen.")
	else
		local new_url = url
		new_url = set_url_param(new_url, "canvasW", fmt_num(canvasW))
		new_url = set_url_param(new_url, "canvasH", fmt_num(canvasH))
		new_url = set_url_param(new_url, "x", fmt_num(t.x))
		new_url = set_url_param(new_url, "y", fmt_num(t.y))
		new_url = set_url_param(new_url, "scaleX", fmt_num(t.scaleX))
		new_url = set_url_param(new_url, "scaleY", fmt_num(t.scaleY))
		if new_url ~= url then
			local update = obs.obs_data_create()
			obs.obs_data_set_string(update, "url", new_url)
			obs.obs_source_update(mask_source, update)
			obs.obs_data_release(update)
		end
		last_sync = {
			canvasW = canvasW,
			canvasH = canvasH,
			x = t.x,
			y = t.y,
			scaleX = t.scaleX,
			scaleY = t.scaleY,
		}
	end
	obs.obs_data_release(settings)
	obs.obs_source_release(mask_source)
end

-- ---------------------------------------------------------------------------
-- Debounce
-- ---------------------------------------------------------------------------

function schedule_sync()
	if debounce_active then
		obs.timer_remove(do_sync)
	end
	debounce_active = true
	obs.timer_add(do_sync, DEBOUNCE_MS)
end

function do_sync()
	debounce_active = false
	obs.remove_current_callback()
	sync_mask()
end

-- ---------------------------------------------------------------------------
-- Scene-Signal-Hookup (item_transform)
-- ---------------------------------------------------------------------------

-- Verbindet das item_transform-Signal der aktuell aktiven Szene. Scene-
-- Signale (inkl. item_transform) liegen auf dem Signal-Handler der
-- Scene-SOURCE, nicht auf einem separaten Scene-Handler.
function connect_current_scene()
	local scene_source = obs.obs_frontend_get_current_scene()
	if scene_source == nil then
		return
	end
	local handler = obs.obs_source_get_signal_handler(scene_source)
	obs.signal_handler_connect(handler, "item_transform", on_item_transform)
	connected_handler = handler
	connected_scene_source = scene_source
end

-- Trennt das item_transform-Signal der zuvor aktiven Szene und gibt die
-- gehaltene Szenen-Referenz frei. Keine verwaisten Signal-Verbindungen.
function disconnect_current_scene()
	if connected_handler ~= nil then
		obs.signal_handler_disconnect(connected_handler, "item_transform", on_item_transform)
		connected_handler = nil
	end
	if connected_scene_source ~= nil then
		obs.obs_source_release(connected_scene_source)
		connected_scene_source = nil
	end
end

-- ---------------------------------------------------------------------------
-- Callbacks
-- ---------------------------------------------------------------------------

-- item_transform: feuert bei Transform-Änderungen eines Scene-Items der
-- aktuellen Szene. Nur das gepaarte normale Resonance-Overlay triggert
-- den Debounce; alle anderen Items werden ignoriert.
function on_item_transform(cd)
	local item = obs.calldata_sceneitem(cd, "item")
	if item == nil then
		return
	end
	-- obs_sceneitem_get_source liefert eine BORROWED-Referenz (kein
	-- Refcount-Increment) und darf NICHT an obs_source_release gehen.
	local source = obs.obs_sceneitem_get_source(item)
	if source ~= nil then
		local name = obs.obs_source_get_name(source)
		if name == normal_source_name then
			schedule_sync()
		end
	end
end

function on_event(event)
	if event == obs.OBS_FRONTEND_EVENT_SCENE_CHANGED then
		disconnect_current_scene()
		find_sources()
		connect_current_scene()
		schedule_sync()
	end
end

-- ---------------------------------------------------------------------------
-- Script-Lifecycle
-- ---------------------------------------------------------------------------

function script_description()
	return "Resonance Blur Follow V1: Synchronisiert die Afterglow-Mask-URL (canvasW/canvasH/x/y/scaleX/scaleY) mit dem Transform der normalen Resonance Browser Source. Kein OBS-WebSocket, keine Szenen-/Source-Änderungen."
end

function script_load(settings)
	obs.obs_frontend_add_event_callback(on_event)
	connect_current_scene()
	if find_sources() then
		print("[resonance-blur-follow] Geladen: normale Source '" .. normal_source_name .. "', Mask-Source '" .. mask_source_name .. "'.")
		sync_mask()
	end
end

function script_unload()
	disconnect_current_scene()
end