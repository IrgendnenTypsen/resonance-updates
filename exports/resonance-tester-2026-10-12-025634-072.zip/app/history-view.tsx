'use client';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Switch } from '@/components/ui/switch';
import type { HistoryPlayView, HistorySessionView } from '@/lib/track-history';

// F03 Track History – Studio-Tab „Verlauf“ (Mockup abgesegnet 2026-10-12).

type Overview = {
  sessions: HistorySessionView[];
  current: { session: HistorySessionView; plays: HistoryPlayView[] } | null;
  recording: boolean;
  pending?: boolean;
  error?: string;
};

const WEEKDAYS = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
const MONTHS = ['Jan.', 'Feb.', 'März', 'Apr.', 'Mai', 'Juni', 'Juli', 'Aug.', 'Sep.', 'Okt.', 'Nov.', 'Dez.'];
const MONTHS_LONG = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

const pad = (n: number) => String(n).padStart(2, '0');
const clock = (t: number) => {
  const d = new Date(t);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
};
/** 3:07 bzw. 1:02:07 */
function stamp(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h ? `${h}:${pad(m)}:${pad(s % 60)}` : `${m}:${pad(s % 60)}`;
}
/** 34 min bzw. 1 h 22 min */
function span(ms: number) {
  const min = Math.max(0, Math.round(ms / 60000));
  if (min < 60) return `${min} min`;
  return `${Math.floor(min / 60)} h ${pad(min % 60)} min`;
}
function dayLabel(t: number) {
  const d = new Date(t);
  const today = new Date();
  const start = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((start(today) - start(d)) / 86400000);
  if (diff === 0) return 'Heute';
  if (diff === 1) return 'Gestern';
  if (diff < 7) return WEEKDAYS[d.getDay()];
  return `${d.getDate()}. ${MONTHS[d.getMonth()]}`;
}
const sessionEnd = (s: HistorySessionView) => (s.live ? Date.now() : (s.endedAt ?? s.lastSeenAt));
const songs = (n: number) => `${n} ${n === 1 ? 'Song' : 'Songs'}`;

const STATUS: Record<HistoryPlayView['status'], string> = {
  playing: 'läuft',
  completed: 'durchgehört',
  partial: 'teilweise',
  skipped: 'übersprungen',
};

function trackList(session: HistorySessionView, plays: HistoryPlayView[]) {
  return plays
    .filter((p) => p.status !== 'skipped')
    .map((p) => `${stamp(p.startedAt - session.startedAt)} ${p.title}${p.artist ? ' – ' + p.artist : ''}`)
    .join('\n');
}

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  }
}

function Cover({ src, className }: { src: string; className: string }) {
  const [broken, setBroken] = useState(false);
  return src && !broken ? (
    <img className={className} src={src} alt="" loading="lazy" onError={() => setBroken(true)} />
  ) : (
    <span className={className + ' hv-cover-empty'} aria-hidden="true" />
  );
}

export default function HistoryView({ connected }: { connected: boolean }) {
  const [data, setData] = useState<Overview | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [plays, setPlays] = useState<HistoryPlayView[] | null>(null);
  const [mode, setMode] = useState<'list' | 'wall'>('list');
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState('');
  const [copied, setCopied] = useState(false);
  const selectedRef = useRef<string | null>(null);
  selectedRef.current = selected;

  const load = useCallback(async () => {
    try {
      const r = await fetch('/api/history', { cache: 'no-store' });
      const d = (await r.json()) as Overview;
      if (!r.ok) throw new Error(d.error || 'Verlauf konnte nicht geladen werden.');
      setData(d);
      const sel = selectedRef.current;
      if (!sel || sel === d.current?.session.id) setPlays(d.current?.plays ?? []);
      else if (!d.sessions.some((s) => s.id === sel)) setSelected(null);
    } catch (e) {
      setNote(e instanceof Error ? e.message : 'Verlauf konnte nicht geladen werden.');
    }
  }, []);

  useEffect(() => {
    void load();
    const t = setInterval(() => {
      if (document.visibilityState === 'visible') void load();
    }, 10000);
    return () => clearInterval(t);
  }, [load]);

  const pick = async (id: string) => {
    setSelected(id);
    setCopied(false);
    if (id === data?.current?.session.id) {
      setPlays(data.current.plays);
      return;
    }
    setPlays(null);
    try {
      const r = await fetch('/api/history?session=' + encodeURIComponent(id), { cache: 'no-store' });
      const d = (await r.json()) as { plays?: HistoryPlayView[]; error?: string };
      if (selectedRef.current === id) setPlays(d.plays ?? []);
    } catch {
      setNote('Songs dieses Streams konnten nicht geladen werden.');
    }
  };

  const post = async (body: object) => {
    setBusy(true);
    setNote('');
    try {
      const r = await fetch('/api/history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const d = (await r.json()) as { error?: string };
      if (!r.ok) throw new Error(d.error || 'Das hat nicht geklappt.');
      await load();
    } catch (e) {
      setNote(e instanceof Error ? e.message : 'Das hat nicht geklappt.');
    } finally {
      setBusy(false);
    }
  };

  const sessions = data?.sessions ?? [];
  const session = sessions.find((s) => s.id === (selected ?? data?.current?.session.id)) ?? null;
  const list = plays ?? [];
  const stats = useMemo(() => {
    const c = { completed: 0, partial: 0, skipped: 0, listened: 0 };
    for (const p of list) {
      if (p.status !== 'playing') c[p.status] += 1;
      c.listened += p.listenedMs;
    }
    return c;
  }, [list]);

  const copy = async () => {
    if (!session) return;
    const ok = await copyText(trackList(session, list));
    setCopied(ok);
    if (!ok) setNote('Kopieren hat nicht geklappt.');
  };

  return (
    <div className="v2-page hv-page">
      <div className="v2-page-head">
        <div>
          <h1>
            Verlauf<span>.</span>
          </h1>
          <p>Alle Songs deiner Streams – als Liste oder Cover-Wand, mit Tracklist zum Kopieren.</p>
        </div>
      </div>

      <div className="hv-layout">
        <aside className="hv-sessions" aria-label="Streams">
          <div className="hv-sessions-head">
            <b>Streams</b>
            <label className="hv-record">
              Aufzeichnen
              <Switch
                checked={data?.recording ?? true}
                disabled={busy || !data || data.pending}
                onCheckedChange={(on) => void post({ action: 'record', on })}
                aria-label="Song-Verlauf aufzeichnen"
              />
            </label>
          </div>
          {sessions.map((s) => {
            const covers = s.covers;
            return (
              <button
                key={s.id}
                type="button"
                className={'hv-session' + (s.id === session?.id ? ' is-on' : '')}
                aria-current={s.id === session?.id ? 'true' : undefined}
                onClick={() => void pick(s.id)}
              >
                <span className="hv-mosaic" aria-hidden="true">
                  {[0, 1, 2, 3].map((i) =>
                    covers[i] ? <img key={i} src={covers[i]} alt="" loading="lazy" /> : <i key={i} />,
                  )}
                </span>
                <span className="hv-session-text">
                  <b>
                    {dayLabel(s.startedAt)}
                    {s.live && <em className="hv-live">LIVE</em>}
                  </b>
                  <span>
                    {s.live ? `seit ${clock(s.startedAt)}` : `${new Date(s.startedAt).getDate()}. ${MONTHS[new Date(s.startedAt).getMonth()]}`}
                    {' · '}
                    {songs(s.trackCount)} · {span(sessionEnd(s) - s.startedAt)}
                  </span>
                </span>
              </button>
            );
          })}
          {data && !sessions.length && (
            <p className="hv-empty-side">Noch keine Streams aufgezeichnet.</p>
          )}
          <p className="hv-privacy">
            Nur lokal auf deinem PC gespeichert. Resonance zeichnet auf, was es sieht – solange ein
            Overlay oder das Studio offen ist. Kein vollständiger Spotify-Verlauf.
          </p>
        </aside>

        <section className="hv-main" aria-label="Songs des Streams">
          {!data ? (
            <p className="hv-empty">Lade Verlauf …</p>
          ) : data.pending ? (
            <p className="hv-empty">
              Der Verlauf braucht ein kleines Datenbank-Update. Starte Resonance einmal neu über
              Start-Resonance.
            </p>
          ) : !session ? (
            <p className="hv-empty">
              {!connected
                ? 'Verbinde Spotify im Setup – danach erscheinen hier die Songs deiner Streams.'
                : data.recording
                  ? 'Noch nichts aufgezeichnet. Spiel Musik in Spotify ab, während das Overlay oder das Studio offen ist.'
                  : 'Die Aufzeichnung ist aus. Schalte „Aufzeichnen“ ein, damit Resonance deine Songs mitschreibt.'}
            </p>
          ) : (
            <>
              <div className="hv-head">
                <div className="hv-head-text">
                  <span className="hv-kicker">{session.live ? 'Läuft jetzt' : 'Beendet'}</span>
                  <h2>
                    Stream vom {new Date(session.startedAt).getDate()}.{' '}
                    {MONTHS_LONG[new Date(session.startedAt).getMonth()]}
                  </h2>
                  <span className="hv-meta">
                    {clock(session.startedAt)} – {session.live ? 'jetzt' : clock(sessionEnd(session))} ·{' '}
                    {songs(session.trackCount)}
                  </span>
                </div>
                <div className="hv-actions">
                  <div className="hv-seg" role="tablist" aria-label="Ansicht">
                    <button type="button" role="tab" aria-selected={mode === 'list'} className={mode === 'list' ? 'is-on' : ''} onClick={() => setMode('list')}>
                      Liste
                    </button>
                    <button type="button" role="tab" aria-selected={mode === 'wall'} className={mode === 'wall' ? 'is-on' : ''} onClick={() => setMode('wall')}>
                      Cover
                    </button>
                  </div>
                  <button type="button" className="hv-btn" onClick={() => void copy()} disabled={!list.length}>
                    {copied ? '✓ Tracklist kopiert' : 'Tracklist kopieren'}
                  </button>
                  {session.live && (
                    <button type="button" className="hv-btn is-strong" disabled={busy} onClick={() => void post({ action: 'end' })}>
                      Stream beenden
                    </button>
                  )}
                </div>
              </div>

              <div className="hv-stats">
                <span><b>{stats.completed}</b> durchgehört</span>
                <span><b>{stats.partial}</b> teilweise</span>
                <span><b>{stats.skipped}</b> übersprungen</span>
                <span><b>{span(stats.listened)}</b> Musik gehört</span>
              </div>

              {plays === null ? (
                <p className="hv-empty">Lade Songs …</p>
              ) : mode === 'list' ? (
                <div className="hv-table" role="table" aria-label="Songs">
                  <div className="hv-row hv-row-head" role="row">
                    <span role="columnheader">#</span>
                    <span role="columnheader" aria-label="Cover" />
                    <span role="columnheader">Song</span>
                    <span role="columnheader">Im Stream</span>
                    <span role="columnheader">Gehört</span>
                    <span role="columnheader">Status</span>
                  </div>
                  {list.map((p, i) => {
                    const d = p.durationMs || 1;
                    const from = Math.min(100, (p.observedFromMs / d) * 100);
                    const w = Math.min(100 - from, (p.listenedMs / d) * 100);
                    const pct = Math.round((p.listenedMs / d) * 100);
                    const listen =
                      p.status === 'playing'
                        ? 'läuft gerade'
                        : pct >= 95
                          ? 'komplett'
                          : `${pct} % gehört` + (p.observedFromMs > 15000 ? ` · ab ${stamp(p.observedFromMs)}` : '');
                    return (
                      <div key={p.id} className={'hv-row is-' + p.status} role="row">
                        <span className="hv-n" role="cell">{i + 1}</span>
                        <span role="cell"><Cover src={p.cover} className="hv-cover" /></span>
                        <span className="hv-song" role="cell">
                          <b title={p.title}>{p.title}</b>
                          <span title={p.artist}>{p.artist}</span>
                        </span>
                        <span className="hv-at" role="cell" title={clock(p.startedAt)}>
                          +{stamp(p.startedAt - session.startedAt)}
                        </span>
                        <span className="hv-listen" role="cell">
                          <span className="hv-bar"><i style={{ left: from + '%', width: Math.max(0, w) + '%' }} /></span>
                          <span>{listen}</span>
                        </span>
                        <span role="cell"><span className={'hv-pill is-' + p.status}>{STATUS[p.status]}</span></span>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="hv-wall">
                  {list.map((p) => (
                    <div key={p.id} className={'hv-tile is-' + p.status} title={`${p.title} – ${p.artist}`}>
                      <Cover src={p.cover} className="hv-tile-cover" />
                      <b>{p.title}</b>
                      <span>{p.artist}</span>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
          {note && <p className="hv-note" role="status">{note}</p>}
        </section>
      </div>
    </div>
  );
}
