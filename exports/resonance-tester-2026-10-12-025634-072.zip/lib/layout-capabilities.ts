import type { Config } from './overlay';

export type LayoutId =
  | 'glass'
  | 'winamp'
  | 'memory'
  | 'aqua'
  | 'pixel'
  | 'sticker'
  | 'lol'
  | 'valo'
  | 'minimal'
  | 'vinyl'
  | 'spotlight'
  | 'cd'
  | 'floating';

export type EditorTarget =
  | 'device'
  | 'cover'
  | 'display'
  | 'led'
  | 'controls'
  | 'progress'
  | 'note'
  | 'title'
  | 'artist'
  | 'meta'
  | 'visualizer'
  | 'rank';

export type EditorSelectionTarget = Exclude<EditorTarget, 'meta'> | 'display-meta';
export type TypographyRole = 'title' | 'artist' | 'meta';

export type ControlGroup = {
  readonly fields: readonly (keyof Config)[];
};

export type LayoutCapabilities = {
  readonly selectors: Partial<Record<EditorTarget, string>>;
  readonly surface: ControlGroup;
  readonly elements: ControlGroup;
  readonly motion: ControlGroup;
  readonly typography: Partial<Record<TypographyRole, ControlGroup>>;
  readonly cover?: ControlGroup;
  readonly progress?: ControlGroup;
  readonly controls?: ControlGroup;
  readonly display?: ControlGroup;
  readonly led?: ControlGroup;
  readonly note?: ControlGroup;
  readonly glass?: ControlGroup;
  readonly visualizer?: ControlGroup;
  readonly game?: ControlGroup;
  readonly ranked?: ControlGroup;
};

const group = (...fields: readonly (keyof Config)[]): ControlGroup => ({ fields });

const GENERIC_SURFACE = group(
  'accent',
  'background',
  'text',
  'radius',
  'opacity',
  'glow',
  'width',
  'spacing',
  'align',
  'moodSwitch',
  'moodIntensity',
);
const GENERIC_ELEMENTS = group('cover', 'artist', 'progress', 'badge');
const GENERIC_MOTION = group('animation', 'hidePaused', 'spin', 'spinSpeed');
// Cover-Effekte (Helligkeit/Sättigung/Kontrast + Filter) für alle Player.
const GENERIC_COVER = group(
  'cover',
  'coverBrightness',
  'coverSaturation',
  'coverContrast',
  'coverFilter',
);
const GENERIC_PROGRESS = group('progress');
const GENERIC_TYPOGRAPHY = {
  title: group(
    'titleFont',
    'titleWeight',
    'titleSize',
    'titleLetterSpacing',
    'titleCase',
  ),
  artist: group(
    'artistFont',
    'artistWeight',
    'artistSize',
    'artistLetterSpacing',
    'artistCase',
  ),
  meta: group(
    'metaFont',
    'metaWeight',
    'metaSize',
    'metaLetterSpacing',
    'metaCase',
  ),
} satisfies LayoutCapabilities['typography'];
const GENERIC_SELECTORS = {
  device: '.overlay',
  cover: '.album-art',
  progress: '.track-progress',
  title: '.track-title',
  artist: '.track-artist',
  meta: '.now-playing',
} satisfies LayoutCapabilities['selectors'];

function genericCapabilities(
  surface: ControlGroup = GENERIC_SURFACE,
  motion: ControlGroup = GENERIC_MOTION,
): LayoutCapabilities {
  return {
    selectors: GENERIC_SELECTORS,
    surface,
    elements: GENERIC_ELEMENTS,
    motion,
    typography: GENERIC_TYPOGRAPHY,
    cover: GENERIC_COVER,
    progress: GENERIC_PROGRESS,
  };
}

const MEMORY_SELECTORS = {
  device: '.layout-memory',
  cover: '.memory-cover-slot',
  display: '.memory-screen',
  led: '.memory-led',
  controls: '.memory-controls',
  progress: '.track-progress',
  note: '.memory-note',
  title: '.track-title',
  artist: '.track-artist',
  meta: '.memory-status',
} satisfies LayoutCapabilities['selectors'];

const MEMORY_CAPABILITIES: LayoutCapabilities = {
  selectors: MEMORY_SELECTORS,
  surface: group(
    'accent',
    'background',
    'text',
    'radius',
    'opacity',
    'glow',
    'width',
    'spacing',
    'align',
    'moodSwitch',
    'moodIntensity',
    'progressColor',
    'controlAccentColor',
    'statusAccentColor',
    'linkAccentColors',
  ),
  elements: group(
    'cover',
    'artist',
    'progress',
    'badge',
    'memoryLabel',
    'observedPlaylistId',
    'observedPlaylistName',
  ),
  motion: group('animation', 'hidePaused'),
  typography: {
    title: group(
      ...GENERIC_TYPOGRAPHY.title.fields,
      'titleOffsetX',
      'titleOffsetY',
      'titleArtistSpacing',
    ),
    artist: group(
      ...GENERIC_TYPOGRAPHY.artist.fields,
      'artistOffsetX',
      'artistOffsetY',
    ),
    meta: group(
      ...GENERIC_TYPOGRAPHY.meta.fields,
      'metaOffsetX',
      'metaOffsetY',
      'statusAccentColor',
    ),
  },
  cover: group(
    'cover',
    'coverBrightness',
    'coverSaturation',
    'coverContrast',
    'coverFilter',
    'coverSize',
    'coverOffsetX',
    'coverOffsetY',
    'coverRadius',
    'coverFit',
  ),
  progress: group(
    'progress',
    'progressColor',
    'progressEdge',
    'progressWidth',
    'progressThickness',
    'progressOffsetX',
    'progressOffsetY',
    'progressRadius',
  ),
  controls: group(
    'controlAccentColor',
    'controlsSize',
    'controlsIconSize',
    'controlsGap',
    'controlsOffsetX',
    'controlsOffsetY',
  ),
  display: group(
    'displayColor',
    'displayBrightness',
    'textGlow',
    'scanlinesEnabled',
    'scanlineStrength',
    'grainEnabled',
    'grainStrength',
    'vignetteStrength',
  ),
  led: group(
    'ledVisible',
    'ledColor',
    'ledBehavior',
    'ledBrightness',
    'ledGlow',
    'ledSpeed',
    'ledSize',
    'ledOffsetX',
    'ledOffsetY',
  ),
  note: group(
    'memoryLabel',
    'noteSize',
    'noteOffsetX',
    'noteOffsetY',
    'noteRotation',
    'noteOpacity',
  ),
};

const surfaceWithout = (...unsupported: readonly (keyof Config)[]) =>
  group(...GENERIC_SURFACE.fields.filter((field) => !unsupported.includes(field)));

const motionWithout = (...unsupported: readonly (keyof Config)[]) =>
  group(...GENERIC_MOTION.fields.filter((field) => !unsupported.includes(field)));

const GLASS_CAPABILITIES: LayoutCapabilities = {
  ...genericCapabilities(),
  glass: group(
    'glassOpacity',
    'glassTintColor',
    'glassTintStrength',
    'glassHighlight',
  ),
};

export const LAYOUT_CAPABILITIES = {
  glass: GLASS_CAPABILITIES,
  // Nullsoft '99: eigener Schatten (Glow wirkungslos), dazu Gehäuse-Stil,
  // Visualizer und ein-/ausblendbare Tasten & Lautstärke.
  winamp: {
    ...genericCapabilities(
      group(...surfaceWithout('glow').fields, 'bodyStyle'),
    ),
    selectors: {
      ...GENERIC_SELECTORS,
      visualizer: '.ns-bars',
      controls: '.ns-controls',
    },
    visualizer: group(
      'visualizerVisible',
      'visualizerColor',
      'visualizerPosition',
    ),
    controls: group('controlsVisible', 'volumeVisible'),
  },
  memory: MEMORY_CAPABILITIES,
  // Aqua Days (Redesign 3/4): eigener Fensterschatten (Glow wirkungslos),
  // Gehäuse-Stile, Aqua-Gel (Besonderheit), Album-Zeile, Tasten & Lautstärke.
  aqua: {
    ...genericCapabilities(
      group(...surfaceWithout('glow').fields, 'bodyStyle', 'gelAnimation'),
    ),
    selectors: {
      ...GENERIC_SELECTORS,
      controls: '.aq-controls',
    },
    typography: {
      ...GENERIC_TYPOGRAPHY,
      artist: group(...GENERIC_TYPOGRAPHY.artist.fields, 'albumVisible'),
    },
    controls: group('controlsVisible', 'volumeVisible'),
  },
  // Pocket Quest: eigener Pixel-Rahmen (Glow wirkungslos), Gehäuse-Stile
  // und schaltbare Spielmechanik (Level, Seltenheit, Combo, Quest, Erfolge,
  // Party).
  pixel: {
    ...genericCapabilities(
      group(...surfaceWithout('glow').fields, 'bodyStyle'),
    ),
    game: group(
      'gameLevel',
      'gameRarity',
      'gameCombo',
      'gameQuest',
      'gameAchievements',
      'gameParty',
    ),
  },
  // Ranked LoL (Ranked Gaming Players 1/3): Rahmen-Stil, Splash-Hintergrund
  // des Mains (oder fester Champ), Rang-Zeile aus dem League-Client.
  lol: {
    ...genericCapabilities(
      group(
        ...surfaceWithout('glow', 'opacity', 'radius').fields,
        'bodyStyle',
        'lolSplash',
        'lolSplashMotion',
        'lolSplashDim',
        'lolChamp',
        'lolMain',
      ),
    ),
    selectors: {
      ...GENERIC_SELECTORS,
      rank: '.lol-rank',
    },
    ranked: group('lolRank', 'lolQueue', 'lolTicker'),
  },
  // Valo Ranked (Ranked Gaming Players 2/3): Agent-Portrait + Name, Splitter,
  // letztes Match, Rang-Plakette (HenrikDev).
  valo: {
    ...genericCapabilities(
      group(
        ...surfaceWithout('glow', 'opacity', 'radius', 'background').fields,
        'valoAgentVisible',
        'valoAgent',
        'valoNameVisible',
        'valoShards',
        'valoMatch',
      ),
    ),
    selectors: {
      ...GENERIC_SELECTORS,
      rank: '.valo-rank',
    },
    ranked: group('valoRank', 'valoTicker'),
  },
  // Sticky Notes (Redesign 4/4): Post-it-Stapel. Papierfarbe kommt aus der
  // Palette (bodyStyle), daher kein Hintergrund/Deckkraft/Glow. Spin wäre
  // wegen der Schräglage ruckelig und wird nicht angeboten.
  sticker: genericCapabilities(
    group(
      ...surfaceWithout('glow', 'background', 'opacity', 'align').fields,
      'bodyStyle',
      'stickyStack',
      'stickyTilt',
      'stickySlap',
    ),
    motionWithout('spin', 'spinSpeed'),
  ),
  // Minimal-CSS neutralisiert background/opacity/glow (!important transparent
  // bzw. box-shadow: none). Radius wirkt über das Cover (base .album-art folgt
  // --or), spin/spinSpeed wirken sauber (kein statischer transform auf dem
  // Cover).
  minimal: genericCapabilities(surfaceWithout('background', 'opacity', 'glow')),
  // Vinyl nutzt die volle generische Basis: kein Overlay-Level-Override der
  // Surface-Felder, und spin/spinSpeed wirken sauber auf der runden Platte
  // (kein statischer transform auf .album-art).
  vinyl: genericCapabilities(),
  // Spotlight nutzt die generische Basis, aber die feste Spaltenstruktur
  // (.overlay-main: flex-direction column + text-align center) zentriert den
  // Hauptinhalt unabhängig vom Inline-textAlign. Der Progress-Bereich ist
  // Flex (justify-content: space-between) — text-align wirkt dort ebenfalls
  // nicht. align hat daher keine sichtbare/sinnvolle Wirkung und wird nicht
  // angeboten. Alle übrigen Surface-Felder sowie spin/spinSpeed wirken
  // (kein statischer transform auf dem Cover).
  spotlight: genericCapabilities(surfaceWithout('align')),
  // CD-CSS neutralisiert background/radius/opacity/glow: Overlay ist
  // transparent ohne Border (overflow visible), die Coverform ist fest
  // (border-radius: 50%). Spin/spinSpeed wirken sauber auf der runden Platte
  // (kein statischer transform auf .album-art).
  cd: genericCapabilities(surfaceWithout('background', 'radius', 'opacity', 'glow')),
  // Floating-CSS neutralisiert background/opacity/glow (!important). Radius
  // wirkt über das Cover (border-radius: var(--or)). Spin/spinSpeed werden
  // nicht angeboten: Das Cover trägt einen statischen transform
  // (rotate(-5deg)), wodurch die disc-spin-Animation (nur to-Keyframe)
  // ruckelig springt statt sauber zu rotieren.
  floating: genericCapabilities(
    surfaceWithout('background', 'opacity', 'glow'),
    motionWithout('spin', 'spinSpeed'),
  ),
} satisfies Record<LayoutId, LayoutCapabilities>;

const MEMORY_TARGET_ORDER = [
  'led',
  'title',
  'artist',
  'meta',
  'progress',
  'controls',
  'display',
  'cover',
  'note',
  'device',
] as const satisfies readonly EditorTarget[];

const MEMORY_ELEMENT_ORDER = [
  'device',
  'cover',
  'display',
  'title',
  'artist',
  'meta',
  'progress',
  'controls',
  'led',
  'note',
] as const satisfies readonly EditorTarget[];

const GLASS_TARGET_ORDER = [
  'cover',
  'title',
  'artist',
  'meta',
  'progress',
  'device',
] as const satisfies readonly EditorTarget[];

// Pixel nutzt denselben generischen Renderer wie Glass. Die Ziel-Reihenfolge
// stellt sicher, dass spezifische Kindziele (Cover, Titel, Artist, Meta,
// Progress) Vorrang vor dem Device-Target besitzen.
const PIXEL_TARGET_ORDER = [
  'cover',
  'title',
  'artist',
  'meta',
  'progress',
  'device',
] as const satisfies readonly EditorTarget[];

// Sticker und Vinyl nutzen denselben generischen Renderer. Die Reihenfolge
// entspricht der Glass-/Pixel-Reihenfolge: Kindziele vor Device.
const STICKER_TARGET_ORDER = [
  'cover',
  'title',
  'artist',
  'meta',
  'progress',
  'device',
] as const satisfies readonly EditorTarget[];

const VINYL_TARGET_ORDER = [
  'cover',
  'title',
  'artist',
  'meta',
  'progress',
  'device',
] as const satisfies readonly EditorTarget[];

// Minimal, Floating und CD nutzen denselben generischen Renderer. Die
// Reihenfolge entspricht der Glass-/Pixel-Reihenfolge: Kindziele vor Device.
const MINIMAL_TARGET_ORDER = [
  'cover',
  'title',
  'artist',
  'meta',
  'progress',
  'device',
] as const satisfies readonly EditorTarget[];

const FLOATING_TARGET_ORDER = [
  'cover',
  'title',
  'artist',
  'meta',
  'progress',
  'device',
] as const satisfies readonly EditorTarget[];

const CD_TARGET_ORDER = [
  'cover',
  'title',
  'artist',
  'meta',
  'progress',
  'device',
] as const satisfies readonly EditorTarget[];

// Spotlight nutzt denselben generischen Renderer. Die Reihenfolge entspricht
// der Glass-/Pixel-Reihenfolge: Kindziele vor Device.
const SPOTLIGHT_TARGET_ORDER = [
  'cover',
  'title',
  'artist',
  'meta',
  'progress',
  'device',
] as const satisfies readonly EditorTarget[];

function selectionTarget(target: EditorTarget): EditorSelectionTarget {
  return target === 'meta' ? 'display-meta' : target;
}

function editorTargets(
  layout: LayoutId,
  order: readonly EditorTarget[],
): readonly (readonly [EditorSelectionTarget, string])[] {
  const selectors: LayoutCapabilities['selectors'] =
    LAYOUT_CAPABILITIES[layout].selectors;
  return order.flatMap((target) => {
    const selector = selectors[target];
    return selector ? [[selectionTarget(target), selector] as const] : [];
  });
}

export function supportsField(
  layout: string,
  field: keyof Config,
): boolean {
  if (!Object.prototype.hasOwnProperty.call(LAYOUT_CAPABILITIES, layout))
    return false;

  const resolvedLayout = layout as LayoutId;
  const capabilities = LAYOUT_CAPABILITIES[resolvedLayout];
  const groups = [
    capabilities.surface,
    capabilities.elements,
    capabilities.motion,
    ...Object.values(capabilities.typography),
    capabilities.cover,
    capabilities.progress,
    capabilities.controls,
    capabilities.display,
    capabilities.led,
    capabilities.note,
    capabilities.glass,
    capabilities.visualizer,
    capabilities.game,
    capabilities.ranked,
  ];
  return groups.some((entry) => entry?.fields.includes(field));
}

export const MEMORY_EDITOR_TARGETS = editorTargets(
  'memory',
  MEMORY_TARGET_ORDER,
);

export const GLASS_EDITOR_TARGETS = editorTargets('glass', GLASS_TARGET_ORDER);

export const PIXEL_EDITOR_TARGETS = editorTargets('pixel', PIXEL_TARGET_ORDER);

export const STICKER_EDITOR_TARGETS = editorTargets(
  'sticker',
  STICKER_TARGET_ORDER,
);

export const VINYL_EDITOR_TARGETS = editorTargets('vinyl', VINYL_TARGET_ORDER);

export const MINIMAL_EDITOR_TARGETS = editorTargets(
  'minimal',
  MINIMAL_TARGET_ORDER,
);

export const FLOATING_EDITOR_TARGETS = editorTargets(
  'floating',
  FLOATING_TARGET_ORDER,
);

export const CD_EDITOR_TARGETS = editorTargets('cd', CD_TARGET_ORDER);

export const SPOTLIGHT_EDITOR_TARGETS = editorTargets(
  'spotlight',
  SPOTLIGHT_TARGET_ORDER,
);

export const MEMORY_EDITOR_ELEMENTS = MEMORY_ELEMENT_ORDER.map(selectionTarget);

// Studio 2.0: Winamp und Aqua nutzen den generischen Renderer (gleiche
// Selektoren wie Glass). Vorher fielen beide auf die Memory-Ziele zurück,
// wodurch Cover, Gerät und Statuszeile nicht anklickbar waren.
const GENERIC_TARGET_ORDER = [
  'cover',
  'title',
  'artist',
  'meta',
  'progress',
  'device',
] as const satisfies readonly EditorTarget[];

export const WINAMP_EDITOR_TARGETS = editorTargets('winamp', [
  'cover',
  'visualizer',
  'title',
  'artist',
  'meta',
  'progress',
  'controls',
  'device',
]);

export const LOL_EDITOR_TARGETS = editorTargets('lol', [
  'cover',
  'title',
  'artist',
  'meta',
  'progress',
  'rank',
  'device',
]);

export const VALO_EDITOR_TARGETS = editorTargets('valo', [
  'cover',
  'title',
  'artist',
  'meta',
  'progress',
  'rank',
  'device',
]);

export const AQUA_EDITOR_TARGETS = editorTargets('aqua', [
  'cover',
  'title',
  'artist',
  'meta',
  'progress',
  'controls',
  'device',
]);

const EDITOR_TARGETS_BY_LAYOUT: Record<
  LayoutId,
  readonly (readonly [EditorSelectionTarget, string])[]
> = {
  glass: GLASS_EDITOR_TARGETS,
  winamp: WINAMP_EDITOR_TARGETS,
  memory: MEMORY_EDITOR_TARGETS,
  aqua: AQUA_EDITOR_TARGETS,
  lol: LOL_EDITOR_TARGETS,
  valo: VALO_EDITOR_TARGETS,
  pixel: PIXEL_EDITOR_TARGETS,
  sticker: STICKER_EDITOR_TARGETS,
  minimal: MINIMAL_EDITOR_TARGETS,
  vinyl: VINYL_EDITOR_TARGETS,
  spotlight: SPOTLIGHT_EDITOR_TARGETS,
  cd: CD_EDITOR_TARGETS,
  floating: FLOATING_EDITOR_TARGETS,
};

/** Klickziele eines Layouts (unbekannte Layouts: Glass-Ziele). */
export function editorTargetsFor(layout: string) {
  return Object.prototype.hasOwnProperty.call(EDITOR_TARGETS_BY_LAYOUT, layout)
    ? EDITOR_TARGETS_BY_LAYOUT[layout as LayoutId]
    : GLASS_EDITOR_TARGETS;
}

/** Reihenfolge der Element-Chips im Studio (ohne 'device' = Player). */
export function editorElementsFor(layout: string): EditorSelectionTarget[] {
  if (layout === 'memory')
    return MEMORY_ELEMENT_ORDER.filter((t) => t !== 'device').map(
      selectionTarget,
    );
  return editorTargetsFor(layout)
    .map(([name]) => name)
    .filter((name) => name !== 'device');
}
