'use client';
import {
  useEffect,
  useState,
  useRef,
  type CSSProperties,
  type ReactNode,
} from 'react';
import {
  AudioLines,
  ArrowUpRight,
  SlidersHorizontal,
  Radio,
  Check,
  Music2,
  Monitor,
  Sparkles,
  Copy,
  Save,
  RotateCcw,
  Pause,
  Play,
  ExternalLink,
  Lock,
  Unplug,
  RefreshCw,
  Info,
  MousePointer2,
  ChevronLeft,
  Image as ImageIcon,
  Gauge,
  Languages,
  Gamepad2,
  Trophy,
  Tag,
  Box,
  Lightbulb,
  Type,
  Plus,
  Trash2,
  Download,
  Eye,
  EyeOff,
  X,
  ChevronDown,
  Star,
  Upload,
  Share2,
  ClipboardPaste,
  SkipForward,
} from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import {
  Overlay,
  defaults,
  demo,
  FONT_LIBRARY,
  COVER_FILTERS,
  estimatedProgress,
  isAfterglow,
  type Config,
  type Track,
} from '@/lib/overlay';
import { presets } from '@/lib/presets';
import {
  editorElementsFor,
  editorTargetsFor,
  supportsField,
} from '@/lib/layout-capabilities';
import { detectMood, moodDemos } from '@/lib/mood';
import { getMoodMode, isMoodEffectivelyEnabled } from '@/lib/mood-capabilities';
import { fontFormatHint } from '@/lib/fonts';
import { GALLERY_TRACKS } from '@/lib/gallery-demo';
import HistoryView from './history-view';
import LikesView from './likes-view';
import SourceCard from './source-card';
import { DesktopWidgetCard, WidgetMenu } from './desktop-widget';
import { hasKey, LOCALES, serverMsg, tNow, useT, type Locale } from '@/lib/i18n';
import { decodeLookCode, encodeLookCode, LookCodeError } from '@/lib/look-code';
import { LOL_TIER_NAMES, isApexTier, useLolRanked } from '@/lib/lol-ranked';
async function api(path: string, body?: unknown) {
  const r = await fetch(path, {
    method: body ? 'POST' : 'GET',
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const d = (await r.json()) as {
    error?: string;
    config: Config;
    connected: boolean;
    overlayKey: string;
    redirect: string;
    url: string;
    track: Track | null;
    message?: string;
    retryAfter?: number;
    pinned_at?: number | null;
    look?: CustomLook;
  };
  if (!r.ok) throw new Error(d.error || tNow('st.verbindungFehlgeschlagen'));
  return d;
}
type PlaylistItem = {
  id: string;
  name: string;
  image?: string;
  owner?: { id?: string };
  collaborative?: boolean;
};
type CustomFontMeta = {
  id: string;
  name: string;
  format: string;
  family: string;
  size: number;
  createdAt: number;
};
type CustomLook = {
  id: string;
  name: string;
  config: Config;
  created_at: number;
  pinned: number;
  pinned_at: number | null;
};
type ResonanceLookFile = {
  format: 'resonance-look';
  version: 1;
  name: string;
  config: unknown;
};
function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function configSnapshotKey(config: Config): string {
  return JSON.stringify(
    Object.fromEntries(
      Object.keys(config)
        .sort()
        .map((key) => [key, config[key as keyof Config]]),
    ),
  );
}
function Picker({
  label,
  value,
  options,
  onChange,
  field,
}: {
  label: string;
  value: string;
  options: [string, string][];
  onChange: (v: string) => void;
  field?: string;
}) {
  return (
    <label className="picker" data-field={field}>
      <span>{label}</span>
      <Select value={value} onValueChange={(v) => v && onChange(v)}>
        <SelectTrigger aria-label={label}>
          <SelectValue>{options.find((o) => o[0] === value)?.[1]}</SelectValue>
        </SelectTrigger>
        <SelectContent>
          {options.map(([v, l]) => (
            <SelectItem key={v} value={v}>
              {l}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </label>
  );
}
const LED_BEHAVIOR_LABELS: Record<string, string> = {
  solid: 'Solid',
  soft: 'Soft Pulse',
  breathe: 'Breathe',
  double: 'Double Pulse',
  heartbeat: 'Heartbeat',
  flicker: 'Flicker',
  off: 'Off',
};
const EDITOR_NAMES: Record<string, string> = {
  device: 'Gerät',
  cover: 'Albumcover',
  display: 'Display',
  led: 'LED',
  controls: 'Bedienelemente',
  progress: 'Wiedergabe',
  note: 'Notiz',
  title: 'Songtitel',
  artist: 'Interpret',
  'display-meta': 'Statuszeile',
  visualizer: 'Visualizer',
  rank: 'Rang',
  shelf: 'Regal',
  disc: 'CD',
};
// Studio 2.0: kurze Namen für Element-Chips und Panel-Titel.
const CHIP_NAMES: Record<string, string> = {
  cover: 'Cover',
  title: 'Titel',
  artist: 'Interpret',
  'display-meta': 'Status',
  progress: 'Fortschritt',
  display: 'Display',
  led: 'LED',
  controls: 'Tasten',
  note: 'Notiz',
  visualizer: 'Visualizer',
  rank: 'Rang',
  shelf: 'Regal',
  disc: 'CD',
};
// Gehäuse-Stile je Layout (Oberfläche; der Farbton kommt aus „Hintergrund“).
const BODY_STYLES: Record<string, [string, string][]> = {
  winamp: [
    ['default', 'Gebürstet'],
    ['gloss', 'Glanz'],
    ['matte', 'Matt'],
    ['carbon', 'Carbon'],
  ],
  aqua: [
    ['default', 'Nadelstreifen'],
    ['metal', 'Gebürstetes Metall'],
    ['graphite', 'Graphit'],
    ['clean', 'Schlicht'],
  ],
  lol: [
    ['default', 'Gold'],
    ['hextech', 'Hextech'],
    ['void', 'Leere'],
    ['clean', 'Schlicht'],
  ],
  sticker: [
    ['default', 'Neon'],
    ['pastel', 'Pastell'],
    ['kraft', 'Kraft & Weiß'],
  ],
  shelf: [
    ['default', 'Klar'],
    ['smoke', 'Rauchglas'],
    ['color', 'Farbig (Cover)'],
    ['frost', 'Milchglas'],
  ],
  pixel: [
    ['default', 'Dialog'],
    ['gameboy', 'Handheld-Grün'],
    ['parchment', 'Pergament'],
    ['midnight', 'Mitternacht'],
  ],
};
// Elemente, die über das Auge im Panel-Kopf ein-/ausgeblendet werden.
const VISIBILITY_FIELD: Record<
  string,
  | 'cover'
  | 'artist'
  | 'progress'
  | 'badge'
  | 'visualizerVisible'
  | 'lolRank'
  | 'valoRank'
  | 'shelfDisc'
> = {
  cover: 'cover',
  artist: 'artist',
  progress: 'progress',
  'display-meta': 'badge',
  visualizer: 'visualizerVisible',
  rank: 'lolRank',
  disc: 'shelfDisc',
};
// Rang-Ziel teilen sich LoL und VALORANT – Sichtbarkeitsfeld je Layout.
function visibilityFieldFor(el: string, layout: string) {
  if (el === 'rank' && layout === 'valo') return 'valoRank' as const;
  return VISIBILITY_FIELD[el];
}
const TIP_STORAGE_KEY = 'resonance.studio.tipDismissed';
function readableOn(hex: string) {
  const m = /^#([0-9a-f]{6})$/i.exec(hex);
  if (!m) return '#131811';
  const n = parseInt(m[1], 16);
  const lin = (c: number) => {
    const v = c / 255;
    return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
  };
  const l =
    0.2126 * lin((n >> 16) & 255) +
    0.7152 * lin((n >> 8) & 255) +
    0.0722 * lin(n & 255);
  return l > 0.36 ? '#131811' : '#ffffff';
}
function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="v2-section">
      <h4>{title}</h4>
      {children}
    </section>
  );
}
function Disclosure({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className={'v2-disclosure' + (open ? ' is-open' : '')}>
      <button
        type="button"
        className="v2-disclosure-toggle"
        data-disclosure=""
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
      >
        <span>{title}</span>
        <ChevronDown size={15} aria-hidden="true" />
      </button>
      {open && <div className="v2-disclosure-body">{children}</div>}
    </div>
  );
}
export default function Studio() {
  const [config, setConfig] = useState<Config>(defaults),
    [historyPast, setHistoryPast] = useState<Config[]>([]),
    [historyFuture, setHistoryFuture] = useState<Config[]>([]),
    [saved, setSaved] = useState(''),
    [connected, setConnected] = useState(false),
    [ready, setReady] = useState(false),
    [key, setKey] = useState(''),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState(''),
    [error, setError] = useState(''),
    [modal, setModal] = useState<'spotify' | 'obs' | null>(null),
    [track, setTrack] = useState<Track | null>(null),
    [demoMode, setDemoMode] = useState(true),
    [demoPlaying, setDemoPlaying] = useState(true),
    [canvas, setCanvas] = useState('ambient'),
    [canvasWidth, setCanvasWidth] = useState(600),
    [selectedElement, setSelectedElement] = useState<string | null>(null),
    [markerRect, setMarkerRect] = useState<{
      top: number;
      left: number;
      width: number;
      height: number;
    } | null>(null),
    [tick, setTick] = useState(0),
    [origin, setOrigin] = useState(''),
    [testerVersion, setTesterVersion] = useState<string | null>(null),
    [setupExpanded, setSetupExpanded] = useState(false),
    [spotifyRedirect, setSpotifyRedirect] = useState(''),
    [playlists, setPlaylists] = useState<PlaylistItem[]>([]),
    [currentUserId, setCurrentUserId] = useState(''),
    [demoIndex, setDemoIndex] = useState(0),
    [moodSettingsOpen, setMoodSettingsOpen] = useState(false),
    [moodSetupDismissed, setMoodSetupDismissed] = useState(false),
    [lastfmConfigured, setLastfmConfigured] = useState(false),
    [geniusConfigured, setGeniusConfigured] = useState(false),
    [lastfmKey, setLastfmKey] = useState(''),
    [geniusToken, setGeniusToken] = useState(''),
    [moodBusy, setMoodBusy] = useState(false),
    [lastfmTest, setLastfmTest] = useState<
      '' | 'testing' | 'connected' | 'invalid' | 'unavailable'
    >(''),
    [geniusTest, setGeniusTest] = useState<
      '' | 'testing' | 'connected' | 'invalid' | 'unavailable'
    >('');
  const [customFonts, setCustomFonts] = useState<CustomFontMeta[]>([]);
  const [customLooks, setCustomLooks] = useState<CustomLook[]>([]);
  const [view, setView] = useState<'studio' | 'looks' | 'likes' | 'history' | 'setup'>('studio');
  // F20: Studio-Sprache (bisher übersetzt: Navigation + Tab „Verlauf“).
  const i18n = useT();
  // F20: Sprache der Texte im Stream (eigene Einstellung, Tabelle stream_settings).
  const [streamLang, setStreamLang] = useState('auto');
  useEffect(() => {
    let alive = true;
    fetch('/api/stream-lang', { cache: 'no-store' })
      .then((r) => (r.ok ? (r.json() as Promise<{ lang?: string }>) : null))
      .then((d) => {
        if (alive && d?.lang) setStreamLang(d.lang);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, []);
  async function saveStreamLangChoice(v: string) {
    const before = streamLang;
    setStreamLang(v);
    try {
      await api('/api/stream-lang', { lang: v });
    } catch (e) {
      setStreamLang(before);
      setError((e as Error).message);
    }
  }
  /** Dynamischer Schlüssel mit Fallback (z. B. chip.<id>, mood.<id>). */
  const dynT = (k: string, fallback: string) => (hasKey(k) ? i18n.t(k) : fallback);
  const elementName = (el: string) =>
    dynT('chip.' + el.replace('-', ''), CHIP_NAMES[el] || dynT('editor.' + el.replace('-', ''), EDITOR_NAMES[el] || el));
  // F22: Widget als schwebendes Mini-Fenster. Chrome/Edge: Document
  // Picture-in-Picture = immer im Vordergrund, ohne Adressleiste (bleibt offen,
  // solange das Studio-Tab offen ist). Sonst: normales Popup-Fenster.
  const openWidget = async () => {
    const dpip = (window as unknown as {
      documentPictureInPicture?: { requestWindow: (o: { width: number; height: number }) => Promise<Window> };
    }).documentPictureInPicture;
    if (dpip) {
      try {
        const pip = await dpip.requestWindow({ width: 520, height: 190 });
        const d = pip.document;
        d.title = 'Resonance Widget';
        d.body.style.cssText = 'margin:0;background:#0c0d0d;overflow:hidden';
        const frame = d.createElement('iframe');
        frame.src = location.origin + '/widget';
        frame.title = 'Resonance Widget';
        frame.style.cssText = 'border:0;width:100vw;height:100vh;display:block';
        d.body.appendChild(frame);
        return;
      } catch {
        // abgelehnt / nicht erlaubt → Popup
      }
    }
    window.open('/widget', 'resonance-widget', 'popup=yes,width=560,height=230');
  };
  const presetNote = (p: { id: string; note: string }) => {
    const k = 'preset.' + p.id;
    return hasKey(k) ? i18n.t(k) : p.note;
  };
  // League-Client-Status nur auf der Setup-Seite abfragen.
  const lol = useLolRanked(view === 'setup', 'solo', 10000);
  // Champion-Liste (Riot Data Dragon, öffentlich) für den festen Hintergrund-
  // Champ beim Rift-Ranked-Player. Nur laden, wenn der Player gewählt ist.
  const [lolChamps, setLolChamps] = useState<[string, string][]>([]);
  // VALORANT: Agentenliste (valorant-api.com) + HenrikDev-Einrichtung (lokal).
  const [valoAgents, setValoAgents] = useState<[string, string][]>([]);
  const [valoSettings, setValoSettings] = useState<{
    configured: boolean;
    hasKey: boolean;
    name: string;
    tag: string;
    region: string;
    platform: string;
  } | null>(null);
  const [valoForm, setValoForm] = useState({
    name: '',
    tag: '',
    region: 'eu',
    platform: 'pc',
    key: '',
  });
  const [valoMsg, setValoMsg] = useState('');
  const [valoBusy, setValoBusy] = useState(false);
  const [tipDismissed, setTipDismissed] = useState(false);
  const [saveLookOpen, setSaveLookOpen] = useState(false);
  // Entwicklermodus (nur wenn das Vite-Dev-Plugin antwortet; Tester-Builds nie).
  const [devStatus, setDevStatus] = useState<{
    latest: { file: string; createdAt: string; size: number } | null;
    newestSourceChange: string | null;
    stale: boolean;
  } | null>(null);
  const [devBusy, setDevBusy] = useState(false);
  const [lookName, setLookName] = useState('');
  const lookImportRef = useRef<HTMLInputElement>(null);
  // Galerie (F01): Demo-Playlist ohne Spotify, Bühne mit 1–2 Playern.
  const [galleryIdx, setGalleryIdx] = useState(0);
  const [galleryAuto, setGalleryAuto] = useState(true);
  const [gallerySel, setGallerySel] = useState<string[]>(['glass']);
  const [galleryTag, setGalleryTag] = useState('all');
  const [galleryStart, setGalleryStart] = useState(() => Date.now());
  const [galleryNow, setGalleryNow] = useState(() => Date.now());
  // Look-Codes: teilen (Code anzeigen) oder einfügen (Vorschau + speichern).
  const [codePanel, setCodePanel] = useState<
    | null
    | { mode: 'share'; name: string; code: string; copied: boolean }
    | {
        mode: 'import';
        text: string;
        name: string;
        config: Config | null;
        error: string;
        busy: boolean;
      }
  >(null);
  const [uploading, setUploading] = useState(false);
  const [pendingUploadTarget, setPendingUploadTarget] = useState<
    'title' | 'artist' | 'meta' | null
  >(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{
    id: string;
    name: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sliderStart = useRef<Config | null>(null);
  const preview = useRef<HTMLDivElement>(null);
  const inspector = useRef<HTMLElement>(null);
  const liveTrackId = useRef('');
  const liveSlot = useRef(0);
  const configRef = useRef(config);
  const savedRef = useRef(saved);
  const persistRevision = useRef(0);
  const persisting = useRef(false);
  configRef.current = config;
  savedRef.current = saved;
  const dirty = saved !== JSON.stringify(config);
  const savedConfig = (() => {
    try {
      const parsed: unknown = JSON.parse(saved);
      return isRecord(parsed) ? (parsed as Config) : null;
    } catch {
      return null;
    }
  })();
  const activeLiveLookId = savedConfig
    ? customLooks.find(
        (look) =>
          !!look.pinned &&
          configSnapshotKey(look.config) === configSnapshotKey(savedConfig),
      )?.id
    : undefined;
  const liveLooks = customLooks
    .filter((look) => !!look.pinned)
    .sort(
      (a, b) =>
        (a.pinned_at ?? Number.MAX_SAFE_INTEGER) -
          (b.pinned_at ?? Number.MAX_SAFE_INTEGER) || a.id.localeCompare(b.id),
    );
  const isActivePreset = (preset: (typeof presets)[number]) =>
    preset.id === config.layout &&
    (preset.id !== 'glass' || isAfterglow(config));
  const chosen = presets.find(isActivePreset);
  const chosenName =
    config.layout === 'glass' && !isAfterglow(config)
      ? 'Glass'
      : chosen?.name;
  const editorTargets = editorTargetsFor(config.layout);
  const editorElements = editorElementsFor(config.layout);
  const canEdit = (field: keyof Config) => supportsField(config.layout, field);
  useEffect(() => {
    if (config.layout !== 'valo' || valoAgents.length) return;
    let alive = true;
    fetch('https://valorant-api.com/v1/agents?isPlayableCharacter=true&language=de-DE')
      .then((r) => r.json() as Promise<{ data?: { uuid: string; displayName: string }[] }>)
      .then((d) => {
        if (!alive || !Array.isArray(d.data)) return;
        setValoAgents(
          d.data
            .map((a) => [a.uuid, a.displayName] as [string, string])
            .sort((a, b) => a[1].localeCompare(b[1], 'de')),
        );
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [config.layout, valoAgents.length]);
  // HenrikDev-Einrichtung laden (nur Setup-Seite; Endpunkt nur lokal).
  useEffect(() => {
    if (view !== 'setup' || valoSettings) return;
    fetch('/__resonance/valo/settings')
      .then((r) =>
        r.ok
          ? (r.json() as Promise<{
              configured: boolean;
              hasKey: boolean;
              name: string;
              tag: string;
              region: string;
              platform: string;
            }>)
          : null,
      )
      .then((s) => {
        if (!s || typeof s.configured !== 'boolean') return;
        setValoSettings(s);
        setValoForm((f) => ({
          ...f,
          name: s.name,
          tag: s.tag,
          region: s.region,
          platform: s.platform,
        }));
      })
      .catch(() => {});
  }, [view, valoSettings]);
  async function saveValo(removeKey = false) {
    setValoBusy(true);
    setValoMsg('');
    try {
      const r = await fetch('/__resonance/valo/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: valoForm.name,
          tag: valoForm.tag,
          region: valoForm.region,
          platform: valoForm.platform,
          key: removeKey ? null : valoForm.key,
        }),
      });
      const d = (await r.json()) as {
        error?: string;
        settings?: typeof valoSettings;
        result?: { status: string; reason?: string; tierName?: string; rr?: number } | null;
      };
      if (!r.ok || !d.settings) {
        setValoMsg(d.error || i18n.t('setup.err.save'));
        return;
      }
      setValoSettings(d.settings);
      setValoForm((f) => ({ ...f, key: '' }));
      const res = d.result;
      setValoMsg(
        !res
          ? removeKey
            ? i18n.t('setup.valo.m.removed')
            : i18n.t('setup.valo.m.incomplete')
          : res.status === 'ok'
            ? i18n.t('setup.valo.m.ok', { tier: res.tierName || '', rr: res.rr ?? 0 })
            : res.status === 'unranked'
              ? i18n.t('setup.valo.m.okUnranked')
              : res.reason === 'key'
                ? i18n.t('setup.valo.m.key')
                : res.reason === 'notfound'
                  ? i18n.t('setup.valo.m.notfound')
                  : res.reason === 'rate'
                    ? i18n.t('setup.valo.m.rate')
                    : i18n.t('setup.valo.m.offline'),
      );
    } catch {
      setValoMsg(i18n.t('setup.err.save'));
    } finally {
      setValoBusy(false);
    }
  }
  useEffect(() => {
    if (config.layout !== 'lol' || lolChamps.length) return;
    let alive = true;
    (async () => {
      try {
        const versions = (await fetch(
          'https://ddragon.leagueoflegends.com/api/versions.json',
        ).then((r) => r.json())) as string[];
        const data = (await fetch(
          'https://ddragon.leagueoflegends.com/cdn/' +
            versions[0] +
            '/data/de_DE/champion.json',
        ).then((r) => r.json())) as {
          data: Record<string, { id: string; name: string }>;
        };
        if (!alive) return;
        setLolChamps(
          Object.values(data.data)
            .map((ch) => [ch.id, ch.name] as [string, string])
            .sort((a, b) => a[1].localeCompare(b[1], 'de')),
        );
      } catch {}
    })();
    return () => {
      alive = false;
    };
  }, [config.layout, lolChamps.length]);
  const demoTrack = {
    ...demo,
    ...moodDemos[demoIndex],
    slot: demoIndex + 1,
    playing: demoPlaying,
    progress: demoPlaying
      ? (demo.progress + tick * 1000) % demo.duration
      : demo.progress,
  };
  const shown = demoMode
    ? demoTrack
    : track
      ? { ...track, progress: estimatedProgress(track) }
      : null;
  const moodMode = getMoodMode(config);
  const moodEnabled = isMoodEffectivelyEnabled(config);
  const detected = moodEnabled
    ? detectMood(shown, shown?.lastfmTags)
    : null;
  const obsOrigin = origin.replace(/^http:\/\/localhost(?=[:/]|$)/, 'http://127.0.0.1');
  const obsUrl = obsOrigin + '/overlay#' + key;
  const afterglowMaskUrl =
    obsOrigin + '/overlay/afterglow-mask#' + key;
  const setupComplete = connected && !!key;
  const showSetupDetails = !setupComplete || setupExpanded;
  useEffect(() => {
    setOrigin(location.origin);
    if (new URLSearchParams(location.search).has('connect'))
      setModal('spotify');
    let alive = true;
    api('/api/studio')
      .then((d) => {
        if (!alive) return;
        configRef.current = d.config;
        setConfig(d.config);
        setHistoryPast([]);
        setHistoryFuture([]);
        const initialSaved = JSON.stringify(d.config);
        savedRef.current = initialSaved;
        setSaved(initialSaved);
        setConnected(d.connected);
        setDemoMode(!d.connected);
        setKey(d.overlayKey);
        setSpotifyRedirect(d.redirect);
        setReady(true);
      })
      .catch((e) => {
        if (alive) setError(e.message);
      });
    fetch('/api/mood/settings')
      .then(async (r) => {
        if (!alive || !r.ok) return;
        const d = (await r.json()) as {
          lastfmConfigured?: boolean;
          geniusConfigured?: boolean;
        };
        setLastfmConfigured(!!d.lastfmConfigured);
        setGeniusConfigured(!!d.geniusConfigured);
      })
      .catch(() => {});
    fetch('/resonance-version.json', { cache: 'no-store' })
      .then(async (r) =>
        r.ok
          ? ((await r.json()) as { version?: string | null })
          : { version: null },
      )
      .then((d) => {
        if (alive) setTesterVersion(d.version || null);
      })
      .catch(() => {});
    fetch('/api/looks')
      .then((r) => (r.ok ? r.json() : { looks: [] }))
      .then((d) => alive && setCustomLooks(d.looks || []))
      .catch(() => {});
    const status = new URLSearchParams(location.search).get('spotify');
    if (status) {
      setMessage(
        status === 'connected'
          ? i18n.t('st.spotifyIstVerbundenStarteEinen')
          : status === 'cancelled'
            ? i18n.t('st.spotifyAnmeldungAbgebrochen')
            : status === 'expired'
              ? i18n.t('st.anmeldungAbgelaufenBitteErneutVerbinden')
              : status === 'token'
                ? i18n.t('st.spotifyHatDieAnmeldungAbgelehnt')
                : i18n.t('st.spotifyAnmeldungFehlgeschlagenPruefeDie'),
      );
      history.replaceState(null, '', '/');
    }
    return () => {
      alive = false;
    };
  }, []);
  useEffect(() => {
    if (!ready) return;
    let stopped = false;
    let inFlight = false;
    let requestSequence = 0;
    let timer: ReturnType<typeof setInterval> | undefined;

    async function syncLiveConfig(force = false) {
      if (
        stopped ||
        (inFlight && !force) ||
        persisting.current ||
        document.visibilityState !== 'visible'
      )
        return;
      inFlight = true;
      const requestId = ++requestSequence;
      const requestRevision = persistRevision.current;
      try {
        const d = await api('/api/studio');
        if (
          stopped ||
          requestId !== requestSequence ||
          persisting.current ||
          document.visibilityState !== 'visible' ||
          requestRevision !== persistRevision.current
        )
          return;

        const serverConfig = d.config;
        let persistedConfig: Config | null = null;
        try {
          const parsed: unknown = JSON.parse(savedRef.current);
          if (isRecord(parsed)) persistedConfig = parsed as Config;
        } catch {}
        if (
          persistedConfig &&
          configSnapshotKey(serverConfig) === configSnapshotKey(persistedConfig)
        )
          return;

        const localConfig = configRef.current;
        const editorWasClean =
          !!persistedConfig &&
          configSnapshotKey(localConfig) === configSnapshotKey(persistedConfig);
        const nextSaved = JSON.stringify(serverConfig);
        savedRef.current = nextSaved;
        setSaved(nextSaved);

        if (editorWasClean) {
          configRef.current = serverConfig;
          setConfig(serverConfig);
          setHistoryPast([]);
          setHistoryFuture([]);
          sliderStart.current = null;
        } else {
          setMessage(
            i18n.t('st.liveKonfigurationWurdeExternGeaendert'),
          );
        }
      } catch {
        // Hintergrund-Sync bleibt bei temporären Fehlern absichtlich still.
      } finally {
        if (requestId === requestSequence) inFlight = false;
      }
    }

    function stopPolling() {
      if (timer) clearInterval(timer);
      timer = undefined;
    }
    function startPolling() {
      stopPolling();
      if (document.visibilityState !== 'visible') return;
      void syncLiveConfig(true);
      timer = setInterval(() => void syncLiveConfig(), 1000);
    }
    function handleVisibilityChange() {
      startPolling();
    }

    document.addEventListener('visibilitychange', handleVisibilityChange);
    startPolling();
    return () => {
      stopped = true;
      stopPolling();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [ready]);
  // Custom Fonts: Liste laden und @font-face-Regeln injizieren.
  useEffect(() => {
    let alive = true;
    fetch('/api/fonts')
      .then(async (r) => {
        const d = (await r.json()) as { fonts?: CustomFontMeta[] };
        if (!alive || !r.ok) return;
        setCustomFonts(d.fonts || []);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, []);
  useEffect(() => {
    if (customFonts.length === 0) return;
    const style = document.createElement('style');
    style.textContent = customFonts
      .map(
        (f) => `
  @font-face {
    font-family: '${f.family}';
    src: url('/api/fonts/${f.id}/file') format('${fontFormatHint(f.format)}');
    font-display: swap;
  }
`,
      )
      .join('\n');
    document.head.appendChild(style);
    return () => {
      style.remove();
    };
  }, [customFonts]);
  useEffect(() => {
    const timer = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    if (!preview.current) return;
    const ob = new ResizeObserver((entries) =>
      setCanvasWidth(entries[0].contentRect.width),
    );
    ob.observe(preview.current);
    return () => ob.disconnect();
  }, []);
  // Editor-Selection: Escape → Deselect (nur wenn kein Base-UI-Popup offen ist)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        // Offene Base-UI-Popups (Select/Popover/Dropdown/Dialog) schließt
        // Base UI selbst per Escape – hier kein Deselect auslösen.
        const openPopup = document.querySelector(
          '[data-base-ui-portal] [data-open]',
        );
        if (!openPopup) setSelectedElement(null);
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);
  useEffect(() => {
    inspector.current?.scrollTo({ top: 0, behavior: 'smooth' });
  }, [selectedElement]);
  // Editor-Selection: Marker-Position des gewählten Elements verfolgen
  // Studio 2.0: Ohne Auswahl ist der ganze Player (Gerät) markiert.
  const markerTarget = selectedElement ?? 'device';
  useEffect(() => {
    const canvas = preview.current;
    const sel = editorTargets.find(([n]) => n === markerTarget)?.[1];
    if (!sel) {
      const frame = requestAnimationFrame(() =>
        setMarkerRect((current) => (current === null ? current : null)),
      );
      return () => cancelAnimationFrame(frame);
    }
    if (!canvas || !sel) return;
    const update = () => {
      const el = canvas.querySelector(sel);
      if (!el) {
        setMarkerRect((current) => (current === null ? current : null));
        return;
      }
      const flying = canvas
        .querySelector('.overlay')
        ?.getAnimations?.()
        .some(
          (a) =>
            a.playState === 'running' &&
            String((a as CSSAnimation).animationName).startsWith('sn-slap'),
        );
      // Während der Player „reinfliegt“ (Sticky-Notes-Draufklatschen) stimmt
      // die gemessene Lage nicht → Markierung ausblenden, nach animationend
      // neu messen (und ohne Gleit-Transition an der richtigen Stelle zeigen).
      if (flying) {
        setMarkerRect((current) => (current === null ? current : null));
        return;
      }
      const cr = canvas.getBoundingClientRect();
      let { top, left, right, bottom } = el.getBoundingClientRect();
      // Ganzer Player: Teile außerhalb des Overlay-Rahmens (z. B. der
      // Post-it-Stapel bei Sticky Notes) gehören mit in die Markierung.
      if (markerTarget === 'device')
        canvas.querySelectorAll('[data-body-part]').forEach((part) => {
          const pr = part.getBoundingClientRect();
          top = Math.min(top, pr.top);
          left = Math.min(left, pr.left);
          right = Math.max(right, pr.right);
          bottom = Math.max(bottom, pr.bottom);
        });
      const next = {
        top: top - cr.top,
        left: left - cr.left,
        width: right - left,
        height: bottom - top,
      };
      setMarkerRect((current) => {
        if (
          current &&
          Math.abs(current.top - next.top) < 0.25 &&
          Math.abs(current.left - next.left) < 0.25 &&
          Math.abs(current.width - next.width) < 0.25 &&
          Math.abs(current.height - next.height) < 0.25
        )
          return current;
        return next;
      });
    };
    const frame = requestAnimationFrame(update);
    const ro = new ResizeObserver(update);
    ro.observe(canvas);
    const el = canvas.querySelector(sel);
    if (el) ro.observe(el);
    // Songwechsel-Animationen (z. B. neuer Post-it mit anderer Schräglage)
    // ändern die Lage ohne Größenänderung → nach Animationsende neu messen.
    canvas.addEventListener('animationstart', update);
    canvas.addEventListener('animationend', update);
    canvas.addEventListener('transitionend', update);
    return () => {
      cancelAnimationFrame(frame);
      ro.disconnect();
      canvas.removeEventListener('animationstart', update);
      canvas.removeEventListener('animationend', update);
      canvas.removeEventListener('transitionend', update);
    };
  }, [
    markerTarget,
    view,
    config,
    shown?.id,
    shown?.title,
    shown?.artist,
    shown?.playing,
  ]);
  useEffect(() => {
    if (!connected || demoMode) return;
    let stopped = false;
    let timeout: ReturnType<typeof setTimeout>;
    async function poll() {
      let wait = 5000;
      try {
        const d = await api('/api/now');
        if (stopped) return;
        if (d.track) {
          const id = d.track.id || d.track.title + '|' + d.track.artist;
          if (id !== liveTrackId.current) {
            liveTrackId.current = id;
            liveSlot.current += 1;
          }
          setTrack({
            ...d.track,
            slot: liveSlot.current,
            fetchedAt: Date.now(),
          });
        } else if (!d.message) setTrack(null);
        setError(d.message || '');
        if (!d.connected) {
          setConnected(false);
          setError(i18n.t('st.spotifyVerbindungAbgelaufenBitteErneut'));
        }
        wait = Math.max(5000, (d.retryAfter || 0) * 1000);
      } catch (e) {
        if (stopped) return;
        setError((e as Error).message);
        wait = 10000;
      }
      if (!stopped) timeout = setTimeout(poll, wait);
    }
    poll();
    return () => {
      stopped = true;
      clearTimeout(timeout);
    };
  }, [connected, demoMode]);
  useEffect(() => {
    if (!connected) return;
    let alive = true;
    fetch('/api/spotify/playlists')
      .then(async (r) => {
        const d = await r.json();
        if (!alive) return;
        if (!r.ok)
          throw new Error(d.error || i18n.t('st.playlistsKonntenNichtGeladenWerden'));
        setCurrentUserId(d.currentUserId || '');
        setPlaylists(d.playlists || []);
      })
      .catch((e) => {
        if (alive) setError((e as Error).message);
      });
    return () => {
      alive = false;
    };
  }, [connected]);
  useEffect(() => {
    try {
      setTipDismissed(localStorage.getItem(TIP_STORAGE_KEY) === '1');
    } catch {}
  }, []);
  async function loadDevStatus() {
    try {
      const r = await fetch('/__resonance/dev/status', { cache: 'no-store' });
      if (!r.ok) return setDevStatus(null);
      const d = (await r.json()) as {
        devMode?: boolean;
        latest: { file: string; createdAt: string; size: number } | null;
        newestSourceChange: string | null;
        stale: boolean;
      };
      setDevStatus(d && d.devMode ? d : null);
    } catch {
      setDevStatus(null);
    }
  }
  useEffect(() => {
    if (view === 'setup') void loadDevStatus();
  }, [view]);
  async function buildTesterZip(download: boolean) {
    setDevBusy(true);
    setError('');
    try {
      const r = await fetch('/__resonance/dev/export-tester', { method: 'POST' });
      const d = (await r.json()) as {
        error?: string;
        latest?: { file: string };
      };
      if (!r.ok || !d.latest) throw new Error(d.error || i18n.t('setup.err.export'));
      setMessage(i18n.t('setup.zip.built', { file: d.latest.file }));
      if (download) {
        const a = document.createElement('a');
        a.href = '/exports/' + encodeURIComponent(d.latest.file);
        a.download = d.latest.file;
        a.click();
      }
      await loadDevStatus();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setDevBusy(false);
    }
  }
  function dismissTip() {
    setTipDismissed(true);
    try {
      localStorage.setItem(TIP_STORAGE_KEY, '1');
    } catch {}
  }
  useEffect(() => {
    if (selectedElement) dismissTip();
  }, [selectedElement]);
  // Studio 2.0: Das gesamte Studio übernimmt die Akzentfarbe des Players.
  useEffect(() => {
    const root = document.documentElement;
    const accent = /^#[0-9a-f]{6}$/i.test(config.accent)
      ? config.accent
      : defaults.accent;
    root.style.setProperty('--primary', accent);
    root.style.setProperty('--studio-on-accent', readableOn(accent));
    return () => {
      root.style.removeProperty('--primary');
      root.style.removeProperty('--studio-on-accent');
    };
  }, [config.accent]);
  const update = <K extends keyof Config>(k: K, v: Config[K]) => {
    const current = configRef.current;
    if (Object.is(current[k], v)) return;
    const next = { ...current, [k]: v };
    configRef.current = next;
    setHistoryPast((past) => [...past, current].slice(-50));
    setHistoryFuture([]);
    setConfig(next);
  };
  const beginSlider = () => {
    if (!sliderStart.current) sliderStart.current = config;
  };
  const updateSlider = <K extends keyof Config>(k: K, v: Config[K]) => {
    beginSlider();
    setConfig((current) => ({ ...current, [k]: v }));
  };
  const commitSlider = () => {
    const start = sliderStart.current;
    sliderStart.current = null;
    if (!start || JSON.stringify(start) === JSON.stringify(config)) return;
    setHistoryPast((past) => [...past, start].slice(-50));
    setHistoryFuture([]);
  };
  const undo = () => {
    const previous = historyPast.at(-1);
    if (!previous) return;
    setHistoryPast((past) => past.slice(0, -1));
    setHistoryFuture((future) => [config, ...future].slice(0, 50));
    setConfig(previous);
  };
  const redo = () => {
    const next = historyFuture[0];
    if (!next) return;
    setHistoryFuture((future) => future.slice(1));
    setHistoryPast((past) => [...past, config].slice(-50));
    setConfig(next);
  };
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (
        target?.matches('input,textarea,[contenteditable="true"]') ||
        !event.ctrlKey
      )
        return;
      if (event.key.toLowerCase() === 'z') {
        event.preventDefault();
        event.shiftKey ? redo() : undo();
      } else if (event.key.toLowerCase() === 'y') {
        event.preventDefault();
        redo();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [historyPast, historyFuture, config]);
  const canObserve = (p: PlaylistItem) =>
    p.collaborative === true || p.owner?.id === currentUserId;
  const selectedObserved = playlists.find(
    (p) => p.id === config.observedPlaylistId,
  );
  async function save() {
    setBusy(true);
    setError('');
    persisting.current = true;
    persistRevision.current += 1;
    try {
      await api('/api/studio', { config });
      const nextSaved = JSON.stringify(config);
      savedRef.current = nextSaved;
      setSaved(nextSaved);
      setMessage(
        i18n.t('st.designGespeichertDeinObsOverlay'),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      persisting.current = false;
      setBusy(false);
    }
  }
  async function saveLook() {
    const name = lookName.trim();
    if (!name) {
      setError(i18n.t('looks.m.nameMissing'));
      return;
    }
    try {
      const r = await api('/api/looks', { name, config });
      const look = r.look;
      if (!look) throw new Error(i18n.t('looks.m.saveFailed'));
      setCustomLooks((looks) => [look, ...looks]);
      setLookName('');
      setMessage(i18n.t('looks.m.saved'));
    } catch (e) {
      setError((e as Error).message);
    }
  }
  async function deleteLook(id: string) {
    try {
      const r = await fetch('/api/looks?id=' + encodeURIComponent(id), {
        method: 'DELETE',
        headers: { Origin: location.origin },
      });
      if (!r.ok) throw new Error(i18n.t('looks.m.deleteFailed'));
      setCustomLooks((looks) => looks.filter((look) => look.id !== id));
    } catch (e) {
      setError((e as Error).message);
    }
  }
  async function pinLook(look: CustomLook) {
    try {
      const r = await api('/api/looks', {
        action: 'pin',
        id: look.id,
        pinned: !look.pinned,
      });
      if (!r) return;
      setCustomLooks((looks) =>
        looks.map((item) =>
          item.id === look.id
            ? {
                ...item,
                pinned: look.pinned ? 0 : 1,
                pinned_at: look.pinned ? null : (r.pinned_at ?? null),
              }
            : item,
        ),
      );
    } catch (e) {
      setError((e as Error).message);
    }
  }
  async function activateLook(look: CustomLook) {
    const previous = config;
    persisting.current = true;
    persistRevision.current += 1;
    configRef.current = look.config;
    setConfig(look.config);
    try {
      await api('/api/studio', { config: look.config });
      const nextSaved = JSON.stringify(look.config);
      savedRef.current = nextSaved;
      setSaved(nextSaved);
      setMessage(i18n.t('looks.m.live', { name: look.name }));
    } catch (e) {
      configRef.current = previous;
      setConfig(previous);
      setError((e as Error).message);
    } finally {
      persisting.current = false;
    }
  }
  function exportLook(look: CustomLook) {
    const blob = new Blob(
      [
        JSON.stringify(
          {
            format: 'resonance-look',
            version: 1,
            name: look.name,
            config: look.config,
            exportedAt: new Date().toISOString(),
          },
          null,
          2,
        ),
      ],
      { type: 'application/json' },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `resonance-look-${
      look.name
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '') || 'custom-look'
    }.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
  async function importLook(file: File) {
    try {
      const parsed: unknown = JSON.parse(await file.text());
      if (!isRecord(parsed)) throw new Error(i18n.t('looks.m.fileInvalid'));
      if (parsed.format !== 'resonance-look')
        throw new Error(i18n.t('looks.m.notLookFile'));
      if (parsed.version !== 1)
        throw new Error(
          i18n.t('looks.m.newerFile'),
        );
      const data: ResonanceLookFile = {
        format: 'resonance-look',
        version: 1,
        name: typeof parsed.name === 'string' ? parsed.name : '',
        config: parsed.config,
      };
      if (!data.name.trim() || !isRecord(data.config))
        throw new Error(i18n.t('looks.m.incomplete'));
      const r = await api('/api/looks', {
        name: data.name,
        config: data.config,
        import: true,
      });
      const look = r.look;
      if (!look) throw new Error(i18n.t('looks.m.importFailed'));
      setCustomLooks((looks) => [look, ...looks]);
      const fonts = [
        data.config.titleFont,
        data.config.artistFont,
        data.config.metaFont,
      ];
      if (
        fonts.some(
          (font) =>
            typeof font === 'string' &&
            font.startsWith('custom:') &&
            !customFonts.some((item) => `custom:${item.id}` === font),
        )
      )
        setMessage(
          i18n.t('looks.m.importedFont'),
        );
      else setMessage(i18n.t('looks.m.imported'));
    } catch (e) {
      setError((e as Error).message || i18n.t('looks.m.importFailed'));
    }
  }
  async function connect() {
    setBusy(true);
    setError('');
    try {
      const d = await api('/api/spotify/start', {});
      window.location.assign(d.url);
    } catch (e) {
      setError((e as Error).message);
      setBusy(false);
    }
  }
  async function disconnect() {
    setBusy(true);
    try {
      await api('/api/studio', { action: 'disconnect' });
      setConnected(false);
      setDemoMode(true);
      setTrack(null);
      setMessage(i18n.t('st.spotifyWurdeGetrennt'));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function copy(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      setMessage(i18n.t('st.inDieZwischenablageKopiert'));
    } catch {
      setError(i18n.t('st.bitteMarkiereDieAdresseUnd'));
    }
  }
  async function reloadCustomFonts() {
    const r = await fetch('/api/fonts');
    if (!r.ok) return;
    const d = (await r.json()) as { fonts?: CustomFontMeta[] };
    setCustomFonts(d.fonts || []);
  }
  async function uploadFont(file: File, target: 'title' | 'artist' | 'meta') {
    const fontKey = `${target}Font` as 'titleFont' | 'artistFont' | 'metaFont';
    setUploading(true);
    setError('');
    try {
      const fd = new FormData();
      fd.append('file', file);
      const r = await fetch('/api/fonts', { method: 'POST', body: fd });
      const d = (await r.json()) as {
        error?: string;
        duplicate?: boolean;
        message?: string;
        font?: CustomFontMeta;
      };
      if (!r.ok) throw new Error(d.error || i18n.t('st.uploadFehlgeschlagen'));
      if (d.duplicate) {
        // Font NICHT neu anwenden, wenn er schon angewendet ist; sonst anwenden
        if (d.font)
          update(fontKey, ('custom:' + d.font.id) as Config[typeof fontKey]);
        setMessage(
          (d.message || i18n.t('st.dieserFontIstSchonHochgeladen')) +
            i18n.t('st.designSpeichernUmDieAuswahl'),
        );
        return;
      }
      await reloadCustomFonts();
      if (d.font)
        update(fontKey, ('custom:' + d.font.id) as Config[typeof fontKey]);
      setMessage(
        i18n.t('st.fontHochgeladenUndAngewendetDesign'),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setUploading(false);
    }
  }
  async function doDeleteFont(id: string) {
    setBusy(true);
    setError('');
    try {
      const r = await fetch('/api/fonts/' + id, { method: 'DELETE' });
      const d = (await r.json()) as { error?: string };
      if (!r.ok) throw new Error(d.error || i18n.t('st.loeschenFehlgeschlagen'));
      await reloadCustomFonts();
      setMessage(i18n.t('st.fontGeloescht'));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  function requestDeleteFont(id: string, name: string) {
    const used =
      config.titleFont === 'custom:' + id ||
      config.artistFont === 'custom:' + id ||
      config.metaFont === 'custom:' + id;
    if (used) {
      setDeleteConfirm({ id, name });
      return;
    }
    void doDeleteFont(id);
  }
  async function confirmDeleteFont() {
    if (!deleteConfirm) return;
    const { id } = deleteConfirm;
    setDeleteConfirm(null);
    // Fallback: verwendete Felder auf Inter ('sans') zurücksetzen.
    const usedKeys = (['titleFont', 'artistFont', 'metaFont'] as const).filter(
      (k) => config[k] === 'custom:' + id,
    );
    if (usedKeys.length > 0) {
      setConfig((c) => {
        const next = { ...c };
        for (const k of usedKeys) next[k] = 'sans';
        return next;
      });
    }
    await doDeleteFont(id);
  }
  async function openMoodSettings() {
    setMoodSettingsOpen(true);
    setLastfmTest('');
    setGeniusTest('');
    setError('');
    try {
      const r = await fetch('/api/mood/settings');
      if (!r.ok) return;
      const d = (await r.json()) as {
        lastfmConfigured?: boolean;
        geniusConfigured?: boolean;
      };
      setLastfmConfigured(!!d.lastfmConfigured);
      setGeniusConfigured(!!d.geniusConfigured);
    } catch {
      // Status bleibt unverändert
    }
  }
  async function saveMoodCredential(provider: 'lastfm' | 'genius') {
    setMoodBusy(true);
    setError('');
    try {
      const body =
        provider === 'lastfm'
          ? { lastfmApiKey: lastfmKey.trim() }
          : { geniusAccessToken: geniusToken.trim() };
      const r = await fetch('/api/mood/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const d = (await r.json()) as {
        error?: string;
        lastfmConfigured?: boolean;
        geniusConfigured?: boolean;
      };
      if (!r.ok) throw new Error(d.error || i18n.t('setup.err.save'));
      setLastfmConfigured(!!d.lastfmConfigured);
      setGeniusConfigured(!!d.geniusConfigured);
      setMessage(
        provider === 'lastfm'
          ? i18n.t('setup.lastfm.saved')
          : i18n.t('setup.genius.saved'),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setMoodBusy(false);
    }
  }
  async function removeMoodCredential(provider: 'lastfm' | 'genius') {
    setMoodBusy(true);
    setError('');
    try {
      const body =
        provider === 'lastfm'
          ? { lastfmApiKey: '' }
          : { geniusAccessToken: '' };
      const r = await fetch('/api/mood/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const d = (await r.json()) as {
        error?: string;
        lastfmConfigured?: boolean;
        geniusConfigured?: boolean;
      };
      if (!r.ok) throw new Error(d.error || i18n.t('setup.err.remove'));
      setLastfmConfigured(!!d.lastfmConfigured);
      setGeniusConfigured(!!d.geniusConfigured);
      if (provider === 'lastfm') setLastfmKey('');
      else setGeniusToken('');
      setMessage(
        provider === 'lastfm'
          ? i18n.t('setup.lastfm.removed')
          : i18n.t('setup.genius.removed'),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setMoodBusy(false);
    }
  }
  async function testMoodCredential(provider: 'lastfm' | 'genius') {
    const setTest = provider === 'lastfm' ? setLastfmTest : setGeniusTest;
    setTest('testing');
    setError('');
    try {
      const r = await fetch('/api/mood/settings/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider }),
      });
      const d = (await r.json()) as {
        error?: string;
        status?: 'connected' | 'invalid' | 'unavailable';
      };
      if (!r.ok) throw new Error(d.error || i18n.t('setup.err.test'));
      setTest(d.status || 'unavailable');
    } catch (e) {
      setTest('unavailable');
      setError((e as Error).message);
    }
  }
  function range(
    k:
      | 'radius'
      | 'opacity'
      | 'width'
      | 'spacing'
      | 'fontSize'
      | 'moodIntensity'
      | 'glassOpacity'
      | 'glassTintStrength'
      | 'glassHighlight'
      | 'spinSpeed'
      | 'ledBrightness'
      | 'ledGlow'
      | 'ledSize'
      | 'ledOffsetX'
      | 'ledOffsetY'
      | 'displayBrightness'
      | 'textGlow'
      | 'progressEdge'
      | 'progressWidth'
      | 'progressThickness'
      | 'progressOffsetX'
      | 'progressOffsetY'
      | 'progressRadius'
      | 'controlsSize'
      | 'controlsIconSize'
      | 'controlsGap'
      | 'controlsOffsetX'
      | 'controlsOffsetY'
      | 'coverBrightness'
      | 'coverSaturation'
      | 'coverContrast'
      | 'coverSize'
      | 'coverOffsetX'
      | 'coverOffsetY'
      | 'coverRadius'
      | 'noteSize'
      | 'noteOffsetX'
      | 'noteOffsetY'
      | 'noteRotation'
      | 'noteOpacity'
      | 'titleOffsetX'
      | 'titleOffsetY'
      | 'artistOffsetX'
      | 'artistOffsetY'
      | 'metaOffsetX'
      | 'metaOffsetY'
      | 'titleArtistSpacing'
      | 'scanlineStrength'
      | 'grainStrength'
      | 'vignetteStrength'
      | 'titleSize'
      | 'artistSize'
      | 'metaSize'
      | 'titleLetterSpacing'
      | 'artistLetterSpacing'
      | 'metaLetterSpacing'
      | 'lolSplashDim'
      | 'shelfCount',
    label: string,
    min: number,
    max: number,
    unit: string,
  ) {
    return (
      <div className="range-control" data-field={k}>
        <div className="range-label">
          <span>{label}</span>
          <code>
            {config[k]} {unit}
          </code>
        </div>
        <Slider
          aria-label={label}
          value={[config[k]]}
          min={min}
          max={max}
          onPointerDown={beginSlider}
          onValueChange={(v) => updateSlider(k, Array.isArray(v) ? v[0] : v)}
          onValueCommitted={commitSlider}
        />
      </div>
    );
  }
  function toggle(
    k:
      | 'glow'
      | 'cover'
      | 'progress'
      | 'artist'
      | 'badge'
      | 'hidePaused'
      | 'moodSwitch'
      | 'spin'
      | 'scanlinesEnabled'
      | 'grainEnabled'
      | 'linkAccentColors'
      | 'autoAccentFromCover'
      | 'titleAccent'
      | 'visualizerVisible'
      | 'controlsVisible'
      | 'volumeVisible'
      | 'gameLevel'
      | 'gameRarity'
      | 'gameCombo'
      | 'gameQuest'
      | 'gameAchievements'
      | 'gameParty'
      | 'gelAnimation'
      | 'albumVisible'
      | 'stickyTilt'
      | 'stickySlap'
      | 'lolSplash'
      | 'lolSplashMotion'
      | 'lolMain'
      | 'lolRank'
      | 'lolTicker'
      | 'valoAgentVisible'
      | 'shelfLean'
      | 'shelfLabel'
      | 'shelfReflection'
      | 'shelfDisc'
      | 'shelfDiscSpin'
      | 'shelfGlint'
      | 'shelfOpen'
      | 'valoNameVisible'
      | 'valoShards'
      | 'valoMatch'
      | 'valoRank'
      | 'valoTicker',
    label: string,
  ) {
    return (
      <div className="switch-row" key={k} data-field={k}>
        <label htmlFor={k}>{label}</label>
        <Switch
          id={k}
          checked={config[k]}
          onCheckedChange={(v) => update(k, v)}
        />
      </div>
    );
  }
  function renderLedPanel() {
    const ledHidden = !(config.ledVisible && config.ledBehavior !== 'off');
    return (
      <div className="context-transition">
        <div
          className={'led-preview' + (config.moodSwitch ? ' led-muted' : '')}
          data-led-preview="playing"
          data-led-behavior={
            config.ledVisible && config.ledBehavior !== 'off'
              ? config.ledBehavior
              : 'off'
          }
          style={
            {
              '--memory-led-user-color': config.ledColor,
              '--memory-led-user-brightness': config.ledBrightness / 100,
              '--memory-led-user-glow': config.ledGlow / 100,
              '--memory-led-user-speed':
                (8 - (config.ledSpeed / 100) * 5.5).toFixed(2) + 's',
            } as CSSProperties
          }
        >
          <div className="led-preview-stage">
            <i className="memory-led" />
          </div>
          <div className="led-preview-meta">
            <span className="led-preview-title">{i18n.t('st.ledVorschau')}</span>
            <span className="led-preview-behavior">
              {
                LED_BEHAVIOR_LABELS[
                  config.ledVisible && config.ledBehavior !== 'off'
                    ? config.ledBehavior
                    : 'off'
                ]
              }
            </span>
          </div>
        </div>
        <div
          className={'switch-row' + (config.moodSwitch ? ' led-muted' : '')}
          data-field="ledVisible"
        >
          <label htmlFor="ledVisible">{i18n.t('st.ledSichtbar')}</label>
          <Switch
            id="ledVisible"
            checked={config.ledVisible && config.ledBehavior !== 'off'}
            onCheckedChange={(v) => {
              update('ledVisible', v);
              if (v && config.ledBehavior === 'off')
                update('ledBehavior', 'soft');
            }}
          />
        </div>
        <div
          className={
            'led-controls' +
            (config.moodSwitch || ledHidden ? ' led-muted' : '')
          }
        >
          <label className="color-field" data-field="ledColor">
            <span>{i18n.t('st.ledFarbe')}</span>
            <code>{config.ledColor}</code>
            <input
              aria-label={i18n.t('st.ledFarbe')}
              type="color"
              value={config.ledColor}
              onChange={(e) => update('ledColor', e.target.value)}
            />
          </label>
          <Picker
            label={i18n.t('st.ledVerhalten')}
            field="ledBehavior"
            value={config.ledBehavior}
            options={[
              ['solid', 'Solid'],
              ['soft', 'Soft Pulse'],
              ['breathe', 'Breathe'],
              ['double', 'Double Pulse'],
              ['heartbeat', 'Heartbeat'],
              ['flicker', 'Flicker'],
            ]}
            onChange={(v) => update('ledBehavior', v)}
          />
          {range('ledBrightness', i18n.t('st.helligkeit'), 10, 100, '%')}
          {range('ledGlow', 'Glow', 0, 100, '%')}
          <div className="range-control" data-field="ledSpeed">
            <div className="range-label">
              <span>{i18n.t('st.tempo')}</span>
              <code>
                {config.ledSpeed <= 33
                  ? i18n.t('wall.o.slow')
                  : config.ledSpeed <= 66
                    ? 'Normal'
                    : i18n.t('wall.o.fast')}
              </code>
            </div>
            <Slider
              aria-label={i18n.t('st.ledTempo')}
              value={[config.ledSpeed]}
              min={0}
              max={100}
              onValueChange={(v) =>
                update('ledSpeed', Array.isArray(v) ? v[0] : v)
              }
            />
          </div>
          <Disclosure title={i18n.t('st.feinjustierung')}>
            {range('ledSize', i18n.t('st.groesse'), 80, 120, '%')}
            {range('ledOffsetX', 'Horizontal', -8, 8, 'px')}
            {range('ledOffsetY', i18n.t('st.vertikal'), -8, 8, 'px')}
            <button
              type="button"
              className="context-reset"
              onClick={() =>
                setConfig((current) => ({
                  ...current,
                  ledSize: defaults.ledSize,
                  ledOffsetX: defaults.ledOffsetX,
                  ledOffsetY: defaults.ledOffsetY,
                }))
              }
            >
              {i18n.t('st.ledPositionZuruecksetzen')}
            </button>
          </Disclosure>
        </div>
        {config.moodSwitch && (
          <small className="led-hint">
            {i18n.t('st.solangeMoodAktivIstSteuert2')}
          </small>
        )}
      </div>
    );
  }
  function renderDisplayPanel() {
    return (
      <div className="context-transition">
        <div
          className={'led-controls' + (config.moodSwitch ? ' led-muted' : '')}
        >
          <label className="color-field" data-field="displayColor">
            <span>{i18n.t('st.displayFarbe')}</span>
            <code>{config.displayColor}</code>
            <input
              aria-label={i18n.t('st.displayFarbe')}
              type="color"
              value={config.displayColor}
              onChange={(e) => update('displayColor', e.target.value)}
            />
          </label>
          {range('displayBrightness', i18n.t('st.helligkeit'), 20, 100, '%')}
          {range('textGlow', 'Text Glow', 0, 100, '%')}
          {toggle('scanlinesEnabled', 'Scanlines')}
          <div className={config.scanlinesEnabled ? '' : 'led-muted'}>
            {range('scanlineStrength', i18n.t('st.scanlineStaerke'), 0, 100, '%')}
          </div>
          {toggle('grainEnabled', 'Grain')}
          <div className={config.grainEnabled ? '' : 'led-muted'}>
            {range('grainStrength', i18n.t('st.grainStaerke'), 0, 100, '%')}
          </div>
          {range('vignetteStrength', 'Vignette', 0, 100, '%')}
        </div>
        {config.moodSwitch && (
          <small className="led-hint">
            {i18n.t('st.solangeMoodAktivIstSteuert')}
          </small>
        )}
      </div>
    );
  }
  function renderTypographyPanel(target: 'title' | 'artist' | 'meta') {
    const fontKey = `${target}Font` as 'titleFont' | 'artistFont' | 'metaFont';
    const weightKey = `${target}Weight` as
      | 'titleWeight'
      | 'artistWeight'
      | 'metaWeight';
    const sizeKey = `${target}Size` as 'titleSize' | 'artistSize' | 'metaSize';
    const lsKey = `${target}LetterSpacing` as
      | 'titleLetterSpacing'
      | 'artistLetterSpacing'
      | 'metaLetterSpacing';
    const caseKey = `${target}Case` as 'titleCase' | 'artistCase' | 'metaCase';
    const currentFont = config[fontKey] as string;
    const currentWeight = config[weightKey] as number;
    const currentFontDef = FONT_LIBRARY.find((f) => f.id === currentFont);
    const fontOptions: [string, string][] = [
      ...FONT_LIBRARY.map(
        (f) => [f.id, f.name + ' · ' + f.category] as [string, string],
      ),
      ...customFonts.map(
        (f) => ['custom:' + f.id, f.name + ' · Custom'] as [string, string],
      ),
    ];
    return (
      <>
        {canEdit(fontKey) && (
          <>
            <Picker
              label={i18n.t('st.schrift')}
              field={fontKey}
              value={currentFont}
              options={fontOptions}
              onChange={(v) => update(fontKey, v)}
            />
            <button
              type="button"
              className="upload-font-button"
              onClick={() => {
                setPendingUploadTarget(target);
                fileInputRef.current?.click();
              }}
            >
              <Plus size={13} />
              {i18n.t('st.eigenenFontHochladen')}
            </button>
            {uploading && <p className="upload-status">{i18n.t('st.laedtHoch')}</p>}
            {customFonts.length > 0 && (
              <div className="custom-font-list">
                <span className="custom-font-list-label">{i18n.t('st.eigeneFonts')}</span>
                {customFonts.map((f) => (
                  <div key={f.id} className="custom-font-row">
                    <span className="custom-font-name" title={f.name}>
                      {f.name}
                    </span>
                    <button
                      className="custom-font-delete"
                      aria-label={i18n.t('st.fontLoeschen2') + f.name}
                      onClick={() => requestDeleteFont(f.id, f.name)}
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
        {canEdit(weightKey) && (
          <Picker
            label={i18n.t('st.staerke')}
            field={weightKey}
            value={String(currentWeight)}
            options={(currentFontDef?.weights || [400]).map((w) => [
              String(w),
              String(w),
            ])}
            onChange={(v) => update(weightKey, Number(v))}
          />
        )}
        {canEdit(sizeKey) &&
          range(
            sizeKey,
            i18n.t('st.groesse'),
            target === 'title' ? 14 : target === 'artist' ? 10 : 8,
            target === 'title' ? 48 : 24,
            'px',
          )}
        {(canEdit(lsKey) || canEdit(caseKey)) && (
          <Disclosure title={i18n.t('st.laufweiteSchreibweise')}>
            {canEdit(lsKey) && range(lsKey, i18n.t('st.laufweite'), -2, 6, 'px')}
            {canEdit(caseKey) && (
          <Picker
            label={i18n.t('st.schreibweise')}
            field={caseKey}
            value={config[caseKey] as string}
            options={[
              ['normal', 'Normal'],
              ['uppercase', 'UPPERCASE'],
            ]}
            onChange={(v) => update(caseKey, v)}
          />
            )}
          </Disclosure>
        )}
      </>
    );
  }
  function renderGlassMaterialPanel() {
    if (!isAfterglow(config) || !canEdit('glassHighlight')) return null;
    return (
      <div className="glass-material-editor">
        <div className="context-divider" />
        <div className="glass-material-head">
          <span>Afterglow Material</span>
          <small>{i18n.t('st.obsSicheresLiquidGlass')}</small>
        </div>
        {range('glassHighlight', i18n.t('st.lichtbrechung'), 0, 100, '%')}
        <small className="context-note">
          {i18n.t('st.lichtbrechungEntstehtAusLokalenMaterialebenen')}
        </small>
      </div>
    );
  }
  function contextHead(icon: ReactNode, title: string, description: string) {
    return (
      <div className="context-panel-head">
        <span className="context-icon" aria-hidden="true">
          {icon}
        </span>
        <div>
          <small>{i18n.t('st.direktBearbeiten')}</small>
          <h3>{title}</h3>
          <p>{description}</p>
        </div>
      </div>
    );
  }
  function renderAccentField(label = i18n.t('wall.g.accent')) {
    return (
      <label className="color-field color-field-featured" data-field="accent">
        <span>{label}</span>
        <code>{config.accent}</code>
        <input
          aria-label={label}
          type="color"
          value={config.accent}
          onChange={(e) => update('accent', e.target.value)}
        />
      </label>
    );
  }
  function renderColorField(
    k: 'progressColor' | 'controlAccentColor' | 'statusAccentColor',
    label: string,
    muted = false,
  ) {
    return (
      <label
        className={
          'color-field color-field-featured' + (muted ? ' led-muted' : '')
        }
        data-field={k}
      >
        <span>{label}</span>
        <code>{config[k]}</code>
        <input
          aria-label={label}
          type="color"
          value={config[k]}
          onChange={(e) => update(k, e.target.value)}
        />
      </label>
    );
  }
  const selectedVisibilityField = selectedElement
    ? visibilityFieldFor(selectedElement, config.layout)
    : undefined;
  const selectedHidden =
    !!selectedVisibilityField &&
    canEdit(selectedVisibilityField) &&
    !config[selectedVisibilityField];
  const panelTitle = selectedElement
    ? elementName(selectedElement)
    : 'Player';
  const showTip = !tipDismissed && !selectedElement;
  const essentialsDone = (connected ? 1 : 0) + (key ? 1 : 0);
  useEffect(() => {
    if (view !== 'looks') return;
    const tick = setInterval(() => setGalleryNow(Date.now()), 1000);
    return () => clearInterval(tick);
  }, [view]);
  useEffect(() => {
    if (view !== 'looks' || !galleryAuto) return;
    const t = setTimeout(() => {
      setGalleryIdx((i) => (i + 1) % GALLERY_TRACKS.length);
      setGalleryStart(Date.now());
    }, 8000);
    return () => clearTimeout(t);
  }, [view, galleryAuto, galleryIdx]);
  const galleryBase = GALLERY_TRACKS[galleryIdx];
  const galleryTrack: Track = {
    ...galleryBase,
    progress: Math.min(
      galleryBase.duration,
      galleryBase.progress + Math.max(0, galleryNow - galleryStart),
    ),
  };
  function nextGallerySong() {
    setGalleryIdx((i) => (i + 1) % GALLERY_TRACKS.length);
    setGalleryStart(Date.now());
  }
  async function shareLook(look: CustomLook) {
    try {
      const code = await encodeLookCode(look.name, look.config);
      let copied = false;
      try {
        await navigator.clipboard.writeText(code);
        copied = true;
      } catch {}
      setCodePanel({ mode: 'share', name: look.name, code, copied });
    } catch {
      setError(i18n.t('looks.m.codeFailed'));
    }
  }
  async function readLookCode(text: string) {
    setCodePanel((p) =>
      p && p.mode === 'import' ? { ...p, text, error: '', config: null } : p,
    );
    if (!text.trim()) return;
    try {
      const d = await decodeLookCode(text);
      setCodePanel((p) =>
        p && p.mode === 'import' && p.text === text
          ? { ...p, name: p.name || d.name, config: d.config, error: '' }
          : p,
      );
    } catch (e) {
      setCodePanel((p) =>
        p && p.mode === 'import' && p.text === text
          ? { ...p, config: null, error: e instanceof LookCodeError ? i18n.t(('looks.code.' + e.code) as 'looks.code.invalid') : i18n.t('looks.code.invalid') }
          : p,
      );
    }
  }
  async function saveCodeLook() {
    if (!codePanel || codePanel.mode !== 'import' || !codePanel.config) return;
    const name = codePanel.name.trim() || i18n.t('looks.m.sharedName');
    setCodePanel({ ...codePanel, busy: true });
    try {
      const r = await api('/api/looks', {
        name,
        config: codePanel.config,
        import: true,
      });
      const look = r.look;
      if (!look) throw new Error(i18n.t('looks.m.saveFailed'));
      setCustomLooks((looks) => [look, ...looks]);
      setCodePanel(null);
      setMessage(i18n.t('looks.m.codeSaved', { name }));
    } catch (e) {
      setCodePanel((p) =>
        p && p.mode === 'import'
          ? { ...p, busy: false, error: e instanceof Error ? e.message : i18n.t('looks.m.saveFailedShort') }
          : p,
      );
    }
  }
  function applyPreset(p: (typeof presets)[number]) {
    setSelectedElement(null);
    setConfig({
      ...p.config,
      moodSwitch: config.moodSwitch,
      moodIntensity: config.moodIntensity,
    });
  }
  function loadLook(look: CustomLook) {
    setConfig(look.config);
    setSelectedElement(null);
    setMessage(
      i18n.t('looks.m.loaded', { name: look.name }),
    );
  }
  function miniPreview(
    c: Config,
    small = false,
    track: Track = { ...demo, playing: true },
  ) {
    const width = c.layout === 'memory' ? 520 : c.width;
    return (
      <div
        className={'v2-mini-stage' + (small ? ' is-small' : '')}
        aria-hidden="true"
      >
        <div
          style={
            { zoom: (small ? 150 : 240) / Math.max(280, width) } as CSSProperties
          }
        >
          <Overlay
            config={{ ...c, animation: 'none', autoAccentFromCover: false }}
            track={track}
            lang={streamLang}
          />
        </div>
      </div>
    );
  }
  function renderStatus() {
    return (
      <div className="status-area" aria-live="polite">
        {error && (
          <p className="error-message">
            {serverMsg(error)}
            <button
              type="button"
              aria-label={i18n.t('st.meldungSchliessen')}
              onClick={() => setError('')}
            >
              <X size={14} />
            </button>
          </p>
        )}
        {message && (
          <p className="success-message">
            {serverMsg(message)}
            <button
              type="button"
              aria-label={i18n.t('st.meldungSchliessen')}
              onClick={() => setMessage('')}
            >
              <X size={14} />
            </button>
          </p>
        )}
      </div>
    );
  }
  function renderSaveLookForm(compact: boolean) {
    return (
      <form
        className={'v2-save-look-form' + (compact ? ' is-compact' : '')}
        onSubmit={(e) => {
          e.preventDefault();
          void saveLook().then(() => setSaveLookOpen(false));
        }}
      >
        <input
          value={lookName}
          maxLength={50}
          autoFocus={compact}
          aria-label={i18n.t('looks.saveName')}
          placeholder={i18n.t('looks.savePlaceholder')}
          onChange={(e) => setLookName(e.target.value)}
        />
        <button type="submit" className="primary" disabled={!lookName.trim()}>
          {i18n.t('looks.save')}
        </button>
        {compact && (
          <button
            type="button"
            className="v2-icon-btn"
            aria-label={i18n.t('looks.cancel')}
            onClick={() => setSaveLookOpen(false)}
          >
            <X size={15} />
          </button>
        )}
      </form>
    );
  }
  function renderPlayerPanel() {
    return (
      <>
        {moodMode !== 'none' && (
          <div className="mood-card">
            <div className="mood-title" data-field="moodSwitch">
              <Sparkles size={17} />
              <label htmlFor="moodSwitch">Mood Switch</label>
              <Switch
                id="moodSwitch"
                checked={config.moodSwitch}
                onCheckedChange={(v) => update('moodSwitch', v)}
              />
            </div>
            <p>{i18n.t('st.deinLookFuehltMitFarben')}</p>
            {config.moodSwitch && (
              <>
                {!moodSetupDismissed &&
                  (!lastfmConfigured || !geniusConfigured) && (
                    <div className="mood-setup-hint">
                      <b>{i18n.t('st.genauereErkennung')}</b>
                      <p>
                        Last.fm {lastfmConfigured ? '✓' : i18n.t('st.nichtVerbunden')}{' '}
                        · Genius {geniusConfigured ? '✓' : '· optional'}
                      </p>
                      <button onClick={openMoodSettings}>{i18n.t('st.einrichten')}</button>
                      <button onClick={() => setMoodSetupDismissed(true)}>
                        {i18n.t('st.spaeter')}
                      </button>
                    </div>
                  )}
                <div
                  className="mood-result"
                  style={{ borderColor: detected?.mood.accent || '#54634b' }}
                >
                  <b>
                    {detected ? dynT('mood.' + detected.mood.id, detected.mood.label) : i18n.t('st.deinOriginalLook')}
                  </b>
                  <span>
                    {detected
                      ? i18n.t('st.moodEstimated', {
                          source: detected.source
                            .split('+')
                            .map((x) => dynT('mood.src.' + x.replace(/[^A-Za-z]/g, ''), x))
                            .join('+'),
                          confidence: dynT('mood.conf.' + detected.confidence, detected.confidence),
                        })
                      : i18n.t('st.keinKlaresStimmungssignal')}
                  </span>
                </div>
                {range('moodIntensity', i18n.t('st.intensitaet'), 0, 100, '%')}
                {demoMode && (
                  <button
                    className="secondary"
                    onClick={() =>
                      setDemoIndex((i) => (i + 1) % moodDemos.length)
                    }
                  >
                    <RefreshCw size={13} />
                    {i18n.t('st.naechstenDemoMoodTesten')}
                  </button>
                )}
                <button className="text-button" onClick={openMoodSettings}>
                  {i18n.t('st.moodQuellenVerwalten')}
                </button>
              </>
            )}
          </div>
        )}
        <Section title={i18n.t('st.farbe')}>
          <div className="swatches" data-field="accent">
            {['#b3f47c', '#c1a0ff', '#ffac75', '#71d6ff', '#fb88bd', '#ffffff'].map(
              (c) => (
                <button
                  key={c}
                  aria-label={i18n.t('st.akzent') + c}
                  onClick={() => update('accent', c)}
                  style={{ background: c }}
                  className={c === config.accent ? 'chosen' : ''}
                >
                  {c === config.accent && <Check size={15} />}
                </button>
              ),
            )}
          </div>
          {canEdit('accent') && renderAccentField(i18n.t('wall.g.accent'))}
          {canEdit('accent') && toggle('autoAccentFromCover', i18n.t('st.akzentAusAlbumcover'))}
          {config.autoAccentFromCover && (
            <small className="context-note">
              {i18n.t('st.folgtDemAktuellenCoverDie')}
            </small>
          )}
          {canEdit('linkAccentColors') && (
            <>
              {toggle('linkAccentColors', i18n.t('st.akzenteKoppeln'))}
              <small className="context-note">
                {i18n.t('st.einAkzentFuerTastenFortschritt')}
              </small>
            </>
          )}
          {canEdit('background') && !isAfterglow(config) && (
            <label className="color-field" data-field="background">
              <span>{config.layout === 'memory' ? i18n.t('st.gehaeusefarbe') : i18n.t('wall.g.bg')}</span>
              <code>{config.background}</code>
              <input
                aria-label={i18n.t('st.hintergrundfarbe')}
                type="color"
                value={config.background}
                onChange={(e) => update('background', e.target.value)}
              />
            </label>
          )}
          {canEdit('text') && (
            <label className="color-field" data-field="text">
              <span>{i18n.t('st.textfarbe')}</span>
              <code>{config.text}</code>
              <input
                aria-label={i18n.t('st.textfarbe')}
                type="color"
                value={config.text}
                onChange={(e) => update('text', e.target.value)}
              />
            </label>
          )}
        </Section>
        <Section title={i18n.t('st.form')}>
          {canEdit('width') && range('width', i18n.t('st.breite'), 280, 900, 'px')}
          {canEdit('spacing') && range('spacing', i18n.t('st.innenabstand'), 8, 48, 'px')}
          {canEdit('radius') && range('radius', i18n.t('st.rundung'), 0, 40, 'px')}
          {canEdit('opacity') &&
            !isAfterglow(config) &&
            range('opacity', i18n.t('st.deckkraft'), 0, 100, '%')}
          {canEdit('glow') &&
            config.layout !== 'memory' &&
            toggle('glow', i18n.t('st.sanfterGlow'))}
          {canEdit('align') && (
            <Picker
              label={i18n.t('st.textausrichtung')}
              field="align"
              value={config.align}
              options={[
                ['left', i18n.t('st.links')],
                ['center', i18n.t('st.zentriert')],
              ]}
              onChange={(v) => update('align', v)}
            />
          )}
          {renderGlassMaterialPanel()}
          {canEdit('bodyStyle') && BODY_STYLES[config.layout] && (
            <Picker
              label={
                config.layout === 'sticker'
                  ? i18n.t('st.papierfarben')
                  : config.layout === 'shelf'
                    ? i18n.t('st.cdHuelle')
                    : i18n.t('st.gehaeuse')
              }
              field="bodyStyle"
              value={config.bodyStyle}
              options={BODY_STYLES[config.layout].map(([v, l]) => [v, dynT('body.' + config.layout + '.' + v, l)] as [string, string])}
              onChange={(v) => update('bodyStyle', v)}
            />
          )}
          {canEdit('stickyStack') && (
            <Picker
              label={i18n.t('st.stapel')}
              field="stickyStack"
              value={String(config.stickyStack)}
              options={[
                ['0', i18n.t('st.keinStapel')],
                ['1', '1 Zettel darunter'],
                ['2', '2 Zettel darunter'],
              ]}
              onChange={(v) => update('stickyStack', Number(v))}
            />
          )}
          {canEdit('stickyTilt') && toggle('stickyTilt', i18n.t('st.schraeglage'))}
        </Section>
        {canEdit('stickySlap') && (
          <Section title={i18n.t('st.besonderheit')}>
            {toggle('stickySlap', i18n.t('st.neuerZettelProSong'))}
            <small className="context-note">
              {i18n.t('st.beiJedemSongwechselWirdEin')}
            </small>
          </Section>
        )}
        {canEdit('shelfOpen') && (
          <Section title={i18n.t('st.besonderheit')}>
            {toggle('shelfOpen', i18n.t('st.huelleKlapptBeiSongwechselAuf'))}
            {toggle('shelfGlint', i18n.t('st.lichtreflexAufDerHuelle'))}
            <small className="context-note">
              {i18n.t('st.jederSongStecktInSeiner')}
            </small>
          </Section>
        )}
        {canEdit('valoAgentVisible') && (
          <Section title="Agent & Look">
            {toggle('valoAgentVisible', i18n.t('st.agentPortrait'))}
            <Picker
              label="Agent"
              field="valoAgent"
              value={config.valoAgent || 'auto'}
              options={[
                ['auto', i18n.t('st.automatischDeinMain')],
                ...(config.valoAgent &&
                !valoAgents.some((x) => x[0] === config.valoAgent)
                  ? [
                      [
                        config.valoAgent,
                        config.valoAgentName || i18n.t('st.gewaehlterAgent'),
                      ] as [string, string],
                    ]
                  : []),
                ...valoAgents,
              ]}
              onChange={(v) =>
                setConfig((current) => ({
                  ...current,
                  valoAgent: v === 'auto' ? '' : v,
                  valoAgentName:
                    v === 'auto' ? '' : valoAgents.find((x) => x[0] === v)?.[1] || '',
                }))
              }
            />
            {toggle('valoNameVisible', i18n.t('st.agentNameGross'))}
            {toggle('valoShards', i18n.t('st.splitterImHintergrund'))}
            {toggle('valoMatch', i18n.t('st.letztesMatch'))}
            <small className="context-note">
              {i18n.t('st.besonderheitDeinMeistgespielterAgentDer')}
            </small>
          </Section>
        )}
        {canEdit('lolSplash') && (
          <Section title={i18n.t('st.hintergrundMain')}>
            {toggle('lolSplash', i18n.t('st.splashArtImHintergrund'))}
            {config.lolSplash && (
              <>
                <Picker
                  label="Champ"
                  field="lolChamp"
                  value={config.lolChamp || 'auto'}
                  options={[
                    ['auto', i18n.t('st.automatischDeinMain')],
                    ...(config.lolChamp &&
                    !lolChamps.some((x) => x[0] === config.lolChamp)
                      ? [
                          [
                            config.lolChamp,
                            config.lolChampName || config.lolChamp,
                          ] as [string, string],
                        ]
                      : []),
                    ...lolChamps,
                  ]}
                  onChange={(v) =>
                    setConfig((current) => ({
                      ...current,
                      lolChamp: v === 'auto' ? '' : v,
                      lolChampName:
                        v === 'auto'
                          ? ''
                          : lolChamps.find((x) => x[0] === v)?.[1] || v,
                    }))
                  }
                />
                {range('lolSplashDim', i18n.t('st.abdunkeln'), 0, 80, '%')}
                {toggle('lolSplashMotion', i18n.t('st.langsameBewegung'))}
              </>
            )}
            {toggle('lolMain', i18n.t('st.mainChampUntenLinks'))}
            <small className="context-note">
              {i18n.t('st.besonderheitDieSplashArtDeines')}
            </small>
          </Section>
        )}
        {canEdit('gelAnimation') && (
          <Section title={i18n.t('st.besonderheit')}>
            {toggle('gelAnimation', i18n.t('st.aquaGel'))}
            <small className="context-note">
              {i18n.t('st.wanderndeBonbonStreifenImFortschrittsbalken')}
            </small>
          </Section>
        )}
        {canEdit('gameLevel') && (
          <Section title={i18n.t('st.spielmechanik')}>
            {toggle('gameLevel', i18n.t('st.levelLevelUp'))}
            {toggle('gameRarity', i18n.t('st.seltenheitAmCover'))}
            {toggle('gameCombo', i18n.t('st.comboZaehler'))}
            {toggle('gameQuest', 'Quests')}
            {toggle('gameAchievements', i18n.t('st.erfolge'))}
            {toggle('gameParty', i18n.t('st.partyLetzteSongs'))}
            <small className="context-note">
              {i18n.t('st.allesAusEchtenWiedergabedatenLieblingssong')}
            </small>
          </Section>
        )}
        <Section title={i18n.t('looks.songChange')}>
          <Picker
            label={i18n.t('st.uebergang')}
            field="animation"
            value={config.animation}
            options={[
              ['fade', i18n.t('st.sanftEinblenden')],
              ['slide', i18n.t('st.hineingleiten')],
              ['zoom', 'Pop-in'],
              ['blur', i18n.t('st.ausDerUnschaerfe')],
              ['flip', '3D-Flip'],
              ['none', i18n.t('st.ohneAnimation')],
            ]}
            onChange={(v) => update('animation', v)}
          />
          {toggle('hidePaused', i18n.t('st.beiPauseAusblenden'))}
        </Section>
        {config.layout === 'memory' && (
          <Disclosure title={i18n.t('st.beobachtetePlaylist')}>
            <div className="playlist-picker" data-field="observedPlaylistId">
              <span>Playlist</span>
              <Select
                value={config.observedPlaylistId}
                onValueChange={(v) => {
                  if (!v || v === '__none__') {
                    update('observedPlaylistId', '');
                    update('observedPlaylistName', '');
                  } else {
                    const p = playlists.find((p) => p.id === v);
                    update('observedPlaylistId', v);
                    update('observedPlaylistName', p?.name || '');
                  }
                }}
              >
                <SelectTrigger aria-label={i18n.t('st.beobachtetePlaylist')}>
                  <SelectValue>
                    {config.observedPlaylistId
                      ? playlists.find(
                          (p) => p.id === config.observedPlaylistId,
                        )?.name || config.observedPlaylistName
                      : i18n.t('st.keinePlaylist')}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">{i18n.t('st.keinePlaylist')}</SelectItem>
                  {playlists.map((p) => (
                    <SelectItem
                      key={p.id}
                      value={p.id}
                      disabled={!canObserve(p)}
                    >
                      {p.image && (
                        <img src={p.image} alt="" className="playlist-cover" />
                      )}
                      {p.name}
                      {!canObserve(p) && (
                        <Lock size={12} className="playlist-access-mark" />
                      )}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {!connected && (
                <small>{i18n.t('st.verbindeSpotifyUmEinePlaylist')}</small>
              )}
              {config.observedPlaylistId &&
                selectedObserved &&
                !canObserve(selectedObserved) && (
                  <small className="playlist-access-warn">
                    {i18n.t('st.nurEigeneOderGemeinsamePlaylists')}
                  </small>
                )}
              {track?.playlistAccess === 'denied' && (
                <small className="playlist-access-warn">
                  {i18n.t('st.keinZugriffAufDiesePlaylist')}
                </small>
              )}
              {track?.playlistAccess === 'rate_limited' && (
                <small className="playlist-access-warn">
                  {i18n.t('st.spotifyLimitErreichtDerStatus')}
                </small>
              )}
              <div className="playlist-api-hint">
                <Info size={13} className="playlist-api-hint-icon" />
                <span>
                  {i18n.t('st.derMemorySlotFragtSpotify')}
                </span>
              </div>
            </div>
          </Disclosure>
        )}
        {isAfterglow(config) && (
          <Disclosure title={i18n.t('st.enhancedBlurFuerObs')}>
            <section className="afterglow-blur-card">
              <p>
                {i18n.t('st.optionalAfterglowFunktioniertBereitsAls')}
              </p>
              <div className="afterglow-blur-actions">
                <a href="/api/downloads/resonance-blur-follow" download>
                  <Download size={14} aria-hidden="true" />
                  {i18n.t('st.blurCompanionHerunterladen')}
                </a>
                <button
                  type="button"
                  disabled={!key || dirty}
                  title={
                    !key
                      ? i18n.t('st.maskenUrlWirdVorbereitet')
                      : dirty
                        ? i18n.t('st.speichereDeinDesignVorDem')
                        : i18n.t('st.maskenUrlKopieren')
                  }
                  onClick={() => copy(afterglowMaskUrl)}
                >
                  <Copy size={14} aria-hidden="true" />
                  {i18n.t('st.maskenUrlKopieren')}
                </button>
              </div>
              <details className="afterglow-blur-guide">
                <summary>{i18n.t('st.einrichtungAnzeigen')}</summary>
                <ol>
                  <li>{i18n.r('st.blur1')}</li>
                  <li>{i18n.r('st.blur2')}</li>
                  <li>{i18n.r('st.blur3')}</li>
                  <li>{i18n.r('st.blur4')}</li>
                  <li>{i18n.r('st.blur5')}</li>
                  <li>{i18n.r('st.blur6')}</li>
                  <li>{i18n.r('st.blur7')}</li>
                  <li>{i18n.r('st.blur8')}</li>
                  <li>{i18n.r('st.blur9')}</li>
                </ol>
              </details>
            </section>
          </Disclosure>
        )}
      </>
    );
  }
  function renderElementPanel(sel: string) {
    if (sel === 'led') return renderLedPanel();
    if (sel === 'display') return renderDisplayPanel();
    if (sel === 'title')
      return (
        <div className="context-transition">
          {renderTypographyPanel('title')}
          {config.layout !== 'memory' &&
            toggle('titleAccent', i18n.t('st.titelInAkzentfarbe'))}
          {(canEdit('titleOffsetX') ||
            canEdit('titleOffsetY') ||
            canEdit('titleArtistSpacing')) && (
            <Disclosure title={i18n.t('st.feinjustierung')}>
              {canEdit('titleOffsetX') &&
                range('titleOffsetX', 'Horizontal', -8, 8, 'px')}
              {canEdit('titleOffsetY') &&
                range('titleOffsetY', i18n.t('st.vertikal'), -6, 6, 'px')}
              {canEdit('titleArtistSpacing') &&
                range(
                  'titleArtistSpacing',
                  i18n.t('st.abstandZumInterpreten'),
                  0,
                  8,
                  'px',
                )}
              <button
                type="button"
                className="context-reset"
                onClick={() =>
                  setConfig((current) => ({
                    ...current,
                    titleOffsetX: defaults.titleOffsetX,
                    titleOffsetY: defaults.titleOffsetY,
                  }))
                }
              >
                {i18n.t('st.titelPositionZuruecksetzen')}
              </button>
            </Disclosure>
          )}
        </div>
      );
    if (sel === 'artist')
      return (
        <div className="context-transition">
          {canEdit('albumVisible') &&
            toggle('albumVisible', i18n.t('st.albumAnzeigen'))}
          {renderTypographyPanel('artist')}
          {(canEdit('artistOffsetX') || canEdit('artistOffsetY')) && (
            <Disclosure title={i18n.t('st.feinjustierung')}>
              {canEdit('artistOffsetX') &&
                range('artistOffsetX', 'Horizontal', -8, 8, 'px')}
              {canEdit('artistOffsetY') &&
                range('artistOffsetY', i18n.t('st.vertikal'), -6, 6, 'px')}
              <button
                type="button"
                className="context-reset"
                onClick={() =>
                  setConfig((current) => ({
                    ...current,
                    artistOffsetX: defaults.artistOffsetX,
                    artistOffsetY: defaults.artistOffsetY,
                  }))
                }
              >
                {i18n.t('st.interpretPositionZuruecksetzen')}
              </button>
            </Disclosure>
          )}
        </div>
      );
    if (sel === 'display-meta')
      return (
        <div className="context-transition">
          {renderTypographyPanel('meta')}
          {canEdit('statusAccentColor') && (
            <>
              {renderColorField(
                'statusAccentColor',
                i18n.t('st.statusAkzent'),
                config.linkAccentColors,
              )}
              {config.linkAccentColors && (
                <small className="context-note">
                  {i18n.t('st.folgtDemGekoppeltenAkzentPlayer')}
                </small>
              )}
            </>
          )}
          {(canEdit('metaOffsetX') || canEdit('metaOffsetY')) && (
            <Disclosure title={i18n.t('st.feinjustierung')}>
              {canEdit('metaOffsetX') &&
                range('metaOffsetX', 'Horizontal', -8, 8, 'px')}
              {canEdit('metaOffsetY') &&
                range('metaOffsetY', i18n.t('st.vertikal'), -6, 6, 'px')}
              <button
                type="button"
                className="context-reset"
                onClick={() =>
                  setConfig((current) => ({
                    ...current,
                    metaOffsetX: defaults.metaOffsetX,
                    metaOffsetY: defaults.metaOffsetY,
                  }))
                }
              >
                {i18n.t('st.statusPositionZuruecksetzen')}
              </button>
            </Disclosure>
          )}
        </div>
      );
    if (sel === 'progress')
      return (
        <div className="context-transition">
          {canEdit('progressColor') ? (
            <>
              {renderColorField(
                'progressColor',
                i18n.t('st.farbe'),
                config.linkAccentColors,
              )}
              {config.linkAccentColors && (
                <small className="context-note">
                  {i18n.t('st.folgtDemGekoppeltenAkzentPlayer')}
                </small>
              )}
            </>
          ) : (
            <small className="context-note">
              {i18n.t('st.dieFarbeFolgtDemAkzent')}
            </small>
          )}
          {canEdit('progressEdge') &&
            range('progressEdge', i18n.t('st.lichtkante'), 0, 100, '%')}
          {(canEdit('progressWidth') ||
            canEdit('progressThickness') ||
            canEdit('progressOffsetX') ||
            canEdit('progressOffsetY') ||
            canEdit('progressRadius')) && (
            <Disclosure title={i18n.t('st.feinjustierung')}>
              {canEdit('progressWidth') &&
                range('progressWidth', i18n.t('st.breite'), 84, 100, '%')}
              {canEdit('progressThickness') &&
                range('progressThickness', i18n.t('st.staerke'), 72, 128, '%')}
              {canEdit('progressOffsetX') &&
                range('progressOffsetX', 'Horizontal', -6, 6, 'px')}
              {canEdit('progressOffsetY') &&
                range('progressOffsetY', i18n.t('st.vertikal'), -5, 5, 'px')}
              {canEdit('progressRadius') &&
                range('progressRadius', i18n.t('st.rundung'), 0, 12, 'px')}
              <button
                type="button"
                className="context-reset"
                onClick={() =>
                  setConfig((current) => ({
                    ...current,
                    progressWidth: defaults.progressWidth,
                    progressThickness: defaults.progressThickness,
                    progressOffsetX: defaults.progressOffsetX,
                    progressOffsetY: defaults.progressOffsetY,
                    progressRadius: defaults.progressRadius,
                  }))
                }
              >
                {i18n.t('st.fortschrittZuruecksetzen')}
              </button>
            </Disclosure>
          )}
        </div>
      );
    if (sel === 'shelf')
      return (
        <div className="context-transition">
          <Picker
            label="Material"
            field="shelfMaterial"
            value={config.shelfMaterial}
            options={[
              ['glass', i18n.t('shelf.o.glass')],
              ['wood', i18n.t('shelf.o.wood')],
              ['metal', i18n.t('shelf.o.metal')],
              ['none', i18n.t('st.keinBrett')],
            ]}
            onChange={(v) => update('shelfMaterial', v)}
          />
          <Picker
            label={i18n.t('st.cdsImRegal')}
            field="shelfCount"
            value={String(config.shelfCount)}
            options={[
              ['0', i18n.t('shelf.o.none')],
              ['2', '2'],
              ['4', '4'],
              ['6', '6'],
            ]}
            onChange={(v) => update('shelfCount', Number(v))}
          />
          {toggle('shelfLean', i18n.t('st.neuesteCdLehntSchraeg'))}
          {toggle('shelfLabel', i18n.t('st.beschriftungAufDerKante'))}
          {toggle('shelfReflection', i18n.t('st.spiegelungGlas'))}
          <button
            type="button"
            className="context-reset"
            onClick={async () => {
              try {
                const r = await fetch('/api/history', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ action: 'end' }),
                });
                if (!r.ok) throw new Error();
                setMessage(i18n.t('st.neuerStreamDasRegalStartet'));
              } catch {
                setError(i18n.t('st.dasRegalKonnteNichtGeleert'));
              }
            }}
          >
            {i18n.t('st.neuerStreamRegalLeeren')}
          </button>
          <small className="context-note">
            {i18n.t('st.jederSongWandertNachDem')}
          </small>
        </div>
      );
    if (sel === 'disc')
      return (
        <div className="context-transition">
          {toggle('shelfDisc', i18n.t('st.cdAnzeigen'))}
          {config.shelfDisc && toggle('shelfDiscSpin', i18n.t('st.cdDrehtSich'))}
          {config.shelfDisc &&
            config.shelfDiscSpin &&
            range('spinSpeed', i18n.t('st.eineUmdrehung'), 4, 40, 's')}
          <small className="context-note">
            {i18n.t('st.dasCoverIstAufDie')}
          </small>
        </div>
      );
    if (sel === 'rank' && config.layout === 'valo')
      return (
        <div className="context-transition">
          {toggle('valoRank', i18n.t('st.rangAnzeigen'))}
          {toggle('valoTicker', i18n.t('st.rrTickerNachJedemMatch'))}
          <small className="context-note">
            {i18n.t('st.kommtUeberHenrikdevSetupZusatz')}
          </small>
        </div>
      );
    if (sel === 'rank')
      return (
        <div className="context-transition">
          {toggle('lolRank', i18n.t('st.rangAnzeigen'))}
          <Picker
            label={i18n.t('st.warteschlange')}
            field="lolQueue"
            value={config.lolQueue}
            options={[
              ['solo', 'Solo/Duo'],
              ['flex', 'Flex'],
            ]}
            onChange={(v) => update('lolQueue', v)}
          />
          {toggle('lolTicker', i18n.t('st.lpTickerNachJedemSpiel'))}
          <small className="context-note">
            {i18n.t('st.kommtLiveAusDeinemLeague')}
          </small>
        </div>
      );
    if (sel === 'controls' && canEdit('controlsVisible'))
      return (
        <div className="context-transition">
          {toggle('controlsVisible', i18n.t('st.tastenAnzeigen'))}
          {canEdit('volumeVisible') &&
            toggle('volumeVisible', i18n.t('st.lautstaerkeAnzeigen'))}
          <small className="context-note">
            {i18n.t('st.dieTastenSindDekoIm')}
          </small>
        </div>
      );
    if (sel === 'visualizer')
      return (
        <div className="context-transition">
          <Section title={i18n.t('st.farbe')}>
            <div className="switch-row" data-field="visualizerColor">
              <label htmlFor="visualizerAccent">{i18n.t('st.akzentfarbeNutzen')}</label>
              <Switch
                id="visualizerAccent"
                checked={!config.visualizerColor}
                onCheckedChange={(v) =>
                  update('visualizerColor', v ? '' : config.accent)
                }
              />
            </div>
            {!!config.visualizerColor && (
              <label className="color-field" data-field="visualizerColor">
                <span>{i18n.t('st.visualizerFarbe')}</span>
                <code>{config.visualizerColor}</code>
                <input
                  aria-label={i18n.t('st.visualizerFarbe')}
                  type="color"
                  value={config.visualizerColor}
                  onChange={(e) => update('visualizerColor', e.target.value)}
                />
              </label>
            )}
          </Section>
          <Section title="Position">
            <Picker
              label="Position"
              field="visualizerPosition"
              value={config.visualizerPosition}
              options={[
                ['right', i18n.t('st.imDisplayObenRechts')],
                ['bottom', i18n.t('st.imDisplayUntenBreit')],
              ]}
              onChange={(v) => update('visualizerPosition', v)}
            />
          </Section>
        </div>
      );
    if (sel === 'controls')
      return (
        <div className="context-transition">
          {renderColorField(
            'controlAccentColor',
            i18n.t('st.tastenAkzent'),
            config.linkAccentColors,
          )}
          {config.linkAccentColors && (
            <small className="context-note">
              {i18n.t('st.folgtDemGekoppeltenAkzentPlayer')}
            </small>
          )}
          {canEdit('glow') && toggle('glow', i18n.t('st.sanfterTastenglow'))}
          <Disclosure title={i18n.t('st.feinjustierung')}>
            {range('controlsSize', i18n.t('st.tastengroesse'), 85, 115, '%')}
            {range('controlsIconSize', i18n.t('st.icongroesse'), 80, 120, '%')}
            {range('controlsGap', i18n.t('st.abstand'), 70, 140, '%')}
            {range('controlsOffsetX', 'Horizontal', -8, 8, 'px')}
            {range('controlsOffsetY', i18n.t('st.vertikal'), -6, 6, 'px')}
            <button
              type="button"
              className="context-reset"
              onClick={() =>
                setConfig((current) => ({
                  ...current,
                  controlsSize: defaults.controlsSize,
                  controlsIconSize: defaults.controlsIconSize,
                  controlsGap: defaults.controlsGap,
                  controlsOffsetX: defaults.controlsOffsetX,
                  controlsOffsetY: defaults.controlsOffsetY,
                }))
              }
            >
              {i18n.t('st.tastenZuruecksetzen')}
            </button>
          </Disclosure>
          <small className="context-note">
            {i18n.t('st.dieTastenSindDekoIm')}
          </small>
        </div>
      );
    if (sel === 'cover')
      return (
        <div className="context-transition">
          {canEdit('coverFilter') && (
            <Section title="Filter">
              <div className="v2-filter-grid" data-field="coverFilter">
                {Object.entries(COVER_FILTERS).map(([id, f]) => (
                  <button
                    type="button"
                    key={id}
                    className={config.coverFilter === id ? 'active' : ''}
                    aria-pressed={config.coverFilter === id}
                    onClick={() => update('coverFilter', id)}
                  >
                    <span
                      className="v2-filter-swatch"
                      style={{ filter: f.css }}
                      aria-hidden="true"
                    />
                    {dynT('filter.' + id, f.label)}
                  </button>
                ))}
              </div>
            </Section>
          )}
          {(canEdit('coverBrightness') ||
            canEdit('coverSaturation') ||
            canEdit('coverContrast')) && (
            <Section title={i18n.t('st.bild')}>
              {canEdit('coverBrightness') &&
                range('coverBrightness', i18n.t('st.helligkeit'), 40, 140, '%')}
              {canEdit('coverSaturation') &&
                range('coverSaturation', i18n.t('st.saettigung'), 0, 150, '%')}
              {canEdit('coverContrast') &&
                range('coverContrast', i18n.t('st.kontrast'), 60, 140, '%')}
            </Section>
          )}
          {canEdit('spin') && (
            <Section title={i18n.t('st.bewegung')}>
              {toggle('spin', i18n.t('st.coverDrehen'))}
              {config.spin && range('spinSpeed', i18n.t('st.eineUmdrehung'), 4, 40, 's')}
            </Section>
          )}
          {(canEdit('coverSize') ||
            canEdit('coverOffsetX') ||
            canEdit('coverOffsetY') ||
            canEdit('coverRadius') ||
            canEdit('coverFit')) && (
            <Disclosure title={i18n.t('st.feinjustierung')}>
              {canEdit('coverSize') && range('coverSize', i18n.t('st.groesse'), 84, 116, '%')}
              {canEdit('coverOffsetX') &&
                range('coverOffsetX', 'Horizontal', -8, 8, 'px')}
              {canEdit('coverOffsetY') &&
                range('coverOffsetY', i18n.t('st.vertikal'), -8, 8, 'px')}
              {canEdit('coverRadius') &&
                range('coverRadius', i18n.t('st.eckenrundung'), 0, 16, 'px')}
              {canEdit('coverFit') && (
                <Picker
                  label={i18n.t('st.bildanpassung')}
                  field="coverFit"
                  value={config.coverFit}
                  options={[
                    ['cover', i18n.t('st.fuellen')],
                    ['contain', i18n.t('st.ganzZeigen')],
                  ]}
                  onChange={(v) => update('coverFit', v)}
                />
              )}
              <button
                type="button"
                className="context-reset"
                onClick={() =>
                  setConfig((current) => ({
                    ...current,
                    coverSize: defaults.coverSize,
                    coverOffsetX: defaults.coverOffsetX,
                    coverOffsetY: defaults.coverOffsetY,
                    coverRadius: defaults.coverRadius,
                    coverFit: defaults.coverFit,
                  }))
                }
              >
                {i18n.t('st.coverZuruecksetzen')}
              </button>
            </Disclosure>
          )}
          {!canEdit('coverBrightness') && !canEdit('spin') && (
            <small className="context-note">
              {i18n.t('st.dasArtworkFolgtAutomatischDem')}
            </small>
          )}
        </div>
      );
    if (sel === 'note')
      return (
        <div className="context-transition">
          <label
            className="memory-label-editor context-label-editor"
            data-field="memoryLabel"
          >
            <span>{i18n.t('st.textAufDerNotiz')}</span>
            <input
              value={config.memoryLabel}
              maxLength={32}
              placeholder="GOOD MUSIC BETTER DAYS."
              onChange={(e) => update('memoryLabel', e.target.value)}
            />
            <small>{i18n.t('st.leerLassenUmDieNotiz')}</small>
          </label>
          <Disclosure title={i18n.t('st.feinjustierung')}>
            {range('noteSize', i18n.t('st.groesse'), 88, 112, '%')}
            {range('noteOffsetX', 'Horizontal', -8, 8, 'px')}
            {range('noteOffsetY', i18n.t('st.vertikal'), -8, 8, 'px')}
            {range('noteRotation', i18n.t('st.drehung'), -6, 6, '°')}
            {range('noteOpacity', i18n.t('st.deckkraft'), 55, 100, '%')}
            <button
              type="button"
              className="context-reset"
              onClick={() =>
                setConfig((current) => ({
                  ...current,
                  noteSize: defaults.noteSize,
                  noteOffsetX: defaults.noteOffsetX,
                  noteOffsetY: defaults.noteOffsetY,
                  noteRotation: defaults.noteRotation,
                  noteOpacity: defaults.noteOpacity,
                }))
              }
            >
              {i18n.t('st.notizZuruecksetzen')}
            </button>
          </Disclosure>
        </div>
      );
    return null;
  }
  return (
    <main className="studio v2">
      <input
        ref={fileInputRef}
        type="file"
        accept=".woff2,.woff,.ttf,.otf"
        style={{ display: 'none' }}
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = '';
          if (file && pendingUploadTarget) {
            void uploadFont(file, pendingUploadTarget);
          }
          setPendingUploadTarget(null);
        }}
      />
      <header className="topbar v2-topbar">
        <a className="brand" href="/">
          <AudioLines />
          <span>
            resonance<span className="brand-dot">.</span>
          </span>
        </a>
        <nav className="v2-nav" aria-label={i18n.t('st.bereiche')}>
          {(
            [
              ['studio', i18n.t('nav.studio')],
              ['looks', i18n.t('nav.looks')],
              ['likes', i18n.t('nav.likes')],
              ['history', i18n.t('nav.history')],
              ['setup', i18n.t('nav.setup')],
            ] as const
          ).map(([v, l]) => (
            <button
              key={v}
              type="button"
              className={view === v ? 'active' : ''}
              aria-current={view === v ? 'page' : undefined}
              onClick={() => setView(v)}
            >
              {l}
              {v === 'setup' && !setupComplete && (
                <i className="v2-nav-dot" aria-label={i18n.t('st.setupOffen')} />
              )}
            </button>
          ))}
        </nav>
        <div className="top-actions">
          <span className="demo-badge">
            <i className={connected ? 'is-connected' : ''} />
            {connected ? i18n.t('st.spotifyVerbunden') : i18n.t('st.demoModus')}
          </span>
          <WidgetMenu onBrowser={() => void openWidget()} />
          <button className="primary" onClick={() => setModal('obs')}>
            {i18n.t('st.abInObs')} <ArrowUpRight size={16} />
          </button>
        </div>
      </header>
      {view === 'studio' && (
        <div className="workspace v2-workspace">
          <section className="v2-stage-column">
            <div className="v2-stage-toolbar">
              <span className="v2-stage-name">
                {chosenName || i18n.t('st.eigenerStil')}
                <small>{config.width} px</small>
              </span>
              <div className="canvas-modes" role="group" aria-label={i18n.t('st.hintergrundDerVorschau')}>
                {[
                  ['ambient', 'Stream'],
                  ['checker', 'Transparent'],
                  ['light', i18n.t('st.hell')],
                ].map(([v, l]) => (
                  <button
                    key={v}
                    aria-pressed={canvas === v}
                    className={canvas === v ? 'active' : ''}
                    onClick={() => setCanvas(v)}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>
            <div
              ref={preview}
              data-selected={selectedElement || undefined}
              className={
                'preview-canvas canvas-' +
                canvas +
                ' allow-motion editor-selecting'
              }
              onClick={(e) => {
                const t = e.target as HTMLElement;
                for (const [name, sel] of editorTargets) {
                  if (name === 'device') continue;
                  if (t.closest(sel)) {
                    setSelectedElement(name);
                    return;
                  }
                }
                // Leere Fläche im Player oder daneben: ganzer Player.
                setSelectedElement(null);
              }}
            >
              <div className="v2-stage-hint" aria-hidden="true">
                <span className="v2-stage-hint-icon">
                  <MousePointer2 size={12} />
                </span>
                {selectedElement
                  ? i18n.t('st.duBearbeitest') +
                    panelTitle +
                    i18n.t('st.danebenKlickenGanzerPlayer')
                  : i18n.t('st.klickAufIrgendwasImPlayer')}
              </div>
              <div
                style={
                  {
                    zoom: Math.min(1, (canvasWidth - 50) / config.width),
                  } as CSSProperties
                }
              >
                <Overlay config={config} track={shown} lang={streamLang} />
              </div>
              {markerRect && (
                <div
                  className="editor-selection"
                  data-label={panelTitle}
                  style={{
                    top: markerRect.top,
                    left: markerRect.left,
                    width: markerRect.width,
                    height: markerRect.height,
                  }}
                >
                  <i className="corner tl" />
                  <i className="corner tr" />
                  <i className="corner bl" />
                  <i className="corner br" />
                </div>
              )}
              {!shown && (
                <div className="empty-track">
                  <Music2 />
                  <b>{i18n.t('st.bereitFuerDeinenNaechstenTrack')}</b>
                  <span>{i18n.t('st.starteEinenSongInSpotify')}</span>
                </div>
              )}
              {shown && !shown.playing && config.hidePaused && (
                <div className="empty-track">
                  <Pause />
                  <span>{i18n.t('st.beiPauseAusgeblendet')}</span>
                </div>
              )}
            </div>
            <div className="canvas-bottom v2-canvas-bottom">
              <div className="preview-play">
                <button
                  onClick={() =>
                    demoMode ? setDemoPlaying(!demoPlaying) : setDemoMode(true)
                  }
                  aria-label={
                    demoMode
                      ? demoPlaying
                        ? i18n.t('st.demoPausieren')
                        : i18n.t('st.demoAbspielen')
                      : i18n.t('st.demoAnzeigen')
                  }
                >
                  {demoMode && demoPlaying ? (
                    <Pause size={14} />
                  ) : (
                    <Play size={14} />
                  )}
                </button>
                <span>{demoMode ? 'Demo' : 'Spotify live'}</span>
                {connected && (
                  <button
                    className={!demoMode ? 'live-active' : ''}
                    onClick={() => setDemoMode(!demoMode)}
                  >
                    {demoMode ? i18n.t('st.liveAnsehen') : i18n.t('st.demoAnsehen')}
                  </button>
                )}
              </div>
              <button
                type="button"
                className="v2-ghost"
                onClick={() => {
                  setDemoMode(true);
                  setDemoIndex((i) => (i + 1) % moodDemos.length);
                }}
              >
                <RefreshCw size={13} />
                {i18n.t('st.songwechselTesten')}
              </button>
            </div>
            <section className="v2-styles-strip" aria-label={i18n.t('st.stile')}>
              <div className="v2-looks-strip-head">
                <b>{i18n.t('st.stile')}</b>
                <span className="v2-strip-hint">{i18n.t('st.klickZumAusprobierenSpeichernMacht')}</span>
              </div>
              <div className="preset-grid v2-preset-grid">
                {presets.map((p) => {
                  const active = isActivePreset(p);
                  return (
                    <button
                      type="button"
                      key={p.id}
                      data-preset={p.name}
                      className={'preset' + (active ? ' selected' : '')}
                      aria-pressed={active}
                      onClick={() => {
                        applyPreset(p);
                        setView('studio');
                      }}
                    >
                      <div className={'preset-art art-' + p.id} aria-hidden="true">
                        <div className="mini-chrome">
                          <i />
                          <i />
                          <i />
                        </div>
                        <span className="mini-cover" />
                        <span className="mini-lines">
                          <b />
                          <i />
                          <em />
                        </span>
                        {p.id === 'sticker' && <span className="mini-star">✦</span>}
                      </div>
                      <div className="v2-preset-name">
                        <span>{p.name}</span>
                        {active ? <Check size={14} /> : <ArrowUpRight size={14} />}
                      </div>
                      <p>{presetNote(p)}</p>
                    </button>
                  );
                })}
              </div>
            </section>
            <section className="v2-looks-strip" aria-label={i18n.t('st.deineLooks')}>
              <div className="v2-looks-strip-head">
                <b>{i18n.t('st.deineLooks')}</b>
                <button
                  type="button"
                  className="v2-ghost"
                  onClick={() => setView('looks')}
                >
                  {i18n.t('st.alleLooks')} <ArrowUpRight size={13} />
                </button>
              </div>
              <div className="v2-looks-strip-row">
                {saveLookOpen ? (
                  renderSaveLookForm(true)
                ) : (
                  <button
                    type="button"
                    className="v2-save-look"
                    onClick={() => setSaveLookOpen(true)}
                  >
                    <Plus size={15} />
                    {i18n.t('looks.saveAsLook')}
                  </button>
                )}
                {customLooks.map((look) => {
                  const live = look.id === activeLiveLookId;
                  return (
                    <button
                      type="button"
                      key={look.id}
                      className={'v2-look-chip' + (live ? ' is-live' : '')}
                      title={
                        look.pinned
                          ? i18n.t('st.liveLookLadenInDen')
                          : i18n.t('st.inDenEditorLaden')
                      }
                      onClick={() => loadLook(look)}
                    >
                      {look.pinned ? (
                        <Star size={12} fill="currentColor" aria-hidden="true" />
                      ) : null}
                      {look.name}
                      {live && <i className="v2-live-dot" aria-label="live" />}
                    </button>
                  );
                })}
                {customLooks.length === 0 && !saveLookOpen && (
                  <span className="v2-strip-empty">
                    {i18n.t('st.nochKeineLooksSpeichereDeinen')}
                  </span>
                )}
              </div>
            </section>
            {renderStatus()}
          </section>
          <aside className="inspector v2-inspector" ref={inspector} data-inspector="">
            <div className="v2-inspector-head">
              <div className="v2-inspector-title">
                {selectedElement && (
                  <button
                    type="button"
                    className="v2-icon-btn"
                    onClick={() => setSelectedElement(null)}
                    aria-label={i18n.t('st.zurueckZumGanzenPlayer')}
                  >
                    <ChevronLeft size={16} />
                  </button>
                )}
                <span>
                  <small>{selectedElement ? i18n.t('st.ausgewaehlt') : i18n.t('st.gesamterLook')}</small>
                  <b>{panelTitle}</b>
                </span>
              </div>
              {selectedVisibilityField && canEdit(selectedVisibilityField) && (
                <button
                  type="button"
                  className={'v2-eye' + (selectedHidden ? ' is-hidden' : '')}
                  data-field={selectedVisibilityField}
                  aria-pressed={!selectedHidden}
                  onClick={() =>
                    update(selectedVisibilityField, !config[selectedVisibilityField])
                  }
                >
                  {selectedHidden ? <EyeOff size={14} /> : <Eye size={14} />}
                  {selectedHidden ? i18n.t('st.ausgeblendet') : i18n.t('st.sichtbar')}
                </button>
              )}
            </div>
            <div className="v2-chips" role="tablist" aria-label={i18n.t('st.elementWaehlen')}>
              <button
                type="button"
                role="tab"
                aria-selected={!selectedElement}
                className={!selectedElement ? 'active' : ''}
                onClick={() => setSelectedElement(null)}
              >
                Player
              </button>
              {editorElements.map((el) => {
                const vis = visibilityFieldFor(el, config.layout);
                const hidden = !!vis && canEdit(vis) && !config[vis];
                return (
                  <button
                    type="button"
                    role="tab"
                    key={el}
                    aria-selected={selectedElement === el}
                    className={
                      (selectedElement === el ? 'active' : '') +
                      (hidden ? ' is-hidden' : '')
                    }
                    onClick={() => setSelectedElement(el)}
                  >
                    {elementName(el)}
                  </button>
                );
              })}
            </div>
            <div className="v2-inspector-body">
              {showTip && (
                <div className="v2-tip">
                  <span className="v2-tip-glow" aria-hidden="true" />
                  <b>
                    <Sparkles size={15} aria-hidden="true" /> {i18n.t('st.machIhnZuDeinem')}
                  </b>
                  <p>
                    {i18n.t('st.klickEinfachAufEinElement')}
                  </p>
                  <div>
                    {editorElements.includes('cover') && (
                      <button
                        type="button"
                        className="primary"
                        onClick={() => setSelectedElement('cover')}
                      >
                        {i18n.t('st.zeigMalCover')}
                      </button>
                    )}
                    <button type="button" className="v2-ghost" onClick={dismissTip}>
                      {i18n.t('st.habSVerstanden')}
                    </button>
                  </div>
                </div>
              )}
              {selectedHidden && (
                <div className="v2-hidden-note">
                  <span>{i18n.t('st.diesesElementIstGeradeAusgeblendet')}</span>
                  <button
                    type="button"
                    className="v2-ghost"
                    onClick={() =>
                      selectedVisibilityField &&
                      update(selectedVisibilityField, true)
                    }
                  >
                    {i18n.t('st.einblenden')}
                  </button>
                </div>
              )}
              <div className="v2-panel" key={selectedElement || 'player'}>
                {selectedElement
                  ? renderElementPanel(selectedElement)
                  : renderPlayerPanel()}
              </div>
            </div>
            <div className="v2-inspector-foot">
              <div className="save-row">
                <button
                  type="button"
                  className="icon-button"
                  onClick={undo}
                  disabled={!historyPast.length}
                  aria-label={i18n.t('st.rueckgaengigStrgZ')}
                  title={i18n.t('st.rueckgaengigStrgZ')}
                >
                  <RotateCcw size={16} />
                </button>
                <button
                  type="button"
                  className="icon-button"
                  onClick={redo}
                  disabled={!historyFuture.length}
                  aria-label={i18n.t('st.wiederholenStrgY')}
                  title={i18n.t('st.wiederholenStrgY')}
                >
                  <RotateCcw size={16} style={{ transform: 'scaleX(-1)' }} />
                </button>
                <button
                  className="primary"
                  disabled={busy || !ready || !dirty}
                  onClick={save}
                >
                  <Save size={16} />
                  {busy ? i18n.t('st.speichert') : i18n.t('looks.save')}
                </button>
                <button
                  className="icon-button"
                  title={i18n.t('st.aufDenStilZuruecksetzen')}
                  aria-label={i18n.t('st.aufDenStilZuruecksetzen')}
                  onClick={() => setConfig({ ...(chosen?.config || defaults) })}
                >
                  <X size={16} />
                </button>
              </div>
              <p className="save-hint">
                {!ready
                  ? i18n.t('st.studioWirdVerbunden')
                  : dirty
                    ? i18n.t('st.ungespeicherteAenderungen')
                    : i18n.t('st.gespeichertLiveInObs')}
              </p>
            </div>
          </aside>
        </div>
      )}
      {view === 'looks' && (
        <div className="v2-page">
          <div className="v2-page-head">
            <div>
              <h1>
                {i18n.t('looks.title')}<span>.</span>
              </h1>
              <p>{i18n.t('looks.subtitle')}</p>
            </div>
          </div>
          <section className="v2-looks-section" aria-label={i18n.t('looks.mine')}>
            <div className="v2-section-head">
              <h2>{i18n.t('looks.mine')}</h2>
              <div className="v2-section-actions">
                {renderSaveLookForm(false)}
                <input
                  ref={lookImportRef}
                  type="file"
                  accept="application/json,.json"
                  hidden
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) void importLook(file);
                    e.currentTarget.value = '';
                  }}
                />
                <button
                  type="button"
                  className="v2-ghost"
                  onClick={() => lookImportRef.current?.click()}
                >
                  <Upload size={14} /> {i18n.t('looks.import')}
                </button>
                <button
                  type="button"
                  className="v2-ghost"
                  onClick={() =>
                    setCodePanel({
                      mode: 'import',
                      text: '',
                      name: '',
                      config: null,
                      error: '',
                      busy: false,
                    })
                  }
                >
                  <ClipboardPaste size={14} /> {i18n.t('looks.pasteCode')}
                </button>
              </div>
            </div>
            {codePanel && (
              <div className="v2-code-panel" role="region" aria-label={i18n.t('looks.codeRegion')}>
                {codePanel.mode === 'share' ? (
                  <>
                    <div className="v2-code-head">
                      <b>{i18n.t('looks.codeFor', { name: codePanel.name })}</b>
                      <span>
                        {codePanel.copied
                          ? i18n.t('looks.copied')
                          : i18n.t('looks.selectCopy')}
                      </span>
                    </div>
                    <textarea
                      readOnly
                      value={codePanel.code}
                      onFocus={(e) => e.currentTarget.select()}
                      aria-label={i18n.t('looks.codeRegion')}
                    />
                    <p className="v2-code-note">{i18n.t('looks.codeNote')}</p>
                    <div className="v2-card-actions">
                      <button
                        type="button"
                        className="primary"
                        onClick={async () => {
                          try {
                            await navigator.clipboard.writeText(codePanel.code);
                            setCodePanel({ ...codePanel, copied: true });
                          } catch {}
                        }}
                      >
                        <Copy size={14} /> {i18n.t('looks.copy')}
                      </button>
                      <button
                        type="button"
                        className="v2-ghost"
                        onClick={() => setCodePanel(null)}
                      >
                        {i18n.t('looks.close')}
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="v2-code-head">
                      <b>{i18n.t('looks.pasteTitle')}</b>
                      <span>{i18n.t('looks.startsWith')}</span>
                    </div>
                    <textarea
                      autoFocus
                      value={codePanel.text}
                      placeholder="RSN1-…"
                      aria-label={i18n.t('looks.pasteTitle')}
                      onChange={(e) => void readLookCode(e.target.value)}
                    />
                    {codePanel.error && (
                      <p className="v2-code-error">{codePanel.error}</p>
                    )}
                    {codePanel.config && (
                      <div className="v2-code-preview">
                        {miniPreview(codePanel.config)}
                        <label>
                          <span>{i18n.t('looks.name')}</span>
                          <input
                            value={codePanel.name}
                            maxLength={60}
                            onChange={(e) =>
                              setCodePanel({ ...codePanel, name: e.target.value })
                            }
                          />
                        </label>
                      </div>
                    )}
                    <div className="v2-card-actions">
                      <button
                        type="button"
                        className="primary"
                        disabled={!codePanel.config || codePanel.busy}
                        onClick={() => void saveCodeLook()}
                      >
                        {i18n.t('looks.saveAsLook')}
                      </button>
                      <button
                        type="button"
                        className="v2-ghost"
                        onClick={() => setCodePanel(null)}
                      >
                        {i18n.t('looks.cancel')}
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}
            {customLooks.length === 0 ? (
              <p className="v2-empty">{i18n.t('looks.empty')}</p>
            ) : (
              <div className="v2-card-grid">
                {customLooks.map((look) => {
                  const live = look.id === activeLiveLookId;
                  return (
                    <article
                      className={'v2-look-card' + (live ? ' is-live' : '')}
                      key={look.id}
                    >
                      <button
                        type="button"
                        className="v2-card-preview"
                        aria-label={i18n.t('looks.loadAria', { name: look.name })}
                        onClick={() => {
                          loadLook(look);
                          setView('studio');
                        }}
                      >
                        {miniPreview(look.config)}
                      </button>
                      <div className="v2-card-meta">
                        <b>{look.name}</b>
                        {live && <span className="v2-live-pill">LIVE</span>}
                      </div>
                      <div className="v2-card-actions">
                        <button
                          type="button"
                          className="primary"
                          onClick={() => {
                            loadLook(look);
                            setView('studio');
                          }}
                        >
                          {i18n.t('looks.load')}
                        </button>
                        <button
                          type="button"
                          className="v2-ghost"
                          onClick={() => activateLook(look)}
                        >
                          {i18n.t('looks.goLive')}
                        </button>
                        <button
                          type="button"
                          className={'v2-icon-btn' + (look.pinned ? ' is-on' : '')}
                          aria-pressed={!!look.pinned}
                          aria-label={
                            look.pinned
                              ? i18n.t('looks.unpinAria', { name: look.name })
                              : i18n.t('looks.pinAria', { name: look.name })
                          }
                          title={i18n.t('looks.pinTitle')}
                          onClick={() => pinLook(look)}
                        >
                          <Star
                            size={14}
                            fill={look.pinned ? 'currentColor' : 'none'}
                          />
                        </button>
                        <button
                          type="button"
                          className="v2-icon-btn"
                          aria-label={i18n.t('looks.shareAria', { name: look.name })}
                          title={i18n.t('looks.shareTitle')}
                          onClick={() => void shareLook(look)}
                        >
                          <Share2 size={14} />
                        </button>
                        <button
                          type="button"
                          className="v2-icon-btn"
                          aria-label={i18n.t('looks.exportAria', { name: look.name })}
                          title={i18n.t('looks.exportTitle')}
                          onClick={() => exportLook(look)}
                        >
                          <Download size={14} />
                        </button>
                        <button
                          type="button"
                          className="v2-icon-btn"
                          aria-label={i18n.t('looks.deleteAria', { name: look.name })}
                          title={i18n.t('looks.deleteTitle')}
                          onClick={() => deleteLook(look.id)}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </section>
          <section className="v2-looks-section v2-gallery" aria-label={i18n.t('looks.gallery')}>
            <div className="v2-section-head">
              <h2>{i18n.t('looks.gallery')}</h2>
              <span className="v2-section-note">
                {i18n.t('looks.galleryNote', { n: presets.length })}
              </span>
              <div className="v2-section-actions">
                <button
                  type="button"
                  className={'v2-ghost' + (galleryAuto ? ' is-on' : '')}
                  aria-pressed={galleryAuto}
                  onClick={() => setGalleryAuto((a) => !a)}
                >
                  {galleryAuto ? <Pause size={14} /> : <Play size={14} />}
                  {galleryAuto ? i18n.t('looks.demoRunning') : i18n.t('looks.demoPaused')}
                </button>
                <button type="button" className="v2-ghost" onClick={nextGallerySong}>
                  <SkipForward size={14} /> {i18n.t('looks.songChange')}
                </button>
              </div>
            </div>
            <div className="v2-gallery-stage" data-count={gallerySel.length}>
              {gallerySel.map((id) => {
                const p = presets.find((x) => x.id === id);
                if (!p) return null;
                const w = p.config.layout === 'memory' ? 520 : p.config.width;
                return (
                  <div className="v2-gallery-slot" key={id}>
                    <div className="v2-gallery-canvas">
                      <div
                        style={
                          {
                            zoom: Math.min(1, (gallerySel.length > 1 ? 300 : 520) / w),
                          } as CSSProperties
                        }
                      >
                        <Overlay
                          config={{ ...p.config, autoAccentFromCover: false }}
                          track={galleryTrack}
                          lang={streamLang}
                        />
                      </div>
                    </div>
                    <div className="v2-gallery-meta">
                      <div>
                        <b>{p.name}</b>
                        <span>{presetNote(p)}</span>
                      </div>
                      <button
                        type="button"
                        className="primary"
                        onClick={() => {
                          applyPreset(p);
                          setView('studio');
                        }}
                      >
                        {i18n.t('looks.tryInStudio')}
                      </button>
                    </div>
                  </div>
                );
              })}
              <div className="v2-gallery-now">
                {i18n.t('looks.demoNow', {
                  i: galleryIdx + 1,
                  n: GALLERY_TRACKS.length,
                  title: galleryTrack.title,
                  artist: galleryTrack.artist,
                })}
                {!connected && (
                  <button
                    type="button"
                    className="v2-ghost"
                    onClick={() => setView('setup')}
                  >
                    {i18n.t('looks.connectCta')}
                  </button>
                )}
              </div>
            </div>
            <div className="v2-gallery-tags" role="tablist" aria-label={i18n.t('looks.filter')}>
              {['all', ...Array.from(new Set(presets.map((p) => p.tag)))].map((t) => (
                <button
                  type="button"
                  role="tab"
                  key={t}
                  aria-selected={galleryTag === t}
                  className={'v2-chip' + (galleryTag === t ? ' is-on' : '')}
                  onClick={() => setGalleryTag(t)}
                >
                  {t === 'all' ? i18n.t('looks.all') : t.charAt(0) + t.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
            <div className="v2-gallery-grid">
              {presets
                .filter((p) => galleryTag === 'all' || p.tag === galleryTag)
                .map((p) => {
                  const on = gallerySel.includes(p.id);
                  return (
                    <article
                      key={p.id}
                      className={'v2-gallery-card' + (on ? ' is-on' : '')}
                    >
                      <button
                        type="button"
                        className="v2-card-preview"
                        aria-label={i18n.t('looks.stageAria', { name: p.name })}
                        onClick={() => setGallerySel([p.id])}
                      >
                        {miniPreview(p.config, false, galleryTrack)}
                      </button>
                      <div className="v2-card-meta">
                        <b>{p.name}</b>
                        <span className="v2-tag">{p.tag}</span>
                      </div>
                      <p>{presetNote(p)}</p>
                      <div className="v2-card-actions">
                        <button
                          type="button"
                          className="v2-ghost"
                          aria-pressed={on && gallerySel.length > 1}
                          onClick={() =>
                            setGallerySel((sel) =>
                              sel.includes(p.id)
                                ? sel.length > 1
                                  ? sel.filter((x) => x !== p.id)
                                  : sel
                                : [sel[sel.length - 1], p.id],
                            )
                          }
                        >
                          {on && gallerySel.length > 1 ? i18n.t('looks.comparing') : i18n.t('looks.compare')}
                        </button>
                        <button
                          type="button"
                          className="primary"
                          onClick={() => {
                            applyPreset(p);
                            setView('studio');
                          }}
                        >
                          {i18n.t('looks.try')}
                        </button>
                      </div>
                    </article>
                  );
                })}
            </div>
          </section>
          {renderStatus()}
        </div>
      )}
      {view === 'likes' && <LikesView connected={connected} />}
      {view === 'history' && (
        <HistoryView
          connected={connected}
          wallUrl={key ? obsOrigin + '/overlay/wall#' + key : ''}
          shelfUrl={key ? obsOrigin + '/overlay/shelf#' + key : ''}
          onCopy={(text) => void copy(text)}
        />
      )}
      {view === 'setup' && (
        <div className="v2-page v2-setup">
          <div className="v2-page-head">
            <div>
              <h1>
                {i18n.t('setup.title')}<span>.</span>
              </h1>
              <p>
                {essentialsDone === 2
                  ? i18n.t('setup.allDone')
                  : i18n.t('setup.progress', { n: essentialsDone })}
              </p>
            </div>
            <div className="v2-setup-progress" aria-hidden="true">
              <i style={{ width: (essentialsDone / 2) * 100 + '%' }} />
            </div>
          </div>

          <section className="v2-setup-group">
            <div className="v2-section-head">
              <h2>{i18n.t('setup.essentials')}</h2>
              <span className="v2-section-note">{i18n.t('setup.essentialsNote')}</span>
            </div>
            <div className="v2-setup-cards">
              <article className={'v2-setup-card' + (connected ? ' is-done' : '')}>
                <header>
                  <span className="v2-setup-icon">
                    <Music2 size={17} />
                  </span>
                  <div>
                    <b>{i18n.t('setup.spotify.title')}</b>
                    <small>
                      {connected ? i18n.t('setup.spotify.connected') : i18n.t('setup.spotify.notConnected')}
                    </small>
                  </div>
                  <span className={'v2-status-pill' + (connected ? ' ok' : '')}>
                    {connected ? i18n.t('setup.done') : i18n.t('setup.open')}
                  </span>
                </header>
                <p className="v2-setup-why">
                  {i18n.r('setup.why', { text: i18n.t('setup.spotify.why') })}
                </p>
                <details className="v2-tutorial">
                  <summary>{i18n.t('setup.howShort')}</summary>
                  <ol>
                    <li>{i18n.t('setup.spotify.s1')}</li>
                    <li>{i18n.r('setup.spotify.s2')}</li>
                    <li>{i18n.t('setup.spotify.s3')}</li>
                    <li>{i18n.t('setup.spotify.s4')}</li>
                  </ol>
                </details>
                <div className="v2-setup-actions">
                  <button
                    className={connected ? 'secondary' : 'primary'}
                    onClick={() => setModal('spotify')}
                  >
                    {connected ? i18n.t('setup.spotify.manage') : i18n.t('setup.spotify.title')}
                  </button>
                </div>
              </article>

              <SourceCard active={view === 'setup'} />

              <article className={'v2-setup-card' + (key ? ' is-done' : '')}>
                <header>
                  <span className="v2-setup-icon">
                    <Monitor size={17} />
                  </span>
                  <div>
                    <b>{i18n.t('setup.obs.title')}</b>
                    <small>{i18n.t('setup.obs.sub')}</small>
                  </div>
                  <span className={'v2-status-pill' + (key ? ' ok' : '')}>
                    {key ? i18n.t('setup.obs.ready') : i18n.t('setup.obs.preparing')}
                  </span>
                </header>
                <p className="v2-setup-why">
                  {i18n.r('setup.why', { text: i18n.t('setup.obs.why') })}
                </p>
                <div className="setup-url">
                  <code>{key ? obsUrl : i18n.t('setup.obs.urlPreparing')}</code>
                  <button
                    type="button"
                    aria-label={i18n.t('setup.obs.copy')}
                    title={i18n.t('setup.obs.copy')}
                    disabled={!key}
                    onClick={() => copy(obsUrl)}
                  >
                    <Copy size={15} />
                  </button>
                  {key && (
                    <a href={obsUrl} target="_blank" rel="noreferrer" title={i18n.t('setup.obs.openOverlay')}>
                      <ExternalLink size={15} />
                    </a>
                  )}
                </div>
                <details className="v2-tutorial">
                  <summary>{i18n.t('setup.howShort')}</summary>
                  <ol>
                    <li>{i18n.t('setup.obs.s1')}</li>
                    <li>{i18n.r('setup.obs.s2')}</li>
                    <li>{i18n.r('setup.obs.s3')}</li>
                    <li>{i18n.t('setup.obs.s4')}</li>
                  </ol>
                  <small>{i18n.t('setup.obs.secret')}</small>
                </details>
              </article>

              <DesktopWidgetCard active={view === 'setup'} onBrowser={() => void openWidget()} />
            </div>
          </section>

          <section className="v2-setup-group">
            <div className="v2-section-head">
              <h2>{i18n.t('setup.extras')}</h2>
              <span className="v2-section-note">{i18n.t('setup.extrasNote')}</span>
            </div>
            <div className="v2-setup-cards">
              <article className={'v2-setup-card' + (lastfmConfigured ? ' is-done' : '')}>
                <header>
                  <span className="v2-setup-icon">
                    <Sparkles size={17} />
                  </span>
                  <div>
                    <b>Last.fm</b>
                    <small>{i18n.t('setup.forMood')}</small>
                  </div>
                  <span className={'v2-status-pill' + (lastfmConfigured ? ' ok' : '')}>
                    {lastfmConfigured ? i18n.t('setup.active') : i18n.t('setup.optional')}
                  </span>
                </header>
                <p className="v2-setup-why">
                  {i18n.r('setup.why', { text: i18n.t('setup.lastfm.why') })}
                </p>
                <details className="v2-tutorial">
                  <summary>{i18n.t('setup.lastfm.how')}</summary>
                  <ol>
                    <li>{i18n.r('setup.lastfm.s1', undefined, { a1: 'https://www.last.fm/api/account/create' })}</li>
                    <li>{i18n.t('setup.lastfm.s2')}</li>
                    <li>{i18n.r('setup.lastfm.s3')}</li>
                    <li>{i18n.t('setup.lastfm.s4')}</li>
                  </ol>
                </details>
                <div className="v2-key-row">
                  <input
                    type="password"
                    autoComplete="off"
                    aria-label={i18n.t('setup.lastfm.aria')}
                    placeholder={lastfmConfigured ? i18n.t('setup.savedMask') : i18n.t('setup.lastfm.placeholder')}
                    value={lastfmKey}
                    onChange={(e) => setLastfmKey(e.target.value)}
                  />
                  <button
                    className="primary"
                    disabled={moodBusy || !lastfmKey.trim()}
                    onClick={() => saveMoodCredential('lastfm')}
                  >
                    {i18n.t('setup.save')}
                  </button>
                </div>
                {lastfmConfigured && (
                  <div className="v2-setup-actions">
                    <button
                      className="v2-ghost"
                      disabled={lastfmTest === 'testing'}
                      onClick={() => testMoodCredential('lastfm')}
                    >
                      {lastfmTest === 'testing'
                        ? i18n.t('setup.testing')
                        : lastfmTest === 'connected'
                          ? i18n.t('setup.works')
                          : lastfmTest === 'invalid'
                            ? i18n.t('setup.lastfm.invalid')
                            : i18n.t('setup.testConnection')}
                    </button>
                    <button
                      className="v2-ghost"
                      disabled={moodBusy}
                      onClick={() => removeMoodCredential('lastfm')}
                    >
                      {i18n.t('setup.remove')}
                    </button>
                  </div>
                )}
              </article>

              <article className={'v2-setup-card' + (geniusConfigured ? ' is-done' : '')}>
                <header>
                  <span className="v2-setup-icon">
                    <Type size={17} />
                  </span>
                  <div>
                    <b>Genius</b>
                    <small>{i18n.t('setup.forMood')}</small>
                  </div>
                  <span className={'v2-status-pill' + (geniusConfigured ? ' ok' : '')}>
                    {geniusConfigured ? i18n.t('setup.active') : i18n.t('setup.optional')}
                  </span>
                </header>
                <p className="v2-setup-why">
                  {i18n.r('setup.why', { text: i18n.t('setup.genius.why') })}
                </p>
                <details className="v2-tutorial">
                  <summary>{i18n.t('setup.genius.how')}</summary>
                  <ol>
                    <li>{i18n.r('setup.genius.s1', undefined, { a1: 'https://genius.com/api-clients' })}</li>
                    <li>{i18n.r('setup.genius.s2')}</li>
                    <li>{i18n.r('setup.genius.s3')}</li>
                    <li>{i18n.r('setup.genius.s4')}</li>
                  </ol>
                </details>
                <div className="v2-key-row">
                  <input
                    type="password"
                    autoComplete="off"
                    aria-label={i18n.t('setup.genius.aria')}
                    placeholder={geniusConfigured ? i18n.t('setup.savedMask') : i18n.t('setup.genius.placeholder')}
                    value={geniusToken}
                    onChange={(e) => setGeniusToken(e.target.value)}
                  />
                  <button
                    className="primary"
                    disabled={moodBusy || !geniusToken.trim()}
                    onClick={() => saveMoodCredential('genius')}
                  >
                    {i18n.t('setup.save')}
                  </button>
                </div>
                {geniusConfigured && (
                  <div className="v2-setup-actions">
                    <button
                      className="v2-ghost"
                      disabled={geniusTest === 'testing'}
                      onClick={() => testMoodCredential('genius')}
                    >
                      {geniusTest === 'testing'
                        ? i18n.t('setup.testing')
                        : geniusTest === 'connected'
                          ? i18n.t('setup.works')
                          : geniusTest === 'invalid'
                            ? i18n.t('setup.genius.invalid')
                            : i18n.t('setup.testConnection')}
                    </button>
                    <button
                      className="v2-ghost"
                      disabled={moodBusy}
                      onClick={() => removeMoodCredential('genius')}
                    >
                      {i18n.t('setup.remove')}
                    </button>
                  </div>
                )}
              </article>

              <article
                className={
                  'v2-setup-card' + (lol.data.status === 'ok' ? ' is-done' : '')
                }
              >
                <header>
                  <span className="v2-setup-icon">
                    <Trophy size={17} />
                  </span>
                  <div>
                    <b>{i18n.t('setup.lol.title')}</b>
                    <small>{i18n.t('setup.lol.sub')}</small>
                  </div>
                  <span className="v2-status-pill">
                    {lol.data.status === 'ok'
                      ? i18n.t('setup.lol.connected')
                      : lol.data.status === 'unranked'
                        ? i18n.t('setup.lol.unranked')
                        : lol.data.status === 'loading'
                          ? i18n.t('setup.testing')
                          : i18n.t('setup.lol.notFound')}
                  </span>
                </header>
                <p className="v2-setup-why">
                  {i18n.r('setup.why', { text: i18n.t('setup.lol.why') })}
                </p>
                {lol.data.status === 'ok' && (
                  <p className="v2-setup-why" data-field="lolStatus">
                    <b>{lol.data.summoner || i18n.t('setup.lol.account')}:</b>{' '}
                    {LOL_TIER_NAMES[lol.data.tier || ''] || lol.data.tier}{' '}
                    {isApexTier(lol.data.tier) ? '' : lol.data.division} ·{' '}
                    {lol.data.lp} LP · {i18n.t('setup.lol.record', { w: lol.data.wins ?? 0, l: lol.data.losses ?? 0 })}
                  </p>
                )}
                {lol.data.status === 'unranked' && (
                  <p className="v2-setup-why" data-field="lolStatus">
                    {i18n.t('setup.lol.foundUnranked', {
                      name: lol.data.summoner ? ' (' + lol.data.summoner + ')' : '',
                    })}
                  </p>
                )}
                <details className="v2-tutorial">
                  <summary>{i18n.t('setup.how')}</summary>
                  <ol>
                    <li>{i18n.t('setup.lol.s1')}</li>
                    <li>{i18n.t('setup.lol.s2')}</li>
                    <li>{i18n.t('setup.lol.s3')}</li>
                  </ol>
                  <small className="context-note">{i18n.t('setup.lol.note')}</small>
                </details>
              </article>

              <article
                className={
                  'v2-setup-card' + (valoSettings?.configured ? ' is-done' : '')
                }
              >
                <header>
                  <span className="v2-setup-icon">
                    <Trophy size={17} />
                  </span>
                  <div>
                    <b>{i18n.t('setup.valo.title')}</b>
                    <small>{i18n.t('setup.valo.sub')}</small>
                  </div>
                  <span
                    className={
                      'v2-status-pill' + (valoSettings?.configured ? ' ok' : '')
                    }
                  >
                    {valoSettings?.configured ? i18n.t('setup.valo.configured') : i18n.t('setup.optional')}
                  </span>
                </header>
                <p className="v2-setup-why">
                  {i18n.r('setup.why', { text: i18n.t('setup.valo.why') })}
                </p>
                <details className="v2-tutorial">
                  <summary>{i18n.t('setup.valo.how')}</summary>
                  <ol>
                    <li>{i18n.r('setup.valo.s1', undefined, { a1: 'https://api.henrikdev.xyz/dashboard/' })}</li>
                    <li>{i18n.r('setup.valo.s2')}</li>
                    <li>{i18n.t('setup.valo.s3')}</li>
                  </ol>
                  <small className="context-note">{i18n.t('setup.valo.note')}</small>
                </details>
                <div className="v2-key-row" data-field="valoRiotId">
                  <input
                    type="text"
                    autoComplete="off"
                    aria-label={i18n.t('setup.valo.name')}
                    placeholder={i18n.t('setup.valo.name')}
                    value={valoForm.name}
                    onChange={(e) => setValoForm((f) => ({ ...f, name: e.target.value }))}
                  />
                  <input
                    type="text"
                    autoComplete="off"
                    aria-label={i18n.t('setup.valo.tag')}
                    placeholder={i18n.t('setup.valo.tag')}
                    style={{ maxWidth: 90 }}
                    value={valoForm.tag}
                    onChange={(e) => setValoForm((f) => ({ ...f, tag: e.target.value }))}
                  />
                </div>
                <div className="v2-key-row">
                  <select
                    aria-label={i18n.t('setup.valo.region')}
                    value={valoForm.region}
                    onChange={(e) => setValoForm((f) => ({ ...f, region: e.target.value }))}
                  >
                    <option value="eu">{i18n.t('setup.valo.r.eu')}</option>
                    <option value="na">{i18n.t('setup.valo.r.na')}</option>
                    <option value="ap">{i18n.t('setup.valo.r.ap')}</option>
                    <option value="kr">{i18n.t('setup.valo.r.kr')}</option>
                    <option value="latam">{i18n.t('setup.valo.r.latam')}</option>
                    <option value="br">{i18n.t('setup.valo.r.br')}</option>
                  </select>
                  <select
                    aria-label={i18n.t('setup.valo.platform')}
                    value={valoForm.platform}
                    onChange={(e) => setValoForm((f) => ({ ...f, platform: e.target.value }))}
                  >
                    <option value="pc">{i18n.t('setup.valo.p.pc')}</option>
                    <option value="console">{i18n.t('setup.valo.p.console')}</option>
                  </select>
                </div>
                <div className="v2-key-row">
                  <input
                    type="password"
                    autoComplete="off"
                    aria-label={i18n.t('setup.valo.key')}
                    placeholder={
                      valoSettings?.hasKey ? i18n.t('setup.savedMask') : i18n.t('setup.valo.key')
                    }
                    value={valoForm.key}
                    onChange={(e) => setValoForm((f) => ({ ...f, key: e.target.value }))}
                  />
                  <button
                    className="primary"
                    disabled={
                      valoBusy ||
                      !valoForm.name.trim() ||
                      !valoForm.tag.trim() ||
                      (!valoForm.key.trim() && !valoSettings?.hasKey)
                    }
                    onClick={() => void saveValo()}
                  >
                    {valoBusy ? i18n.t('setup.testing') : i18n.t('setup.valo.saveTest')}
                  </button>
                </div>
                {valoMsg && <p className="v2-setup-why">{serverMsg(valoMsg)}</p>}
                {valoSettings?.hasKey && (
                  <div className="v2-setup-actions">
                    <button
                      className="v2-ghost"
                      disabled={valoBusy}
                      onClick={() => void saveValo(true)}
                    >
                      {i18n.t('setup.valo.removeKey')}
                    </button>
                  </div>
                )}
              </article>

              <article className="v2-setup-card is-info">
                <header>
                  <span className="v2-setup-icon">
                    <Gamepad2 size={17} />
                  </span>
                  <div>
                    <b>{i18n.t('setup.live.title')}</b>
                    <small>Streamer.bot</small>
                  </div>
                  <span className="v2-status-pill">
                    {i18n.t('setup.live.pinned', { n: liveLooks.length })}
                  </span>
                </header>
                <p className="v2-setup-why">
                  {i18n.r('setup.why', { text: i18n.t('setup.live.why') })}
                </p>
                <details className="v2-tutorial">
                  <summary>{i18n.t('setup.how')}</summary>
                  <ol>
                    <li>{i18n.r('setup.live.s1')}</li>
                    <li>{i18n.r('setup.live.s2')}</li>
                    <li>{i18n.r('setup.live.s3')}</li>
                  </ol>
                </details>
              </article>

              <article className="v2-setup-card is-info">
                <header>
                  <span className="v2-setup-icon">
                    <Box size={17} />
                  </span>
                  <div>
                    <b>Enhanced Blur</b>
                    <small>{i18n.t('setup.blur.sub')}</small>
                  </div>
                  <span className="v2-status-pill">{i18n.t('setup.optional')}</span>
                </header>
                <p className="v2-setup-why">
                  {i18n.r('setup.why', { text: i18n.t('setup.blur.why') })}
                </p>
                <div className="v2-setup-actions">
                  <button
                    className="v2-ghost"
                    onClick={() => {
                      const p = presets.find((x) => x.id === 'glass');
                      if (p && !isAfterglow(config)) applyPreset(p);
                      setView('studio');
                    }}
                  >
                    {i18n.t('setup.blur.action')}
                  </button>
                </div>
              </article>
            </div>
          </section>

          <section className="v2-setup-group">
            <div className="v2-section-head">
              <h2>{i18n.t('setup.system')}</h2>
            </div>
            <div className="v2-setup-cards is-compact">
              <article className="v2-setup-card is-info v2-lang-card">
                <header>
                  <span className="v2-setup-icon">
                    <Languages size={17} />
                  </span>
                  <div>
                    <b>{i18n.t('setup.lang.title')}</b>
                    <small>{i18n.t('setup.lang.sub')}</small>
                  </div>
                </header>
                <div className="v2-lang-pickers">
                  <Picker
                    label={i18n.t('setup.lang.studio')}
                    value={i18n.locale}
                    options={LOCALES}
                    onChange={(v) => i18n.setLocale(v as Locale)}
                  />
                  <Picker
                    label={i18n.t('setup.lang.stream')}
                    value={streamLang}
                    options={[
                      ['auto', i18n.t('setup.lang.auto')],
                      ['de', 'Deutsch'],
                      ['en', 'English'],
                    ]}
                    onChange={(v) => void saveStreamLangChoice(v)}
                  />
                </div>
                <p className="v2-setup-why">{i18n.t('setup.lang.why')}</p>
              </article>
              <article className="v2-setup-card is-info">
                <header>
                  <span className="v2-setup-icon">
                    <RefreshCw size={17} />
                  </span>
                  <div>
                    <b>{i18n.t('setup.version')}</b>
                    <small>
                      {testerVersion ? i18n.t('setup.version.tester', { v: testerVersion }) : i18n.t('setup.version.dev')}
                    </small>
                  </div>
                </header>
                <p className="v2-setup-why">{i18n.r('setup.version.update')}</p>
              </article>
              <article className="v2-setup-card is-info">
                <header>
                  <span className="v2-setup-icon">
                    <Gauge size={17} />
                  </span>
                  <div>
                    <b>QA Lab</b>
                    <small>{i18n.t('setup.qa.sub')}</small>
                  </div>
                </header>
                <div className="v2-setup-actions">
                  <a className="v2-ghost" href="/mood-visual-check">
                    {i18n.t('setup.qa.open')} <ArrowUpRight size={13} />
                  </a>
                </div>
              </article>
              {devStatus && (
                <article className={'v2-setup-card is-dev' + (devStatus.stale ? '' : ' is-done')}>
                  <header>
                    <span className="v2-setup-icon">
                      <Download size={17} />
                    </span>
                    <div>
                      <b>{i18n.t('setup.zip.title')}</b>
                      <small>{i18n.t('setup.zip.sub')}</small>
                    </div>
                    <span className={'v2-status-pill' + (devStatus.stale ? ' warn' : ' ok')}>
                      {devStatus.stale ? i18n.t('setup.zip.stale') : i18n.t('setup.zip.current')}
                    </span>
                  </header>
                  <p className="v2-setup-why">
                    {devStatus.latest
                      ? i18n.t('setup.zip.last', {
                          date: new Date(devStatus.latest.createdAt).toLocaleString(i18n.locale === 'de' ? 'de-DE' : 'en-GB'),
                          size: (devStatus.latest.size / 1024 / 1024).toFixed(1),
                        })
                      : i18n.t('setup.zip.none')}
                    {devStatus.stale &&
                      devStatus.newestSourceChange &&
                      i18n.t('setup.zip.changed', {
                        date: new Date(devStatus.newestSourceChange).toLocaleString(i18n.locale === 'de' ? 'de-DE' : 'en-GB'),
                      })}
                  </p>
                  <div className="v2-setup-actions">
                    <button
                      className="primary"
                      disabled={devBusy}
                      onClick={() => buildTesterZip(true)}
                    >
                      {devBusy ? i18n.t('setup.zip.building') : i18n.t('setup.zip.build')}
                    </button>
                    {devStatus.latest && !devStatus.stale && (
                      <a
                        className="v2-ghost"
                        href={'/exports/' + encodeURIComponent(devStatus.latest.file)}
                        download
                      >
                        {i18n.t('setup.zip.download')}
                      </a>
                    )}
                  </div>
                </article>
              )}
            </div>
          </section>
          {renderStatus()}
        </div>
      )}
      <Dialog
        open={modal !== null}
        onOpenChange={(open) => !open && setModal(null)}
      >
        <DialogContent className="setup-dialog">
          <DialogTitle>
            {modal === 'spotify'
              ? i18n.t('setup.spotify.title')
              : i18n.t('st.bereitFuerDeinenStream')}
          </DialogTitle>
          <DialogDescription>
            {modal === 'spotify'
              ? i18n.t('st.deineDeveloperAppIstVorbereitet')
              : i18n.t('st.speichereDeinDesignUndFuege')}
          </DialogDescription>
          {modal === 'spotify' ? (
            <>
              <div className="setup-step">
                <span>01</span>
                <div>
                  <h3>{i18n.t('st.redirectUriEintragen')}</h3>
                  <p>
                    {i18n.r('st.spotifyStep1', undefined, {
                      a1: 'https://developer.spotify.com/dashboard',
                    })}
                  </p>
                  <div className="copy-field">
                    <input
                      aria-label={i18n.t('st.spotifyRedirectUri')}
                      readOnly
                      value={spotifyRedirect}
                    />
                    <button
                      aria-label={i18n.t('st.redirectUriKopieren')}
                      onClick={() => copy(spotifyRedirect)}
                    >
                      <Copy size={16} />
                    </button>
                  </div>
                </div>
              </div>
              <div className="setup-step">
                <span>02</span>
                <div>
                  <h3>{i18n.t('st.mitSpotifyAnmelden')}</h3>
                  <p>
                    {i18n.r('st.spotifyStep2')}
                  </p>
                </div>
              </div>
              <button
                className="primary"
                disabled={busy || !ready}
                onClick={connect}
              >
                <Music2 size={17} />
                {connected
                  ? i18n.t('st.erneutMitSpotifyVerbinden')
                  : i18n.t('st.mitSpotifyVerbinden')}
              </button>
              {connected && (
                <button
                  className="secondary"
                  disabled={busy}
                  onClick={disconnect}
                >
                  <Unplug size={15} />
                  {i18n.t('st.spotifyTrennen')}
                </button>
              )}
            </>
          ) : (
            <>
              <div className="setup-step">
                <span>01</span>
                <div>
                  <h3>{i18n.t('st.designUebernehmen')}</h3>
                  <p>
                    {dirty
                      ? i18n.t('st.deinEntwurfEnthaeltAenderungenSpeichere')
                      : i18n.t('st.deinAktuellesDesignIstGespeichert')}
                  </p>
                  {dirty && (
                    <button
                      className="secondary"
                      disabled={!ready || busy}
                      onClick={save}
                    >
                      <Save size={15} />
                      {i18n.t('st.jetztSpeichern')}
                    </button>
                  )}
                </div>
              </div>
              <div className="setup-step">
                <span>02</span>
                <div>
                  <h3>{i18n.t('st.browserQuelleHinzufuegen')}</h3>
                  <p>
                    {i18n.r('st.obsStep2', { w: config.width + 100 })}
                  </p>
                  <div className="copy-field">
                    <input
                      aria-label={i18n.t('st.obsOverlayAdresse')}
                      readOnly
                      value={key ? obsUrl : i18n.t('st.studioWirdGeladen')}
                    />
                    <button
                      aria-label={i18n.t('st.overlayAdresseKopieren')}
                      disabled={!key || dirty}
                      onClick={() => copy(obsUrl)}
                    >
                      <Copy size={16} />
                    </button>
                  </div>
                </div>
              </div>
              {!connected && (
                <button className="primary" onClick={() => setModal('spotify')}>
                  <Music2 size={17} />
                  {i18n.t('st.zuerstSpotifyVerbinden')}
                </button>
              )}
              {key && (
                <a
                  className="secondary"
                  href={obsUrl}
                  target="_blank"
                  rel="noreferrer"
                >
                  <ExternalLink size={15} />
                  {i18n.t('setup.obs.openOverlay')}
                </a>
              )}
              <p className="privacy-note">
                {i18n.t('st.derOverlayLinkErlaubtDas')}
              </p>
              <button
                className="text-button"
                disabled={!ready || busy}
                onClick={async () => {
                  setBusy(true);
                  try {
                    const d = await api('/api/studio', { action: 'rotate' });
                    setKey(d.overlayKey);
                    setMessage(
                      i18n.t('st.neuerOverlayLinkErstelltAktualisiere'),
                    );
                  } catch (e) {
                    setError((e as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                <RefreshCw size={13} />
                {i18n.t('st.neuenOverlayLinkErstellen')}
              </button>
            </>
          )}
          <div aria-live="polite">
            {error && <p className="error-message">{serverMsg(error)}</p>}
            {message && <p className="success-message">{serverMsg(message)}</p>}
          </div>
        </DialogContent>
      </Dialog>
      <Dialog
        open={moodSettingsOpen}
        onOpenChange={(open) => !open && setMoodSettingsOpen(false)}
      >
        <DialogContent className="setup-dialog">
          <DialogTitle>{i18n.t('st.moodSwitchEinstellungen')}</DialogTitle>
          <DialogDescription>
            {i18n.t('st.optionaleDatenquellenFuerGenauereMood')}
          </DialogDescription>
          <div className="mood-settings-section">
            <h3>Last.fm</h3>
            <p>{i18n.t('st.genresTagsUndMetadatenFuer')}</p>
            <div
              className={
                'mood-settings-status' + (lastfmConfigured ? ' connected' : '')
              }
            >
              {lastfmConfigured ? i18n.t('setup.spotify.connected') : i18n.t('st.nichtEingerichtet')}
            </div>
            <input
              className="mood-settings-input"
              type="password"
              value={lastfmKey}
              placeholder="Last.fm API Key"
              autoComplete="off"
              spellCheck={false}
              onChange={(e) => setLastfmKey(e.target.value)}
            />
            <div className="mood-settings-actions">
              <button
                className="secondary"
                disabled={moodBusy}
                onClick={() => saveMoodCredential('lastfm')}
              >
                <Save size={15} />
                {i18n.t('looks.save')}
              </button>
              <button
                className="secondary"
                disabled={moodBusy}
                onClick={() => testMoodCredential('lastfm')}
              >
                {i18n.t('setup.testConnection')}
              </button>
              {lastfmConfigured && (
                <button
                  className="text-button"
                  disabled={moodBusy}
                  onClick={() => removeMoodCredential('lastfm')}
                >
                  {i18n.t('setup.remove')}
                </button>
              )}
            </div>
            {lastfmTest && (
              <p className={'mood-settings-test ' + lastfmTest}>
                {lastfmTest === 'testing'
                  ? i18n.t('st.testeVerbindung')
                  : lastfmTest === 'connected'
                    ? i18n.t('setup.spotify.connected')
                    : lastfmTest === 'invalid'
                      ? i18n.t('st.ungueltigerKey')
                      : i18n.t('st.dienstNichtErreichbar')}
              </p>
            )}
            <a
              href="https://www.last.fm/api/account/create"
              target="_blank"
              rel="noreferrer"
            >
              {i18n.t('st.soBekommstDuEinenKey')}
            </a>
          </div>
          <div className="mood-settings-section">
            <h3>
              Genius <em>Optional</em>
            </h3>
            <p>{i18n.t('st.zusaetzlicherLyricsFallbackFuerDie')}</p>
            <div
              className={
                'mood-settings-status' + (geniusConfigured ? ' connected' : '')
              }
            >
              {geniusConfigured ? i18n.t('setup.spotify.connected') : i18n.t('st.nichtEingerichtet')}
            </div>
            <input
              className="mood-settings-input"
              type="password"
              value={geniusToken}
              placeholder="Genius Access Token"
              autoComplete="off"
              spellCheck={false}
              onChange={(e) => setGeniusToken(e.target.value)}
            />
            <div className="mood-settings-actions">
              <button
                className="secondary"
                disabled={moodBusy}
                onClick={() => saveMoodCredential('genius')}
              >
                <Save size={15} />
                {i18n.t('looks.save')}
              </button>
              <button
                className="secondary"
                disabled={moodBusy}
                onClick={() => testMoodCredential('genius')}
              >
                {i18n.t('setup.testConnection')}
              </button>
              {geniusConfigured && (
                <button
                  className="text-button"
                  disabled={moodBusy}
                  onClick={() => removeMoodCredential('genius')}
                >
                  {i18n.t('setup.remove')}
                </button>
              )}
            </div>
            {geniusTest && (
              <p className={'mood-settings-test ' + geniusTest}>
                {geniusTest === 'testing'
                  ? i18n.t('st.testeVerbindung')
                  : geniusTest === 'connected'
                    ? i18n.t('setup.spotify.connected')
                    : geniusTest === 'invalid'
                      ? i18n.t('st.ungueltigerToken')
                      : i18n.t('st.dienstNichtErreichbar')}
              </p>
            )}
            <a
              href="https://genius.com/api-clients"
              target="_blank"
              rel="noreferrer"
            >
              {i18n.t('st.soBekommstDuEinenToken')}
            </a>
          </div>
          <div aria-live="polite">
            {error && <p className="error-message">{serverMsg(error)}</p>}
            {message && <p className="success-message">{serverMsg(message)}</p>}
          </div>
        </DialogContent>
      </Dialog>
      <Dialog
        open={deleteConfirm !== null}
        onOpenChange={(open) => !open && setDeleteConfirm(null)}
      >
        <DialogContent className="setup-dialog">
          <DialogTitle>{i18n.t('st.fontLoeschen')}</DialogTitle>
          <DialogDescription>
            {i18n.t('st.fontInUse')}
          </DialogDescription>
          <p className="delete-font-name">
            {i18n.t('st.fontWillBeDeleted', { name: deleteConfirm?.name ?? '' })}
          </p>
          <div className="dialog-actions">
            <button
              className="primary"
              disabled={busy}
              onClick={() => void confirmDeleteFont()}
            >
              {i18n.t('st.loeschenInterVerwenden')}
            </button>
            <button
              className="secondary"
              disabled={busy}
              onClick={() => setDeleteConfirm(null)}
            >
              {i18n.t('looks.cancel')}
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </main>
  );
}
