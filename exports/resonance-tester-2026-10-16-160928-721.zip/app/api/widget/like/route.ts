import { csrf, json, noteFavorite } from '@/lib/server';
import { isTrackId, setLiked } from '@/lib/spotify-write';
import { studioAccess, writeError } from '@/lib/widget-api';

// F22: Song liken / Like entfernen (Spotify-Lieblingssongs).
// POST { trackId, on } → { ok, liked }
export async function POST(req: Request) {
  try {
    csrf(req);
    const body = (await req.json()) as { trackId?: unknown; on?: unknown };
    if (!isTrackId(body.trackId)) return json({ error: 'Ungültiger Song.' }, 400);
    const a = await studioAccess(req);
    if (a instanceof Response) return a;
    const on = body.on !== false;
    await setLiked(a.access, body.trackId, on);
    noteFavorite(body.trackId, on);
    return json({ ok: true, liked: on });
  } catch (e) {
    return writeError(e);
  }
}
