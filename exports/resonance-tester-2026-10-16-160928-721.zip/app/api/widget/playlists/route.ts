import { csrf, json } from '@/lib/server';
import { addToPlaylist, isPlaylistId, isTrackId, membership, writablePlaylists } from '@/lib/spotify-write';
import { studioAccess, writeError } from '@/lib/widget-api';

// F22: Playlists fürs Widget.
// GET  ?track=ID → { playlists: [{ id, name, image, count, collaborative, has }] }
// POST { playlistId, trackIds[], force? } → { ok, added, skipped }
//      Ohne force werden Songs, die schon drin sind, übersprungen; das Studio
//      fragt vorher nach („Schon drin – trotzdem hinzufügen?“).
export async function GET(req: Request) {
  try {
    const a = await studioAccess(req);
    if (a instanceof Response) return a;
    const track = new URL(req.url).searchParams.get('track');
    const lists = await writablePlaylists(a.access);
    const has = isTrackId(track) ? await membership(a.access, lists, [track]) : {};
    return json({
      playlists: lists.map(({ snapshot: _s, ...p }) => ({ ...p, has: !!has[p.id]?.length })),
    });
  } catch (e) {
    return writeError(e);
  }
}

export async function POST(req: Request) {
  try {
    csrf(req);
    const body = (await req.json()) as { playlistId?: unknown; trackIds?: unknown; force?: unknown };
    const ids = Array.isArray(body.trackIds) ? body.trackIds.filter(isTrackId).slice(0, 500) : [];
    if (!isPlaylistId(body.playlistId) || !ids.length) return json({ error: 'Ungültige Anfrage.' }, 400);
    const a = await studioAccess(req);
    if (a instanceof Response) return a;
    const p = (await writablePlaylists(a.access)).find((x) => x.id === body.playlistId);
    if (!p) return json({ error: 'Diese Playlist kannst du nicht ändern.' }, 403);
    const r = await addToPlaylist(a.access, p, ids, body.force === true);
    return json({ ok: true, ...r, name: p.name });
  } catch (e) {
    return writeError(e);
  }
}
