import { csrf, db, getStudio, json } from '@/lib/server';
import { cleanSourceMode, lastCoverError } from '@/lib/media-source';
import { getPref, setPref } from '@/lib/studio-prefs';

// F23: Musikquelle (auto | spotify | other).
// GET → { mode }  ·  POST { mode } → { ok, mode }
export async function GET(req: Request) {
  try {
    const row = await getStudio(req);
    if (!row) return json({ error: 'Studio nicht gefunden.' }, 401);
    return json({ mode: cleanSourceMode(await getPref(db(), row.owner, 'source')), coverDebug: lastCoverError });
  } catch {
    return json({ mode: 'auto' });
  }
}

export async function POST(req: Request) {
  try {
    csrf(req);
    const row = await getStudio(req);
    if (!row) return json({ error: 'Studio nicht gefunden.' }, 401);
    const body = (await req.json()) as { mode?: unknown };
    const mode = cleanSourceMode(body.mode);
    await setPref(db(), row.owner, 'source', mode);
    return json({ ok: true, mode });
  } catch (e) {
    const msg = e instanceof Error ? e.message : '';
    if (/no such table/i.test(msg)) return json({ error: 'Bitte Resonance einmal neu starten (Datenbank-Update).' }, 409);
    return json({ error: 'Einstellungen konnten nicht gespeichert werden.' }, 400);
  }
}
