import { csrf, json, noteFavorite } from '@/lib/server';
import { isTrackId, likedSongs, membership, setLiked, writablePlaylists } from '@/lib/spotify-write';
import { studioAccess, writeError } from '@/lib/widget-api';

// F22: Like-Bibliothek im Studio.
// GET  → { songs: [{ id, title, artist, cover, addedAt, in: [playlistId…] }], playlists: [...] }
// POST { action: 'unlike', trackIds[] } → { ok }
export async function GET(req: Request) {
  try {
    const a = await studioAccess(req);
    if (a instanceof Response) return a;
    const songs = await likedSongs(a.access, 300);
    const lists = await writablePlaylists(a.access);
    const mem = await membership(a.access, lists, songs.map((s) => s.id));
    const inMap: Record<string, string[]> = {};
    for (const [pid, ids] of Object.entries(mem)) for (const id of ids) (inMap[id] ||= []).push(pid);
    return json({
      songs: songs.map((s) => ({ ...s, in: inMap[s.id] || [] })),
      playlists: lists.map(({ snapshot: _s, ...p }) => p),
    });
  } catch (e) {
    return writeError(e);
  }
}

export async function POST(req: Request) {
  try {
    csrf(req);
    const body = (await req.json()) as { action?: unknown; trackIds?: unknown };
    const ids = Array.isArray(body.trackIds) ? body.trackIds.filter(isTrackId).slice(0, 100) : [];
    if (body.action !== 'unlike' || !ids.length) return json({ error: 'Ungültige Anfrage.' }, 400);
    const a = await studioAccess(req);
    if (a instanceof Response) return a;
    await setLiked(a.access, ids, false);
    ids.forEach((id) => noteFavorite(id, false));
    return json({ ok: true });
  } catch (e) {
    return writeError(e);
  }
}
