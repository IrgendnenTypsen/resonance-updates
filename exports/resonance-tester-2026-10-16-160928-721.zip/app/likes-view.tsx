'use client';
// F22 – Studio-Tab „Likes“ (Mockup abgesegnet 2026-10-13).
// Einfach immer liken, später einsortieren: Inbox = Lieblingssongs, die in
// keiner eigenen Playlist sind. Mehrere wählen → rechts Playlist antippen.
import { useCallback, useEffect, useMemo, useState } from 'react';
import { serverMsg, useT } from '@/lib/i18n';
import './likes.css';

type Song = { id: string; title: string; artist: string; cover: string; addedAt: number; in: string[] };
type Playlist = { id: string; name: string; image: string; count: number; collaborative: boolean };
type Data = { songs: Song[]; playlists: Playlist[] };
type Filter = 'inbox' | 'week' | 'all';

const RECENT_KEY = 'resonance.widget.recentPlaylists';
export function recentPlaylists(): string[] {
  try {
    const v = JSON.parse(localStorage.getItem(RECENT_KEY) || '[]');
    return Array.isArray(v) ? v.filter((x) => typeof x === 'string') : [];
  } catch {
    return [];
  }
}
export function rememberPlaylist(id: string) {
  try {
    localStorage.setItem(RECENT_KEY, JSON.stringify([id, ...recentPlaylists().filter((x) => x !== id)].slice(0, 8)));
  } catch {
    // nur Komfort
  }
}

export default function LikesView({ connected }: { connected: boolean }) {
  const i18n = useT();
  const { t } = i18n;
  const [data, setData] = useState<Data | null>(null);
  const [state, setState] = useState<'loading' | 'ready' | 'error' | 'scope'>('loading');
  const [filter, setFilter] = useState<Filter>('inbox');
  const [query, setQuery] = useState('');
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState('');
  const [recent, setRecent] = useState<string[]>([]);
  const [dupe, setDupe] = useState<{ p: Playlist; already: number; total: number } | null>(null);

  const flash = (m: string) => {
    setToast(m);
    window.setTimeout(() => setToast((x) => (x === m ? '' : x)), 2800);
  };

  const load = useCallback(async () => {
    if (!connected) return;
    try {
      const r = await fetch('/api/likes', { cache: 'no-store' });
      const d = (await r.json()) as Data & { error?: string; code?: string };
      if (r.status === 403 && d.code === 'scope') return setState('scope');
      if (!r.ok) throw new Error(d.error);
      setData(d);
      setState('ready');
    } catch (e) {
      setState('error');
      setToast(serverMsg(e instanceof Error ? e.message : ''));
    }
  }, [connected]);

  useEffect(() => {
    setRecent(recentPlaylists());
    void load();
  }, [load]);

  const weekAgo = Date.now() - 7 * 86400000;
  const songs = data?.songs ?? [];
  const inbox = songs.filter((s) => !s.in.length);
  const week = songs.filter((s) => s.addedAt >= weekAgo);
  const shown = useMemo(() => {
    const base = filter === 'inbox' ? inbox : filter === 'week' ? week : songs;
    const q = query.trim().toLowerCase();
    return q ? base.filter((s) => (s.title + ' ' + s.artist).toLowerCase().includes(q)) : base;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, filter, query]);
  const lists = useMemo(() => {
    const p = data?.playlists ?? [];
    const rank = (id: string) => {
      const k = recent.indexOf(id);
      return k < 0 ? 99 : k;
    };
    return [...p].sort((a, b) => rank(a.id) - rank(b.id));
  }, [data, recent]);
  const nameOf = (id: string) => data?.playlists.find((p) => p.id === id)?.name ?? '';

  const allSel = shown.length > 0 && shown.every((s) => sel.has(s.id));
  const toggle = (id: string) =>
    setSel((x) => {
      const n = new Set(x);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  const addTo = async (p: Playlist, force?: boolean) => {
    if (!sel.size) return flash(t('likes.pickFirst'));
    // Wie in Spotify: schon drin → erst fragen (nur neue / alle / abbrechen).
    const already = [...sel].filter((id) => data?.songs.find((s) => s.id === id)?.in.includes(p.id)).length;
    if (already && force === undefined) return setDupe({ p, already, total: sel.size });
    setDupe(null);
    if (force === false && already === sel.size) return flash(t('likes.alreadyIn', { name: p.name }));
    setBusy(true);
    try {
      const ids = [...sel];
      const r = await fetch('/api/widget/playlists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playlistId: p.id, trackIds: ids, force: force === true }),
      });
      const d = (await r.json()) as { added?: number; error?: string };
      if (!r.ok) throw new Error(d.error);
      rememberPlaylist(p.id);
      setRecent(recentPlaylists());
      setData((x) =>
        x && {
          ...x,
          songs: x.songs.map((s) => (sel.has(s.id) && !s.in.includes(p.id) ? { ...s, in: [...s.in, p.id] } : s)),
          playlists: x.playlists.map((q) => (q.id === p.id ? { ...q, count: q.count + (d.added ?? 0) } : q)),
        },
      );
      setSel(new Set());
      flash(d.added ? i18n.tn('likes.added', d.added).replace('{name}', p.name) : t('likes.alreadyIn', { name: p.name }));
    } catch (e) {
      flash(serverMsg(e instanceof Error ? e.message : ''));
    } finally {
      setBusy(false);
    }
  };

  const unlike = async () => {
    const ids = [...sel];
    setBusy(true);
    try {
      const r = await fetch('/api/likes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'unlike', trackIds: ids }),
      });
      const d = (await r.json()) as { error?: string };
      if (!r.ok) throw new Error(d.error);
      setData((x) => x && { ...x, songs: x.songs.filter((s) => !sel.has(s.id)) });
      setSel(new Set());
      flash(i18n.tn('likes.unliked', ids.length));
    } catch (e) {
      flash(serverMsg(e instanceof Error ? e.message : ''));
    } finally {
      setBusy(false);
    }
  };

  const when = (ts: number) => {
    if (!ts) return '';
    const d = new Date(ts);
    const start = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
    const diff = Math.round((start(new Date()) - start(d)) / 86400000);
    if (diff === 0) return t('history.today') + ' ' + i18n.fmt.time(ts);
    if (diff === 1) return t('history.yesterday');
    if (diff < 7) return i18n.fmt.weekday(ts);
    return i18n.fmt.dateShort(ts);
  };

  return (
    <div className="v2-page lk-page">
      <div className="v2-page-head lk-head">
        <div>
          <h1>
            {t('likes.title')}
            <span>.</span>
          </h1>
          <p>{t('likes.subtitle')}</p>
        </div>
        {state === 'ready' && (
          <div className="lk-stats">
            <span>
              <b>{inbox.length}</b>
              {t('likes.statInbox')}
            </span>
            <span>
              <b>{week.length}</b>
              {t('likes.statWeek')}
            </span>
          </div>
        )}
      </div>

      {!connected ? (
        <div className="lk-empty">{t('likes.connect')}</div>
      ) : state === 'scope' ? (
        <div className="lk-empty">
          <b>{t('likes.scopeTitle')}</b>
          <span>{t('likes.scopeText')}</span>
        </div>
      ) : state === 'loading' ? (
        <div className="lk-empty">{t('likes.loading')}</div>
      ) : state === 'error' ? (
        <div className="lk-empty">
          <span>{toast || t('likes.error')}</span>
          <button className="secondary" onClick={() => void load()}>
            {t('likes.retry')}
          </button>
        </div>
      ) : (
        <div className="lk-layout">
          <section className="lk-main">
            <div className="lk-bar">
              <div className="lk-filters">
                {(
                  [
                    ['inbox', t('likes.fInbox'), inbox.length],
                    ['week', t('likes.fWeek'), week.length],
                    ['all', t('likes.fAll'), songs.length],
                  ] as const
                ).map(([v, l, c]) => (
                  <button
                    key={v}
                    type="button"
                    className={filter === v ? 'is-on' : ''}
                    onClick={() => {
                      setFilter(v);
                      setSel(new Set());
                    }}
                  >
                    {l} <span>{c}</span>
                  </button>
                ))}
              </div>
              <input
                className="lk-search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t('likes.search')}
                aria-label={t('likes.search')}
              />
            </div>
            <div className="lk-table" role="table">
              <div className="lk-row is-head" role="row">
                <button
                  type="button"
                  className={'lk-check' + (allSel ? ' is-on' : '')}
                  aria-label={t('likes.selectAll')}
                  onClick={() => setSel(allSel ? new Set() : new Set(shown.map((s) => s.id)))}
                >
                  {allSel ? '✓' : ''}
                </button>
                <span>{t('likes.colSong')}</span>
                <span>{t('likes.colLiked')}</span>
                <span>{t('likes.colIn')}</span>
              </div>
              {!shown.length ? (
                <div className="lk-done">
                  <i>✓</i>
                  <b>{filter === 'inbox' ? t('likes.allSorted') : t('likes.none')}</b>
                  <span>{filter === 'inbox' ? t('likes.allSortedHint') : ''}</span>
                </div>
              ) : (
                <div className="lk-rows">
                  {shown.map((s) => {
                    const on = sel.has(s.id);
                    return (
                      <div key={s.id} className={'lk-row' + (on ? ' is-sel' : '')} role="row" onClick={() => toggle(s.id)}>
                        <span className={'lk-check' + (on ? ' is-on' : '')} aria-hidden="true">
                          {on ? '✓' : ''}
                        </span>
                        <span className="lk-song">
                          {s.cover ? <img src={s.cover} alt="" /> : <i />}
                          <span>
                            <b>{s.title}</b>
                            <small>{s.artist}</small>
                          </span>
                        </span>
                        <span className="lk-when">{when(s.addedAt)}</span>
                        <span className="lk-in">
                          {s.in.length ? (
                            <>
                              <em>{nameOf(s.in[0])}</em>
                              {s.in.length > 1 && <em>+{s.in.length - 1}</em>}
                            </>
                          ) : (
                            <em className="is-inbox">{t('likes.inbox')}</em>
                          )}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
            {sel.size > 0 && (
              <div className="lk-bulk">
                <b>{i18n.tn('likes.selected', sel.size)}</b>
                <span>{t('likes.bulkHint')}</span>
                <span className="lk-bulk-actions">
                  <button type="button" disabled={busy} onClick={() => void unlike()}>
                    ♡ {t('likes.unlike')}
                  </button>
                  <button type="button" className="is-dark" onClick={() => setSel(new Set())}>
                    {t('likes.done')}
                  </button>
                </span>
              </div>
            )}
          </section>
          <aside className="lk-side">
            <div className="lk-side-head">
              <b>{t('likes.playlists')}</b>
              <span>{t('likes.recentFirst')}</span>
            </div>
            <div className="lk-lists">
              {lists.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  className={'lk-pl' + (sel.size ? ' is-target' : '')}
                  disabled={busy}
                  onClick={() => void addTo(p)}
                >
                  {p.image ? <img src={p.image} alt="" /> : <i />}
                  <span>
                    <b>{p.name}</b>
                    <small>
                      {i18n.tn('likes.songs', p.count)}
                      {p.collaborative ? ' · ' + t('likes.shared') : ''}
                    </small>
                  </span>
                  <em>＋</em>
                </button>
              ))}
            </div>
            <p className="lk-note">{t('likes.note')}</p>
            {toast && state === 'ready' && <span className="lk-toast">{toast}</span>}
            {dupe && (
              <div className="lk-dupe" role="alertdialog">
                <b>{t('dupe.title')}</b>
                <span>
                  {dupe.total === 1
                    ? t('dupe.one', { name: dupe.p.name })
                    : t('dupe.some', { n: dupe.already, total: dupe.total, name: dupe.p.name })}
                </span>
                <div>
                  <button type="button" onClick={() => setDupe(null)}>{t('dupe.cancel')}</button>
                  {dupe.already < dupe.total && (
                    <button type="button" onClick={() => void addTo(dupe.p, false)}>{t('dupe.onlyNew')}</button>
                  )}
                  <button type="button" className="is-main" onClick={() => void addTo(dupe.p, true)}>
                    {dupe.total === 1 ? t('dupe.addAnyway') : t('dupe.addAll')}
                  </button>
                </div>
              </div>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}
