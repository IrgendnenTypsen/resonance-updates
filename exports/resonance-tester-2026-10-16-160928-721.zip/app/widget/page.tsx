'use client';
// F22 – Resonance-Widget (Mockup abgesegnet 2026-10-13, „passt“).
// Kleines Fenster für alle ohne Stream: echter Player (gleicher Renderer wie
// OBS) + ♥ (Spotify-Lieblingssongs) + „+“ (eigene Playlists).
// Stufe 1: Browser-Popup aus dem Studio. Größe = Fenstergröße (an den Ecken
// ziehen), der Player skaliert mit. Später: Desktop-App, immer im Vordergrund.
// Einstellungen pro Browser (localStorage). Nur Studio-Anmeldung, kein Overlay-Key.
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import { Overlay, estimatedProgress, type Config, type Track } from '@/lib/overlay';
import { presets } from '@/lib/presets';
import { GALLERY_TRACKS } from '@/lib/gallery-demo';
import { serverMsg, useT } from '@/lib/i18n';
import { recentPlaylists, rememberPlaylist } from '../likes-view';
import './widget.css';

type Look = { id: string; name: string; config: Config };
// Desktop-App (Tauri, F22 Stufe 2): globale API im Fenster (withGlobalTauri).
type TauriWin = {
  startDragging: () => Promise<void>;
  startResizeDragging: (dir: string) => Promise<void>;
  setSize: (s: unknown) => Promise<void>;
  hide: () => Promise<void>;
};
type TauriGlobal = {
  window: { getCurrentWindow: () => TauriWin };
  dpi: { LogicalSize: new (w: number, h: number) => unknown };
  event: { listen: (name: string, cb: (e: { payload: unknown }) => void) => Promise<() => void> };
};
const tauri = (): TauriGlobal | null =>
  typeof window !== 'undefined' ? ((window as unknown as { __TAURI__?: TauriGlobal }).__TAURI__ ?? null) : null;
type PL = { id: string; name: string; image: string; count: number; collaborative: boolean; has: boolean };
type Settings = {
  style: string; // 'live' | preset-id | 'look:<id>'
  accent: string; // '' = wie im Look
  alpha: number;
  side: 'right' | 'left' | 'bottom';
  dock: 'always' | 'hover';
  like: boolean;
  add: boolean;
  rank: boolean;
  hidePaused: boolean;
  ambient: boolean;
};
const KEY = 'resonance.widget.v1';
const CMD_KEY = 'resonance.widget.cmd';
const DEFAULTS: Settings = { style: 'live', accent: '', alpha: 1, side: 'right', dock: 'hover', like: true, add: true, rank: true, hidePaused: false, ambient: true };
const ACCENTS = ['', '#b3f47c', '#c1a0ff', '#ffac75', '#71d6ff', '#fb88bd', '#ffffff'];
// Stream-Player ohne Sinn allein: StreamShelf (Regal des Streams).
const WIDGET_PRESETS = presets.filter((p) => p.id !== 'shelf');

function readSettings(): Settings {
  try {
    return { ...DEFAULTS, ...(JSON.parse(localStorage.getItem(KEY) || '{}') as Partial<Settings>) };
  } catch {
    return DEFAULTS;
  }
}

export default function WidgetPage() {
  const i18n = useT();
  const { t } = i18n;
  const [s, setS] = useState<Settings>(DEFAULTS);
  const [liveConfig, setLiveConfig] = useState<Config | null>(null);
  const [track, setTrack] = useState<Track | null>(null);
  const [looks, setLooks] = useState<Look[]>([]);
  const [notice, setNotice] = useState('');
  const [toast, setToast] = useState('');
  const [menu, setMenu] = useState(false);
  const [gear, setGear] = useState(false);
  const [pls, setPls] = useState<{ track: string; list: PL[] } | null>(null);
  const [plQuery, setPlQuery] = useState('');
  const [dupe, setDupe] = useState<PL | null>(null);
  const [adding, setAdding] = useState(false);
  // Menü/Einstellungen mit Esc schließen.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      setMenu(false);
      setGear(false);
      setDupe(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  const [needScope, setNeedScope] = useState(false);
  const [natural, setNatural] = useState({ w: 480, h: 160 });
  const [demoParam, setDemoParam] = useState(false);
  const [desktop, setDesktop] = useState(false);
  const [panel, setPanel] = useState(false);
  const [clickThrough, setClickThrough] = useState(false);
  const [view, setView] = useState({ w: 520, h: 200 });
  const measureRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setS(readSettings());
    setDemoParam(/[?&]demo\b/.test(location.search));
    const isPanel = /[?&]panel=settings\b/.test(location.search);
    setPanel(isPanel);
    if (isPanel) {
      document.title = t('widget.settings');
      document.body.classList.add('rw-panel-body');
    }
    const isDesktop = /[?&]desktop\b/.test(location.search) && !!tauri();
    setDesktop(isDesktop);
    if (isDesktop) {
      // Durchsichtiges Fenster: nur der Player schwebt über dem Spiel.
      document.documentElement.style.background = 'transparent';
      document.body.classList.add('rw-desktop');
      void tauri()?.event.listen('resonance://clickthrough', (e) => setClickThrough(e.payload === true));
    }
    document.title = 'Resonance Widget';
    document.body.classList.add('allow-motion', 'rw-body');
    const onResize = () => setView({ w: window.innerWidth, h: window.innerHeight });
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  const save = (patch: Partial<Settings>) =>
    setS((x) => {
      const n = { ...x, ...patch };
      try {
        localStorage.setItem(KEY, JSON.stringify(n));
      } catch {
        // nur diese Sitzung
      }
      return n;
    });

  const flash = (m: string) => {
    setToast(m);
    window.setTimeout(() => setToast((x) => (x === m ? '' : x)), 2600);
  };

  // Laufender Song + Live-Look (Studio-Anmeldung).
  useEffect(() => {
    let stop = false;
    let timer: ReturnType<typeof setTimeout>;
    const poll = async () => {
      let wait = 4000;
      try {
        const r = await fetch('/api/now', { cache: 'no-store' });
        const d = (await r.json()) as { config?: Config; track?: Track | null; error?: string; message?: string; retryAfter?: number; connected?: boolean };
        if (stop) return;
        if (r.status === 401) setNotice(t('widget.signIn'));
        else if (!r.ok) throw new Error(d.error);
        else {
          if (d.config) setLiveConfig(d.config);
          setNotice(d.connected === false ? t('widget.connect') : '');
          if (d.track) setTrack({ ...d.track, fetchedAt: Date.now() });
          else if (!d.message) setTrack(null);
          if (d.retryAfter) wait = Math.max(wait, d.retryAfter * 1000);
        }
      } catch {
        wait = 10000;
      }
      if (!stop) timer = setTimeout(poll, wait);
    };
    void poll();
    const tick = setInterval(() => setTrack((x) => (x?.playing ? { ...x, progress: estimatedProgress(x), fetchedAt: Date.now() } : x)), 1000);
    fetch('/api/looks', { cache: 'no-store' })
      .then((r) => (r.ok ? (r.json() as Promise<{ looks?: Look[] }>) : null))
      .then((d) => d?.looks && setLooks(d.looks))
      .catch(() => {});
    return () => {
      stop = true;
      clearTimeout(timer);
      clearInterval(tick);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Gewählter Stil → Config (+ Akzent / Rang aus den Widget-Einstellungen).
  const config = useMemo<Config | null>(() => {
    let base: Config | null = liveConfig;
    if (s.style.startsWith('look:')) base = looks.find((l) => 'look:' + l.id === s.style)?.config ?? liveConfig;
    else if (s.style !== 'live') base = WIDGET_PRESETS.find((p) => p.id === s.style)?.config ?? liveConfig;
    if (!base) return null;
    let c: Config = { ...base, animation: base.animation, hidePaused: s.hidePaused };
    if (base.layout === 'shelf') c = { ...WIDGET_PRESETS[0].config, hidePaused: s.hidePaused };
    if (s.accent)
      c = { ...c, accent: s.accent, progressColor: s.accent, controlAccentColor: s.accent, statusAccentColor: s.accent, linkAccentColors: true, autoAccentFromCover: false };
    if (!s.rank) c = { ...c, lolRank: false, valoRank: false, lolTicker: false, valoTicker: false };
    return c;
  }, [liveConfig, looks, s]);

  // Natürliche Größe des Players messen → passend ins Fenster skalieren.
  useLayoutEffect(() => {
    const el = measureRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      const w = el.scrollWidth, h = el.scrollHeight;
      if (w > 20 && h > 20) setNatural((n) => (Math.abs(n.w - w) > 1 || Math.abs(n.h - h) > 1 ? { w, h } : n));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [config]);
  // Ohne laufenden Song: beim Anpassen (oder mit ?demo) einen Demo-Song zeigen.
  const shown: Track | null = track ?? (gear || demoParam ? { ...GALLERY_TRACKS[0], fetchedAt: Date.now() } : null);
  // ♥/+ schweben über dem Player (kein eigener Platz) → Player füllt das Fenster.
  const pad = desktop ? 2 : 8;
  // Solange das Playlist-Menü das Fenster vergrößert hat: Player-Maße einfrieren.
  const [room, setRoom] = useState<{ w: number; h: number } | null>(null);
  const base = room ?? view;
  const availW = base.w - pad * 2;
  const availH = base.h - pad * 2;
  const scale = Math.max(0.2, Math.min(availW / natural.w, availH / natural.h, 2.5));

  // ♥
  const liked = !!track?.favorite;
  // F23: Andere Quellen (YouTube Music, Browser …) → ♥/+ nur mit Spotify.
  // Auf Spotify gefunden (track.id) → ♥ und + gehen auch für andere Quellen.
  const spotifyOnly = !!track?.source && track.source !== 'spotify' && !track.id;
  const like = async () => {
    if (spotifyOnly) return flash(t('widget.onlySpotify'));
    if (!track?.id) return flash(t('widget.noSong'));
    const on = !liked;
    setTrack((x) => (x ? { ...x, favorite: on } : x));
    try {
      const r = await fetch('/api/widget/like', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ trackId: track.id, on }),
      });
      const d = (await r.json()) as { error?: string; code?: string };
      if (r.status === 403 && d.code === 'scope') setNeedScope(true);
      if (!r.ok) throw new Error(d.error);
      flash(on ? t('widget.liked') : t('widget.unliked'));
    } catch (e) {
      setTrack((x) => (x ? { ...x, favorite: !on } : x));
      flash(serverMsg(e instanceof Error ? e.message : ''));
    }
  };

  // +
  const loadPls = useCallback(async (id: string) => {
    try {
      const r = await fetch('/api/widget/playlists?track=' + encodeURIComponent(id), { cache: 'no-store' });
      const d = (await r.json()) as { playlists?: PL[]; error?: string; code?: string };
      if (r.status === 403 && d.code === 'scope') setNeedScope(true);
      if (!r.ok) throw new Error(d.error);
      setPls({ track: id, list: d.playlists ?? [] });
    } catch (e) {
      setMenu(false);
      flash(serverMsg(e instanceof Error ? e.message : ''));
    }
  }, []);
  const openMenu = () => {
    if (spotifyOnly) return flash(t('widget.onlySpotify'));
    if (!track?.id) return flash(t('widget.noSong'));
    setGear(false);
    setDupe(null);
    setMenu((m) => !m);
    setPlQuery('');
    if (pls?.track !== track.id) {
      setPls(null);
      void loadPls(track.id);
    }
  };
  const addTo = async (p: PL, force = false) => {
    if (!track?.id) return;
    // Wie in Spotify: schon drin → erst fragen.
    if (p.has && !force) return setDupe(p);
    if (adding) return;
    setAdding(true);
    setDupe(null);
    setPls((x) => x && { ...x, list: x.list.map((q) => (q.id === p.id ? { ...q, has: true, count: q.count + 1 } : q)) });
    setMenu(false);
    try {
      const r = await fetch('/api/widget/playlists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playlistId: p.id, trackIds: [track.id], force }),
      });
      const d = (await r.json()) as { error?: string; code?: string };
      if (r.status === 403 && d.code === 'scope') setNeedScope(true);
      if (!r.ok) throw new Error(d.error);
      rememberPlaylist(p.id);
      flash(t('widget.addedTo', { name: p.name }));
    } catch (e) {
      setPls((x) => x && { ...x, list: x.list.map((q) => (q.id === p.id ? { ...q, has: p.has, count: q.count - 1 } : q)) });
      flash(serverMsg(e instanceof Error ? e.message : ''));
    } finally {
      setAdding(false);
    }
  };
  const sortedPls = useMemo(() => {
    const recent = recentPlaylists();
    const list = (pls?.list ?? []).filter((p) => p.name.toLowerCase().includes(plQuery.trim().toLowerCase()));
    const r = (id: string) => (recent.indexOf(id) < 0 ? 99 : recent.indexOf(id));
    return [...list].sort((a, b) => r(a.id) - r(b.id));
  }, [pls, plQuery]);
  const recentIds = recentPlaylists();

  // Fenster genau auf den Player zuschneiden (k = Größe). Im schwebenden
  // Bild-im-Bild-Fenster liegt die Seite in einem iframe → äußeres Fenster ändern.
  const sizeWindow = (k: number) => {
    const tw = tauri();
    if (desktop && tw) {
      void tw.window.getCurrentWindow().setSize(new tw.dpi.LogicalSize(Math.round(natural.w * k + pad * 2), Math.round(natural.h * k + pad * 2)));
      return;
    }
    try {
      const w = (window.top ?? window) as Window;
      w.resizeTo(
        Math.round(natural.w * k + pad * 2 + (w.outerWidth - w.innerWidth)),
        Math.round(natural.h * k + pad * 2 + (w.outerHeight - w.innerHeight)),
      );
    } catch {
      // Browser erlaubt es nicht → Ecken ziehen
    }
  };

  // Playlist-Menü braucht Platz: kleines Widget-Fenster kurz vergrößern und
  // danach wieder auf die alte Größe setzen (sonst sieht man nur die Überschrift).
  const MENU_W = 320;
  const MENU_H = 400;
  const resizeInner = (w: number, h: number) => {
    const tw = tauri();
    if (desktop && tw) {
      void tw.window.getCurrentWindow().setSize(new tw.dpi.LogicalSize(Math.round(w), Math.round(h)));
      return;
    }
    try {
      const top = (window.top ?? window) as Window;
      top.resizeTo(Math.round(w + (top.outerWidth - top.innerWidth)), Math.round(h + (top.outerHeight - top.innerHeight)));
    } catch {
      // Browser erlaubt es nicht – Menü scrollt dann
    }
  };
  const roomRef = useRef(room);
  roomRef.current = room;
  useEffect(() => {
    if (panel) return;
    if (menu) {
      if (roomRef.current || (view.w >= MENU_W && view.h >= MENU_H)) return;
      const before = { w: view.w, h: view.h };
      setRoom(before);
      resizeInner(Math.max(before.w, MENU_W), Math.max(before.h, MENU_H));
    } else if (roomRef.current) {
      const before = roomRef.current;
      setRoom(null);
      resizeInner(before.w, before.h);
    }
    // nur auf Öffnen/Schließen reagieren
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [menu]);

  // Einstellungen/Befehle aus dem Einstellungsfenster übernehmen.
  const sizeRef = useRef(sizeWindow);
  sizeRef.current = sizeWindow;
  const scaleRef = useRef(scale);
  scaleRef.current = scale;
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === KEY) setS(readSettings());
      if (e.key === CMD_KEY && e.newValue) {
        try {
          const c = JSON.parse(e.newValue) as { fit?: boolean; size?: number };
          sizeRef.current(c.fit ? scaleRef.current : Number(c.size) || 1);
        } catch {
          // ignorieren
        }
      }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  // ⚙ öffnet die Einstellungen als eigenes Fenster (nicht im Widget, das kann
  // winzig sein). Änderungen laufen über localStorage (gleiche Herkunft) zurück.
  const sendCmd = (cmd: { fit?: boolean; size?: number }) => {
    try {
      localStorage.setItem(CMD_KEY, JSON.stringify({ ...cmd, t: Date.now() }));
    } catch {
      // nur Komfort
    }
  };
  const closePanel = () => {
    const tw = tauri();
    if (tw) void (tw.window.getCurrentWindow() as unknown as { close: () => Promise<void> }).close();
    else window.close();
  };
  const openSettings = async () => {
    setMenu(false);
    const url = location.origin + '/widget?panel=settings' + (desktop ? '&desktop=1' : '');
    const tw = tauri() as (TauriGlobal & { webviewWindow?: { WebviewWindow: { new (label: string, o: object): unknown; getByLabel: (l: string) => Promise<{ setFocus: () => Promise<void> } | null> } } }) | null;
    if (desktop && tw?.webviewWindow) {
      try {
        const open = await tw.webviewWindow.WebviewWindow.getByLabel('settings');
        if (open) return void open.setFocus();
        new tw.webviewWindow.WebviewWindow('settings', { url, title: t('widget.settings'), width: 360, height: 680, alwaysOnTop: true, resizable: true });
        return;
      } catch {
        // weiter mit normalem Fenster
      }
    }
    window.open(url, 'resonance-widget-settings', 'popup=yes,width=380,height=700');
  };

  const styleOptions: [string, string][] = [
    ['live', t('widget.styleLive')],
    ...WIDGET_PRESETS.map((p) => [p.id, p.name] as [string, string]),
  ];

  if (panel)
    return (
      <div className="rw-panel">
        <div className="rw-row-head">
            <b>{t('widget.settings')}</b>
            <button type="button" onClick={closePanel} aria-label={t('widget.close')}>×</button>
          </div>
          <label className="rw-field">
            <span>{t('widget.style')}</span>
            <select value={s.style} onChange={(e) => save({ style: e.target.value })}>
              {styleOptions.map(([v, l]) => (
                <option key={v} value={v}>{l}</option>
              ))}
              {looks.length > 0 && (
                <optgroup label={t('widget.yourLooks')}>
                  {looks.map((l) => (
                    <option key={l.id} value={'look:' + l.id}>{l.name}</option>
                  ))}
                </optgroup>
              )}
            </select>
          </label>
          <div className="rw-field">
            <span>{t('widget.accent')}</span>
            <div className="rw-swatches">
              {ACCENTS.map((a) => (
                <button key={a || 'orig'} type="button" className={'rw-sw' + (s.accent === a ? ' is-on' : '') + (a ? '' : ' is-orig')} style={a ? { background: a } : undefined} onClick={() => save({ accent: a })} title={a || t('widget.accentLook')} aria-label={a || t('widget.accentLook')} />
              ))}
            </div>
          </div>
          <button type="button" className="rw-fit" onClick={() => sendCmd({ fit: true })}>{t('widget.fit')}</button>
          <div className="rw-field">
            <span>{t('widget.size')}</span>
            <div className="rw-seg">
              {([['S', 0.6], ['M', 0.85], ['L', 1.1]] as const).map(([l, k]) => (
                <button key={l} type="button" onClick={() => sendCmd({ size: k })}>{t(('widget.size' + l) as 'widget.sizeS')}</button>
              ))}
            </div>
            <small className="rw-muted">{t('widget.sizeHint')}</small>
          </div>
          <div className="rw-field">
            <span>{t('widget.opacity')}</span>
            <div className="rw-seg">
              {[1, 0.85, 0.7, 0.5].map((a) => (
                <button key={a} type="button" className={s.alpha === a ? 'is-on' : ''} onClick={() => save({ alpha: a })}>{Math.round(a * 100)} %</button>
              ))}
            </div>
          </div>
          <div className="rw-field">
            <span>{t('widget.dock')}</span>
            <div className="rw-seg">
              {(['right', 'left', 'bottom'] as const).map((v) => (
                <button key={v} type="button" className={s.side === v ? 'is-on' : ''} onClick={() => save({ side: v })}>{t(('widget.side.' + v) as 'widget.side.right')}</button>
              ))}
            </div>
            <div className="rw-seg">
              {(['always', 'hover'] as const).map((v) => (
                <button key={v} type="button" className={s.dock === v ? 'is-on' : ''} onClick={() => save({ dock: v })}>{t(('widget.dock.' + v) as 'widget.dock.always')}</button>
              ))}
            </div>
          </div>
          {(
            [
              ['like', t('widget.tLike')],
              ['add', t('widget.tAdd')],
              ['rank', t('widget.tRank')],
              ['hidePaused', t('widget.tPause')],
              ['ambient', t('widget.tAmbient')],
            ] as const
          ).map(([k, l]) => (
            <label key={k} className="rw-toggle">
              <span>{l}</span>
              <input type="checkbox" checked={s[k]} onChange={(e) => save({ [k]: e.target.checked } as Partial<Settings>)} />
            </label>
          ))}
          <small className="rw-muted">{t('widget.lookHint')}</small>
      </div>
    );

  return (
    <div className={'rw' + (s.dock === 'hover' ? ' is-dock-hover' : '')} style={{ '--rw-alpha': s.alpha } as CSSProperties}>
      {/* Hintergrund: unscharfes Cover statt schwarzer Fläche (Fenster ist nie ganz passend). */}
      {s.ambient && !desktop && shown?.cover && <div className="rw-ambient" style={{ backgroundImage: `url("${shown.cover}")` }} />}
      {desktop && clickThrough && <div className="rw-ct">{t('widget.clickThrough')}</div>}
      <div
        className={'rw-stage is-' + s.side + (room ? ' is-frozen' : '')}
        style={room ? { left: room.w / 2, top: room.h / 2 } : undefined}
        onMouseDown={(e) => {
          // Desktop-App: Player anfassen = Fenster verschieben (nicht auf Knöpfen).
          if (!desktop || e.button !== 0 || (e.target as HTMLElement).closest('button')) return;
          void tauri()?.window.getCurrentWindow().startDragging();
        }}
      >
        <div className="rw-player" style={shown ? { width: natural.w * scale, height: natural.h * scale } : { width: 0, height: 0, overflow: 'hidden' }}>
          <div ref={measureRef} className="rw-measure" style={{ transform: `scale(${scale})` }}>
            {config && <Overlay config={config} track={shown} lang={i18n.locale} />}
          </div>
        </div>
        {!shown && <div className="rw-idle">{t('widget.idle')}</div>}
        {(s.like || s.add) && shown && (
          <div className={'rw-dock' + (spotifyOnly ? ' is-off' : '')} title={spotifyOnly ? t('widget.onlySpotify') : undefined}>
            {s.like && (
              <button type="button" className={'rw-ib' + (liked ? ' is-liked' : '')} onClick={() => void like()} title={liked ? t('widget.unlikeTitle') : t('widget.likeTitle')} aria-pressed={liked}>
                {liked && <span className="rw-burst" />}
                <svg width="17" height="17" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M12 20.5s-7.5-4.6-9.3-9.2C1.4 8 3.4 4.5 7 4.5c2 0 3.6 1.1 5 3 1.4-1.9 3-3 5-3 3.6 0 5.6 3.5 4.3 6.8-1.8 4.6-9.3 9.2-9.3 9.2z" />
                </svg>
              </button>
            )}
            {s.add && (
              <button type="button" className={'rw-ib' + (menu ? ' is-open' : '')} onClick={openMenu} title={t('widget.addTitle')}>
                +
              </button>
            )}
          </div>
        )}
      </div>

      {desktop && (
        <span
          className="rw-grip"
          title={t('widget.resize')}
          onMouseDown={(e) => {
            e.preventDefault();
            void tauri()?.window.getCurrentWindow().startResizeDragging('SouthEast');
          }}
        />
      )}
      <button type="button" className="rw-gear" onClick={() => void openSettings()} title={t('widget.settings')} aria-label={t('widget.settings')}>
        ⚙
      </button>

      {notice && <div className="rw-notice">{notice}</div>}
      {needScope && (
        <div className="rw-notice is-warn">
          <b>{t('widget.scopeTitle')}</b> {t('widget.scopeText')}
          <button type="button" onClick={() => setNeedScope(false)} aria-label={t('widget.close')}>×</button>
        </div>
      )}
      {toast && <div className="rw-toast">{toast}</div>}

      {menu && (
        <div className="rw-backdrop" onClick={() => { setMenu(false); setDupe(null); }} />
      )}
      {menu && (
        <div className="rw-sheet rw-menu" role="dialog" aria-label={t('widget.addTitle')}>
          <div className="rw-row-head">
            <b>{t('widget.addTitle')}</b>
            <button type="button" onClick={() => { setMenu(false); setDupe(null); }} aria-label={t('widget.close')}>×</button>
          </div>
          {track?.matched && <small className="rw-muted">{t('widget.matched')}</small>}
          {dupe && (
            <div className="rw-dupe" role="alertdialog">
              <b>{t('dupe.title')}</b>
              <span>{t('dupe.one', { name: dupe.name })}</span>
              <div>
                <button type="button" onClick={() => setDupe(null)}>{t('dupe.cancel')}</button>
                <button type="button" className="is-main" onClick={() => void addTo(dupe, true)}>{t('dupe.addAnyway')}</button>
              </div>
            </div>
          )}
          <input autoFocus value={plQuery} onChange={(e) => setPlQuery(e.target.value)} placeholder={t('widget.searchPl')} />
          {!pls ? (
            <span className="rw-muted">{t('widget.loadingPl')}</span>
          ) : !sortedPls.length ? (
            <span className="rw-muted">{t('widget.noPl')}</span>
          ) : (
            <div className="rw-pl-list">
              {sortedPls.map((p, k) => (
                <div key={p.id}>
                  {k === 0 && recentIds.includes(p.id) && !plQuery && <small className="rw-sec">{t('widget.recent')}</small>}
                  {k > 0 && recentIds.includes(sortedPls[k - 1].id) && !recentIds.includes(p.id) && !plQuery && <small className="rw-sec">{t('widget.yourPl')}</small>}
                  <button type="button" className="rw-pl" onClick={() => void addTo(p)}>
                    {p.image ? <img src={p.image} alt="" /> : <i />}
                    <span>
                      <b>{p.name}</b>
                      <small>{i18n.tn('likes.songs', p.count)}{p.collaborative ? ' · ' + t('likes.shared') : ''}</small>
                    </span>
                    <em className={p.has ? 'is-on' : ''}>✓</em>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  );
}
