-- F23: kleine Studio-Einstellungen je Besitzer (z. B. Musikquelle). Rein additiv.
CREATE TABLE studio_prefs (
  owner TEXT NOT NULL,
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (owner, key)
);
