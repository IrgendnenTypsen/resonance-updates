// --- Kleine Studio-Einstellungen je Besitzer (Tabelle studio_prefs, Migration 0013) ---
// Ohne Tabelle (vor dem Neustart) → Standardwerte, nie ein Fehler.
const cache = new Map<string, { v: string | null; at: number }>();
const TTL = 10000;

export async function getPref(db: D1Database, owner: string, key: string): Promise<string | null> {
  const k = owner + '\u0000' + key;
  const hit = cache.get(k);
  if (hit && Date.now() - hit.at < TTL) return hit.v;
  let v: string | null = null;
  try {
    const r = await db.prepare('SELECT value FROM studio_prefs WHERE owner=? AND key=?').bind(owner, key).first<{ value: string }>();
    v = r?.value ?? null;
  } catch {
    v = null;
  }
  cache.set(k, { v, at: Date.now() });
  return v;
}

/** Letzter bekannter Wert ohne DB-Zugriff (für synchrone Stellen). */
export function peekPref(owner: string, key: string): string | null {
  return cache.get(owner + '\u0000' + key)?.v ?? null;
}

export async function setPref(db: D1Database, owner: string, key: string, value: string) {
  await db
    .prepare(
      `INSERT INTO studio_prefs (owner, key, value, updated_at) VALUES (?,?,?,?)
       ON CONFLICT(owner, key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at`,
    )
    .bind(owner, key, value, Date.now())
    .run();
  cache.set(owner + '\u0000' + key, { v: value, at: Date.now() });
}
