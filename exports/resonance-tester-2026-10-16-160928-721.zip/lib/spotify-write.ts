// --- F22: Schreibzugriffe auf Spotify (Liken, In-Playlist-Packen) ---
// Braucht die Scopes user-library-modify + playlist-modify-public/-private
// (seit 2026-10-13, von Pascal freigegeben). Alte Verbindungen ohne diese
// Scopes bekommen 403 → code 'scope' → im Studio „Spotify neu verbinden“.
// API-Stand Feb. 2026: PUT/DELETE /me/library (URIs), POST /playlists/{id}/items,
// GET /me/library/contains, GET /playlists/{id}/items (nur eigene/gemeinsame).

const API = 'https://api.spotify.com/v1';

export class SpotifyWriteError extends Error {
  constructor(
    public code: 'scope' | 'limit' | 'auth' | 'notFound' | 'failed',
    message: string,
    public retryAfter = 0,
  ) {
    super(message);
  }
}

async function call(access: string, method: string, url: string, body?: unknown) {
  const r = await fetch(url, {
    method,
    headers: {
      Authorization: 'Bearer ' + access,
      ...(body ? { 'Content-Type': 'application/json' } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(10000),
    cache: 'no-store',
  });
  if (r.ok) return r;
  const text = await r.text().catch(() => '');
  if (r.status === 429)
    throw new SpotifyWriteError('limit', 'Spotify-Limit erreicht. Bitte kurz warten.', Number(r.headers.get('retry-after')) || 30);
  if (r.status === 401) throw new SpotifyWriteError('auth', 'Spotify-Verbindung abgelaufen. Bitte erneut verbinden.');
  if (r.status === 403 && /scope/i.test(text))
    throw new SpotifyWriteError('scope', 'Für Liken und Playlists Spotify einmal neu verbinden.');
  if (r.status === 403) throw new SpotifyWriteError('scope', 'Spotify erlaubt diese Änderung nicht.');
  if (r.status === 404) throw new SpotifyWriteError('notFound', 'Nicht gefunden.');
  throw new SpotifyWriteError('failed', 'Spotify hat die Änderung abgelehnt.');
}

const trackUri = (id: string) => 'spotify:track:' + id;
export const isTrackId = (id: unknown): id is string => typeof id === 'string' && /^[A-Za-z0-9]{10,40}$/.test(id);
export const isPlaylistId = isTrackId;

/** Songs liken (on) oder Likes entfernen – bis 40 pro Anfrage. */
export async function setLiked(access: string, trackIds: string | string[], on: boolean) {
  const ids = Array.isArray(trackIds) ? trackIds : [trackIds];
  for (let i = 0; i < ids.length; i += 40)
    await call(access, on ? 'PUT' : 'DELETE', API + '/me/library?uris=' + ids.slice(i, i + 40).map((t) => encodeURIComponent(trackUri(t))).join(','));
}

/** Like-Status für bis zu 40 Songs. */
export async function likedState(access: string, ids: string[]): Promise<Record<string, boolean>> {
  const out: Record<string, boolean> = {};
  for (let i = 0; i < ids.length; i += 40) {
    const part = ids.slice(i, i + 40);
    const r = await call(access, 'GET', API + '/me/library/contains?uris=' + part.map((t) => encodeURIComponent(trackUri(t))).join(','));
    const d = (await r.json()) as boolean[];
    part.forEach((id, k) => (out[id] = d[k] === true));
  }
  return out;
}

export type PlaylistInfo = {
  id: string;
  name: string;
  image: string;
  count: number;
  collaborative: boolean;
  snapshot: string;
};

/** Eigene und gemeinsame Playlists (nur die darf man ändern). */
export async function writablePlaylists(access: string): Promise<PlaylistInfo[]> {
  const me = (await (await call(access, 'GET', API + '/me')).json()) as { id?: string };
  const out: PlaylistInfo[] = [];
  let url: string | null = API + '/me/playlists?limit=50';
  for (let page = 0; url && page < 10; page++) {
    const d = (await (await call(access, 'GET', url)).json()) as {
      items?: {
        id?: string;
        name?: string;
        images?: { url?: string }[] | null;
        owner?: { id?: string };
        collaborative?: boolean;
        snapshot_id?: string;
        items?: { total?: number };
        tracks?: { total?: number };
      }[];
      next?: string | null;
    };
    for (const p of d.items || []) {
      if (!p.id) continue;
      if (p.owner?.id !== me.id && !p.collaborative) continue;
      out.push({
        id: p.id,
        name: p.name || '',
        image: p.images?.[0]?.url || '',
        count: p.items?.total ?? p.tracks?.total ?? 0,
        collaborative: p.collaborative === true,
        snapshot: p.snapshot_id || '',
      });
    }
    url = d.next ?? null;
  }
  return out;
}

// Inhalt je Playlist (Song-IDs), gecacht bis sich der snapshot_id ändert.
const index = new Map<string, { snapshot: string; ids: Set<string> }>();

async function playlistIds(access: string, p: PlaylistInfo): Promise<Set<string>> {
  const hit = index.get(p.id);
  if (hit && hit.snapshot === p.snapshot) return hit.ids;
  const ids = new Set<string>();
  let url: string | null = API + '/playlists/' + p.id + '/items?limit=100&fields=items(item(id),track(id)),next';
  for (let page = 0; url && page < 30; page++) {
    if (page) await new Promise((r) => setTimeout(r, 80)); // Spotify-Limit schonen
    const d = (await (await call(access, 'GET', url)).json()) as {
      items?: { item?: { id?: string } | null; track?: { id?: string } | null }[];
      next?: string | null;
    };
    for (const it of d.items || []) {
      const id = it.item?.id || it.track?.id;
      if (id) ids.add(id);
    }
    url = d.next ?? null;
  }
  index.set(p.id, { snapshot: p.snapshot, ids });
  return ids;
}

/** Für jede Playlist: welche der Songs schon drin sind. */
export async function membership(access: string, lists: PlaylistInfo[], trackIds: string[]) {
  const out: Record<string, string[]> = {};
  for (const p of lists) {
    try {
      const ids = await playlistIds(access, p);
      out[p.id] = trackIds.filter((t) => ids.has(t));
    } catch (e) {
      if (e instanceof SpotifyWriteError && e.code === 'limit') throw e;
      out[p.id] = [];
    }
  }
  return out;
}

// Pro Playlist nacheinander: zwei schnelle Klicks dürfen nicht beide „ist noch
// nicht drin“ sehen und den Song doppelt eintragen.
const locks = new Map<string, Promise<unknown>>();

/** Songs in eine Playlist packen – Doppelte werden übersprungen (außer `force`). */
export async function addToPlaylist(access: string, p: PlaylistInfo, trackIds: string[], force = false) {
  const prev = locks.get(p.id) ?? Promise.resolve();
  const run = prev.catch(() => {}).then(() => addNow(access, p, trackIds, force));
  locks.set(p.id, run);
  try {
    return await run;
  } finally {
    if (locks.get(p.id) === run) locks.delete(p.id);
  }
}

async function addNow(access: string, p: PlaylistInfo, trackIds: string[], force: boolean) {
  const have = await playlistIds(access, p);
  const fresh = force ? [...new Set(trackIds)] : [...new Set(trackIds)].filter((t) => !have.has(t));
  for (let i = 0; i < fresh.length; i += 100) {
    const part = fresh.slice(i, i + 100);
    const r = await call(access, 'POST', API + '/playlists/' + p.id + '/items', { uris: part.map(trackUri) });
    const d = (await r.json().catch(() => ({}))) as { snapshot_id?: string };
    part.forEach((t) => have.add(t));
    if (d.snapshot_id) index.set(p.id, { snapshot: d.snapshot_id, ids: have });
  }
  return { added: fresh.length, skipped: trackIds.length - fresh.length };
}

export type LikedSong = { id: string; title: string; artist: string; cover: string; addedAt: number };

/** Lieblingssongs (neueste zuerst), bis `max`. */
export async function likedSongs(access: string, max = 300): Promise<LikedSong[]> {
  const out: LikedSong[] = [];
  let url: string | null = API + '/me/tracks?limit=50';
  while (url && out.length < max) {
    const d = (await (await call(access, 'GET', url)).json()) as {
      items?: {
        added_at?: string;
        track?: { id?: string; name?: string; artists?: { name?: string }[]; album?: { images?: { url?: string }[] } } | null;
      }[];
      next?: string | null;
    };
    for (const it of d.items || []) {
      const t = it.track;
      if (!t?.id) continue;
      out.push({
        id: t.id,
        title: t.name || '',
        artist: (t.artists || []).map((a) => a.name || '').filter(Boolean).join(', '),
        cover: t.album?.images?.[t.album.images.length > 1 ? 1 : 0]?.url || '',
        addedAt: it.added_at ? Date.parse(it.added_at) : 0,
      });
    }
    url = d.next ?? null;
  }
  return out.slice(0, max);
}
