// --- F22: gemeinsame Hilfen für /api/widget/* und /api/likes ---
// Nur Studio-Anmeldung (Cookie), NIE der Overlay-Key: Schreibzugriffe auf
// Spotify dürfen OBS-Links nicht erlauben.
import { freshAccess, getStudio, json, type Row } from './server';
import { SpotifyWriteError } from './spotify-write';

export async function studioAccess(req: Request): Promise<{ row: Row; access: string } | Response> {
  const row = await getStudio(req);
  if (!row) return json({ error: 'Studio nicht gefunden.' }, 401);
  if (!row.refresh_token) return json({ error: 'Spotify ist nicht verbunden.', code: 'connect' }, 400);
  const access = await freshAccess(row);
  if (!access) return json({ error: 'Spotify ist nicht verbunden.', code: 'connect' }, 400);
  return { row, access };
}

export function writeError(e: unknown) {
  if (e instanceof SpotifyWriteError) {
    const status = e.code === 'scope' ? 403 : e.code === 'limit' ? 429 : e.code === 'auth' ? 401 : e.code === 'notFound' ? 404 : 502;
    return json({ error: e.message, code: e.code, retryAfter: e.retryAfter || undefined }, status);
  }
  return json({ error: e instanceof Error ? e.message : 'Spotify ist gerade nicht erreichbar.' }, 503);
}
