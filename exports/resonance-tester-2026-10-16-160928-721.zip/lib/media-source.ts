// --- F23: Musikquelle wählen (Spotify ↔ Windows-Medienwiedergabe) ---
// Läuft im Worker. Holt die Wiedergaben vom Vite-Plugin
// (/__resonance/media/sessions, nur localhost) und entscheidet je nach
// Einstellung (auto | spotify | other), welcher Song angezeigt wird.
import type { Track } from './overlay';

export type SourceMode = 'auto' | 'spotify' | 'other';
export const SOURCE_MODES: SourceMode[] = ['auto', 'spotify', 'other'];
export const cleanSourceMode = (v: unknown): SourceMode => (SOURCE_MODES.includes(v as SourceMode) ? (v as SourceMode) : 'auto');

export type MediaSession = {
  app: string;
  title: string;
  artist: string;
  album: string;
  status: string;
  posMs: number;
  durMs: number;
  at: number;
  cover: string;
};

let origin = 'http://127.0.0.1:3000';
/** Wird von /api/now mit dem echten Ursprung (Port) gesetzt. */
export function setLocalOrigin(url: string) {
  try {
    const u = new URL(url);
    if (['127.0.0.1', 'localhost'].includes(u.hostname)) origin = u.origin.replace('localhost', '127.0.0.1');
  } catch {
    // bleibt
  }
}

let cache: { at: number; sessions: MediaSession[] } = { at: 0, sessions: [] };
export async function mediaSessions(): Promise<MediaSession[]> {
  if (Date.now() - cache.at < 1200) return cache.sessions;
  try {
    const r = await fetch(origin + '/__resonance/media/sessions', { signal: AbortSignal.timeout(800), cache: 'no-store' });
    const d = (await r.json()) as { sessions?: MediaSession[] };
    cache = { at: Date.now(), sessions: Array.isArray(d.sessions) ? d.sessions : [] };
  } catch {
    cache = { at: Date.now(), sessions: [] };
  }
  return cache.sessions;
}

const isSpotifyApp = (app: string) => /spotify/i.test(app);
const isBrowser = (app: string) => /chrome|msedge|edge|firefox|opera|brave|vivaldi/i.test(app);

/** Anzeigename der Quelle (für die Statuszeile), leer = Browser/unbekannt. */
export function sourceName(app: string): string {
  if (/amazon/i.test(app)) return 'Amazon Music';
  if (/youtube\s*music|youtubemusic|cinhimbnkkaeohfgghhklpknlkffjgod/i.test(app)) return 'YouTube Music';
  if (/applemusic|apple\s*music/i.test(app)) return 'Apple Music';
  if (/deezer/i.test(app)) return 'Deezer';
  if (/tidal/i.test(app)) return 'TIDAL';
  if (/soundcloud/i.test(app)) return 'SoundCloud';
  return '';
}

/** YouTube-Titel aufräumen: „Künstler - Topic“, „Künstler – Song (Official Video)“. */
export function cleanMedia(s: MediaSession): { title: string; artist: string } {
  let title = s.title.trim();
  let artist = s.artist.trim().replace(/\s+-\s+Topic$/i, '');
  if (isBrowser(s.app)) {
    const m = /^(.+?)\s+[-–—]\s+(.+)$/.exec(title);
    // Nur trennen, wenn der Interpret wie ein Kanal aussieht (oder fehlt).
    if (m && (!artist || /vevo$|official|records|music$/i.test(artist) || m[1].toLowerCase().includes(artist.toLowerCase()) || artist.toLowerCase().includes(m[1].toLowerCase()))) {
      artist = m[1].trim();
      title = m[2].trim();
    }
    title = title
      .replace(/\s*[([](official\s*(music\s*)?(video|audio|visualizer|lyric(s)?\s*video)|lyrics?|audio|video|mv|hd|4k|visualizer)[)\]]/gi, '')
      .trim();
  }
  return { title, artist };
}

export function mediaToTrack(s: MediaSession, now = Date.now()): Track {
  const playing = s.status === 'Playing';
  const { title, artist } = cleanMedia(s);
  const progress = Math.max(0, Math.min(s.durMs || Infinity, s.posMs + (playing ? Math.max(0, now - s.at) : 0)));
  return {
    title,
    artist,
    album: s.album || '',
    cover: s.cover,
    duration: s.durMs || 0,
    progress: Number.isFinite(progress) ? progress : 0,
    playing,
    source: sourceName(s.app) || 'browser',
  };
}

/** Wahl je Modus. Spotify-App-Einträge der Windows-Liste werden ignoriert (kommen per API). */
export function pickTrack(mode: SourceMode, spotify: Track | null, list: MediaSession[]): Track | null {
  const others = list.filter((s) => !isSpotifyApp(s.app));
  const playingOther = others.find((s) => s.status === 'Playing');
  const lastOther = playingOther || [...others].sort((a, b) => b.at - a.at)[0];
  if (mode === 'spotify') return spotify;
  if (mode === 'other') return lastOther ? mediaToTrack(lastOther) : null;
  if (spotify?.playing) return spotify;
  if (playingOther) return mediaToTrack(playingOther);
  return spotify ?? (lastOther ? mediaToTrack(lastOther) : null);
}

// Cover-Ersatz: Windows liefert nicht immer ein Bild (z. B. pausierte Tabs).
// Dann über die Spotify-Suche (eigene Verbindung) das passende Album-Cover holen.
export let lastCoverError = '';
const coverCache = new Map<string, { cover: string; id: string; at: number }>();
const norm = (s: string) =>
  s
    .toLowerCase()
    .replace(/\(.*?\)|\[.*?\]/g, '')
    .replace(/feat\..*$/, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim();

/**
 * Song auf Spotify finden (eigene Verbindung): echtes Album-Cover und – bei
 * sicherem Treffer (Titel + Interpret passen) – die Spotify-ID. Mit der ID
 * gehen ♥ und „+“ auch für Songs aus YouTube Music, Amazon Music, Browser …
 */
export async function spotifyMatch(access: string | null, track: Track): Promise<Track> {
  if (!access || !track.title) return track;
  const key = norm(track.title) + '|' + norm(track.artist);
  const apply = (hit: { cover: string; id: string }) => ({
    ...track,
    cover: hit.cover || track.cover,
    ...(hit.id ? { id: hit.id, matched: true } : {}),
  });
  const hit = coverCache.get(key);
  if (hit && Date.now() - hit.at < 6 * 3600_000) return apply(hit);
  coverCache.set(key, { cover: '', id: '', at: Date.now() - 6 * 3600_000 + 120_000 }); // Sperre 2 min
  try {
    const plain = (x: string) => x.replace(/\(.*?\)|\[.*?\]/g, ' ').replace(/["'“”„]/g, '').replace(/\s+/g, ' ').trim();
    const q = plain(track.title) + (track.artist ? ' ' + plain(track.artist) : '');
    const r = await fetch('https://api.spotify.com/v1/search?type=track&limit=5&q=' + encodeURIComponent(q), {
      headers: { Authorization: 'Bearer ' + access },
      signal: AbortSignal.timeout(4000),
    });
    if (!r.ok) {
      lastCoverError = 'search ' + r.status;
      return track;
    }
    const d = (await r.json()) as {
      tracks?: { items?: { id?: string; name?: string; artists?: { name?: string }[]; album?: { images?: { url?: string }[] } }[] };
    };
    const items = d.tracks?.items || [];
    // Interpret vergleichen, tolerant für Schreibweisen wie „Hiroyuki SAWANO“ vs.
    // „SawanoHiroyuki[nZk]“: alle Wörter des einen kommen im anderen (ohne
    // Leerzeichen) vor.
    const compact = (x: string) => norm(x).replace(/\s+/g, '');
    const words = (x: string) => norm(x).split(' ').filter((w) => w.length > 1);
    const sameArtist = (a: string, b: string) => {
      if (!a || !b) return false;
      const ca = compact(a), cb = compact(b);
      if (ca.includes(cb) || cb.includes(ca)) return true;
      const wa = words(a), wb = words(b);
      return (wa.length > 0 && wa.every((w) => cb.includes(w))) || (wb.length > 0 && wb.every((w) => ca.includes(w)));
    };
    const artistOk = (x: { artists?: { name?: string }[] }) =>
      !!track.artist && (x.artists || []).some((a) => sameArtist(a.name || '', track.artist));
    const strict = items.find((x) => norm(x.name || '') === norm(track.title) && artistOk(x));
    const loose = strict || items.find((x) => norm(x.name || '') === norm(track.title));
    const found = { cover: loose?.album?.images?.[0]?.url || '', id: strict?.id || '' };
    coverCache.set(key, { ...found, at: found.cover ? Date.now() : Date.now() - 6 * 3600_000 + 600_000 });
    if (coverCache.size > 300) coverCache.delete(coverCache.keys().next().value as string);
    lastCoverError = found.cover ? '' : 'no-match ' + items.length;
    return apply(found);
  } catch {
    return track;
  }
}
