# F23: Windows-Medienwiedergabe (SMTC) dauerhaft auslesen – NUR LESEN.
# Gibt alle 1,5 s eine JSON-Zeile mit allen Wiedergaben aus (stdout).
# Cover nur beim ersten Auftauchen eines Songs als Base64 (Feld "cover").
# Gestartet von lib/media-session.mjs (Vite-Plugin), nie direkt nötig.
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, [Type]$type) { $t = $asTask.MakeGenericMethod($type).Invoke($null, @($op)); if ($t.Wait(4000)) { $t.Result } else { $null } }
$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.IContentTypeProvider, Windows.Storage.Streams, ContentType = WindowsRuntime]
$mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
if (-not $mgr) { Write-Output '{"error":"no-manager"}'; exit 1 }
$sent = @{}
while ($true) {
  $list = @()
  foreach ($s in $mgr.GetSessions()) {
    $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
    if (-not $p -or -not $p.Title) { continue }
    $tl = $s.GetTimelineProperties()
    $pb = $s.GetPlaybackInfo()
    $key = "$($s.SourceAppUserModelId)|$($p.Title)|$($p.Artist)"
    $item = [ordered]@{
      app = $s.SourceAppUserModelId
      title = $p.Title
      artist = $p.Artist
      album = $p.AlbumTitle
      status = "$($pb.PlaybackStatus)"
      posMs = [math]::Round($tl.Position.TotalMilliseconds)
      durMs = [math]::Round($tl.EndTime.TotalMilliseconds)
      at = $tl.LastUpdatedTime.ToUnixTimeMilliseconds()
      key = $key
    }
    if (-not $p.Thumbnail -and -not $sent.ContainsKey($key)) { $item.coverErr = 'no-thumbnail'; $sent[$key] = $true }
    if ($p.Thumbnail -and -not $sent.ContainsKey($key)) {
      # Cover über DataReader lesen (funktioniert in Windows PowerShell 5.1 zuverlässig).
      try {
        $st = Await ($p.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
        if (-not $st) { $item.coverErr = 'open-null' }
        else {
          # PowerShell 5.1 sieht WinRT-Objekte oft ohne Eigenschaften → über das Interface lesen.
          $ira = [Windows.Storage.Streams.IRandomAccessStream]
          $size = [uint64]$ira.GetProperty('Size').GetValue($st)
          if ($size -gt 0 -and $size -lt 1500000) {
            $input = $ira.GetMethod('GetInputStreamAt').Invoke($st, @([uint64]0))
            $reader = [Windows.Storage.Streams.DataReader]::new($input)
            $null = Await ($reader.LoadAsync([uint32]$size)) ([uint32])
            $bytes = New-Object byte[] ([int]$size)
            $reader.ReadBytes($bytes)
            $item.cover = [Convert]::ToBase64String($bytes)
            try { $item.coverType = [Windows.Storage.Streams.IContentTypeProvider].GetProperty('ContentType').GetValue($st) } catch { $item.coverType = 'image/png' }
            $reader.Dispose()
          } else { $item.coverErr = 'size-' + $size }
        }
        $sent[$key] = $true
      } catch {
        $item.coverErr = $_.Exception.Message
        $sent[$key] = $true
      }
      if ($sent.Count -gt 300) { $sent = @{} }
    }
    $list += [pscustomobject]$item
  }
  $json = ConvertTo-Json -InputObject @($list) -Depth 3 -Compress
  [Console]::Out.WriteLine('{"t":' + [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() + ',"sessions":' + $json + '}')
  [Console]::Out.Flush()
  Start-Sleep -Milliseconds 1500
}
