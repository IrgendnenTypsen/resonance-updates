import { sites } from '@openai/sites-vite-plugin';
import tailwindcss from '@tailwindcss/postcss';
import vinext from 'vinext';
import { defineConfig, type Plugin } from 'vite';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';

const SITE_CREATOR_PLACEHOLDER_DATABASE_ID =
  '00000000-0000-4000-8000-000000000000';

// hosting.json ist eine lokale OpenAI-Sites-Datei und fehlt in Tester-ZIPs.
// Fallback auf local-wrangler.json, damit der Build ohne sie startbar ist.
function loadHostingConfig() {
  try {
    if (existsSync('./.openai/hosting.json')) {
      return JSON.parse(readFileSync('./.openai/hosting.json', 'utf8'));
    }
  } catch {}
  // Fallback: local-wrangler.json
  try {
    if (existsSync('./local-wrangler.json')) {
      const w = JSON.parse(readFileSync('./local-wrangler.json', 'utf8'));
      const d1 = w.d1_databases?.[0]?.binding || null;
      return { d1, r2: null };
    }
  } catch {}
  return { d1: null, r2: null };
}

const hostingConfig = loadHostingConfig();
const { d1, r2 } = hostingConfig;

// Das @openai/sites-vite-plugin kopiert hosting.json in closeBundle
// bedingungslos nach dist/.openai/. Damit der Build auch ohne die Datei
// startbar ist, wird sie hier aus dem Fallback erzeugt (nicht-sekret).
if (!existsSync('./.openai/hosting.json')) {
  try {
    mkdirSync('./.openai', { recursive: true });
    writeFileSync(
      './.openai/hosting.json',
      JSON.stringify({ d1, r2: null }, null, 2) + '\n',
    );
  } catch {}
}

// macOS Seatbelt blocks FSEvents, so Codex previews need polling for HMR.
const isCodexSeatbeltSandbox = process.env.CODEX_SANDBOX === 'seatbelt';
const isStableLocalPreview = process.env.RESONANCE_LOCAL === '1';

// Entwicklermodus-Werkzeuge (nur `vite dev` im Entwickler-Workspace).
// Tester-Builds enthalten eine resonance-version.json im Projektroot – dort
// ist das Plugin aus. Endpunkte:
//   GET  /__resonance/dev/status         → { devMode, latest, newestSourceChange, stale }
//   POST /__resonance/dev/export-tester  → baut das Tester-ZIP frisch, liefert latest
function resonanceDevTools(): Plugin {
  const isTesterBuild = existsSync('./resonance-version.json');
  return {
    name: 'resonance-dev-tools',
    apply: 'serve',
    configureServer(server) {
      if (isTesterBuild) return;
      server.middlewares.use(async (req, res, next) => {
        const url = req.url || '';
        if (!url.startsWith('/__resonance/dev/')) return next();
        const host = (req.headers.host || '').split(':')[0];
        if (!['127.0.0.1', 'localhost', '[::1]'].includes(host)) {
          res.statusCode = 403;
          return res.end();
        }
        const send = (status: number, body: unknown) => {
          res.statusCode = status;
          res.setHeader('Content-Type', 'application/json');
          res.setHeader('Cache-Control', 'no-store');
          res.end(JSON.stringify(body));
        };
        try {
          const mod = await import('./scripts/export-tester.mjs');
          const readLatest = () => {
            try {
              return JSON.parse(
                readFileSync('./public/exports/latest.json', 'utf8'),
              ) as { file: string; createdAt: string; size: number };
            } catch {
              return null;
            }
          };
          if (url.startsWith('/__resonance/dev/status') && req.method === 'GET') {
            const latest = readLatest();
            const newest = mod.newestSourceChange();
            return send(200, {
              devMode: true,
              latest,
              newestSourceChange: newest ? new Date(newest).toISOString() : null,
              stale: !latest || Date.parse(latest.createdAt) < newest,
            });
          }
          if (
            url.startsWith('/__resonance/dev/export-tester') &&
            req.method === 'POST'
          ) {
            const latest = mod.buildTesterExport({ log: false });
            return send(200, { ok: true, latest });
          }
          return send(404, { error: 'Unbekannter Dev-Endpunkt.' });
        } catch (e) {
          return send(500, {
            error: e instanceof Error ? e.message : 'Export fehlgeschlagen.',
          });
        }
      });
    },
  };
}

// F23: Windows-Medienwiedergabe (YouTube Music, Amazon Music, Browser-Tabs …).
// Läuft in Entwickler- UND Tester-Installationen. Nur von localhost.
//   GET /__resonance/media/sessions    → { available, error, sessions: [...] }
//   GET /__resonance/media/cover/<id>  → Coverbild
function resonanceMediaSession(): Plugin {
  return {
    name: 'resonance-media-session',
    apply: 'serve',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const url = req.url || '';
        if (!url.startsWith('/__resonance/media/')) return next();
        const host = (req.headers.host || '').split(':')[0];
        if (!['127.0.0.1', 'localhost', '[::1]'].includes(host)) {
          res.statusCode = 403;
          return res.end();
        }
        try {
          const mod = await import('./lib/media-session.mjs');
          if (url.startsWith('/__resonance/media/sessions')) {
            res.setHeader('Content-Type', 'application/json');
            res.setHeader('Cache-Control', 'no-store');
            return res.end(JSON.stringify(mod.getMediaSessions()));
          }
          const m = /^\/__resonance\/media\/cover\/([0-9a-f]{16})/.exec(url);
          const cover = m ? mod.getMediaCover(m[1]) : null;
          if (!cover) {
            res.statusCode = 404;
            return res.end();
          }
          res.setHeader('Content-Type', cover.type);
          res.setHeader('Cache-Control', 'private, max-age=3600');
          return res.end(cover.buf);
        } catch {
          res.statusCode = 500;
          return res.end();
        }
      });
    },
  };
}

// League of Legends: Rang direkt aus dem laufenden League-Client (LCU).
// Läuft in Entwickler- UND Tester-Installationen (beide nutzen `vite dev`).
// Nur von localhost erreichbar; das Client-Passwort bleibt in Node.
//   GET /__resonance/lol/ranked?queue=solo|flex
//     → { status: 'ok'|'unranked'|'no-client', tier, division, lp, wins, losses, streak, ... }
function resonanceLolClient(): Plugin {
  return {
    name: 'resonance-lol-client',
    apply: 'serve',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const url = req.url || '';
        if (!url.startsWith('/__resonance/lol/')) return next();
        const host = (req.headers.host || '').split(':')[0];
        const send = (status: number, body: unknown) => {
          res.statusCode = status;
          res.setHeader('Content-Type', 'application/json');
          res.setHeader('Cache-Control', 'no-store');
          res.end(JSON.stringify(body));
        };
        if (!['127.0.0.1', 'localhost', '[::1]'].includes(host))
          return send(403, { error: 'Nur lokal.' });
        if (!url.startsWith('/__resonance/lol/ranked') || req.method !== 'GET')
          return send(404, { error: 'Unbekannter Endpunkt.' });
        try {
          const queue = new URL(url, 'http://x').searchParams.get('queue') || 'solo';
          const mod = await import('./lib/lol-client.mjs');
          return send(200, await mod.getRanked(queue));
        } catch {
          return send(200, { status: 'no-client', fetchedAt: Date.now() });
        }
      });
    },
  };
}

// VALORANT: Rang über die HenrikDev-API (Schlüssel bleibt lokal in Node).
//   GET  /__resonance/valo/settings → { configured, hasKey, name, tag, region, platform }
//   POST /__resonance/valo/settings → speichert (key '' = behalten, null = löschen) + Test
//   GET  /__resonance/valo/rank     → { status, tier, rr, lastChange, main, lastMatch, ... }
function resonanceValoClient(): Plugin {
  return {
    name: 'resonance-valo-client',
    apply: 'serve',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const url = req.url || '';
        if (!url.startsWith('/__resonance/valo/')) return next();
        const host = (req.headers.host || '').split(':')[0];
        const send = (status: number, body: unknown) => {
          res.statusCode = status;
          res.setHeader('Content-Type', 'application/json');
          res.setHeader('Cache-Control', 'no-store');
          res.end(JSON.stringify(body));
        };
        if (!['127.0.0.1', 'localhost', '[::1]'].includes(host))
          return send(403, { error: 'Nur lokal.' });
        try {
          const mod = await import('./lib/valo-client.mjs');
          if (url.startsWith('/__resonance/valo/rank') && req.method === 'GET')
            return send(200, await mod.getRank());
          if (url.startsWith('/__resonance/valo/settings')) {
            if (req.method === 'GET') return send(200, mod.publicSettings());
            if (req.method === 'POST') {
              let raw = '';
              for await (const chunk of req) {
                raw += chunk;
                if (raw.length > 4096) return send(413, { error: 'Zu groß.' });
              }
              let body: Record<string, unknown> = {};
              try {
                body = JSON.parse(raw || '{}');
              } catch {
                return send(400, { error: 'Ungültige Daten.' });
              }
              try {
                const settings = mod.saveSettings(body);
                const result = settings.configured ? await mod.getRank(true) : null;
                return send(200, { settings, result });
              } catch (e) {
                return send(400, {
                  error: e instanceof Error ? e.message : 'Ungültige Daten.',
                });
              }
            }
          }
          return send(404, { error: 'Unbekannter Endpunkt.' });
        } catch {
          return send(200, { status: 'error', reason: 'http' });
        }
      });
    },
  };
}

const localBindingConfig = {
  main: 'vinext/server/fetch-handler',
  compatibility_flags: ['nodejs_compat'],
  d1_databases: d1
    ? [
        {
          binding: d1,
          database_name: 'site-creator-d1',
          database_id: SITE_CREATOR_PLACEHOLDER_DATABASE_ID,
        },
      ]
    : [],
  r2_buckets: r2
    ? [
        {
          binding: r2,
          bucket_name: 'site-creator-r2',
        },
      ]
    : [],
};

export default defineConfig(async () => {
  // Keep Wrangler and Miniflare state project-local. These are non-secret tool
  // settings; application environment belongs in ignored `.env*` files.
  process.env.WRANGLER_WRITE_LOGS ??= 'false';
  process.env.WRANGLER_LOG_PATH ??= '.wrangler/logs';
  process.env.MINIFLARE_REGISTRY_PATH ??= '.wrangler/registry';

  // Wrangler snapshots its log path while the Cloudflare plugin is imported.
  const { cloudflare } = await import('@cloudflare/vite-plugin');

  return {
    resolve: { dedupe: ['react', 'react-dom'] },
    optimizeDeps: {
      include: [
        'react',
        'react-dom/client',
        '@base-ui/react/select',
        '@base-ui/react/dialog',
        '@base-ui/react/slider',
        '@base-ui/react/switch',
        '@base-ui/react/tabs',
        '@base-ui/react/button',
      ],
    },
    css: { postcss: { plugins: [tailwindcss()] } },
    server: {
      ...(isCodexSeatbeltSandbox
        ? { watch: { useFsEvents: false, usePolling: true } }
        : {}),
      ...(isStableLocalPreview ? { hmr: false } : {}),
    },
    plugins: [
      resonanceDevTools(),
      resonanceLolClient(),
      resonanceValoClient(),
      resonanceMediaSession(),
      vinext(),
      sites(),
      cloudflare({
        viteEnvironment: { name: 'rsc', childEnvironments: ['ssr'] },
        config: localBindingConfig,
      }),
    ],
  };
});
